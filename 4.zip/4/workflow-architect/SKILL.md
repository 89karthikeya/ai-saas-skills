---
name: workflow-architect
description: >-
  Discover your actual workflow through conversation or observation, then generate a
  tailored skills bundle that encodes it as loadable agent skills with trigger conditions.
  Use when you want to understand your own process, formalize it, or share it with
  collaborators. Also use when a session feels aimless — this skill gives it structure. Do
  not use this skill for unrelated requests; route to the nearest named specialist.
license: MIT
compatibility: Hermes Agent — uses skill_view(), memory tool, session context scanning,
  and write_file for bundle generation. Output bundles are standard Agent Skills.
metadata:
  tags: workflow, meta, productivity, skills-bundle, onboarding, process
  spec-version: '1.0'
---

# Workflow Architect

A meta-skill that helps you (and your agent) understand how you actually work. It
discovers your workflow patterns through either active interrogation or passive
observation, then generates a **skills bundle** — a set of loadable skills, each
with trigger conditions, that encode your workflow so your agent can meet you
where you are in every session.

## What You Get

After running workflow-architect, you'll have a new bundle in your agent's skill
directory containing:

- **Umbrella SKILL.md** — the entry point that makes the bundle auto-detectable
  via trigger conditions in its description. Load it with `skill_view(name='<bundle-name>')`
  or let the agent discover it automatically when you say something matching its triggers.
- **Sub-skills** — one per phase of your workflow, each with a `description`
  that tells the agent when to load it (e.g., "load this when the user starts
  their morning triage routine" or "use this when the user shifts into deep work
  mode")
- **A manifest** — maps skill names to their trigger conditions, entry points,
  and transition signals
- **A decision map** — Mermaid flowchart visualizing your workflow as the agent
  sees it
- **A kanban board** (optional) — only included if your workflow follows a
  predictable linear path where WIP limits and lane transitions add value

The umbrella and sub-skills are registered via `skill_manage(action='create')`
so they appear in `skills_list()` and are immediately loadable in future sessions.

## Two Modes

Workflow-architect adapts to how you want to engage with it.

### Mode 1: Active Interrogation (One-Shot)

**When to use:** You have a few minutes to talk through your process. This is
the most thorough mode — the agent asks guided questions, branches based on your
answers, and builds a model of your workflow turn by turn.

**How to invoke:**
```
/workflow-architect
```

The agent will guide you through a conversation of about 8-15 questions.
Answer naturally — the skill adapts its probes based on what you say.

### Mode 2: Passive Observation

**When to use:** You're already in a session doing real work and don't want to
stop and reflect. Let this mode watch what you actually do, then infer the
workflow pattern from your actions.

**How to invoke:**
```
/workflow-architect passive
```

The agent loads the observer skill silently. It does nothing until you say one
of the trigger phrases below, at which point it scans the current session's
message history and reconstructs your workflow from what happened.

**Trigger phrases (say any of these to activate observation analysis):**
- "catalog my workflow"
- "what's my workflow"
- "analyze my process"
- "figure out what I do"
- "work it out from what I just did"

> **Limitation:** Observation mode works best after a session with at least
> 20+ turns of substantive work. If the session context is too thin, the
> observer will suggest switching to active interrogation mode instead.

## Loading Protocol

1. Read this umbrella SKILL.md for context
2. If active: load `skills/interviewer/SKILL.md`
3. If passive: load `skills/observer/SKILL.md`
4. After convergence: load `skills/bundle-builder/SKILL.md` to synthesize
   and write the output bundle. The bundle is written to
   `~/.hermes/skills/<category>/<bundle-name>/` — verify the umbrella loads
   with `skill_view(name='<bundle-name>')` and at least one sub-skill loads
   with `skill_view(name='<bundle-name>-<phase-name>')`. Tell the user where
   it landed, what skills it contains, and a trigger phrase they can use to
   enter the workflow.

## What the Interview Builds

The interviewer (and observer, through inference) builds a structured model
with these dimensions:

| Dimension | What it captures |
|-----------|------------------|
| **Entry points** | How your sessions typically start |
| **Phases** | The distinct modes or stages in your workflow |
| **Branching signals** | What makes you go left vs right at each fork |
| **Tool preferences** | What you reach for in each phase |
| **Loop conditions** | What keeps you in a mode vs what kicks you out |
| **Exit criteria** | How you know a session is done |
| **Pain points** | What feels frictionful or inefficient |

## Environment

No environment variables required. State is stored via memory tool
with the prefix `workflow-architect:state:` so it persists across turns
during multi-turn interviews.

## When not to use

Do not use this skill for one-off task help or when there is no repeatable multi-phase workflow worth capturing — a standalone skill is a better fit. If you already have a well-defined process and only need it packaged, generate the bundle directly rather than re-running an interview.

## Prerequisites

This skill ships no scripts; it is a resource-based protocol carried by the files bundled with this SKILL.md:

- **Sub-skill protocols** — `skills/interviewer/SKILL.md` (active interrogation), `skills/observer/SKILL.md` (passive observation), and `skills/bundle-builder/SKILL.md` (bundle synthesis and registration). Load them per the Loading Protocol above.
- **Reference patterns** — `references/workflow-archetypes.md` (convergence-detection pattern library), `references/trigger-condition-patterns.md` (trigger-condition format spec), `references/kanban-decision-criteria.md` (when to include a kanban board), and `references/example-output/` (worked example bundles: `developer-triage`, `developer-pipeline-kanban`).
- **Generation templates** — `templates/skill-skeleton.md`, `templates/manifest.yaml.tmpl`, `templates/decision-map.md.tmpl`, `templates/kanban-board-setup.sh.tmpl`, and `templates/kanban-task-blueprints.yaml.tmpl` for the generated bundle's files.
- **Agent capabilities** — the host agent needs skill management tools (`skill_view`, `skill_manage`, `skills_list`), a memory tool for `workflow-architect:state:` keys, session context access for observation mode, and file writing for bundle output.
- **A writable skills directory** — generated bundles land in `~/.hermes/skills/<category>/<bundle-name>/`; that location must be creatable and registrable.

## Limitations

- The output targets the Hermes-style skill runtime named in `compatibility`: bundles are standard Agent Skills, but registration via `skill_manage(action='create')` and the `~/.hermes/skills` path assume that environment. On other runtimes, copy the bundle manually into the client's skill directory.
- Passive observation reconstructs only what happened in the current session; with fewer than roughly 20 substantive turns it will under-infer and should fall back to active interrogation.
- The generated workflow is only as good as what you say or do during discovery — phases, branching signals, and exit criteria are inferred from evidence, not invented, so thin input yields generic bundles.
- Bundle generation writes new skill files and registers them; confirm scope before overwriting an existing bundle of the same name.
