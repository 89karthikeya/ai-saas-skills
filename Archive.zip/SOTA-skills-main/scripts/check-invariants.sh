#!/usr/bin/env bash
#
# Enforce SOTA-skills repository invariants. Run by pre-commit and CI.
# Exits non-zero (and prints offenders) if any invariant is violated.
#
# Invariants:
#   1. Every tracked SKILL file (skills/*/*.md, skills/*/rules/*.md) is <= 500
#      lines, so skills load incrementally. ONLY INSTRUCTION FILES ARE CAPPED:
#      a file is capped iff an agent loads it as instructions. Everything else
#      (README, CHANGELOG, docs/, evals/, scripts) is deliberately uncapped.
#   2. Every skills/*/rules/*.md ends with an "## Audit checklist".
#   3. No internal/private references leak in (the library stays generic).
#   4. Every skills/*/SKILL.md description is <= 1024 characters (Agent Skills
#      spec: loaders skip a skill whose description exceeds the cap) and is
#      not YAML-invalid (unquoted ': ' inline — strict loaders reject it).
#   5. Version lockstep: VERSION == plugin.json "version"; CHANGELOG's top
#      entry is [Unreleased] or [VERSION]; the newest v* tag is never ahead
#      of VERSION (VERSION may lead during a release PR).
#   6. Count-bearing surfaces match the tree: README badge/hero/social-alt,
#      the router's "N domain skills", plugin.json + marketplace.json
#      descriptions, and the social-preview pill.
#   7. Router completeness: every skill appears in the router's routing table
#      AND its library map (skills/sota/SKILL.md), and every map entry names a
#      real skill (catches the map-drift the 2026-07-10 audit found).
#   8. Internal links resolve: every relative Markdown link to a *.md target
#      (in any tracked *.md) points at a file that exists — catches doc/README/
#      INDEX/CHANGELOG link rot when a file is moved or renamed. Scope is *.md
#      targets only: non-.md relative links overlap prose/code fragments that
#      match the [text](x) shape (e.g. type annotations) and false-positive.
#      (Idea adopted from the training-knowledge-vault vault-doctor, 2026-07-24;
#      see docs/ADOPTION-LOG.md.)
#   9. CHANGELOG has at most one "## [Unreleased]" heading, it is the topmost
#      entry, and the archives have none. Check 5 only compares the TOP entry
#      to VERSION, so a second [Unreleased] lower down passed CI silently — on
#      2026-07-28 two feature PRs each added one above [1.19.3] and main
#      carried both until the release cut noticed by hand.
#  10. Every skills/*/rules/*.md is referenced by its own SKILL.md. The model
#      reads only the rules files the SKILL.md index points at, so an unindexed
#      rules file is never loaded — written, capped, checklist-ed, unreachable.
#      Skill-level twin of check 7 (a skill missing from the router).
#  11. LAST-VERIFIED only moves alongside a sweep. The stamp records the last
#      FULL re-verification pass, not the newest verified fact, so bumping it on
#      an ordinary edit asserts a sweep that never happened. Escapes: a
#      sweep-shaped diff (>= 20 skill files; the real 2026-07-08 sweep touched
#      100), or naming LAST-VERIFIED in the CHANGELOG, which is how a rolling
#      pass declares completion. DIFF-based — skips with a note if there is no
#      merge base, like checks 4 and 8 skip without python3.
#  12. Every assets/*.png is no older than the assets/*.html it renders. The PNGs
#      are committed build outputs and nothing regenerates them, so an un-rendered
#      HTML fix is invisible: the README embeds the image, never the source. PR
#      #173 fixed a stale line-cap claim in how-it-works.html and left the PNG at
#      its 2026-07-09 render, so main served the old claim all day while the diff
#      read as done. HISTORY-based (commit times, not mtimes — a fresh clone
#      stamps every file identically); escape is "[no-render]" in the HTML's own
#      commit subject.
#  13. Every scoreboard row in evals/results/RESULTS.md declares its sample size.
#      A lift from one run is typographically identical to a lift from ten, and
#      this repo has been burned twice: a +0.07 retracted when the set grew 15 ->
#      49, and a +0.40 corrected to +0.39 by a second run. A REGRESSION GUARD like
#      check 10 — all 10 rows pass today. Shape-driven (finds the table by its
#      "Samples" header), so a renamed or dropped column fails closed instead of
#      passing over zero rows.
#  14. A release declares its front-door terms, and they resolve. Invariant 6 fails
#      on a wrong NUMBER in the README; nothing failed on a CAPABILITY that never
#      got a sentence anywhere a reader looks -- five shipped across v1.17.0-v1.19.7
#      with zero README hits. Discovery ("what counts as a capability") is judgement
#      and cannot be gated; DECLARATION can, so a release must carry
#      "**Front door checked:** a · b" in its CHANGELOG section, and every term must
#      resolve in README.md or docs/INDEX.md AND appear in that release's own entry.
#      DIFF-based, release commits only — silent on an ordinary PR.
#  15. The router's library map lists every rules FILE, both directions. Check 7
#      proves each SKILL appears in the map; check 10 proves each rules file is
#      indexed by its OWN SKILL.md. Neither looks at the map's CONTENTS, so
#      sota-code-security/rules/11 sat unlisted in skills/sota/SKILL.md for two
#      releases (v1.19.8 → v1.21.0) with every check green. Compares the NN numbers
#      the map enumerates per skill against skills/<skill>/rules/NN-*.md, and
#      reports BOTH a file missing from the map and a map entry naming a file that
#      does not exist. Needs python3 (map entries wrap across lines); skipped with
#      a note if absent, like checks 4 and 8.
#  16. The hook README documents == the hook install.sh writes. install.sh WRITES
#      the UserPromptSubmit hook and README DOCUMENTS it; nothing kept them equal.
#      On 2026-08-05 three texts existed at once — the README block (two revisions
#      behind), HOOK_CMD, and what was in a real settings.json — and the README's
#      is the one a reader copies by hand, so the stale one is the one that
#      spreads. Parses the fenced JSON rather than regexing the string, so
#      reformatting the block is not a false positive. Needs python3; skipped with
#      a note if absent, like checks 4, 8 and 15.
#
# ADDING A CHECK? Three things this file learned the hard way — all from real
# incidents recorded in the checks below:
#   - WATCH IT FAIL FIRST. Break the input deliberately, confirm the abort, restore.
#     Invariant 9's first cut printed its heading and nothing else: a `grep -m 1` on
#     a PIPE SIGPIPE'd the upstream printf, and `pipefail` + `set -e` killed the
#     script mid-check. It looked like it passed. Never `grep -m 1`/`head` on a pipe
#     in here.
#   - PRINT YOUR DENOMINATOR, and fail on an empty scope — use scope(). Checks 2 and
#     10 printed "ok" over ZERO files until 2026-07-30, and check 6's tree recount
#     did not catch it.
#   - SKIP, DON'T GUESS. If a prerequisite is missing (python3, a merge base), say so
#     and skip. A check that assumes it passed is worse than one that isn't there.
#
# Portable to macOS bash 3.2 (no mapfile/associative arrays). Checks 4 and 8 need
# python3 (Unicode char counting; link parsing); they are skipped with a warning
# if python3 is absent locally (CI runs on a runner that always has it).
# Check 5's tag comparison is skipped with a note when no v* tags are visible
# (e.g. a shallow CI checkout without tags).
set -euo pipefail

cd "$(git rev-parse --show-toplevel)"

# Wall time for the whole run, reported at the end next to the denominators.
# rules/11 §2.1: a gate that reports "nothing wrong" far faster than its claimed
# work allows did not do the work — but that tell is unavailable unless someone
# records the duration. Printed, never gated: a duration threshold in CI is flaky
# under runner variance, and a flaky gate gets disabled, which is how a control
# becomes inert. Whole seconds only ($SECONDS), because sub-second timing is not
# portable to the macOS bash 3.2 this script still supports.
START_SECONDS=$SECONDS

MAX_LINES=500
MAX_DESC=1024
MAX_AGENTS=200          # AGENTS.md loads every session; check 24. A CAP, not a target.
MAX_UNDOC=21            # check 25's ratchet: undocumented eval (file, flag) pairs.
                        # 27 -> 21 on 2026-09-09: documenting `--judge-model` for
                        # run-conflict-rate.py documented it for the three runners
                        # that already carried it, and the SLACK direction fails too.
fail=0
# --- --self-test: the suite, then the harness that watches it fail ----------
# `sota-code-security` rules/12 §1b: the negative control belongs INSIDE the tool.
# The structural half of that ("no check lacks a known-bad") is no longer gated
# behind this flag — it is **invariant 19**, and runs on every ordinary
# invocation, because it costs ~50 ms and a check you must remember to run is a
# convention, not a property. What remains behind the flag is the expensive half:
# the harness, which actually mutates the tree and watches each check go red.
if [ "${1:-}" = "--self-test" ]; then
  harness="$(dirname "$0")/check-negative-controls.sh"
  [ -r "$harness" ] || { echo "FAIL: cannot read $harness"; exit 1; }
  "$0" || exit 1                     # invariant 19 is in here
  echo
  echo "[self-test] structure verified above (invariant 19); now watching each check fail"
  exec "$harness"
fi

note() { printf '    %s\n' "$1"; }

# Every file-list-driven check reports HOW MANY items it examined, and fails on
# an empty scope. "0 checked, 0 failed, exit 0" is the signature of a gate whose
# pathspec drifted — the gate reads as green while verifying nothing. Found here
# by mutation on 2026-07-30: renaming the rules/ pathspec made checks 2 and 10
# print "ok" over zero files, and check 6's tree recount did NOT catch it because
# the SKILL.md count was unchanged. See sota-code-security rules/11 §2.
# Returns 1 on an empty scope so callers can set fail=1.
scope() {  # <count> <noun> — returns 1 on an empty scope; prints nothing on success
  if [ "$1" -eq 0 ]; then
    note "SCOPE EMPTY: examined 0 $2 — pathspec drift? a gate that checks nothing passes silently"
    return 1
  fi
  return 0
}

# --- 1. Line budget -------------------------------------------------------
# ONLY INSTRUCTION FILES ARE CAPPED. A file is capped iff an agent loads it as
# instructions -- skills/*/SKILL.md and skills/*/rules/*.md, nothing else. The cap
# is load-bearing only there: a rules/SKILL file over ~500 lines defeats
# incremental loading (the whole point is that the model reads the rules matching
# the task, not a wall of text). Everything else in this repo -- README,
# CHANGELOG, docs/, evals/, AGENTS.md, these scripts -- is prose or code read by
# people, deliberately uncapped since 2026-07-15; navigability there comes from a
# table of contents and docs/INDEX.md, not a line ceiling.
echo "[1/34] Skill Markdown (skills/**) <= ${MAX_LINES} lines"
over=0
seen1=0
while IFS= read -r f; do
  [ -f "$f" ] || { note "SKIPPED (tracked but missing from worktree): $f"; continue; }
  seen1=$((seen1 + 1))
  # awk NR, not `wc -l`: counts a final line without trailing newline too.
  n=$(awk 'END{print NR}' "$f")
  if [ "$n" -gt "$MAX_LINES" ]; then
    note "OVER ${MAX_LINES} (${n} lines): $f"
    over=1
  fi
done < <(git ls-files 'skills/*/*.md' 'skills/*/rules/*.md')
scope "$seen1" "skill files" || over=1
if [ "$over" -eq 0 ]; then echo "    ok ($seen1 skill files)"; else fail=1; fi

# --- 2. Audit checklist ends every rules file, exactly once -----------------
#
# SECOND HALF added 2026-09-09: EXACTLY ONE. The "last heading" test below passes
# happily on a file with TWO '## Audit checklist' sections, and five files had
# exactly that -- `sota-code-security` rules/13, `sota-detection-engineering`
# rules/01, `sota-devsecops` rules/07, `sota-testing` rules/04 and rules/07 --
# carrying six stranded bullets between them. Same authoring slip in all five:
# whoever appended a section added its checklist bullets under a FRESH heading
# instead of into the existing one.
#
# It is the same defect class as invariant 22 (a checklist bullet stranded inside
# a code fence): the bullets exist, render, and sit where nobody reads them,
# because the file appears to have already ended. Nothing about the line count or
# the last-heading test changes, which is why it survived five times.
echo "[2/34] Every skills/*/rules/*.md ends with exactly one '## Audit checklist'"
missing=0
seen2=0
while IFS= read -r f; do
  [ -f "$f" ] || { note "SKIPPED (tracked but missing from worktree): $f"; continue; }
  seen2=$((seen2 + 1))
  # The checklist must be the file's LAST '## ' heading (docs say "ends
  # with"). Track code-fence state so a '## Audit checklist' INSIDE a fence
  # doesn't satisfy the check (the 2026-07-01 fix missed this; 2026-07-10
  # audit reproduced the bypass). A trailing suffix is still allowed — four
  # files use '## Audit checklist (meta — …)' legitimately.
  last_h2=$(awk '/^(```|~~~)/{fence=!fence} !fence && /^## /{h=$0} END{print h}' "$f")
  case "$last_h2" in
    '## Audit checklist'*) ;;
    *) note "MISSING/NOT-LAST '## Audit checklist': $f"; missing=1 ;;
  esac
  # Fence-aware too: a second heading inside a fence is sample output, not a
  # section, and must not be counted against the file.
  n_ck=$(awk '/^(```|~~~)/{fence=!fence} !fence && /^## Audit checklist/{n++} END{print n+0}' "$f")
  if [ "$n_ck" -gt 1 ]; then
    note "DUPLICATE '## Audit checklist' ($n_ck) in $f — the earlier block's bullets"
    note "  render where a reader has already stopped. Merge them into the last one."
    missing=1
  fi
done < <(git ls-files 'skills/*/rules/*.md')
scope "$seen2" "rules files" || missing=1
if [ "$missing" -eq 0 ]; then echo "    ok ($seen2 rules files, one checklist each)"; else fail=1; fi

# --- 3. No internal/private references -------------------------------------
# Keep the library generic and shareable. Two pattern sets:
#   - generic reader-assumption phrases, tracked right here;
#   - a PRIVATE denylist of pre-publication internal names, deliberately NOT
#     tracked: a tracked list would disclose the very names it suppresses.
#     (The pre-July-2026 list remains in public git history — accepted risk,
#     decided 2026-07-01; see docs/AUDIT-2026-07-01.md finding S1.)
# Private patterns load from $SOTA_DENYLIST (CI: repository secret) or
# .denylist.local (git-ignored, one ERE per line, '#' comments). When neither
# exists (e.g. an external fork's PR), only the generic phrases are checked —
# the maintainer's pre-commit hook and this repo's CI carry the full list.
echo "[3/34] No internal-name leaks"
DENY='the user runs|the user operates'
if [ -n "${SOTA_DENYLIST:-}" ]; then
  DENY="$DENY|$SOTA_DENYLIST"
elif [ -f .denylist.local ]; then
  extra=$(grep -vE '^[[:space:]]*(#|$)' .denylist.local | paste -sd'|' - || true)
  if [ -n "$extra" ]; then
    DENY="$DENY|$extra"
  else
    # An all-comment or unreadable .denylist.local silently degraded this check to the
    # two generic phrases, with output byte-identical to a full scan (found 2026-08-16).
    note "(private denylist present but empty/unparseable — generic checks only)"
  fi
else
  note "(private denylist unavailable — generic checks only)"
fi
# Case-insensitive so casing variants can't slip past; errors are fatal, not
# swallowed (a scan that can't read a file must not pass). This script holds
# the generic phrase patterns, so it is excluded from its own scan.
set +e
hits=$(git grep -iInE "$DENY" -- ':(exclude)scripts/check-invariants.sh')
rc=$?
name_hits=$(git ls-files | grep -iE "$DENY")
nrc=$?
set -e
if [ "$rc" -gt 1 ] || [ "$nrc" -gt 1 ]; then
  note "ERROR: denylist scan failed (grep exit content=$rc names=$nrc)"
  fail=1
elif [ -n "$hits" ] || [ -n "$name_hits" ]; then
  note "Internal reference(s) found — keep the library generic:"
  { printf '%s\n' "$hits"; printf '%s\n' "$name_hits" | sed 's/$/ (file name)/'; } \
    | sed '/^ *(file name)$/d; s/^/      /'
  fail=1
else
  echo "    ok"
fi

# --- 4. Skill description length <= 1024 chars ----------------------------
# The Agent Skills spec caps `description` at 1024 characters; loaders (Claude
# Code, Codex, ...) skip any skill that exceeds it. Count Unicode characters
# (descriptions use em-dashes: 1 char, 3 bytes) via python3, parsing both
# folded block scalars (`>-`) and plain single-line descriptions.
echo "[4/34] Every skills/*/SKILL.md description <= ${MAX_DESC} characters"
if command -v python3 >/dev/null 2>&1; then
  if desc_out=$(python3 - "$MAX_DESC" <<'PY'
import sys, glob, re
cap = int(sys.argv[1])
bad = 0
def get_desc(text):
    """Return (description, yaml_error_or_None)."""
    m = re.match(r'---\n(.*?)\n---', text, re.S)
    if not m:
        return None, None
    lines = m.group(1).split('\n')
    for i, ln in enumerate(lines):
        if ln.startswith('description:'):
            rest = ln[len('description:'):].strip()
            if rest[:1] in ('>', '|'):           # block scalar
                buf = []
                for cont in lines[i + 1:]:
                    if cont.strip() and not cont[:1].isspace():
                        break                    # next top-level key ends it
                    buf.append(cont.strip())
                return ' '.join(x for x in buf if x), None
            # Plain (unquoted) inline scalar: ': ' inside it, or a trailing
            # ':', is invalid YAML — strict loaders reject the frontmatter
            # and silently skip the skill. Quoted scalars are fine.
            err = None
            if rest[:1] not in ('"', "'") and (': ' in rest or rest.endswith(':')):
                err = "unquoted ':' in inline description (invalid YAML — use 'description: >-')"
            return rest.strip('\'"'), err        # plain / quoted single line
    return None, None
def get_name(text):
    m = re.match(r'---\n(.*?)\n---', text, re.S)
    if not m:
        return None
    n = re.search(r'^name:\s*(.+)$', m.group(1), re.M)
    return n.group(1).strip().strip('\'"') if n else None

# Anthropic's Agent Skills reference states two constraints the agentskills.io
# spec page does not: `name` and `description` "Cannot contain XML tags", and
# `name` "Cannot contain reserved words: anthropic, claude". Found 2026-08-02 by
# re-verifying an ABSENCE claim ("there is no size cap") against a SECOND
# independent source, exactly as skills/sota/rules/01 sections 5 and 7 require --
# and the second source is the only one that carries these. sota-dotnet's
# description held `Span<T>/Memory<T>`, which is a well-formed XML start tag.
XML_TAG = re.compile(r'<[A-Za-z/][^>]*>')
RESERVED = ('anthropic', 'claude')
files4 = sorted(glob.glob('skills/*/SKILL.md'))
print("SCOPE %d" % len(files4))
for f in files4:
    d, err = get_desc(open(f, encoding='utf-8').read())
    if not d:
        print(f"MISSING/EMPTY description: {f}"); bad = 1; continue
    if err:
        print(f"{err}: {f}"); bad = 1
    if len(d) > cap:
        print(f"OVER {cap} ({len(d)} chars): {f}"); bad = 1
    hits = XML_TAG.findall(d)
    if hits:
        print(f"XML TAG in description {hits[:3]} (spec: descriptions cannot contain XML tags): {f}")
        bad = 1
    n = get_name(open(f, encoding='utf-8').read())
    if n:
        if XML_TAG.search(n):
            print(f"XML TAG in name: {f}"); bad = 1
        for w in RESERVED:
            if w in n.lower():
                print(f"RESERVED WORD '{w}' in name '{n}': {f}"); bad = 1
sys.exit(1 if bad else 0)
PY
  ); then
    # Denominator, per this file's own rule at the top: a drifted glob that
    # examines 0 files used to print "ok" and exit 0 here (found 2026-08-16).
    n4=$(printf '%s\n' "$desc_out" | sed -n 's/^SCOPE //p')
    if scope "${n4:-0}" "SKILL.md descriptions"; then
      echo "    ok (${n4} descriptions)"
    else
      fail=1
    fi
  else
    printf '%s\n' "$desc_out" | grep -v '^SCOPE ' | sed 's/^/    /'
    fail=1
  fi
else
  note "SKIPPED: python3 not found (CI enforces this check)"
fi

# --- 5. Version lockstep ----------------------------------------------------
# One version, four places: VERSION, plugin.json, the CHANGELOG's top entry,
# and (after the release lands) the newest v* tag. Drift here shipped a main
# briefly claiming 1.8.0 with 1.9.0 content (2026-07-03) — hence a hard check.
echo "[5/34] Version lockstep (VERSION == plugin.json == CHANGELOG top; tag not ahead)"
v5=0
ver=$(tr -d '[:space:]' < VERSION)
# Strict X.Y.Z: rejects interior malformations (1..2, 1.2, 1.2.3.4) the old
# character-class guard missed (2026-07-10 audit).
if ! printf '%s' "$ver" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+$'; then
  note "VERSION is not a plain X.Y.Z semver: '$ver'"; v5=1
fi
pj=$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' .claude-plugin/plugin.json | head -n 1)
[ "$pj" = "$ver" ] || { note "plugin.json version '$pj' != VERSION '$ver'"; v5=1; }
top=$(grep -m 1 -E '^## \[' CHANGELOG.md | sed 's/^## \[\([^]]*\)\].*/\1/')
case "$top" in
  Unreleased|"$ver") ;;
  *) note "CHANGELOG top entry is [$top] — expected [Unreleased] or [$ver]"; v5=1 ;;
esac
# Newest v* tag by semver sort. VERSION may lead the tag (open release PR);
# a tag ahead of VERSION means VERSION was never bumped — fail.
tag=$(git tag --list 'v[0-9]*' | sed 's/^v//' | sort -t. -k1,1n -k2,2n -k3,3n | tail -n 1)
if [ -z "$tag" ]; then
  note "(no v* tags visible — tag check skipped; needs a full-depth checkout)"
else
  newest=$(printf '%s\n%s\n' "$tag" "$ver" | sort -t. -k1,1n -k2,2n -k3,3n | tail -n 1)
  if [ "$tag" != "$ver" ] && [ "$newest" = "$tag" ]; then
    note "newest tag v$tag is AHEAD of VERSION $ver — bump VERSION + plugin.json"
    v5=1
  fi
fi
if [ "$v5" -eq 0 ]; then echo "    ok"; else fail=1; fi

# --- 6. Count-bearing surfaces match the tree --------------------------------
# The drift class the 2026-07-01 audit kept finding: skill/file/line counts
# rot on surfaces nobody recounts (the social preview said "30 skills" for
# three releases). Recount from the tree and compare every tracked surface;
# RELEASING.md lists the same surfaces for manual release edits.
echo "[6/34] Count-bearing surfaces match the tree"
v6=0
ck() { # ck <found> <expected> <surface>
  [ "$1" = "$2" ] || { note "$3: says '${1:-<not found>}', tree says '$2'"; v6=1; }
}
ck_floor() { # ck_floor <found-floor> <actual> <surface> — "N+" surfaces (the
  # social-preview image and its alt say "40+" so the PNG needn't be
  # re-rendered/re-uploaded every release): pass while actual >= floor.
  case "$1" in
    ''|*[!0-9]*) note "$3: no 'N+' floor found (expected e.g. '40+')"; v6=1; return ;;
  esac
  [ "$2" -ge "$1" ] || { note "$3: floor '$1+' is ahead of tree count '$2'"; v6=1; }
}
n_skills=$(git ls-files 'skills/*/SKILL.md' | wc -l | tr -d ' ')
n_files=$(git ls-files 'skills/' | grep -c '\.md$' || true)
n_lines=$(git ls-files 'skills/' | grep '\.md$' | tr '\n' '\0' | xargs -0 cat | awk 'END{print NR}')
n_klines=$(awk -v l="$n_lines" 'BEGIN{printf "%d", (l + 500) / 1000}')
n_domains=$((n_skills - 1))   # every skill except the router

ck "$(sed -n 's/.*badge\/skills-\([0-9]*\)-.*/\1/p' README.md | head -n 1)" \
   "$n_skills" "README badge"
# The badge's ALT text as well as its number. They drifted apart on 2026-09-07: the
# shields URL read 42 while `alt="41 skills"` sat beside it, because a count bump had
# updated the machine-readable half and not the human-readable one. The alt is what a
# screen reader announces and what survives when the image 404s, so a stale alt is the
# half a person actually receives.
ck "$(sed -n 's/.*badge\/skills-[0-9]*-[^>]*alt="\([0-9]*\) skills".*/\1/p' README.md | head -n 1)" \
   "$n_skills" "README badge alt text"
hero=$(grep -m 1 -E '[0-9]+ skills \([0-9]+ files, ~[0-9]+k lines\)' README.md || true)
ck "$(printf '%s' "$hero" | grep -oE '[0-9]+ skills \(' | grep -oE '[0-9]+' || true)" \
   "$n_skills" "README hero skill count"
ck "$(printf '%s' "$hero" | grep -oE '\([0-9]+ files' | grep -oE '[0-9]+' || true)" \
   "$n_files" "README hero file count"
ck "$(printf '%s' "$hero" | grep -oE '~[0-9]+k lines' | grep -oE '[0-9]+' || true)" \
   "$n_klines" "README hero ~k-lines"
ck_floor "$(sed -n 's/.*alt="SOTA Engineering Skills — \([0-9]*\)+ .*/\1/p' README.md | head -n 1)" \
   "$n_skills" "README social-preview alt (N+)"
ck "$(sed -n 's/^A library of \([0-9]*\) domain skills.*/\1/p' skills/sota/SKILL.md | head -n 1)" \
   "$n_domains" "router body (skills/sota/SKILL.md)"
for j in .claude-plugin/plugin.json .claude-plugin/marketplace.json; do
  ck "$(sed -n 's/.*(\([0-9]*\) skills).*/\1/p' "$j" | head -n 1)" "$n_skills" "$j skill count"
  ck "$(sed -n 's/.*across \([0-9]*\) domains.*/\1/p' "$j" | head -n 1)" "$n_domains" "$j domain count"
done
ck_floor "$(sed -n 's/.*>\([0-9]*\)+ skills<.*/\1/p' assets/social-preview.html | head -n 1)" \
   "$n_skills" "social-preview.html pill (N+)"
if [ "$v6" -eq 0 ]; then echo "    ok"; else fail=1; fi

# --- 7. Router completeness -----------------------------------------------
# Every domain skill must appear in the router's routing table (as a
# `sota-name` table row) AND its library map (as **sota-name/rules**); every
# library-map entry must name a real skill dir. Catches the drift the
# 2026-07-10 audit found: sota-confidential-computing was added to the table
# but missing from the map for a full release.
#
# TWO FILES since the map was offloaded out of the router: the routing table is
# still the router's (it is the classifier and stays where the model reads it),
# the map is `sota/rules/04`. Both paths are asserted to exist before anything is
# checked — a moved file would otherwise make every grep miss and report all 40
# skills as absent, which is loud, or make the reverse loop read nothing, which
# is not.
echo "[7/34] Router lists every skill (routing table + library map)"
v7=0
seen7=0
router=skills/sota/SKILL.md
libmap=skills/sota/rules/04-library-map.md
for f in "$router" "$libmap"; do
  [ -f "$f" ] || { note "MISSING: $f — this check cannot verify anything"; v7=1; }
done
bt='`'
for d in skills/sota-*/; do
  name=$(basename "$d")
  seen7=$((seen7 + 1))
  grep -qE "^\| ${bt}${name}${bt} " "$router" || { note "routing table missing: $name"; v7=1; }
  grep -qF "**${name}/rules**" "$libmap" || { note "library map missing: $name"; v7=1; }
done
while IFS= read -r name; do
  [ -d "skills/$name" ] || { note "library map names a non-existent skill: $name"; v7=1; }
done < <(grep -oE '\*\*sota-[a-z-]+/rules\*\*' "$libmap" | sed 's/\*\*//g; s#/rules##')
scope "$seen7" "domain skills" || v7=1
if [ "$v7" -eq 0 ]; then echo "    ok ($seen7 domain skills)"; else fail=1; fi

# --- 8. Internal Markdown links resolve -----------------------------------
# Every relative Markdown link whose target is a *.md file must resolve to a
# file that exists, in ANY tracked *.md (skills, README, docs, CHANGELOG,
# evals). Catches the link rot a rename/move leaves behind — the class the
# 2026-07-24 dry run found already live in evals/results (../../docs vs the
# real ../../../docs). Scoped to *.md targets on purpose: broadening to every
# relative link flags prose/code fragments that match the [text](x) shape
# (type annotations like `(x: T)`, `(std|default)`) — a false-positive source
# with no rot-catching upside. Fenced AND inline code are stripped so link-shaped
# examples (in ``` fences or `backticks`) are not scanned. Idea from vault-doctor
# (training-knowledge-vault); see docs/ADOPTION-LOG.md.
echo "[8/34] Internal Markdown links resolve (*.md targets)"
if command -v python3 >/dev/null 2>&1; then
  if link_out=$(python3 - <<'PY'
import os, re, sys
files = [l for l in os.popen("git ls-files '*.md'").read().splitlines() if l.strip()]
print("SCOPE %d" % len(files))
LINK = re.compile(r'(?<!\!)\[[^\]]*\]\(([^)]+)\)')   # [text](target); (?<!!) skips images
bad = 0
for f in files:
    try:
        text = open(f, encoding='utf-8').read()
    except OSError:
        continue
    # drop fenced AND inline code so link-shaped *examples* (e.g. this file's own
    # `[text](file.md)`) are not mistaken for real links
    text = re.sub(r'```.*?```', '', text, flags=re.S)
    text = re.sub(r'~~~.*?~~~', '', text, flags=re.S)
    text = re.sub(r'`[^`\n]*`', '', text)
    for m in LINK.finditer(text):
        raw = m.group(1).strip()
        if raw.startswith(('http://', 'https://', 'mailto:', 'tel:', '#', '<')):
            continue                                   # external / anchor-only / autolink
        tgt = raw.split('#', 1)[0].split('?', 1)[0].strip()
        if not tgt.endswith('.md'):
            continue                                   # *.md targets only (see comment)
        target = os.path.normpath(os.path.join(os.path.dirname(f), tgt))
        if not os.path.exists(target):
            print(f"BROKEN LINK  {f}: ({raw})")
            bad = 1
sys.exit(1 if bad else 0)
PY
  ); then
    # Denominator (added 2026-08-16): an empty pathspec used to print "ok", exit 0.
    n8=$(printf '%s\n' "$link_out" | sed -n 's/^SCOPE //p')
    if scope "${n8:-0}" "markdown files"; then
      echo "    ok (${n8} markdown files)"
    else
      fail=1
    fi
  else
    printf '%s\n' "$link_out" | grep -v '^SCOPE ' | sed 's/^/    /'
    fail=1
  fi
else
  note "SKIPPED: python3 not found (CI enforces this check)"
fi

# --- 9. One [Unreleased] section, at the top ---------------------------------
# Check 5 reads only the FIRST '## [' heading, so a duplicate [Unreleased]
# further down is invisible to it. Two feature PRs each opened one above the
# previous release (2026-07-28) and both sat on main until a human noticed
# during the release cut. Fence-aware, like check 2: a CHANGELOG entry may
# legitimately quote '## [Unreleased]' inside a code fence.
echo "[9/34] CHANGELOG has at most one [Unreleased], and it is the top entry"
v9=0
changelogs="CHANGELOG.md $(git ls-files 'docs/CHANGELOG-archive*.md' | tr '\n' ' ')"
for cl in $changelogs; do
  [ -f "$cl" ] || continue
  # strip fenced blocks so quoted headings inside ``` are not counted
  body=$(awk '/^(```|~~~)/ { fence = !fence; next } !fence' "$cl")
  n=$(printf '%s\n' "$body" | grep -cE '^## \[Unreleased\]' || true)
  case "$cl" in
    CHANGELOG.md)
      if [ "$n" -gt 1 ]; then
        note "CHANGELOG.md has $n '## [Unreleased]' headings — merge them into one"
        v9=1
      elif [ "$n" -eq 1 ]; then
        # No `grep -m 1` / `head` here: they close the pipe early, the upstream
        # printf dies of SIGPIPE, and `set -o pipefail` + `set -e` then kill the
        # script mid-check — it printed the heading and nothing else. (Check 5's
        # `grep -m 1` is safe only because it reads a FILE, not a pipe.)
        first=$(printf '%s\n' "$body" | grep -E '^## \[' | sed -n '1s/^## \[\([^]]*\)\].*/\1/p')
        if [ "$first" != "Unreleased" ]; then
          note "CHANGELOG.md has an [Unreleased] section below [$first] — it must be the top entry"
          v9=1
        fi
      fi
      ;;
    *)
      if [ "$n" -gt 0 ]; then
        note "$cl has an '## [Unreleased]' heading — archives hold released versions only"
        v9=1
      fi
      ;;
  esac
done
if [ "$v9" -eq 0 ]; then echo "    ok"; else fail=1; fi

# --- 10. Every rules file is indexed by its own SKILL.md ---------------------
# The library's loading model is: SKILL.md loads first, and the model reads only
# the rules files its index points at. So a rules file that no SKILL.md mentions
# is written, reviewed, capped, checklist-ed — and never loaded. It is the
# skill-level twin of the problem invariant 7 solved one level up (a skill
# missing from the router) and of the front-door gap RELEASING.md §2b covers
# (a capability with no README mention): the artifact exists, nothing errors,
# and it is unreachable. Same class as `sota-devsecops` rules/10, applied
# to ourselves. All 255 rules files passed when this landed, so it is a
# regression gate, not a repair; it was watched to fail on an injected file
# and on a renamed reference before being trusted.
echo "[10/34] Every skills/*/rules/*.md is referenced by its own SKILL.md"
v10=0
seen10=0
while IFS= read -r rf; do
  seen10=$((seen10 + 1))
  skill_dir=$(dirname "$(dirname "$rf")")
  sk="$skill_dir/SKILL.md"
  base=$(basename "$rf")
  if [ ! -f "$sk" ]; then
    note "$rf: no SKILL.md in $skill_dir"
    v10=1
  elif ! grep -qF "$base" "$sk"; then
    note "$rf: not referenced in $sk — the model never loads it (add it to the rules index)"
    v10=1
  fi
done < <(git ls-files 'skills/*/rules/*.md')
scope "$seen10" "rules files indexed" || v10=1
if [ "$v10" -eq 0 ]; then echo "    ok ($seen10 rules files indexed)"; else fail=1; fi

# --- 11. LAST-VERIFIED only moves alongside a sweep -------------------------
# The stamp is the date of the last FULL re-verification pass, not a recency
# marker for the newest verified fact — so a rules section may carry today's
# verification dates while the stamp is months old, by design. Bumping it on an
# ordinary edit asserts a sweep that never happened, planting a false green in
# the one control whose job is detecting stale claims.
#
# That rule was already written in AGENTS.md, docs/MAINTENANCE.md and
# check-freshness.sh's own header — and two separate sessions still proposed
# bumping it wrongly and caught themselves only on verification. A convention
# documented three times and still nearly broken twice is exactly
# `sota-code-security` rules/14 §3: a natural-language instruction standing in
# for an enforced control. So it becomes a gate.
# (Was `rules/10 §2.12` until 2026-09-04 — that content moved to rules/14 and §2.12
# was folded into a combined `2.10-2.14` heading, so the citation rotted where
# invariant 18 could not see it. Which is why 18 now scans this file too.)
#
# Two legitimate escapes, because docs/MAINTENANCE.md allows a BATCHED or a
# ROLLING pass:
#   (a) the diff is sweep-shaped — the 2026-07-08 sweep touched 100 skill files
#       (31 skills, 65 findings), so the floor sits far below a real one;
#   (b) the CHANGELOG diff DECLARES the new stamp — an added line naming both
#       LAST-VERIFIED and the date the stamp now carries. The runbook already
#       requires this ("note the sweep in the CHANGELOG"), and it is how a
#       rolling pass declares its completion.
#
# Escape (b) required only the TOKEN until 2026-09-14, and a bare substring is
# wider than its intent: ANY added CHANGELOG line containing "LAST-VERIFIED"
# excused a stamp move for the whole diff — including a line written to say no
# sweep is due. Worse, it disarmed the negative control even when the stamp had
# NOT moved: a PR whose CHANGELOG merely mentioned the token made probe 11 report
# this check INERT, so the check went unverified exactly when someone was writing
# about it. That happened twice (2026-09-12, 2026-09-14), the second time in a PR
# that never touched the stamp at all.
#
# Requiring the DATE is what turns the mention into a declaration that must be
# TRUE — the design the header below states for every escape in this file. It
# also answers both objections recorded in docs/CONVENTIONS-LEDGER.md: it adds no
# magic string a contributor must memorise (a sweep entry names its date anyway),
# and it keeps the rolling-pass path that collapsing (b) into (a) would remove.
# This is the first DIFF-based invariant; every other check reads the whole tree.
# With no merge base it skips with a note rather than guessing, like checks 4/8.
SWEEP_MIN_SKILL_FILES=20
echo "[11/34] LAST-VERIFIED moves only with a sweep (batched diff, or declared in CHANGELOG)"
v11=0
base=""
for ref in origin/main main; do
  if git rev-parse --verify -q "$ref" >/dev/null 2>&1; then
    base=$(git merge-base HEAD "$ref" 2>/dev/null || true)
    [ -n "$base" ] && break
  fi
done
if [ -z "$base" ] || [ "$base" = "$(git rev-parse HEAD)" ]; then
  note "SKIPPED (no merge base to diff against, or nothing ahead of it)"
  echo "    ok (skipped)"
else
  changed=$(git diff --name-only "$base"...HEAD)
  # Compare the parsed DATE, not the file. Keying on the file meant a comment-only
  # edit demanded an escape — and the first such change (2026-07-31, moving the rule
  # into the file) satisfied it reflexively by naming LAST-VERIFIED in the CHANGELOG
  # even though the stamp never moved. A gate that fires on non-events trains people
  # to wave it through, which is how it becomes decorative (rules/15 §2).
  stamp_now=$(grep -v '^[[:space:]]*#' LAST-VERIFIED 2>/dev/null | tr -d '[:space:]' || true)
  stamp_was=$(git show "$base":LAST-VERIFIED 2>/dev/null | grep -v '^[[:space:]]*#' | tr -d '[:space:]' || true)
  if printf '%s\n' "$changed" | grep -qx 'LAST-VERIFIED' && [ "$stamp_now" != "$stamp_was" ]; then
    n_skill=$(printf '%s\n' "$changed" | grep -c '^skills/.*\.md$' || true)
    declared=0
    # Decide with `case`, not a trailing `grep -q`: under `set -o pipefail` a -q
    # exits early, SIGPIPEs the upstream greps, and 141 becomes the verdict — the
    # defect that made invariant 14 reject correct work for five months.
    declared_lines=$(git diff "$base"...HEAD -- CHANGELOG.md | grep '^+' | grep 'LAST-VERIFIED' || true)
    if [ -n "$stamp_now" ]; then
      case "$declared_lines" in (*"$stamp_now"*) declared=1 ;; esac
    fi
    if [ "$n_skill" -ge "$SWEEP_MIN_SKILL_FILES" ]; then
      echo "    ok (LAST-VERIFIED moved with $n_skill skill files — sweep-shaped)"
    elif [ "$declared" -eq 1 ]; then
      echo "    ok (LAST-VERIFIED moved and declared in the CHANGELOG)"
    else
      note "LAST-VERIFIED changed, but this diff touches only $n_skill skill file(s)"
      note "and no added CHANGELOG line declares it: the declaration must name BOTH"
      note "LAST-VERIFIED and the new stamp value ($stamp_now) on one line. A bare"
      note "mention of the token is not a declaration. The stamp records a FULL"
      note "re-verification pass (the 2026-07-08 sweep touched 100 skill files)."
      note "If this really completes a rolling pass, say so in the CHANGELOG entry;"
      note "otherwise revert the stamp — an ordinary edit must not move it."
      v11=1
    fi
  elif printf '%s\n' "$changed" | grep -qx 'LAST-VERIFIED'; then
    echo "    ok (LAST-VERIFIED touched but the stamp is unchanged: $stamp_now)"
  else
    echo "    ok (LAST-VERIFIED unchanged)"
  fi
fi
if [ "$v11" -ne 0 ]; then fail=1; fi

# --- 12. Rendered assets are current --------------------------------------
# assets/*.png are committed BUILD OUTPUTS of the assets/*.html beside them, and
# nothing regenerates them. The README embeds the PNG and never the source — so an
# HTML edit that is not re-rendered is invisible to every reader, while the diff,
# the commit message and the CHANGELOG all report the surface fixed.
#
# Not hypothetical: PR #173 (2026-08-01) changed how-it-works.html from "every file
# < 500 lines" to "each < 500 lines" — the entire point of that PR — and left
# how-it-works.png at its #55 render from 2026-07-09. main served the stale claim
# for the rest of the day on the one surface anybody actually looks at.
#
# Passes all three docs/CONVENTIONS-LEDGER.md filters: it has already failed; it
# fails SILENTLY (nobody reads the HTML, and the PNG looks fine — it just says the
# old thing); and it is mechanically checkable from git log alone.
#
# COMMIT times, not mtimes: a fresh clone stamps every file with the checkout time,
# so an mtime comparison would pass on any CI runner — green while examining
# nothing (rules/11 §2.2). Equal timestamps PASS: rendering in the same commit as
# the edit is the wanted behaviour, not a violation.
#
# Escape: "[no-render]" in the HTML's own last commit subject, for an edit that
# cannot change the output. Deliberately a DECLARATION and not a heuristic —
# invariant 11 learned that a gate firing on non-events gets waved through until it
# is decorative, and nothing short of rendering both can tell a cosmetic HTML edit
# from a load-bearing one.
#
# HISTORY-based, like check 11's diff: with no commit history for a pair it skips
# with a note rather than guessing, because a shallow clone must not read as a pass.
echo "[12/34] Rendered assets: each assets/*.png is no older than its *.html"
v12=0
seen12=0
checked12=0
while IFS= read -r html; do
  seen12=$((seen12 + 1))
  png="${html%.html}.png"
  html_ct=$(git log -1 --format=%ct -- "$html" 2>/dev/null || true)
  if [ -z "$html_ct" ]; then
    note "SKIPPED (no commit history for $html — shallow clone?)"
    continue
  fi
  if ! git ls-files --error-unmatch "$png" >/dev/null 2>&1; then
    note "NEVER RENDERED: $html has no committed $png"
    note "  Render it and commit both (CONTRIBUTING.md -> Rendered assets)."
    v12=1
    continue
  fi
  png_ct=$(git log -1 --format=%ct -- "$png" 2>/dev/null || true)
  if [ -z "$png_ct" ]; then
    note "SKIPPED (no commit history for $png — shallow clone?)"
    continue
  fi
  checked12=$((checked12 + 1))
  if [ "$html_ct" -gt "$png_ct" ]; then
    # Captured into a variable, NOT piped into grep -q: an early-exiting grep on a
    # pipe SIGPIPEs the upstream git and pipefail turns a MATCH into a failure —
    # the exact shape that made invariant 9's first cut look like it passed.
    subject=$(git log -1 --format=%s -- "$html" 2>/dev/null || true)
    case "$subject" in
      *"[no-render]"*)
        note "ok, declared [no-render]: $html"
        continue
        ;;
    esac
    note "STALE RENDER: $png is older than $html"
    # Full timestamp, not %cs: a same-day miss printed the SAME date on both lines
    # while asserting one was older, which reads as a broken check rather than a
    # real finding — and a check nobody believes is one they turn off.
    note "  $html last changed $(git log -1 --format=%ci -- "$html")"
    note "  $png last changed $(git log -1 --format=%ci -- "$png")"
    note "  The README embeds the PNG, not the source. Re-render and commit both"
    note "  (CONTRIBUTING.md -> Rendered assets), or put [no-render] in the commit"
    note "  subject when the edit cannot change the output."
    v12=1
  fi
done < <(git ls-files 'assets/*.html')
scope "$seen12" "rendered asset sources" || v12=1
if [ "$v12" -eq 0 ]; then
  if [ "$checked12" -eq 0 ] && [ "$seen12" -gt 0 ]; then
    echo "    ok (skipped — no usable commit history)"
  else
    echo "    ok ($checked12 asset pairs)"
  fi
fi
if [ "$v12" -ne 0 ]; then fail=1; fi

# --- 13. Every scoreboard row declares its sample size ---------------------
# The last actionable candidate in docs/CONVENTIONS-LEDGER.md. A lift from one run
# is typographically identical to a lift from ten, and this repo has been burned by
# exactly that twice: a +0.07 on inert-control detection did not survive growing the
# set from 15 to 49 cases and was RETRACTED, and a +0.40 published from one synced
# run became +0.39 on the two-run mean. Neither number looked uncertain on the page.
#
# Like invariant 10, this is a REGRESSION GUARD with no incident of its own: all 10
# rows populate the column today. It prevents the next row from being added without
# one, which is the cheap moment to catch it — the expensive moment is after the
# number has been quoted somewhere.
#
# Shape-driven, not position-driven: it finds any table whose header has a "Samples"
# column and checks that column in every data row beneath it. So it also fails when
# the column is RENAMED or dropped (0 tables -> SCOPE EMPTY), which is the drift a
# hardcoded column index would sail straight past.
echo "[13/34] Every scoreboard row declares its sample size"
v13=0
BOARD="evals/results/RESULTS.md"
if [ ! -f "$BOARD" ]; then
  note "SKIPPED (no $BOARD in this checkout)"
  echo "    ok (skipped)"
else
  s13=$(awk -F'|' '
    /^\|/ {
      if (!intable) {
        for (i = 1; i <= NF; i++) {
          g = $i; gsub(/^[ \t]+|[ \t]+$/, "", g)
          if (g == "Samples") { col = i; intable = 1; tables++; next }
        }
        next
      }
      if ($0 ~ /^\|[ :|-]*$/) next          # the |---|---| separator row
      rows++
      cell = $col;  gsub(/^[ \t]+|[ \t]+$/, "", cell)
      label = $2;   gsub(/^[ \t]+|[ \t]+$/, "", label)
      if (cell == "") printf "EMPTY\t%d\t%s\n", NR, label
      next
    }
    { intable = 0 }                          # a non-table line ends the table
    END { printf "TABLES\t%d\nROWS\t%d\n", tables, rows }
  ' "$BOARD")
  n_tables=$(printf '%s\n' "$s13" | awk -F'\t' '$1=="TABLES"{print $2}')
  n_rows=$(printf '%s\n' "$s13" | awk -F'\t' '$1=="ROWS"{print $2}')
  # Process substitution, NOT a pipe: a `| while` runs the loop in a subshell and
  # every v13=1 set inside it is discarded when the subshell exits — a gate that
  # finds offenders, prints them, and still exits 0.
  while IFS="$(printf '\t')" read -r kind line label; do
    [ "$kind" = "EMPTY" ] || continue
    note "NO SAMPLE SIZE: $BOARD:$line — \"$label\""
    v13=1
  done < <(printf '%s\n' "$s13")
  if [ "$v13" -ne 0 ]; then
    note "  A number without its n reads exactly like a number with one. State the"
    note "  sample size in the row (\"3×, temp 0.7\", \"1×\") — see evals/README.md."
  fi
  scope "${n_tables:-0}" "scoreboard tables with a Samples column" || v13=1
  scope "${n_rows:-0}" "scoreboard rows" || v13=1
  if [ "$v13" -eq 0 ]; then echo "    ok ($n_rows scoreboard rows)"; fi
fi
if [ "$v13" -ne 0 ]; then fail=1; fi

# --- 14. A release declares its front-door terms, and they resolve ---------
# Invariant 6 fails on a wrong NUMBER in the README. Nothing failed on a
# capability that never got a sentence anywhere a reader looks: at the v1.19.7 cut,
# `adversarial`, `refut`, `decision ledger`, `inert`, `no-op` and `ADOPTION-LOG` all
# returned ZERO hits in README.md — five capabilities shipped across three releases
# with no front-door mention. RELEASING.md section 2b has prescribed the grep since,
# and it has caught something at THREE consecutive cuts, which is the argument for a
# gate rather than evidence the habit sticks.
#
# DISCOVERY IS NOT MECHANIZABLE -- "what counts as a capability" is judgement, which
# is why this candidate sat blocked in docs/CONVENTIONS-LEDGER.md. DECLARATION IS.
# So this gates the verification, not the discovery, exactly as invariant 11 gates
# LAST-VERIFIED with escapes that are declarations which must be TRUE.
#
# Only fires on a RELEASE commit (VERSION changed against the merge base), so it adds
# nothing to an ordinary PR. On a release it requires, in the new version's CHANGELOG
# section, a line of the form:
#
#     **Front door checked:** term one · term two · term three
#
# and then verifies every term BOTH ways: it must appear in README.md or
# docs/INDEX.md (the front door is real), AND in that release's own CHANGELOG section
# (you cannot pass by declaring a filler word that was never part of the release).
# A missing line on a release commit fails closed.
echo "[14/34] A release declares its front-door terms, and they resolve"
v14=0
base14=""
for ref in origin/main main; do
  if git rev-parse --verify -q "$ref" >/dev/null 2>&1; then
    base14=$(git merge-base HEAD "$ref" 2>/dev/null || true)
    [ -n "$base14" ] && break
  fi
done
if [ -z "$base14" ] || [ "$base14" = "$(git rev-parse HEAD)" ]; then
  note "SKIPPED (no merge base to diff against, or nothing ahead of it)"
  echo "    ok (skipped)"
elif ! git diff --name-only "$base14"...HEAD | grep -qx 'VERSION'; then
  echo "    ok (not a release commit — VERSION unchanged)"
else
  # The release section is the one matching VERSION -- NOT the topmost '## ['
  # heading. Keying on the top heading read [Unreleased] instead when one still sat
  # above the new entry, and reported "no declaration" for a release that had one.
  # Found by watching case C fail for the wrong reason.
  ver=$(tr -d '[:space:]' < VERSION)
  sec=$(awk -v v="## [$ver]" 'index($0,v)==1{f=1;print;next} f&&/^## \[/{exit} f{print}' CHANGELOG.md)
  if [ -z "$sec" ]; then
    note "VERSION is $ver but CHANGELOG.md has no '## [$ver]' section to check"
    v14=1
    sec=""
  fi
  # ANCHORED to line start. Unanchored, this also matched the format example quoted
  # inside invariant 14's own CHANGELOG entry ("`**Front door checked:** term · term`
  # to its CHANGELOG section..."), and the two matches concatenated into garbage terms.
  # Found on this gate's FIRST real release, which is the point of shipping it early.
  # A declaration is its own line: unindented, unbackticked.
  decl=$(printf '%s\n' "$sec" | grep -i '^\*\*Front door checked:\*\*' || true)
  if [ -z "$decl" ]; then
    note "VERSION changed but this release declares no front-door check."
    note "  Add to the new CHANGELOG section (RELEASING.md section 2b):"
    note "    **Front door checked:** <term> · <term>"
    note "  Each term must appear in README.md or docs/INDEX.md, and in this section."
    v14=1
  else
    # shellcheck disable=SC2016  # single-quoted sed scripts, not expansions
    terms=$(printf '%s\n' "$decl" | sed 's/.*\*\*[Ff]ront door checked:\*\*//' \
      | tr '·,;' '\n' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/^[`*]*//; s/[`*.]*$//' \
      | grep -v '^$' || true)
    # The entry MINUS the declaration line, computed ONCE and matched with a bash
    # built-in rather than re-piped per term. The pipeline this replaces
    # (`printf | grep -v | grep -qiF`) was POSITION-DEPENDENT and reported a false
    # FAILURE: `grep -q` exits on its first match and closes the pipe, the upstream
    # `grep -v` dies of SIGPIPE (141), and `set -o pipefail` makes that the
    # pipeline's status. It only bites when the term appears early enough that
    # `grep -q` exits while `grep -v` is still writing -- i.e. only on a section
    # larger than the pipe buffer, which is why it survived every release until
    # v1.42.0, whose 497-line entry carried its terms in the FIRST heading. Four
    # terms read "absent from the release's own entry" while a fifth, 130 lines
    # further down, passed. Falsifier stated before measuring and both halves held:
    # at 20,000 lines the early term fails and the late one passes; at three lines
    # both pass, because the whole input fits in the buffer.
    #
    # It failed CLOSED, so no bad release was ever waved through -- it blocked a
    # correct one, which is worse than it sounds: the quickest way to a green build
    # is to delete the term from the declaration, and that silently weakens the gate
    # this check exists to be.
    sec_body=$(printf '%s\n' "$sec" | grep -v '\*\*[Ff]ront door checked:\*\*' || true)
    n_terms=0
    shopt -s nocasematch
    while IFS= read -r t; do
      [ -n "$t" ] || continue
      n_terms=$((n_terms + 1))
      # Reading FILES, not a pipeline: no early close, so -q is safe here.
      if ! grep -qiF -- "$t" README.md docs/INDEX.md 2>/dev/null; then
        note "NO FRONT DOOR: \"$t\" appears in neither README.md nor docs/INDEX.md"
        v14=1
      fi
      # Guard against declaring a word that was never part of this release.
      # Substring match, exactly what `grep -iF` did -- not a looser glob.
      if [[ $sec_body != *"$t"* ]]; then
        note "NOT IN THIS RELEASE: \"$t\" is declared but absent from the release's own entry"
        v14=1
      fi
    done <<EOF
$terms
EOF
    shopt -u nocasematch
    scope "$n_terms" "declared front-door terms" || v14=1
    if [ "$v14" -eq 0 ]; then echo "    ok ($n_terms terms declared, all resolve)"; fi
  fi
fi
if [ "$v14" -ne 0 ]; then fail=1; fi

# --- 15. Router library map lists every rules FILE ------------------------
# Check 7 proves every SKILL is in the map. Check 10 proves every rules file is
# indexed by its OWN SKILL.md. Neither reads the map's CONTENTS — which is how
# sota-code-security/rules/11 stayed unlisted in the router for two releases
# (v1.19.8 → v1.21.0) with all fourteen checks green. Both directions matter: a
# file absent from the map is invisible to a router-driven load, and a map entry
# for a file that no longer exists sends the model after nothing.
echo "[15/34] Router library map lists every rules file (both directions)"
v15=0
if command -v python3 >/dev/null 2>&1; then
  map_out=$(python3 - <<'MAPPY'
import os, re, glob, sys
router = "skills/sota/rules/04-library-map.md"   # the map moved out of the router
try:
    lines = open(router, encoding="utf-8").read().splitlines()
except OSError as e:
    print("ERROR: cannot read %s: %s" % (router, e))
    print("SCOPE 0")
    sys.exit(1)

# A map entry is "- **<skill>/rules**: 01 title, 02 title, ..." and wraps onto
# indented continuation lines until the next list item or an unindented line.
entries, name = {}, None
for line in lines:
    m = re.match(r'^- \*\*(sota-[a-z-]+)/rules\*\*:(.*)$', line)
    if m:
        name = m.group(1)
        entries[name] = m.group(2)
        continue
    if name is not None:
        if line.startswith("- ") or (line.strip() and not line.startswith("  ")):
            name = None
        else:
            entries[name] += " " + line

# Anchor each number to a list position (entry start, or after a comma) so a
# title containing digits cannot read as a rules number: "02 NIST 800-53/800-171"
# must yield 02 and never 80, 53 or 17.
NUM = re.compile(r'(?:^|[:,])\s*(\d{2})\s')
dirs = sorted(glob.glob("skills/sota-*/rules"))
bad = 0
for d in dirs:
    skill = d.split("/")[1]
    files = set()
    for f in glob.glob(d + "/*.md"):
        b = os.path.basename(f)
        if re.match(r'^\d{2}-', b):
            files.add(b[:2])
    listed = set(NUM.findall(entries.get(skill, "")))
    for n in sorted(files - listed):
        print("map missing: %s/rules/%s-*.md exists but the router does not list it" % (skill, n))
        bad += 1
    for n in sorted(listed - files):
        print("map stale: router lists %s/rules %s but no such file exists" % (skill, n))
        bad += 1
print("SCOPE %d" % len(dirs))
sys.exit(1 if bad else 0)
MAPPY
  ) || v15=1
  n15=$(printf '%s\n' "$map_out" | sed -n 's/^SCOPE //p')
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'') ;; *) note "$l" ;; esac
  done <<EOF
$map_out
EOF
  scope "${n15:-0}" "skills with a rules/ dir" || v15=1
  if [ "$v15" -eq 0 ]; then echo "    ok (${n15:-0} skills, map matches the tree)"; fi
else
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
fi
if [ "$v15" -ne 0 ]; then fail=1; fi

# --- 16. The documented hook matches the installed hook -------------------
# install.sh WRITES the UserPromptSubmit hook; README DOCUMENTS it. Nothing kept
# them equal, and on 2026-08-05 three different texts existed at once: the
# README's block (two revisions behind), install.sh's HOOK_CMD, and what was
# actually in a user's settings.json. The README's is the one a reader copies by
# hand, so a stale block is the version that spreads. Silent by construction —
# nothing executes the README.
echo "[16/34] README's documented hook == install.sh's HOOK_CMD"
v16=0
if command -v python3 >/dev/null 2>&1; then
  hook_out=$(python3 - <<'HOOKPY'
import re, json, sys

FENCE = chr(96) * 3
try:
    readme = open("README.md", encoding="utf-8").read()
    lines = open("scripts/install.sh", encoding="utf-8").read().splitlines()
except OSError as e:
    print("ERROR: %s" % e); print("SCOPE 0"); sys.exit(1)

# The shipped value: the one HOOK_CMD assignment in install.sh.
PREFIX = 'readonly HOOK_CMD="'
sh = [l for l in lines if l.startswith(PREFIX)]
if len(sh) != 1:
    print("expected exactly 1 HOOK_CMD assignment in scripts/install.sh, found %d" % len(sh))
    print("SCOPE 0"); sys.exit(1)
shipped = sh[0][len(PREFIX):-1]

# The documented value: parse the fenced JSON rather than regexing the string, so
# a reformat of the block is not a false positive.
blocks = [b for b in re.findall(FENCE + r'json\n(.*?)' + FENCE, readme, re.S)
          if "UserPromptSubmit" in b]
documented = []
for b in blocks:
    try:
        d = json.loads(b)
    except json.JSONDecodeError as e:
        print("README JSON block does not parse: %s" % e)
        print("SCOPE 0"); sys.exit(1)
    for grp in d.get("hooks", {}).get("UserPromptSubmit", []):
        for h in grp.get("hooks", []):
            if "command" in h:
                documented.append(h["command"])

if not documented:
    print("no UserPromptSubmit command found in any README json block — "
          "the documented hook vanished, or the block stopped being valid JSON")
    print("SCOPE 0"); sys.exit(1)

bad = 0
for d in documented:
    if d != shipped:
        bad += 1
        print("README documents a hook install.sh does not write.")
        print("  README    (%d chars): %s" % (len(d), d[:90]))
        print("  HOOK_CMD  (%d chars): %s" % (len(shipped), shipped[:90]))
        for i, (x, y) in enumerate(zip(d, shipped)):
            if x != y:
                print("  first difference at char %d: %r vs %r" % (i, d[i:i+40], shipped[i:i+40]))
                break
        else:
            print("  one is a prefix of the other (length differs)")
print("SCOPE %d" % len(documented))
sys.exit(1 if bad else 0)
HOOKPY
  ) || v16=1
  n16=$(printf '%s\n' "$hook_out" | sed -n 's/^SCOPE //p')
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'') ;; *) note "$l" ;; esac
  done <<EOF
$hook_out
EOF
  scope "${n16:-0}" "documented hook commands" || v16=1
  if [ "$v16" -eq 0 ]; then echo "    ok (${n16:-0} documented hook, matches HOOK_CMD)"; fi
else
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
fi
if [ "$v16" -ne 0 ]; then fail=1; fi

# [17] The documents that DESCRIBE the checks drift from the checks themselves.
# Twice in one week: CONTRIBUTING.md listed part A's negative-control coverage as
# five invariants when the harness printed eleven, and CONVENTIONS-LEDGER.md headed
# its enforced section "(14) — invariants 1–14" while 15 and 16 were already gated
# and described in its own table below. Nothing read those documents, so a doc that
# under-describes the gates is indistinguishable from a correct one — the same
# class every other check here is about, aimed at our own prose.
#
# Two traps this had to be built around, both real in the current tree:
#   - "invariant 15 checks the router's library map" is a number followed by the
#     word "checks" and is NOT a count. Excluded by look-behind.
#   - a correction note that QUOTES the old wording ("(14) — invariants 1–14") is
#     history, not a claim. Counts inside double quotes are ignored, which is the
#     same supersede-don't-edit rule the CHANGELOG follows.
echo "[17/34] Docs describing the invariants agree with the scripts"
v17=0
if command -v python3 >/dev/null 2>&1; then
  doc_out=$(python3 - <<'DOCPY'
import re, sys, pathlib

# README.md added 2026-09-10. It is the FRONT DOOR and it was the one document
# describing the gates that nothing validated: it read "Twenty-five invariants"
# while the script had 29, across at least four releases. Both halves of that
# failure are covered now — the file is in scope, and WORD-form counts are read as
# well as digits, since spelling the number out was what hid it.
DOCS = ["AGENTS.md", "CONTRIBUTING.md", "README.md",
        "docs/CONVENTIONS-LEDGER.md", "docs/MAINTENANCE.md",
        "docs/INVARIANTS.md", "docs/WHY-IT-WORKS.md"]

WORDNUM = {"twenty": 20, "thirty": 30, "forty": 40,
           "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
           "six": 6, "seven": 7, "eight": 8, "nine": 9}

def norm(s):
    s = s.replace("*", "").replace("`", "")
    return re.sub(r'"[^"\n]*"', '""', s)      # quotations are history, not claims

def flat(s):
    # Collapse wrapping: these lists are prose and wrap at ~80 cols, so a
    # substring test against the raw text fails on where the line happened to
    # break. Cost me one false positive before it was written down.
    return re.sub(r'\s+', ' ', norm(s))

try:
    inv = pathlib.Path("scripts/check-invariants.sh").read_text(encoding="utf-8")
    neg = pathlib.Path("scripts/check-negative-controls.sh").read_text(encoding="utf-8")
except OSError as e:
    print("ERROR: %s" % e); print("SCOPE 0"); sys.exit(1)

# --- the authority: the numbering the script actually prints -----------------
marks = re.findall(r'echo "\[(\d+)/(\d+)\]', inv)
if not marks:
    print("no [k/N] check markers found in check-invariants.sh")
    print("SCOPE 0"); sys.exit(1)
totals = {int(n) for _, n in marks}
if len(totals) != 1:
    print("check markers disagree on the total: %s" % sorted(totals))
    print("SCOPE 0"); sys.exit(1)
N = totals.pop()
ks = [int(k) for k, _ in marks]
if sorted(ks) != list(range(1, N + 1)):
    print("check numbers are not exactly 1..%d: %s" % (N, sorted(ks)))
    print("SCOPE 0"); sys.exit(1)

bad = 0
claims = 0

# --- every stated count must be N -------------------------------------------
WORD_PAT = re.compile(
    r'\b(twenty|thirty|forty)(?:[- ](one|two|three|four|five|six|seven|eight|nine))?'
    r'\s+(?:checks|invariants)\b', re.I)

COUNT_PATS = [
    # \b before the digits, or "Invariant 10 checks" matches the trailing "0"
    # and reports a phantom "0 checks" — it did, before the boundary was added.
    re.compile(r'(?<!invariant )(?<!Invariant )\b(\d+)\s+(?:checks|invariants)\b'),
    re.compile(r'invariants\s+1\s*[–-]\s*(\d+)'),
    re.compile(r'Enforced\s*\((\d+)\)'),
]
for f in DOCS:
    try:
        text = pathlib.Path(f).read_text(encoding="utf-8")
    except OSError as e:
        print("cannot read %s: %s" % (f, e)); bad += 1; continue
    for ln, line in enumerate(norm(text).splitlines(), 1):
        for pat in COUNT_PATS:
            for m in pat.finditer(line):
                claims += 1
                if int(m.group(1)) != N:
                    bad += 1
                    print("%s:%d says %r but check-invariants.sh has %d checks"
                          % (f, ln, m.group(0).strip(), N))
        # A count spelled out in words is still a count. "Twenty-five invariants"
        # sat in README.md against a script with 29 and no pattern above could see it.
        for m in WORD_PAT.finditer(line):
            claims += 1
            val = WORDNUM[m.group(1).lower()] + (WORDNUM[m.group(2).lower()] if m.group(2) else 0)
            if val != N:
                bad += 1
                print("%s:%d says %r (= %d) but check-invariants.sh has %d checks"
                      % (f, ln, m.group(0).strip(), val, N))

# --- the per-invariant descriptions must enumerate all N ---------------------
# The stated count and the actual list can drift apart: update "runs 18 checks"
# and forget the table row, and every count claim still agrees. docs/INVARIANTS.md
# carries one table row per invariant; CONTRIBUTING.md carries one numbered item.
#
# The table lived in AGENTS.md until 2026-09-13, when it was offloaded so that
# adding an invariant stops costing a line of the always-loaded 200-line budget
# (it had breached the cap five times, every time on an invariant's own row).
# THIS LINE IS THE REASON THE REFACTOR WAS SAFE: the enumeration assertion follows
# the table rather than the filename, and moving the table without moving it here
# would have left check 17 reading an empty list -- which it reported, loudly, on
# the first run after the move.
ENUMS = [("docs/INVARIANTS.md", re.compile(r'^\| (\d+) \| ', re.M), "invariant table rows"),
         ("CONTRIBUTING.md", re.compile(r'^(\d+)\. ', re.M), "numbered invariant items")]
for f, pat, label in ENUMS:
    try:
        raw = pathlib.Path(f).read_text(encoding="utf-8")
    except OSError as e:
        print("cannot read %s: %s" % (f, e)); bad += 1; continue
    nums = sorted({int(x) for x in pat.findall(raw)})
    claims += 1
    if nums != list(range(1, N + 1)):
        bad += 1
        missing = [i for i in range(1, N + 1) if i not in nums]
        print("%s's %s are %s, not 1..%d%s"
              % (f, label, nums if len(nums) < 25 else "%d entries" % len(nums), N,
                 " (missing %s)" % missing if missing else ""))

# --- the two coverage lists the harness prints must appear verbatim ----------
def harness_list(prefix):
    m = re.search(re.escape(prefix) + r'\s*([0-9a-z, ]+?)\s*(?:\(|\.)', neg)
    return m.group(1).strip() if m else None

covered = harness_list("check-invariants.sh COVERED:")
vs_list = harness_list("verify-setup.sh: checks")
m = re.search(r'COVERED:[^(]*\((\d+ of \d+)\)', neg)
ratio = m.group(1) if m else None
if not covered or not vs_list or not ratio:
    print("could not extract the coverage lists from check-negative-controls.sh")
    print("SCOPE 0"); sys.exit(1)

for f in ("AGENTS.md", "CONTRIBUTING.md"):
    try:
        text = flat(pathlib.Path(f).read_text(encoding="utf-8"))
    except OSError as e:
        print("cannot read %s: %s" % (f, e)); bad += 1; continue
    for label, want in (("part A invariant list", covered),
                        ("part A ratio", ratio),
                        ("part B check list", vs_list)):
        claims += 1
        if want not in text:
            bad += 1
            print("%s does not restate the harness's %s (%r)" % (f, label, want))

print("SCOPE %d" % claims)
sys.exit(1 if bad else 0)
DOCPY
  ) || v17=1
  n17=$(printf '%s\n' "$doc_out" | sed -n 's/^SCOPE //p')
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'') ;; *) note "$l" ;; esac
  done <<EOF
$doc_out
EOF
  scope "${n17:-0}" "documented count/coverage claims" || v17=1
  if [ "$v17" -eq 0 ]; then echo "    ok (${n17:-0} claims checked against the scripts)"; fi
else
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
fi
if [ "$v17" -ne 0 ]; then fail=1; fi

# --- 18. Section cross-references resolve ----------------------------------
# Invariant 8 resolves `[text](file.md)` links. It cannot see a `§` reference,
# because a `§` reference is PROSE, not a link — and the library carries ~1,300
# of them across skills/. They break silently: renumber a section, or split a
# rules file, and every citation of it still reads as a valid pointer while
# leading nowhere. Added 2026-08-20 immediately BEFORE splitting rules/10 and
# rules/11 for exactly that reason, and it found six live defects on its very
# first run over the unmodified tree (two dangling sections, four cross-skill
# refs that resolved to the wrong skill's rules/NN).
#
# Two conventions it had to learn the hard way, both found by reading the
# findings instead of trusting the count (`sota-code-security` rules/15 §2.2):
#   - a heading may number itself `## 3.` OR `## §3 ` — missing the second form
#     read one whole file as unnumbered and hid 102 valid references;
#   - `§N.M` means a `### N.M` heading in SOME files and "item M of the ordered
#     list in §N" in others. Both are legitimate; a checker that knows only the
#     first flags nine correct references. That is rules/15 §2.1's "generalised
#     from one sample", committed by this check's own first draft.
# It is deliberately FAIL-OPEN on ambiguity — a bare `rules/NN` is tried against
# every skill named on the line and against the containing skill, and any hit
# passes. A gate that flags correct prose gets disabled, which leaves you worse
# off than no gate (docs/CONVENTIONS-LEDGER.md).
echo "[18/34] Section references (§N) resolve to a real section"
v18=0
if command -v python3 >/dev/null 2>&1; then
  ref_out=$(python3 scripts/lib/check-section-refs.py 2>&1) || v18=1
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'') ;; *) note "$l" ;; esac
  done <<EOF
$ref_out
EOF
  n18=$(printf '%s\n' "$ref_out" | sed -n 's/^SCOPE //p')
  scope "${n18:-0}" "section references" || v18=1
  if [ "$v18" -eq 0 ]; then echo "    ok (${n18:-0} section references resolved)"; fi
else
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
fi
if [ "$v18" -ne 0 ]; then fail=1; fi

# --- 19. Every check has a known-bad, and the exempt set has not grown -------
# rules/12 §1b applied to this repo. Two halves, and the second is the one with
# teeth: without it, "every check is probed or declared unprobeable" is satisfied
# by adding your new check number to the declared-unprobeable list, which is a
# one-line way to silence the check that exists to stop you.
#
# So the exempt set is PINNED here. Growing it is a deliberate edit to this line,
# which a reviewer sees. This literal is a tripwire, not a cached count — the
# distinction that makes it different from the stale literals rules/10 §1 warns
# about is that nothing derives it and everything compares against it.
#
# Runs on every invocation (~50 ms), not behind --self-test: a check you have to
# remember to run is a convention. Invariant 18 was added WITHOUT a probe in the
# very commit that introduced it, which is what this exists to make impossible.
#
# The pin SHRANK on 2026-09-09, from "5 9 11 12 14" to "5 9 12". 11 and 14 were
# exempted as "diff-based: they compare against a merge base" — true, and not a reason:
# a disposable worktree can COMMIT. Writing check 29's probe (also diff-based) produced
# the mechanism, so the two stale exemptions had to go with it. A reason that stops
# being true is the same defect every check here is about, aimed at this list.
EXPECTED_UNPROBED="5 9 12"
echo "[19/34] Every check has a known-bad, or a pinned reason it cannot"
v19=0
if command -v python3 >/dev/null 2>&1; then
  st_out=$(python3 - "$0" "$(dirname "$0")/check-negative-controls.sh" "$EXPECTED_UNPROBED" <<'STPY'
import re, sys, pathlib
try:
    inv = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
    neg = pathlib.Path(sys.argv[2]).read_text(encoding="utf-8")
except OSError as e:
    print("cannot read: %s" % e); print("SCOPE 0"); sys.exit(1)
pinned = {int(x) for x in sys.argv[3].split()}

marks = re.findall(r'echo "\[(\d+)/(\d+)\]', inv)
totals = {int(n) for _, n in marks}
if len(totals) != 1:
    print("check markers disagree on the total: %s" % sorted(totals)); print("SCOPE 0"); sys.exit(1)
N = totals.pop()
checks = set(range(1, N + 1))

probed = {int(m) for m in re.findall(r'^probe(?:_committed)? (\d+) ', neg, re.M)}
tail = neg.split("NOT COVERED", 1)
declared = set()
if len(tail) == 2:
    for line in tail[1].splitlines():
        m = re.match(r'\s*echo "\s+((?:\d+,\s*)*\d+)\s+—', line)
        if m:
            declared |= {int(x) for x in re.findall(r'\d+', m.group(1))}

bad = 0
for n in sorted(checks - probed - declared):
    bad = 1
    print("check %d has no known-bad in check-negative-controls.sh and no declared "
          "reason it cannot have one — add a probe, or say why (and pin it)" % n)
for n in sorted(probed & declared):
    bad = 1; print("check %d is both probed and declared unprobeable" % n)
for n in sorted((probed | declared) - checks):
    bad = 1; print("%d is probed or declared but is not a check in this script" % n)

if declared != pinned:
    bad = 1
    grew = sorted(declared - pinned); shrank = sorted(pinned - declared)
    if grew:
        print("the declared-unprobeable set GREW by %s — a new check may not be "
              "exempted by adding it to that list; probe it, or edit EXPECTED_UNPROBED "
              "deliberately with the reason" % grew)
    if shrank:
        print("checks %s are now probed but EXPECTED_UNPROBED still exempts them — "
              "good news, update the pin" % shrank)
if bad:
    print("SCOPE %d" % N); sys.exit(1)
print("SCOPE %d" % N)
print("    ok (%d checks: %d probed, %d unprobeable and pinned, 0 unaccounted)"
      % (N, len(probed), len(declared)))
STPY
) || v19=1
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'    ok ('*|'') ;; *) note "$l" ;; esac
  done <<EOF
$st_out
EOF
  n19=$(printf '%s\n' "$st_out" | sed -n 's/^SCOPE //p')
  scope "${n19:-0}" "checks accounted for" || v19=1
  if [ "$v19" -eq 0 ]; then printf '%s\n' "$st_out" | sed -n 's/^    ok (/    ok (/p'; fi
else
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
fi
# Fail CLOSED: a suite that cannot verify its own coverage prints no PASS line.
if [ "$v19" -ne 0 ]; then fail=1; fi

# --- 20. The router's §AUDIT is pinned, the way §BUILD is -------------------------
#
# ROADMAP item 26, closed 2026-09-01. §BUILD has had a hash pin since v1.15.0
# (`ROUTER_BUILD_SHA` in run-completeness.py) and it has caught real drift twice.
# §AUDIT had none, and `sota/rules/01` §5 said so in as many words: "nothing catches
# this automatically — the check is this section existing and being read."
#
# The item was parked on "no eval consumes §AUDIT the way run-completeness consumes
# §BUILD". That reason was FALSE by the time it was re-read: `run-repo-audit.py:89`
# returns `f"{router}\n\n{rules}"` — the WHOLE router, §AUDIT included. So an audit
# eval has been measuring against §AUDIT unpinned.
#
# The pin lives here rather than in a runner because the drift that matters is not
# eval-vs-router (run-repo-audit pastes verbatim and cannot drift) but
# router-vs-rules: §AUDIT states seven passes whose procedure lives in
# `sota/rules/01` and `rules/03`, and a pass that contradicts the file it points at
# is worse than no pass, because the reader follows whichever they loaded.
# Bumping this hash is the forcing function to re-read both.
ROUTER_AUDIT_SHA="a0bcc43c182e67ea"
echo "[20/34] Router §AUDIT is pinned (bump only after re-reading sota/rules/01 §5 + rules/03)"
v20=0
audit_sec=$(awk '/^## AUDIT mode — workflow/{f=1} f&&/^## Library map/{exit} f' skills/sota/SKILL.md)
if [ -z "$audit_sec" ]; then
  note "router §AUDIT section not found — the markers moved, so this pin verifies nothing"
  v20=1
else
  got=$(printf '%s' "$audit_sec" | sed -e 's/[[:space:]]*$//' | python3 -c \
        'import hashlib,sys; print(hashlib.sha256(sys.stdin.read().strip().encode()).hexdigest()[:16])')
  if [ "$got" != "$ROUTER_AUDIT_SHA" ]; then
    note "AUDIT DRIFT: router §AUDIT is $got, pinned to $ROUTER_AUDIT_SHA."
    note "  §AUDIT changed. Before bumping the pin, re-read sota/rules/01 §5 and confirm"
    note "  that rules/01 and rules/03 still say what the new §AUDIT says they say."
    note "  Then set ROUTER_AUDIT_SHA=$got in this script, in the same commit."
    v20=1
  fi
  scope 1 "pinned router section" || v20=1
fi
if [ "$v20" -ne 0 ]; then fail=1; fi

# --- 21. Every released CHANGELOG version has a tag -------------------------
#
# Invariant 5 checks that a TAG is never ahead of VERSION. Nothing checked the
# other direction, and it failed TWICE before anyone asked: v1.30.0 (2026-08-29)
# and v1.31.2 (2026-09-02) each had a CHANGELOG section, a VERSION bump and a
# merge to main -- and no tag and no GitHub release. Both were found on 2026-09-04
# by enumerating the CHANGELOG against `git tag`, not by any gate. A version that
# ships in the CHANGELOG and never gets a tag is unreachable: `git tag -l` skips
# it, and the release notes exist only inside a file nobody clones for that.
#
# THE TOP ENTRY IS EXEMPT, and that is not a loophole -- the tag is pushed AFTER
# the squash-merge (RELEASING.md section 4 forbids chaining them), so on a release
# PR the current version legitimately has no tag yet. Everything BELOW it has had
# its chance.
#
# Tags are not fetched by default in a shallow CI checkout, so this SKIPS with a
# note when the repo has no tags at all rather than failing every version at once:
# a gate that cannot see its evidence must say so, not invent a verdict.
echo "[21/34] Every CHANGELOG version below the top one is tagged"
v21=0
seen21=0
if [ -z "$(git tag -l 'v*' 2>/dev/null)" ]; then
  note "SKIPPED (no tags in this checkout — fetch-depth/fetch-tags; cannot verify)"
  echo "    ok (skipped)"
else
  top21=$(grep -m 1 -E '^## \[[0-9]+\.[0-9]+\.[0-9]+\]' CHANGELOG.md \
          | sed 's/^## \[\([^]]*\)\].*/\1/')
  while IFS= read -r ver; do
    [ "$ver" = "$top21" ] && continue        # tagged after the merge, by design
    seen21=$((seen21 + 1))
    git rev-parse -q --verify "refs/tags/v$ver" >/dev/null || {
      note "NO TAG for CHANGELOG version $ver — it shipped and is unreachable by tag."
      note "  Tag it at the commit where VERSION became $ver, then push:"
      note "    git tag -a v$ver -m v$ver <commit> && git push origin v$ver"
      v21=1
    }
  done <<EOF21
$(grep -oE '^## \[[0-9]+\.[0-9]+\.[0-9]+\]' CHANGELOG.md | sed 's/^## \[\([^]]*\)\]/\1/')
EOF21
  scope "$seen21" "past CHANGELOG versions" || v21=1
  if [ "$v21" -eq 0 ]; then echo "    ok ($seen21 past versions, all tagged)"; fi
fi
if [ "$v21" -ne 0 ]; then fail=1; fi

# --- 22. No checklist bullet stranded inside a code fence -------------------
#
# Found 2026-09-05 while evaluating a field brief, in the file that teaches this
# class. PR #226 (2026-08-16) inserted two audit-checklist bullets at the wrong
# offset: they landed INSIDE the fenced block in `sota-code-security` rules/11
# §2.2, wedged between two lines of example gate output. For three weeks they
# rendered as part of a code sample, and both were absent from the checklist an
# auditor actually reads -- one of them ("every collection a suite iterates has a
# non-empty assertion") being the item nearest a class the same brief proposed.
#
# NOTHING CAUGHT IT, and the near misses are the point. Invariant 2 checks only
# that '## Audit checklist' is a file's last h2 -- it already tracks fence state,
# so it would reject a HEADING inside a fence, and says nothing about the bullets
# under it. Invariant 10 checks a rules file is indexed, not that its contents
# reached the reader. The line count did not change; the render did.
#
# The mutation is invisible in exactly the way this repo's own library defines as
# the hunting ground (rules/11 §1): the failure state -- a checklist item nobody
# will ever read -- is typographically identical in the diff to a legitimate
# example line, and Markdown renders it as one.
#
# SCOPE is skill files only. Prose files (README, docs/) legitimately show
# checklist syntax inside samples; skill files are instructions an agent reads,
# and a '- [ ]' there is a claim about what gets audited.
echo "[22/34] No '- [ ]' checklist bullet stranded inside a code fence"
v22=0
seen22=0
while IFS= read -r f; do
  [ -f "$f" ] || { note "SKIPPED (tracked but missing from worktree): $f"; continue; }
  seen22=$((seen22 + 1))
  # Same fence tracking as check 2: ``` or ~~~ toggles, and the fence line
  # itself is never a bullet. Leading whitespace is stripped first -- the
  # stranded bullets were flush-left, but an indented one renders identically.
  hits=$(awk '
    { line = $0; sub(/^[ \t]+/, "", line) }
    line ~ /^(```|~~~)/ { fence = !fence; next }
    fence && line ~ /^- \[[ xX]\]/ { printf "%d: %.70s\n", NR, line }
  ' "$f")
  if [ -n "$hits" ]; then
    note "CHECKLIST BULLET INSIDE A CODE FENCE: $f"
    while IFS= read -r h; do note "  $h"; done <<EOF22
$hits
EOF22
    note "  It renders as sample output, so no auditor ever reads it. Move it to"
    note "  the '## Audit checklist' section, or make it plainly part of the example."
    v22=1
  fi
done < <(git ls-files 'skills/*/*.md' 'skills/*/rules/*.md')
scope "$seen22" "skill files" || v22=1
if [ "$v22" -eq 0 ]; then echo "    ok ($seen22 skill files)"; fi
if [ "$v22" -ne 0 ]; then fail=1; fi

# --- 23. Every CHANGELOG version heading has its link reference --------------
#
# Sibling of invariant 21, and the two fail INDEPENDENTLY. 21 asks whether a
# shipped CHANGELOG version has a git TAG; nothing asked whether it has a link
# REF, and four consecutive releases shipped without one -- 1.31.2, 1.32.0,
# 1.32.1 and 1.32.2, found by hand at the v1.32.3 cut on 2026-09-05 while adding
# 1.32.3's own, and backfilled in that same commit.
#
# WHY IT IS SILENT. A `## [1.32.0]` heading with no `[1.32.0]:` reference is not
# a broken link -- Markdown renders it as literal text, brackets and all. There
# is no error, no 404, and nothing to click; it simply stops being the link every
# other entry is. Invariant 8 cannot see it either: 8 resolves `[text](file.md)`
# inline links to files on disk, and this is a reference-style link to an
# external URL. So the failure state and the success state differ by punctuation
# a reader's eye smooths over -- `sota-code-security` rules/11 §1.
#
# BOTH DIRECTIONS, and the second is the one archiving breaks. RELEASING.md
# section 1 requires that headings and their `[X.Y.Z]:` refs stay in the SAME
# file when old releases are moved to docs/CHANGELOG-archive*.md. Move a section
# and leave its ref behind and you get an orphan ref here plus a bare heading
# there -- one edit, two defects, neither of which changes a count. Which is why
# this compares SETS per file and never counts: at the moment this check was
# written all three files had heading and ref counts that matched exactly, and a
# count check would have been just as green with two versions swapped.
#
# The URL is checked too, because every one of the 75 refs already follows the
# single form RELEASING.md prescribes, so a deviation is a typo rather than a
# style: the ref for X.Y.Z must end in `/releases/tag/vX.Y.Z`. A ref pointing at
# the PREVIOUS release's tag is the copy-paste this catches, and it is invisible
# until someone clicks it.
echo "[23/34] Every CHANGELOG version heading has its own link reference"
v23=0
seen23=0
for f in CHANGELOG.md docs/CHANGELOG-archive.md docs/CHANGELOG-archive-2.md; do
  if [ ! -f "$f" ]; then
    note "MISSING FILE: $f — the CHANGELOG set is fixed; a missing one is a finding, not a skip"
    v23=1
    continue
  fi
  # Sets, not counts: `comm` needs both sides sorted, and the version strings are
  # compared as text (they only ever have to match each other, never to order).
  heads=$(grep -oE '^## \[[0-9]+\.[0-9]+\.[0-9]+\]' "$f" | tr -d '#[] ' | sort -u)
  refs=$(grep -oE '^\[[0-9]+\.[0-9]+\.[0-9]+\]:' "$f" | tr -d '[]:' | sort -u)
  n=$(printf '%s\n' "$heads" | grep -c '[0-9]' || true)
  seen23=$((seen23 + n))
  while IFS= read -r ver; do
    [ -n "$ver" ] || continue
    note "NO LINK REF for CHANGELOG version $ver in $f — the heading renders as literal text."
    note "  Add to the reference block at the bottom of that same file:"
    note "    [$ver]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v$ver"
    v23=1
  done <<EOF23A
$(comm -23 <(printf '%s\n' "$heads") <(printf '%s\n' "$refs") | grep '[0-9]' || true)
EOF23A
  while IFS= read -r ver; do
    [ -n "$ver" ] || continue
    note "ORPHAN LINK REF $ver in $f — a ref whose '## [$ver]' heading is elsewhere."
    note "  RELEASING.md section 1: a heading and its ref move together when archiving."
    v23=1
  done <<EOF23B
$(comm -13 <(printf '%s\n' "$heads") <(printf '%s\n' "$refs") | grep '[0-9]' || true)
EOF23B
  # The ref must point at its OWN tag. A ref copied from the previous release
  # resolves fine and sends every reader to the wrong notes.
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    ver=${line%%]:*}; ver=${ver#[}
    case "$line" in
      *"/releases/tag/v$ver") ;;
      *) note "WRONG TARGET in $f: [$ver] does not point at /releases/tag/v$ver"; v23=1 ;;
    esac
  done <<EOF23C
$(grep -E '^\[[0-9]+\.[0-9]+\.[0-9]+\]:' "$f" || true)
EOF23C
done
scope "$seen23" "CHANGELOG version headings" || v23=1
if [ "$v23" -eq 0 ]; then echo "    ok ($seen23 version headings, each with its own ref)"; fi
if [ "$v23" -ne 0 ]; then fail=1; fi

# --- 24. AGENTS.md stays under its own 200-line target ----------------------
#
# ROADMAP 35. This file says "Keep it under 200" and had **already broken it twice
# in two days** -- 201 on 2026-09-05 (invariant 22's table row) and 202 on
# 2026-09-06 (invariant 23's) -- each time caught only because a session happened
# to run `awk` on it by hand. Nothing reported it, and nothing could: invariant 1
# deliberately exempts this file, and the only symptom is that the file is longer.
#
# WHY A CAP HERE AND NOT ELSEWHERE. `CLAUDE.md` and `GEMINI.md` are symlinks to
# AGENTS.md, so it loads into EVERY session in this repo, where the platform's
# guidance is "target under 200 lines" -- long always-loaded files reduce
# adherence. That is a different constraint from invariant 1 (which is about
# incremental *loading* of skills), and the escape is different too: detail moves
# to CONTRIBUTING.md behind a pointer, not to a rules/ file.
#
# CAP, NOT TARGET -- the decision ROADMAP 35 asked for. Gating a "target" is a
# category error, so the word had to be settled before the check could exist. It
# is a cap because the file already states it as an imperative with a named escape
# hatch, which is exactly the shape invariant 1 has. Bumping it is a deliberate
# edit here, visible in review -- the same tripwire stance as EXPECTED_UNPROBED.
#
# THE PROXY QUESTION (rules/10 section 1) applied to this check: the thing that
# makes the cap matter is that the file is loaded every session, and THAT depends
# on the symlinks. A cap enforced on a file nobody loads would pass forever while
# the constraint it stands for had quietly stopped applying. So the symlinks are
# asserted too -- mode 120000 in the index, pointing at AGENTS.md.
echo "[24/34] AGENTS.md is under its own ${MAX_AGENTS}-line target, and is what loads"
v24=0
if [ ! -f AGENTS.md ]; then
  note "AGENTS.md is missing — the file this whole check exists for"
  v24=1
else
  # awk NR, not `wc -l`: counts a final line with no trailing newline too.
  n24=$(awk 'END{print NR}' AGENTS.md)
  if [ "$n24" -ge "$MAX_AGENTS" ]; then
    note "AGENTS.md is ${n24} lines; it must stay UNDER ${MAX_AGENTS} (it loads into every session)."
    note "  Move detail to CONTRIBUTING.md behind a pointer — that is the stated escape."
    v24=1
  fi
  # The cap only means something while these are the same file.
  for link in CLAUDE.md GEMINI.md; do
    mode=$(git ls-files -s -- "$link" | awk '{print $1}')
    if [ -z "$mode" ]; then
      note "$link is not tracked — it must be a symlink to AGENTS.md"
      v24=1
    elif [ "$mode" != "120000" ]; then
      note "$link is mode $mode, not a symlink (120000) — AGENTS.md's cap now guards a file"
      note "  that $link no longer follows, so the constraint silently stopped applying."
      v24=1
    elif [ "$(git cat-file -p ":$link" 2>/dev/null)" != "AGENTS.md" ]; then
      note "$link is a symlink to '$(git cat-file -p ":$link" 2>/dev/null)', not AGENTS.md"
      v24=1
    fi
  done
fi
if [ "$v24" -eq 0 ]; then echo "    ok (${n24:-?} lines, CLAUDE.md + GEMINI.md symlinked)"; else fail=1; fi

# --- 25. Undocumented eval flags may not grow -------------------------------
#
# ROADMAP 36. `--no-gate-arm` shipped in v1.33.0 documented in the root README's
# index and in the runner's own `--help`, and NOT in `evals/README.md` -- the
# harness's front door, the file a person opens to find out what the instruments
# do. It reached that file only because a follow-up sweep went looking. Invariant
# 14 could not catch it: 14 resolves a release's declared front-door terms against
# README.md or docs/INDEX.md, and a term satisfied by either of those is satisfied.
#
# THE OBVIOUS GATE IS THE WRONG ONE, and measuring said so before it was written:
# "every flag appears in evals/README.md" fails on **27 pre-existing (file, flag)
# pairs**, almost all generic plumbing -- `--json`, `--report`, `--build-model`,
# `--judge-model`, `--timeout`. A gate that opens red on 27 items it does not care
# about is a gate someone disables, which docs/CONVENTIONS-LEDGER.md names as
# strictly worse than no gate. And "which flags deserve documentation" is
# judgement: the ones that matter change what the instrument MEASURES, and no
# regex knows that.
#
# ALSO REJECTED, on inspection rather than measurement: adding `evals/README.md`
# to invariant 14's resolution set. 14 requires a declared term in README.md OR
# docs/INDEX.md, so a third accepted location makes it LOOSER -- it would have
# weakened the gate it was meant to reinforce. Recorded because the proposal was
# in ROADMAP 36's own text and reads plausible.
#
# SO: A RATCHET, which is mechanical and needs no cleanup. The count of
# undocumented (file, flag) pairs may not RISE. Adding a documented flag is free;
# adding an undocumented one fails; documenting an old one and lowering the pin is
# a deliberate visible edit. Same stance as EXPECTED_UNPROBED and the same shape as
# `sota-devsecops` rules/05 section 5.6's "fail when the enumerated count drops".
#
# WHAT THIS DOES NOT CHECK, stated here so the green is not read as more than it is:
# "documented" means the flag string appears SOMEWHERE in evals/README.md. Writing
# `--some-flag` inside a sentence explaining that it is undocumented satisfies it. That
# happened on 2026-09-06, to this check's own author, in the paragraph of evals/README.md
# that explains this ratchet -- listing five example flags took the undocumented count
# from 27 to 10 and would have banked seventeen of them as documented on the strength of
# a sentence saying they were not. `sota-testing` rules/06 section 6.3: an assertion keyed
# on something that is true but is not evidence. The slack direction failing is what
# surfaced it, which is the argument for gating BOTH directions of a ratchet.
#
# FAIL CLOSED ON AN EMPTY SCAN. This is a differential check, so it has the defect
# `sota-code-security` rules/11 section 2.2a describes: if the regex drifts and
# finds NO flags, undocumented becomes 0, 0 <= 27, and it passes green forever
# while measuring nothing. The comparand and the denominator are both asserted.
#
# SECOND HALF, ROADMAP 41 (2026-09-09): THE RATCHET CANNOT SEE A WHOLE NEW RUNNER.
# Demonstrated twice. "Documented" is a substring match, so a runner whose flag names
# already appear here from OTHER runners moves the undocumented count by zero:
# `run-routing-recall.py` shipped with six flags (`--selftest`, `--out`, `--model`, ...)
# and every one of them was already in the file. The unit that goes missing is the
# RUNNER, not the (file, flag) pair.
#
# THE FIX ROADMAP 41 PROPOSED IS NOT THE ONE TAKEN. Per-(file, flag) documentation was
# rejected: evals/README.md is organised by the QUESTION each instrument measures, not
# by runner, so per-runner flag sections are structure it does not have; it would reopen
# the same red-on-27 problem one level down; and "which flag deserves a mention in which
# runner's section" is the same judgement call the paragraph above already refuses to
# mechanise. What IS mechanical, at the granularity the defect actually occurred at, is
# PRESENCE OF THE RUNNER: every evals/*.py must be named in evals/README.md. No ratchet
# and no pin -- it opened red on exactly TWO files when written (run-unscoped-audit.py,
# run-build-safe-arms-guided.py), both real instruments, both fixed in the same change.
# A gate that opens red on two things it does care about is the case CONVENTIONS-LEDGER
# argues FOR; the 27-flag one was the case against.
#
# The match is boundary-anchored, not a bare substring: `run-build-safe.py` must not be
# credited to a README that only mentions `run-build-safe-arms.py`.
echo "[25/34] Eval runners documented, undocumented flags not increased (ratchet at ${MAX_UNDOC})"
v25=0
if command -v python3 >/dev/null 2>&1; then
  if flag_out=$(python3 - "$MAX_UNDOC" <<'PY'
import glob, pathlib, re, sys
cap = int(sys.argv[1])
try:
    readme = pathlib.Path("evals/README.md").read_text(encoding="utf-8")
except OSError as e:
    print(f"cannot read evals/README.md: {e}"); print("SCOPE 0"); sys.exit(1)
scanned = 0
undoc = []
runners = sorted(glob.glob("evals/*.py"))
for f in runners:
    src = pathlib.Path(f).read_text(encoding="utf-8")
    for flag in sorted(set(re.findall(r'add_argument\(\s*["\'](--[a-z0-9-]+)["\']', src))):
        scanned += 1
        if flag not in readme:
            undoc.append(f"{f} {flag}")

# ROADMAP 41: the runner itself, at the granularity the defect occurred at.
# Boundary-anchored so run-build-safe.py is not credited to a mention of
# run-build-safe-arms.py.
unnamed = [f for f in runners
           if not re.search(r'(?<![A-Za-z0-9_.\-])%s(?![A-Za-z0-9_])'
                            % re.escape(f.split("/")[-1]), readme)]
if not runners:
    print("no evals/*.py found at all — the scan pattern drifted, and an empty scan")
    print("makes both halves of this check pass for every possible input.")
    print("SCOPE 0"); sys.exit(1)
if unnamed:
    print(f"{len(unnamed)} eval runner(s) are not named in evals/README.md — the file a")
    print("reader opens to find out what an instrument measures. Describe what it")
    print("measures there (a bare filename in a list is not a description):")
    for u in unnamed:
        print(f"  {u}")
    print(f"SCOPE {scanned}"); print(f"RUNNERS {len(runners)}"); sys.exit(1)
# rules/11 section 2.2a + section 2.2: the comparand and the denominator both.
if scanned == 0:
    print("no add_argument flags found in evals/*.py at all — the scan pattern drifted,")
    print("and an empty scan makes this ratchet pass for every possible input.")
    print("SCOPE 0"); sys.exit(1)
if len(undoc) > cap:
    print(f"undocumented eval flags rose to {len(undoc)} (ratchet is {cap}).")
    print("Document the new one in evals/README.md — it is where a reader looks for")
    print("what an instrument measures — or lower/raise MAX_UNDOC deliberately:")
    for u in undoc:
        print(f"  {u}")
    print(f"SCOPE {scanned}"); print(f"RUNNERS {len(runners)}"); sys.exit(1)
if len(undoc) < cap:
    print(f"undocumented eval flags fell to {len(undoc)} — lower MAX_UNDOC to {len(undoc)}")
    print("so the ratchet keeps its grip (a slack ratchet is not a ratchet).")
    print(f"SCOPE {scanned}"); print(f"RUNNERS {len(runners)}"); sys.exit(1)
print(f"SCOPE {scanned}")
print(f"RUNNERS {len(runners)}")
PY
  ); then :; else v25=1; fi
  n25=$(printf '%s\n' "$flag_out" | sed -n 's/^SCOPE //p')
  nr25=$(printf '%s\n' "$flag_out" | sed -n 's/^RUNNERS //p')
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|RUNNERS\ *|'') ;; *) note "$l" ;; esac
  done <<EOF25
$flag_out
EOF25
  scope "${n25:-0}" "eval CLI flags" || v25=1
  if [ "$v25" -eq 0 ]; then echo "    ok (${nr25:-0} runners named, ${n25:-0} flags scanned, ${MAX_UNDOC} undocumented — unchanged)"; fi
else
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
fi
if [ "$v25" -ne 0 ]; then fail=1; fi

# --- 26. The roadmap's open set agrees with itself ------------------------
# Three places carried an item's status and only one was a fact: the ledger
# row's `**OPEN` marker, the header's hand-written open list, and the
# priorities table's *presence*. Restatements drift — measured, three times in
# one session (2026-09-07/08): the priorities table pointed at item 12 whose
# ledger row said the opposite, then at a follow-up with no ledger row at all,
# then at item 38 hours after a release closed it. A fourth was live when this
# check was written: the header listed 8 open while 5 rows carried the marker.
#
# So the LEDGER ROW is the single source of truth for status and everything
# else is derived. This asserts the derivation, which is the only part a
# machine can check — the ordering and the "what to do first" prose stay
# human, which is why the table exists at all.
echo "[26/34] Roadmap: open count, open list and priorities table agree"
v26=0
if command -v python3 >/dev/null 2>&1; then
  rm_out=$(python3 - "docs/ROADMAP.md" <<'RMPY'
import re, sys, pathlib
try:
    t = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
except OSError as e:
    print("cannot read: %s" % e); print("SCOPE 0"); sys.exit(1)

# "are" / "is": the count reached 1 on 2026-09-12 and the plural-only pattern
# stopped matching, which this check reports as a MISSING header rather than as
# a grammar mismatch — a confusing failure for a correct document. Widened, not
# loosened: the count and the list are still both required.
m = re.search(r'\*\*Only (\d+) (?:are|is) open\*\*\s*[—-]\s*([0-9,\s]+)', t)
if not m:
    print("no '**Only N are/is open** — a, b, c' header found in docs/ROADMAP.md")
    print("SCOPE 0"); sys.exit(1)
stated = int(m.group(1))
listed = {int(x) for x in re.findall(r'\d+', m.group(2))}

marked = {int(x) for x in re.findall(r'(?m)^\|\s*(\d+)\s*\|\s*\*\*OPEN\b', t)}

pt = re.search(r'(?ms)^\| P \| Item \|.*?\n\n', t)
cited = {int(x) for x in re.findall(r'\*\*Item (\d+)', pt.group(0))} if pt else set()

bad = 0
if stated != len(listed):
    bad = 1
    print("header says %d open but lists %d numbers: %s"
          % (stated, len(listed), sorted(listed)))
if listed != marked:
    bad = 1
    only_h = sorted(listed - marked); only_r = sorted(marked - listed)
    if only_h:
        print("listed as open in the header but no ledger row marked '**OPEN': %s" % only_h)
    if only_r:
        print("ledger row marked '**OPEN' but missing from the header list: %s" % only_r)
if not pt:
    bad = 1
    print("priorities table not found — expected a '| P | Item |' table")
else:
    stale = sorted(cited - listed)
    if stale:
        bad = 1
        print("priorities table points at item(s) not in the open list: %s "
              "(a summary must cite the ledger, never restate it)" % stale)

print("SCOPE %d" % len(listed))
if bad:
    sys.exit(1)
print("    ok (%d open items; header, ledger markers and priorities table agree)" % len(listed))
RMPY
) || v26=1
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'    ok ('*|'') ;; *) note "$l" ;; esac
  done <<EOF26
$rm_out
EOF26
  n26=$(printf '%s\n' "$rm_out" | sed -n 's/^SCOPE //p')
  scope "${n26:-0}" "open roadmap items" || v26=1
  if [ "$v26" -eq 0 ]; then printf '%s\n' "$rm_out" | grep '^    ok ('; fi
else
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
fi
if [ "$v26" -ne 0 ]; then fail=1; fi

# --- 27. A deferral names its revisit trigger --------------------------------
# docs/ADOPTION-LOG.md's own rule: "nothing stays open here; if it needs more
# thought it is `deferred` with the condition to revisit". That was prose, and
# prose drifted — on 2026-09-09 the roadmap called it "THE deferred row",
# singular, while three existed and one had been resolved the day before in a
# different entry. Same restated-status shape as invariant 26, one file over.
# So a deferral carries a marker, and the marker carries its trigger.
echo "[27/34] Every ADOPTION-LOG deferral names its revisit trigger"
v27=0
if command -v python3 >/dev/null 2>&1; then
  df_out=$(python3 - "docs/ADOPTION-LOG.md" <<'DFPY'
import re, sys, pathlib
try:
    t = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
except OSError as e:
    print("cannot read: %s" % e); print("SCOPE 0"); sys.exit(1)
# a MARKER is `**DEFERRED —` opening a bullet or a table cell; a mention inside
# the how-this-works prose is not one, so anchor on the line's start.
# The marker opens a bullet OR a table CELL — most of this log is table rows where
# the verdict is the fourth cell, so anchoring at line start found 1 of 2 and would
# have been inert for the log's dominant shape. Prose mentions are inside backticks
# (`write \`**DEFERRED —\``), which neither ^ nor | precedes, so they stay out.
marks = [l for l in t.splitlines()
         if re.search(r'(?:^|\|)\s*(?:-\s+)?\*\*DEFERRED\s+—', l)]
bad = 0
TRIG = re.compile(r'revisit|until|once|if a second|when |trigger', re.I)
# Look in the marker's OWN CELL, not the whole row. Checking the line let a table
# row pass because "revisit" appeared in a different cell — a catch for the wrong
# reason, which is a false pass rather than a catch (`sota-code-security` rules/15).
for l in marks:
    cell = next((c for c in (l.split('|') if '|' in l else [l])
                 if 'DEFERRED' in c), l)
    if not TRIG.search(cell):
        bad = 1
        print("deferral whose marker cell names no revisit trigger: %s" % cell.strip()[:90])
print("SCOPE %d" % len(marks))
if bad: sys.exit(1)
print("    ok (%d deferral(s), each naming a trigger)" % len(marks))
DFPY
) || v27=1
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'    ok ('*|'') ;; *) note "$l" ;; esac
  done <<EOF27
$df_out
EOF27
  n27=$(printf '%s\n' "$df_out" | sed -n 's/^SCOPE //p')
  scope "${n27:-0}" "adoption-log deferrals" || v27=1
  if [ "$v27" -eq 0 ]; then printf '%s\n' "$df_out" | grep '^    ok ('; fi
else
  note "SKIPPED (python3 not found; CI always has it)"; echo "    ok (skipped)"
fi
if [ "$v27" -ne 0 ]; then fail=1; fi

# --- 28. Every eval case set declares how its cases were chosen --------------
# ROADMAP 23/24 established this and it held at 20 sets; two were added after
# and one skipped it — `prompt-independence.jsonl`, which backs the +0.509
# headline. Its rule existed in the results doc and not in the case file, which
# is where a reader opening the set looks. Selecting cases by outcome is the
# defect this guards (`sota-llm-engineering` rules/01 §8): a set built from what
# a model got wrong measures the selection, not the system.
echo "[28/34] Every evals/cases/*.jsonl declares a SELECTION RULE"
v28=0
n28=0; bad28=""
for f in evals/cases/*.jsonl; do
  [ -e "$f" ] || continue
  n28=$((n28 + 1))
  grep -qi 'SELECTION RULE' "$f" || bad28="$bad28 $f"
done
for f in $bad28; do note "no 'SELECTION RULE' comment: $f"; v28=1; done
scope "$n28" "eval case sets" || v28=1
if [ "$v28" -eq 0 ]; then echo "    ok ($n28 case sets, each declaring how its cases were chosen)"; fi
if [ "$v28" -ne 0 ]; then fail=1; fi

# --- 29. A release that changes the routing surface says it re-ran routing ---
# ROADMAP 44. A skill added in v1.35.0 silently took a neighbour's traffic and was
# live for a day. `sota-skill-security` contains "instruction file" twice and neither
# "token" nor "budget", so the description classifier matched the NOUN in
# `r1_token_count` over its QUESTION and the case inverted from
# sota-llm-engineering 3/3 to sota-skill-security 3/3. Found only because someone
# ran the regression set for the second time ever.
#
# NOTHING COULD SEE IT. Invariant 4 checks a description exists and is under the cap,
# 7 that the skill is in the routing table, 15 that it is in the library map. All three
# passed. A description is the ENTIRE auto-load classifier, and adding one competes with
# every existing one for traffic -- a change to the shared surface, dressed as an
# addition to a private one.
#
# WHY THIS IS NOT A CI GATE ON THE RUN ITSELF: routing costs live API calls, and
# docs/CONVENTIONS-LEDGER.md's standing argument is that a gate expensive enough to be
# disabled is worse than none. So this gates the DECLARATION, exactly as invariant 14
# gates the front-door check and invariant 11 gates the sweep -- an escape hatch that
# is a statement which must be TRUE, not a checkbox.
#
# It fires only when BOTH hold: this is a release commit (VERSION changed against the
# merge base, the same detection invariant 14 uses) AND the extracted (name, description)
# map differs from the merge base's. Comparing the extracted MAP, not the diff, is
# deliberate: a description can be a folded block, so `+description:` in a diff misses
# an edit to its second line, and a renamed or deleted skill changes routing without
# touching any surviving description at all.
#
# The declaration names an artifact, and the artifact is checked: it must exist and
# must mention the regression case set, so declaring an unrelated file fails. The run
# is cheap -- 2 cases x 3 samples x 2 arms is about 12 calls -- which is what makes a
# release-time trigger the right price for a defect that shipped for a day.
echo "[29/34] A release changing skill descriptions declares a routing check"
v29=0
base29=""
for ref in origin/main main; do
  if git rev-parse --verify -q "$ref" >/dev/null 2>&1; then
    base29=$(git merge-base HEAD "$ref" 2>/dev/null || true)
    [ -n "$base29" ] && break
  fi
done
if [ -z "$base29" ] || [ "$base29" = "$(git rev-parse HEAD)" ]; then
  note "SKIPPED (no merge base to diff against, or nothing ahead of it)"
  echo "    ok (skipped)"
elif ! git diff --name-only "$base29"...HEAD | grep -qx 'VERSION'; then
  echo "    ok (not a release commit — VERSION unchanged)"
elif ! command -v python3 >/dev/null 2>&1; then
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
else
  # THE SECTION IS READ BY PYTHON, NOT PIPED IN. The first draft did
  # `printf '%s' "$sec29" | python3 - "$base29" <<'ROUTEPY'`, where the heredoc and the
  # pipe both claim stdin: the heredoc wins, python reads its own SCRIPT, and
  # `sys.stdin.read()` returns "". The declaration was therefore ALWAYS empty, so the
  # escape hatch could never fire and a correct release would have been failed. Probe 29
  # passed on that build (it asserts the no-declaration branch, which was the only
  # reachable one); probe 29b is what caught it, which is the argument for probing both
  # sides of an escape hatch and not just the failure it is meant to produce.
  routed_out=$(python3 - "$base29" <<'ROUTEPY'
import pathlib, re, subprocess, sys

base = sys.argv[1]

# Read the release's own CHANGELOG section here rather than accepting it on stdin: this
# script arrives on stdin itself, so anything piped alongside it is discarded silently.
ver = pathlib.Path("VERSION").read_text(encoding="utf-8").strip()
section, in_sec = [], False
for line in pathlib.Path("CHANGELOG.md").read_text(encoding="utf-8").splitlines():
    if line.startswith(f"## [{ver}]"):
        in_sec = True
    elif in_sec and line.startswith("## ["):
        break
    if in_sec:
        section.append(line)
section = "\n".join(section)

FM = re.compile(r'\A---\r?\n(.*?)\r?\n---', re.S)


def descs(read):
    """{skill dir: (name, description)} — extracted, never diffed. Handles an inline
    scalar and a folded/literal block; an unparseable frontmatter is recorded as a
    distinct sentinel rather than dropped, so a file that BECOMES unparseable counts
    as a change instead of silently matching."""
    out = {}
    for path in sorted(pathlib.Path("skills").glob("*/SKILL.md")):
        raw = read(str(path))
        if raw is None:
            continue
        m = FM.match(raw)
        if not m:
            out[path.parent.name] = ("<unparseable frontmatter>", "")
            continue
        fm, name, desc, mode = m.group(1), "", [], None
        for line in fm.splitlines():
            k = re.match(r'^(name|description):\s*(.*)$', line)
            if k:
                mode = k.group(1)
                val = k.group(2).strip()
                if mode == "name":
                    name = val
                elif val in (">", ">-", "|", "|-", ""):
                    desc = []
                else:
                    desc = [val]; mode = None
                continue
            if mode == "description" and (line.startswith(" ") or line.startswith("\t")):
                desc.append(line.strip())
            elif line and not line[0].isspace():
                mode = None
        out[path.parent.name] = (name, " ".join(desc).strip())
    return out


def at_base(p):
    try:
        return subprocess.check_output(["git", "show", f"{base}:{p}"],
                                       stderr=subprocess.DEVNULL).decode("utf-8")
    except subprocess.CalledProcessError:
        return None


def on_disk(p):
    try:
        return pathlib.Path(p).read_text(encoding="utf-8")
    except OSError:
        return None


now, then = descs(on_disk), descs(at_base)
if not now:
    print("no skills/*/SKILL.md found at all — the scan drifted, and an empty scan makes")
    print("this check pass for every possible release.")
    print("SCOPE 0"); sys.exit(1)

changed = sorted(set(now) ^ set(then)) + sorted(
    k for k in set(now) & set(then) if now[k] != then[k])
print(f"SCOPE {len(now)}")
if not changed:
    print(f"    ok (release, {len(now)} descriptions unchanged since the merge base)")
    sys.exit(0)

decl = ""
for line in section.splitlines():
    if re.match(r'^\*\*Routing checked:\*\*', line, re.I):
        decl = line
        break
if not decl:
    print("this release changes the routing surface — the description classifier —")
    print("for: " + ", ".join(changed))
    print("A description is the whole auto-load classifier, so adding or editing one")
    print("competes for every neighbour's traffic (ROADMAP 44). Run the regression set:")
    print("  python3 evals/run-desc-routing.py --samples 3 \\")
    print("      --cases evals/cases/desc-routing-regressions.jsonl")
    print("then add to this release's CHANGELOG section (RELEASING.md §2c):")
    print("  **Routing checked:** evals/results/<date>/<write-up>.md")
    sys.exit(1)

target = re.sub(r'^\*\*Routing checked:\*\*', '', decl, flags=re.I)
target = target.strip().strip('`* .')
if not target:
    print("**Routing checked:** names no artifact")
    sys.exit(1)
art = pathlib.Path(target)
if not art.exists():
    print(f"**Routing checked:** names {target}, which does not exist in the tree")
    sys.exit(1)
body = art.read_text(encoding="utf-8", errors="replace")
if "desc-routing-regressions" not in body:
    print(f"{target} exists but never mentions desc-routing-regressions — a declaration")
    print("that resolves to an unrelated file is not evidence the routing set was run.")
    sys.exit(1)
print(f"    ok (release, {len(changed)} description(s) changed, routing checked in {target})")
ROUTEPY
  ) || v29=1
  n29=$(printf '%s\n' "$routed_out" | sed -n 's/^SCOPE //p')
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'    ok ('*|'') ;; *) note "$l" ;; esac
  done <<EOF29
$routed_out
EOF29
  scope "${n29:-0}" "skill descriptions" || v29=1
  if [ "$v29" -eq 0 ]; then printf '%s\n' "$routed_out" | grep '^    ok ('; fi
fi
if [ "$v29" -ne 0 ]; then fail=1; fi

# --- 30. A spelled-out count agrees with the list it counts ----------------
# The class this closes, found at the v1.41.2 cut: README.md opened its audit
# section with "Eleven classes of defect survive every linter" above a list of
# **26**. Correct when written (2026-08-27, confirmed by counting the list at
# that commit) and fifteen behind seventeen days later. THREE gates sat next to
# it and none had the predicate: invariant 6 counts the skills/ tree, 17 counts
# claims about the SCRIPTS, 26 counts the roadmap's open set. A count whose
# denominator is a LIST IN THE SAME DOCUMENT had nothing.
#
# Two more live instances the same sweep found: docs/ROADMAP.md "Of 55 items"
# (56), docs/WHY-IT-WORKS.md "Fourteen invariants" (29).
#
# WHY OPT-IN, and not a sweep. Measured before building, per the ledger's own
# advice: a regex for <number-word> <plural-noun> over the front-door docs and
# docs/ returns ~200 hits, nearly all historical prose in CHANGELOG and
# ADOPTION-LOG entries that must NOT change. A strict auto-detecting rule opens
# red and gets disabled, which is worse than none (docs/CONVENTIONS-LEDGER.md).
# So the pairing is DECLARED, next to the claim, where it travels with the prose
# rather than living in a registry someone must remember to extend:
#
#     <!-- count-check: ^- \*\* -->
#     Twenty-nine classes of defect survive every linter, ...
#
# The marker names the pattern; the claim is the next non-empty line; the scope
# runs from the marker to the next Markdown heading. Counting the list is the
# whole point -- the stated number is never trusted, only compared.
#
# WHAT THIS CANNOT SEE, written down rather than discovered later: the scope is
# positional, so ANY prose between the list and the next heading that contains the
# pattern is counted as an item. That is not hypothetical -- it happened while this
# check was being landed, in a sentence DESCRIBING the marker: writing the literal
# separator inside a correction note added a phantom entry to the very list the
# note was about. Keep the scope tight, and refer to a separator by name rather
# than by character in any prose that shares a section with it.
#
# Fails closed on an empty scan (zero markers), the repo's standing rule: a
# gate that examines nothing must not report ok.
echo "[30/34] A declared count agrees with the list it counts"
v30=0
if command -v python3 >/dev/null 2>&1; then
  cnt_out=$(python3 - <<'CNTPY'
import re, sys, pathlib, subprocess

WORD = {"zero":0,"one":1,"two":2,"three":3,"four":4,"five":5,"six":6,"seven":7,
        "eight":8,"nine":9,"ten":10,"eleven":11,"twelve":12,"thirteen":13,
        "fourteen":14,"fifteen":15,"sixteen":16,"seventeen":17,"eighteen":18,
        "nineteen":19,"twenty":20,"thirty":30,"forty":40,"fifty":50,"sixty":60,
        "seventy":70,"eighty":80,"ninety":90}

def to_int(tok):
    tok = tok.strip().lower().replace("‑", "-")
    if tok.isdigit():
        return int(tok)
    parts = re.split(r"[- ]", tok)
    if len(parts) == 2 and parts[0] in WORD and parts[1] in WORD:
        return WORD[parts[0]] + WORD[parts[1]]
    return WORD.get(tok)

# Tokenise, then try an adjacent PAIR before each single token, so "twenty-nine"
# parses as 29 and "eleven classes" parses as 11 rather than failing. The first
# draft used one greedy regex ("[A-Za-z]+(?:[- ][A-Za-z]+)?") written against the
# sample in front of it: it read "Twenty-nine" correctly by luck and read "Eleven
# classes" as a single unparseable token, so the real historical defect was caught
# with the WRONG diagnostic ("no number in the claim line"). Probe 30 asserts on the
# comparison's own wording and would have reported NOT CAUGHT -- which is how this
# was found. rules/15 2.1, applied to this file.
TOK = re.compile(r"[A-Za-z]+|\d+")

def first_number(line):
    toks = TOK.findall(line)
    for i, tok in enumerate(toks):
        if i + 1 < len(toks):
            v = to_int(tok + "-" + toks[i + 1])
            if v is not None:
                return v
        v = to_int(tok)
        if v is not None:
            return v
    return None
# An optional trailing "+N" offset exists for ONE real shape: an inline list whose
# items are SEPARATED rather than prefixed, where k separators mean k+1 items.
# docs/CONVENTIONS-LEDGER.md is that shape, and it is not a hypothetical -- its own
# text records the same drift there THREE times (heading right, list short), because
# invariant 17 reads the stated count and never the list.
MARK = re.compile(r"^<!--\s*count-check:\s*(.+?)\s*(?:\+(\d+)\s*)?-->\s*$")
HEAD = re.compile(r"^#{1,6}\s")

try:
    files = subprocess.run(["git", "ls-files", "*.md"], capture_output=True,
                           text=True, check=True).stdout.split()
except Exception as e:
    print("cannot list files: %s" % e); print("SCOPE 0"); sys.exit(1)

checked = bad = 0
for f in files:
    try:
        lines = pathlib.Path(f).read_text(encoding="utf-8").split("\n")
    except OSError:
        continue
    fence = False
    for i, line in enumerate(lines):
        # A marker inside a ``` fence is DOCUMENTATION of the marker, not a marker --
        # the same distinction invariant 22 draws for checklist bullets. Found by this
        # check failing on the CHANGELOG entry that announced it, where the worked
        # example in a ```markdown block was read as a live declaration over an empty
        # list. A gate that cannot tell its own documentation from its own input would
        # make every doc that explains it unwritable.
        if line.lstrip().startswith("```"):
            fence = not fence
            continue
        if fence:
            continue
        m = MARK.match(line)
        if not m:
            continue
        checked += 1
        try:
            pat = re.compile(m.group(1))
        except re.error as e:
            print("%s:%d bad count-check regex %r: %s" % (f, i + 1, m.group(1), e))
            bad = 1
            continue
        # the claim is the next non-empty line
        claim = next((l for l in lines[i + 1:] if l.strip()), "")
        stated = first_number(claim)
        if stated is None:
            print("%s:%d count-check marker, but no number in the claim line: %s"
                  % (f, i + 1, claim.strip()[:70]))
            bad = 1
            continue
        # scope: marker -> next heading. Count OCCURRENCES, not matching lines:
        # an anchored pattern like "^- \*\*" matches at most once per line either
        # way, but a separator pattern needs every hit on the line.
        offset = int(m.group(2)) if m.group(2) else 0
        actual = offset
        for l in lines[i + 1:]:
            if HEAD.match(l):
                break
            actual += len(pat.findall(l))
        if stated != actual:
            print("%s:%d says %d but the list below it has %d match(es) of %r"
                  % (f, i + 1, stated, actual, m.group(1)))
            print("     claim: %s" % claim.strip()[:78])
            print("     recount, then restate -- never carry the number across an edit")
            bad = 1

print("SCOPE %d" % checked)
sys.exit(1 if bad else 0)
CNTPY
  ) || v30=1
  n30=$(printf '%s\n' "$cnt_out" | sed -n 's/^SCOPE //p')
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'') ;; *) note "$l" ;; esac
  done <<EOF30
$cnt_out
EOF30
  scope "${n30:-0}" "declared count-check markers" || v30=1
  if [ "$v30" -eq 0 ]; then echo "    ok ($n30 declared counts, each matching its list)"; fi
else
  note "python3 not available — count-check not verified"
  v30=1
fi
if [ "$v30" -ne 0 ]; then fail=1; fi

# --- 31. New rule text ships with a line in the intake ledger ---------------
# The gap this closes was found by auditing THIS repository's own gates on
# 2026-09-13: all 30 checks assert structure, consistency or a declaration, and
# NONE of them looks at whether a rule's content is true. That is not fixable in
# general -- "is this claim correct" is semantic, and rules/12 2 is explicit that
# a fuzzy gate gets disabled and leaves you worse off (docs/CONVENTIONS-LEDGER.md).
#
# So this gates the thing that IS mechanical: whether the rule went through review
# at all. `docs/ADOPTION-LOG.md` is where an idea's verdict and reasoning are
# recorded, and an EXTERNAL proposal always lands there -- while a rule the author
# both discovered and adopted never does, which is exactly the path that skips
# scrutiny. Same declaration shape as checks 14 and 29: it gates the record, not
# the judgement.
#
# THE INCIDENT. `sota-code-security` rules/12 1d was authored and adopted in one
# session and was about to ship on 30 green checks. An adversarial read returned
# ELEVEN defects -- an over-generalisation refuted by four probes in the harness the
# rule itself cited, an unmeasured comparative claim, a section reference that
# RESOLVED (check 18 green) while its target grounded the opposite prior, a default
# that inverted the harness's own semantics, and a self-contradiction shipped across
# two files in the same branch. Every gate was green on all eleven.
#
# A MOVED HEADING IS NOT A NEW RULE. This repo splits rules files regularly, and a
# split re-adds every heading it carries across. Without that exemption this check
# would fire on every split, open red, and be disabled -- the failure mode the
# ledger warns about. A heading counts as new only if that exact text existed in NO
# rules file at the merge base, which makes a split free and a genuine addition
# visible. There is deliberately no manual escape hatch: the moved-heading test
# removes the only large false-positive class, and an escape nobody can trip is a
# checkbox (probe 29b).
echo "[31/34] New rule sections ship with an ADOPTION-LOG entry"
v31=0
base31=""
for ref in origin/main main; do
  if git rev-parse --verify -q "$ref" >/dev/null 2>&1; then
    base31=$(git merge-base HEAD "$ref" 2>/dev/null || true)
    [ -n "$base31" ] && break
  fi
done
if [ -z "$base31" ] || [ "$base31" = "$(git rev-parse HEAD)" ]; then
  note "SKIPPED (no merge base to diff against, or nothing ahead of it)"
  echo "    ok (skipped)"
elif ! command -v python3 >/dev/null 2>&1; then
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
else
  intake_out=$(BASE31="$base31" python3 - <<'INTPY'
import os, re, subprocess, sys

base = os.environ["BASE31"]

def git(*a):
    return subprocess.run(["git", *a], capture_output=True, text=True, check=True).stdout

changed = [p for p in git("diff", "--name-only", f"{base}...HEAD").split("\n") if p]
touched_ledger = "docs/ADOPTION-LOG.md" in changed
rules = [p for p in changed
         if re.fullmatch(r"skills/[^/]+/rules/[^/]+\.md", p or "")]

# Every heading that existed anywhere in rules/ at the merge base. A heading that
# merely MOVED is not new guidance, and splits move many at once.
old_headings = set()
for line in git("ls-tree", "-r", "--name-only", base).split("\n"):
    if re.fullmatch(r"skills/[^/]+/rules/[^/]+\.md", line or ""):
        try:
            blob = git("show", f"{base}:{line}")
        except subprocess.CalledProcessError:
            continue
        for l in blob.split("\n"):
            if re.match(r"^#{2,3} ", l):
                old_headings.add(l.strip())

added, relocated = [], 0
for p in rules:
    diff = git("diff", "--unified=0", f"{base}...HEAD", "--", p)
    for l in diff.split("\n"):
        if not l.startswith("+") or l.startswith("+++"):
            continue
        head = l[1:].strip()
        if not re.match(r"^#{2,3} ", head):
            continue
        if head.startswith("## Audit checklist"):
            continue          # structural, and check 2 already owns it
        if head in old_headings:
            relocated += 1    # moved, not new
            continue
        added.append((p, head))

# REPORT WHAT WAS EXEMPTED, not only what was caught. Without this a relocated heading
# and no heading at all produce the SAME line, so the exemption is unobservable and a
# probe asserting it held has nothing stable to read. rules/11 2.2, turned on ourselves.
exempt = ", %d relocated" % relocated if relocated else ""

print("SCOPE %d" % len(rules))
if not added:
    print("    ok (%d rules file(s) changed, no new sections%s)" % (len(rules), exempt))
    sys.exit(0)
if touched_ledger:
    print("    ok (%d new rule section(s)%s, ADOPTION-LOG updated)" % (len(added), exempt))
    sys.exit(0)
print("new rule section(s) with no docs/ADOPTION-LOG.md entry in the same change:")
for p, head in added[:6]:
    print("  %s  %s" % (p, head[:72]))
if len(added) > 6:
    print("  ... and %d more" % (len(added) - 6))
print("A rule you both found AND adopted never passes the intake an external")
print("proposal gets. Record the verdict and what you checked, or move the")
print("section without rewriting its heading if it is a relocation.")
sys.exit(1)
INTPY
  ) || v31=1
  # NO `scope` GUARD HERE, deliberately. Every other file-list check fails closed on an
  # empty scope, because examining zero files means the pathspec drifted. Here zero rules
  # files changed is the NORMAL case -- most PRs touch no rule text at all -- so a scope
  # guard would fail every ordinary PR. Same reasoning as check 14's "not a release
  # commit". The SCOPE line is printed for the reader, not consumed; shellcheck flagged
  # the unused variable that used to hold it (SC2034) and it is gone rather than silenced.
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'    ok ('*|'') ;; *) note "$l" ;; esac
  done <<EOF31
$intake_out
EOF31
  if [ "$v31" -eq 0 ]; then printf '%s\n' "$intake_out" | grep '^    ok ('; fi
fi
if [ "$v31" -ne 0 ]; then fail=1; fi

# --- 32. No absence reported through a stderr-suppressed `|| echo` -----------
# THE INCIDENT (2026-09-15, field-reported). Nine skills shipped
# `cmd … 2>/dev/null || echo "missing X"` in their AUDIT CHECKLISTS. The `||` arm is
# meant to mean "the pattern was absent". It fires on EVERY non-zero exit, and the
# `2>/dev/null` has already destroyed the evidence of which: grep exits 1 for no-match
# and 2 for an unreadable or missing path, and `||` cannot tell them apart. With one
# missing path in the list the line printed the match it had just found AND the verdict
# contradicting it. `ls a b c 2>/dev/null || echo …` is the same bug -- ls prints what it
# found and still exits non-zero.
#
# WHY IT EARNS A GATE. The failure is DIRECTIONAL: it manufactures findings about other
# people's code rather than hiding them, so the output looks like a real defect and gets
# filed. It shipped in the guidance of seven skills for months and no gate could see it.
# Three filters from docs/CONVENTIONS-LEDGER.md, all passed: it has already failed (13
# sites), it fails silently (exit 0, plausible output), and it is mechanically checkable
# (one regex on a fenced block).
#
# WHY NOT SHELLCHECK. Measured before building this: `shellcheck -S style` exits 0 on the
# exact broken line. It is a SEMANTIC defect, not a syntax or quoting one, so the general
# linter cannot reach it. And linting every fenced block is not viable either -- extracting
# the 161 sh/bash blocks and running `shellcheck -S error` yields 19 complaints, nearly all
# artifacts of a FRAGMENT (`local` outside a function, half a loop shown for illustration).
# A gate that opens red gets disabled (rules/12 §2), so this one is narrow on purpose.
#
# PRESCRIPTIVE FENCES ONLY. ```sh and ```bash are instructions the reader will run.
# ```console is a transcript -- rules/06 §2d DEMONSTRATES the broken form inside one, and
# a gate that cannot tell its own documentation from its input makes that section
# unwritable. Same distinction checks 22 and 31 draw. `|| true` is excluded: a best-effort
# write to a read-only path is the documented, correct use (sota-devsecops rules/09).
echo "[32/34] No absence reported through a stderr-suppressed '|| echo'"
v32=0
if command -v python3 >/dev/null 2>&1; then
  idiom_out=$(python3 - <<'IDPY'
import re, subprocess, pathlib
BAD = re.compile(r'2>/dev/null\s*\|\|\s*(echo|printf)')
files = [f for f in subprocess.run(["git","ls-files"],capture_output=True,text=True).stdout.split()
         if (f.startswith("skills/") or f.startswith("commands/")) and f.endswith(".md")]
print("SCOPE %d" % len(files))
bad = 0
for f in files:
    try:
        text = pathlib.Path(f).read_text(encoding="utf-8")
    except OSError:
        continue
    fence = None
    for i, line in enumerate(text.split("\n"), 1):
        s = line.lstrip()
        if s.startswith("```"):
            lang = s[3:].strip().lower()
            fence = None if fence is not None else (lang or "plain")
            continue
        if fence in ("sh", "bash") and BAD.search(line):
            print("%s:%d  %s" % (f, i, line.strip()[:80]))
            bad += 1
if bad:
    print("  `||` fires on EVERY non-zero exit and 2>/dev/null destroyed the reason.")
    print("  grep exits 1 for no-match, 2 for an unreadable path -- indistinguishable here,")
    print("  so this reports YOUR broken sweep as a finding about THEIR code.")
    print("  Branch on the exit code and keep stderr (sota-shell-scripting rules/06 2d).")
raise SystemExit(1 if bad else 0)
IDPY
  ) || v32=1
  n32=$(printf '%s\n' "$idiom_out" | sed -n 's/^SCOPE //p')
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'') ;; *) note "$l" ;; esac
  done <<EOF32
$idiom_out
EOF32
  scope "${n32:-0}" "instruction files" || v32=1
  if [ "$v32" -eq 0 ]; then echo "    ok (${n32:-0} instruction files)"; fi
else
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
fi
if [ "$v32" -ne 0 ]; then fail=1; fi

# --- 33. Every top-level area declares what gates it -------------------------
# THE GAP (measured 2026-09-16). Enforcement density is uneven and unevenness is
# INVISIBLE: an area with no gates looks exactly like a covered one from outside.
# `skills/**` (70,200 lines) carries ~20 of the checks above; `commands/**` -- 494
# lines of instructions an agent EXECUTES ON INVOCATION, in any project -- carried two, and nobody
# had decided that. It was added 2026-09-14 and nothing asked the question.
#
# WHY A DECLARATION AND NOT A RATIO. An invariants-per-KLOC floor is arbitrary: the
# right number for a 2-file asset directory is not the right number for 70k lines of
# instructions, and a threshold nobody can defend gets tuned until it passes. This
# gates what is mechanical instead -- every top-level area appears in the coverage
# table with the gates that cover it, or a stated reason it is thin. Same shape as
# check 19 (every check declares a known-bad or a pinned reason), 27 (every deferral
# names a trigger), 28 (every case set declares its selection rule). It forces a
# decision when an area is added; it does not pretend to know the right amount.
#
# WHY IT IS WORTH A CHECK. Ten areas appeared in the repo's first three months --
# about one per ten days -- and the newest arrived under-covered. It will recur.
# Both directions, like check 15: an undeclared area fails, and so does a row for an
# area that no longer exists (that is how a table rots into decoration).
echo "[33/34] Every top-level area declares what gates it"
v33=0
if command -v python3 >/dev/null 2>&1; then
  cov_out=$(python3 - <<'COVPY'
import re, subprocess, pathlib
LEDGER = "docs/CONVENTIONS-LEDGER.md"
areas = sorted({p.split("/")[0] for p in
                subprocess.run(["git","ls-files"],capture_output=True,text=True).stdout.split()
                if "/" in p})
print("SCOPE %d" % len(areas))
try:
    text = pathlib.Path(LEDGER).read_text(encoding="utf-8")
except OSError:
    print("cannot read %s" % LEDGER); raise SystemExit(1)
m = re.search(r"^## Coverage by area.*?^\| area \|.*?$(.*?)(?=^## )", text, re.S | re.M)
if not m:
    print("%s has no '## Coverage by area' table -- check 33 has nothing to read." % LEDGER)
    raise SystemExit(1)
declared = set(re.findall(r"^\|\s*`([^`]+)/`\s*\|", m.group(1), re.M))
bad = 0
for a in areas:
    if a not in declared:
        print("UNDECLARED AREA: %s/ is tracked but absent from the coverage table in %s" % (a, LEDGER))
        print("  Add a row naming the gates that cover it, or say why it is thin.")
        bad = 1
for d in sorted(declared - set(areas)):
    print("ORPHAN ROW: the table declares %s/ but nothing tracked lives there." % d)
    bad = 1
raise SystemExit(1 if bad else 0)
COVPY
  ) || v33=1
  n33=$(printf '%s\n' "$cov_out" | sed -n 's/^SCOPE //p')
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'') ;; *) note "$l" ;; esac
  done <<EOF33
$cov_out
EOF33
  scope "${n33:-0}" "top-level areas" || v33=1
  if [ "$v33" -eq 0 ]; then echo "    ok (${n33:-0} top-level areas, each declaring its gates)"; fi
else
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
fi
if [ "$v33" -ne 0 ]; then fail=1; fi

# --- 34. A version this repo claims for itself must exist ---------------------
# THE INCIDENT, four times, twice in one session (2026-09-16). A rules file's header
# says which release a section moved in. That version is written WHEN THE FILE IS
# EDITED, which is before the cut decides whether the release is a minor or a patch.
# Guess minor, ship patch, and the prose points at a release that never existed:
#
#   rules/08 + 4 others  claimed v1.43.0   shipped in v1.42.2
#   rules/05 header      claimed v1.36.4   shipped in v1.37.0
#   ADOPTION-LOG row     claimed v1.41.3   shipped in v1.42.0
#   rules/11 + 2 others  claimed v1.42.3   still unreleased
#
# The fourth was written THREE HOURS AFTER the third was fixed, by the same author,
# in a commit whose message named the mechanism. A warning does not disable a reflex;
# that is the whole argument for gating it rather than documenting it again.
#
# SCOPE IS THE DESIGN WORK, and it was measured before this was written. "Every
# vX.Y.Z must be a tag" is NOT viable: 35 distinct unresolved strings, nearly all
# legitimate third-party versions (Harbor v2.5.1, actions/checkout v7.0.1). That gate
# opens red and gets disabled. Narrowing to our own v1.* namespace still catches
# placeholder image tags and module specs (`app:v1.2.3`, `require foo v1.2.3`), and
# rewriting six unrelated rules files to suit a gate is letting the gate drive the
# content. What separates them is GRAMMAR: our own claims read "at v1.42.2", "in
# v1.36.0", "· v1.42.0" -- a preposition or the ledger's bullet. A placeholder never
# does. Measured on this tree: 49 claim-shaped references, 0 unresolved.
#
# RECORDS ARE EXEMPT. CHANGELOG.md and docs/ADOPTION-LOG.md QUOTE wrong versions while
# correcting them -- that is what a record is for, and gating them would make the
# correction unwritable (the same distinction checks 22, 31 and 32 draw).
#
# The fix when this fires is NOT to invent a number: write "· unreleased" and let the
# release cut fill it in, which RELEASING.md step 1 already sweeps for.
echo "[34/34] A version this repo claims for itself exists"
v34=0
if command -v python3 >/dev/null 2>&1; then
  ver_out=$(python3 - <<'VERPY'
import re, subprocess, pathlib
tags = set(subprocess.run(["git","tag","-l"],capture_output=True,text=True).stdout.split())
cur = "v" + pathlib.Path("VERSION").read_text(encoding="utf-8").strip()
PAT = re.compile(r'(?:\bat|\bin|\bsince|\buntil|\bshipped in|·)\s+(v1\.\d+\.\d+)')
RECORDS = {"CHANGELOG.md", "docs/ADOPTION-LOG.md"}
files = [f for f in subprocess.run(["git","ls-files"],capture_output=True,text=True).stdout.split()
         if f.endswith(".md") and f not in RECORDS and not f.startswith("docs/CHANGELOG-archive")]
print("SCOPE %d" % len(files))
bad = 0
for f in files:
    try:
        t = pathlib.Path(f).read_text(encoding="utf-8")
    except OSError:
        continue
    for m in PAT.finditer(t):
        v = m.group(1)
        if v not in tags and v != cur:
            print("%s:%d  claims %s, which is not a tag and is not the current VERSION"
                  % (f, t[:m.start()].count("\n") + 1, v))
            bad += 1
if bad:
    print("  A version written before the cut is a guess: minor vs patch is decided AT the cut.")
    print("  Write '· unreleased' instead and let the release fill it in (RELEASING.md step 1).")
raise SystemExit(1 if bad else 0)
VERPY
  ) || v34=1
  n34=$(printf '%s\n' "$ver_out" | sed -n 's/^SCOPE //p')
  while IFS= read -r l; do
    case "$l" in SCOPE\ *|'') ;; *) note "$l" ;; esac
  done <<EOF34
$ver_out
EOF34
  scope "${n34:-0}" "files scanned for self-version claims" || v34=1
  if [ "$v34" -eq 0 ]; then echo "    ok (${n34:-0} files, every self-claimed version resolves)"; fi
else
  note "SKIPPED (python3 not found; CI always has it)"
  echo "    ok (skipped)"
fi
if [ "$v34" -ne 0 ]; then fail=1; fi

# --- Result ---------------------------------------------------------------
echo
if [ "$fail" -ne 0 ]; then
  echo "FAIL: repository invariants violated (see above)."
  exit 1
fi
printf 'PASS: all repository invariants satisfied (34 checks over %s skill files / %s rules files, %ss).\n' \
  "${seen1:-?}" "${seen2:-?}" "$((SECONDS - START_SECONDS))"
