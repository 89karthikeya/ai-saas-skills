#!/usr/bin/env bash
#
# verify-setup.sh — the DETERMINISTIC half of docs/VERIFY-SETUP.md.
#
# init-gates.sh and gen-agents-md.sh SET THINGS UP. This reports whether the
# result is real. "Configured" and "working" render identically: a
# .pre-commit-config.yaml with no installed hook is a file, not a control; a CI
# workflow whose every run is "skipped" is a gate on paper.
#
# READ-ONLY WITH RESPECT TO THE REPO AND YOUR CONFIGURATION. It creates, modifies and
# deletes nothing in either — run it on a repo you do not trust yet. The one exception
# is section F, which builds a throwaway fixture under $TMPDIR and removes it: a
# BEHAVIOURAL probe cannot be run against nothing. Every check reports what it
# OBSERVED; anything it could not actually run is UNVERIFIED with the reason, never a
# pass.
#
# WHAT STAYS IN THE PROMPT (docs/VERIFY-SETUP.md), because a script cannot do it:
#   - check 4's content judgement: does the agent file carry real build/test
#     commands, deviations and traps, or does it restate generic best practice?
#   - check 5b: are the agent file's factual CLAIMS still true? (Commands
#     existing is checkable; "pinned to 3.11" still being accurate is not.)
#   - check 11: the routing dry-run.
# This script does the rest — existence, resolution, installation state, and run
# history — which it does better than a prompt, and identically every time.
#
# Exit code: 1 if any check FAILed, else 0. UNVERIFIED does NOT fail the run —
# it means nobody watched the thing work, which is unknown, not broken. Do not
# read a 0 as "the setup is good" when the report carries UNVERIFIED rows.
#
# Portable to macOS bash 3.2 (no associative arrays, no mapfile).
set -euo pipefail

RUN_SAMPLE=60
# --reach-only: section A only. install.sh runs this after every install/update,
# where the repo-context and gate sections would report on whatever directory the
# installer happened to be invoked from — noise that trains people to ignore the
# whole report (docs/CONVENTIONS-LEDGER.md on gates that get disabled).
REACH_ONLY=0
while [ $# -gt 0 ]; do
  case "$1" in
    --runs) RUN_SAMPLE="${2:?--runs needs a number}"; shift 2 ;;
    --reach-only) REACH_ONLY=1; shift ;;
    --no-color|--no-colour) VS_NO_COLOR=1; shift ;;
    -h|--help)
      echo "usage: verify-setup.sh [--runs N] [--reach-only]"
      echo "  --runs N       CI runs to sample for check 10 (default 60)"
      echo "  --reach-only   section A only: is the library actually reaching this machine?"
      echo
      echo "env: SOTA_SEARCHERS   space-separated searchers for section F"
      echo "                      (default: grep rg ugrep)"
      exit 0 ;;
    *) echo "unknown argument: $1 (try --help)" >&2; exit 2 ;;
  esac
done
case "$RUN_SAMPLE" in
  ''|*[!0-9]*) echo "--runs must be a positive integer, got: $RUN_SAMPLE" >&2; exit 2 ;;
esac

REPO_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || pwd)
cd "$REPO_ROOT"

CLAUDE_HOME="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"

n_pass=0; n_fail=0; n_partial=0; n_unver=0; n_na=0; n_info=0

# --- Presentation -----------------------------------------------------------
# COLOUR AND SYMBOLS ARE TTY-ONLY, AND THAT IS LOAD-BEARING, NOT DECORATION.
# `check-negative-controls.sh` part B asserts on lines that START with the status
# word: `case "$line" in (FAIL*"$needle"*)`. Twelve probes depend on it. Because
# those probes capture output through `$( )`, stdout is not a TTY there, so the
# plain branch below runs and the bytes they match are unchanged. Decorating
# unconditionally would turn all twelve into FALSE PASS silently.
# sota-cli-ux rules/02 §2: pipe-safe by default, honour NO_COLOR and TERM=dumb.
USE_COLOR=0
if [ -t 1 ] && [ -z "${NO_COLOR:-}" ] && [ "${TERM:-}" != "dumb" ] && [ "${VS_NO_COLOR:-0}" != "1" ]; then
  USE_COLOR=1
fi

if [ "$USE_COLOR" = 1 ]; then
  C_RESET=$'\033[0m'; C_DIM=$'\033[2m'; C_BOLD=$'\033[1m'
  C_GREEN=$'\033[32m'; C_RED=$'\033[31m'; C_YELLOW=$'\033[33m'
  C_BLUE=$'\033[34m'; C_GREY=$'\033[90m'
else
  C_RESET=''; C_DIM=''; C_BOLD=''
  C_GREEN=''; C_RED=''; C_YELLOW=''; C_BLUE=''; C_GREY=''
fi

# <status> -> "<colour><symbol> STATUS<reset>", or the bare word when plain.
decorate() {
  [ "$USE_COLOR" = 1 ] || { printf '%s' "$1"; return; }
  case "$1" in
    PASS)       printf '%s' "${C_GREEN}✔ PASS${C_RESET}" ;;
    FAIL)       printf '%s' "${C_RED}${C_BOLD}✘ FAIL${C_RESET}" ;;
    PARTIAL)    printf '%s' "${C_YELLOW}▲ PART${C_RESET}" ;;
    UNVERIFIED) printf '%s' "${C_YELLOW}? UNVR${C_RESET}" ;;
    INFO)       printf '%s' "${C_BLUE}ℹ INFO${C_RESET}" ;;
    "N/A")      printf '%s' "${C_GREY}· N/A ${C_RESET}" ;;
    *)          printf '%s' "$1" ;;
  esac
}

row() {  # <status> <check> <evidence>
  case "$1" in
    PASS)       n_pass=$((n_pass + 1)) ;;
    FAIL)       n_fail=$((n_fail + 1)) ;;
    PARTIAL)    n_partial=$((n_partial + 1)) ;;
    UNVERIFIED) n_unver=$((n_unver + 1)) ;;
    N/A)        n_na=$((n_na + 1)) ;;
    INFO)       n_info=$((n_info + 1)) ;;
  esac
  if [ "$USE_COLOR" = 1 ]; then
    # The status cell is a fixed 6 visible columns, so the label column still
    # aligns; %-11s cannot be used on a string carrying escapes.
    printf '%s  %-34s %s%s%s\n' "$(decorate "$1")" "$2" "$C_DIM" "$3" "$C_RESET"
  else
    printf '%-11s %-34s %s\n' "$1" "$2" "$3"
  fi
}

section() {
  if [ "$USE_COLOR" = 1 ]; then
    printf '\n%s== %s%s\n' "$C_BOLD" "$1" "$C_RESET"
  else
    printf '\n== %s\n' "$1"
  fi
}

echo "SOTA setup verification (read-only) — $REPO_ROOT"

# --- A. Is the library reaching this directory? ---------------------------
section "A. Library reach"

# Probe every install path, not one: personal, project, and plugin.
skill_dirs=""
for d in "$CLAUDE_HOME/skills" ".claude/skills" "$CLAUDE_HOME/plugins"; do
  [ -d "$d" ] && skill_dirs="$skill_dirs $d"
done
n_sota=0
router_seen=0
for d in $skill_dirs; do
  # -L: a symlinked skill dir is the recommended install, so follow links.
  while IFS= read -r s; do
    [ -n "$s" ] || continue
    n_sota=$((n_sota + 1))
    case "$(basename "$s")" in sota) router_seen=1 ;; esac
  done <<EOF
$(find -L "$d" -maxdepth 3 -type d -name 'sota' -o -maxdepth 3 -type d -name 'sota-*' 2>/dev/null || true)
EOF
done
# The denominator: what the checkout actually offers. Without it, "$n_sota
# skills" is a number with nothing to compare against.
#
# Resolve the library from THIS SCRIPT's own path, never from $REPO_ROOT. The
# first draft used $REPO_ROOT and was therefore inert in the place it matters
# most: run from a user's own project there is no ./skills, n_src stayed 0, the
# comparison silently did not happen and the row still said PASS. A check whose
# scope depends on the caller's cwd is the location-dependent silence in
# `sota-code-security` rules/11 — committed here by the fix for it.
LIB_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." 2>/dev/null && pwd) || LIB_ROOT=""
n_src=0
missing_names=""
if [ -n "$LIB_ROOT" ] && [ -d "$LIB_ROOT/skills" ]; then
  for s in "$LIB_ROOT"/skills/*/; do
    [ -d "$s" ] || continue
    n_src=$((n_src + 1))
    nm="$(basename "$s")"
    found=0
    for d in $skill_dirs; do
      if [ -e "$d/$nm" ] || [ -L "$d/$nm" ]; then found=1; break; fi
    done
    [ "$found" -eq 1 ] || missing_names="${missing_names:+$missing_names, }$nm"
  done
fi

if [ -z "$skill_dirs" ]; then
  row "FAIL" "1. sota skills reachable" "no skills dir found (looked in $CLAUDE_HOME/skills, .claude/skills, $CLAUDE_HOME/plugins)"
elif [ "$n_sota" -eq 0 ]; then
  row "FAIL" "1. sota skills reachable" "skills dir(s) exist but contain no sota* skill:$skill_dirs"
elif [ "$router_seen" -eq 0 ]; then
  row "PARTIAL" "1. sota skills reachable" "$n_sota sota* skills, but the 'sota' ROUTER is not among them — routing is what loads the rest"
elif [ "$n_src" -gt 0 ] && [ "$n_sota" -lt "$n_src" ]; then
  # A count with nothing to compare it against is not a check (rules/11 §2.2).
  # This one printed "41 sota* skills" and PASSED while the tree held 42: a
  # `git pull` updates every EXISTING symlink and can create none, so a newly
  # added skill stays uninstalled and silent. A missing skill has no symptom —
  # it looks like the model simply not choosing it.
  row "PARTIAL" "1. sota skills reachable" \
    "$n_sota sota* skills installed but $n_src in $LIB_ROOT/skills — $missing_names missing; re-run scripts/install.sh (a git pull cannot create a link)"
else
  src_note=""
  [ "$n_src" -gt 0 ] && src_note=" (source offers $n_src)"
  row "PASS" "1. sota skills reachable" "$n_sota sota* skills incl. the router, in:$skill_dirs$src_note"
fi

# --- 1b. Do the descriptions actually REACH the classifier? ----------------
#
# Check 1 answers "is the skill installed". This answers the question one layer
# further in, which has a different answer: Claude Code reserves a per-turn
# CHARACTER budget for the skill listing, `(contextTokens x 4) x
# skillListingBudgetFraction` with the fraction defaulting to 0.01 — 8,000 chars
# on a 200k-context model, shared across every skill from every source. Read out
# of the shipped 2.1.268 binary on 2026-09-11: over budget, entries are RANKED by
# recent usage and the ones that do not fit render as a bare `- name` with NO
# description. The skill is installed, correct, invocable by name, and carries no
# trigger text at all — so check 1 says PASS and auto-selection is dead.
#
# INFO-only and never fatal: the real budget depends on the model's context window
# at runtime, which this script cannot know, and the user may have set the fraction
# deliberately. It reports the arithmetic and lets the operator judge.
listing_need=0
for d in $skill_dirs; do
  n="$(find -L "$d" -maxdepth 3 -name SKILL.md 2>/dev/null | wc -l | tr -d ' ')"
  [ "${n:-0}" -gt 0 ] || continue
  # shellcheck disable=SC2016  # awk program, not a shell expansion
  add="$(find -L "$d" -maxdepth 3 -name SKILL.md -exec awk '
    FNR == 1 {
      if (seen) total += len + nlen + 6
      seen = 1; len = 0; fm = 0; ind = 0
      nm = FILENAME; sub(/\/SKILL\.md$/, "", nm); sub(/.*\//, "", nm); nlen = length(nm)
    }
    /^---[[:space:]]*$/ { fm = !fm; next }
    fm && /^description:/ { ind = 1; sub(/^description:[[:space:]]*/, ""); gsub(/^[[:space:]]+|[[:space:]]+$/, ""); len += length($0); next }
    fm && ind && /^[[:space:]]/ { gsub(/^[[:space:]]+|[[:space:]]+$/, ""); len += length($0) + 1; next }
    fm { ind = 0 }
    END { total += len + nlen + 6; print total + 0 }
  ' {} + 2>/dev/null)"
  listing_need=$((listing_need + ${add:-0}))
done
cfg_frac="$(jq -r '.skillListingBudgetFraction // empty' "$CLAUDE_HOME/settings.json" 2>/dev/null || true)"
eff_frac="${cfg_frac:-0.01}"
budget_200k="$(awk -v f="$eff_frac" 'BEGIN { printf "%d", 200000 * 4 * f }')"
if [ "$listing_need" -eq 0 ]; then
  row "INFO" "1b. listing budget" "no SKILL.md descriptions found to measure — nothing to report"
elif [ "$listing_need" -le "$budget_200k" ]; then
  row "PASS" "1b. listing budget" \
    "descriptions total ${listing_need} chars, within the ${budget_200k}-char budget at a 200k context (fraction ${eff_frac})"
else
  row "INFO" "1b. listing budget" \
    "descriptions total ${listing_need} chars vs a ${budget_200k}-char budget at a 200k context (fraction ${eff_frac}) — over by $((listing_need - budget_200k)); the lowest-USED skills will be listed name-only, with no trigger text. Raise skillListingBudgetFraction (scripts/install.sh offers this) or disable skills you do not use"
fi

# Always-on routing is THREE layers; report which of them are actually present.
directive=0; hook=0
# --- 1c. the report command is reachable ------------------------------------
# The library has NO TELEMETRY: it learns nothing from use unless a session that
# used it reports back, and `/sota-report` is that ask. An install where the
# skills reach the machine but the command does not is a library that can still
# be wrong and can no longer be told so — which is invisible, because everything
# it does do keeps working.
#
# Presence AND target, not presence alone: a stale copy from an older --copy
# install is a real file with old text, and reads identically to a live link
# ("configured" vs "working", the whole point of this script).
cmd_file="$CLAUDE_HOME/commands/sota-report.md"
# -L IS TESTED FIRST, and the order is the whole check. `-e` FOLLOWS a symlink, so
# `[ ! -e ]` is true for a dangling one — the first draft put it first and the
# dangling branch was unreachable dead code, reporting "not installed" for a link
# that exists and points nowhere. Caught by feeding it a dangling link rather than
# by reading it (`sota-code-security` rules/15 §2.2: prove every branch reachable).
if [ -L "$cmd_file" ]; then
  cmd_tgt="$(readlink "$cmd_file")"
  if [ -e "$cmd_file" ]; then
    row "PASS" "1c. report command installed" "/sota-report -> ${cmd_tgt} (symlink; --update refreshes it)"
  else
    row "FAIL" "1c. report command installed" \
      "/sota-report is a DANGLING symlink -> ${cmd_tgt} — the repo moved; re-run scripts/install.sh"
  fi
elif [ ! -e "$cmd_file" ]; then
  row "FAIL" "1c. report command installed" \
    "no $cmd_file — run scripts/install.sh; without it the library cannot be told when it is wrong"
elif grep -q 'SOTA-skills field report' "$cmd_file" 2>/dev/null; then
  row "PARTIAL" "1c. report command installed" \
    "/sota-report is a real file, not a link — a --copy snapshot that will NOT update; re-run install.sh"
else
  row "PARTIAL" "1c. report command installed" \
    "$cmd_file exists but does not look like ours — hand-edited or another tool's; left alone"
fi

# --- 1d. every command the checkout ships is installed ----------------------
# 1c proves ONE command, the one whose absence costs the library its only feedback
# channel. This is check 1's denominator idea applied to commands/: compare what is
# installed against what the checkout OFFERS. `git pull` refreshes every existing
# symlink and creates none, so a command added upstream stays uninstalled and
# silent — the identical failure that made check 1 grow a denominator after it
# printed "41 skills" over a tree of 42. PARTIAL, not FAIL: a missing workflow
# command costs a workflow; a missing /sota-report is the row above.
n_cmd_src=0; missing_cmds=""
if [ -n "$LIB_ROOT" ] && [ -d "$LIB_ROOT/commands" ]; then
  for c in "$LIB_ROOT"/commands/*.md; do
    [ -e "$c" ] || continue
    n_cmd_src=$((n_cmd_src + 1))
    cnm="$(basename "$c")"
    # -e follows the link, so a DANGLING link counts as missing here. That is
    # deliberate and it is why 1c exists separately: only that row distinguishes
    # "absent" from "points nowhere", and only for the command worth the words.
    [ -e "$CLAUDE_HOME/commands/$cnm" ] \
      || missing_cmds="${missing_cmds:+$missing_cmds, }/${cnm%.md}"
  done
fi
if [ "$n_cmd_src" -eq 0 ]; then
  # Fails closed on an empty scope: 0 offered, 0 missing, PASS is the signature of
  # a check that verified nothing.
  row "INFO" "1d. commands match the checkout" \
    "no commands/ found under ${LIB_ROOT:-<unresolved>} — nothing to compare against"
elif [ -n "$missing_cmds" ]; then
  row "PARTIAL" "1d. commands match the checkout" \
    "$n_cmd_src offered, missing: $missing_cmds — re-run scripts/install.sh (a git pull cannot create a link)"
else
  row "PASS" "1d. commands match the checkout" \
    "all $n_cmd_src installed in $CLAUDE_HOME/commands"
fi

[ -f "$CLAUDE_HOME/CLAUDE.md" ] && grep -qi 'sota' "$CLAUDE_HOME/CLAUDE.md" 2>/dev/null && directive=1
if [ -f "$CLAUDE_HOME/settings.json" ]; then
  # Substring test, not a JSON parse: the hook may be a shell one-liner, a script
  # path, or a wrapper, and any of those is a working injection.
  if tr -d '\n' < "$CLAUDE_HOME/settings.json" | grep -qi 'UserPromptSubmit' \
     && grep -qi 'sota' "$CLAUDE_HOME/settings.json"; then
    hook=1
  fi
fi
if [ "$directive" -eq 1 ] && [ "$hook" -eq 1 ]; then
  row "PASS" "2. always-on routing" "CLAUDE.md directive + UserPromptSubmit hook mentioning sota"
elif [ "$directive" -eq 1 ]; then
  row "PARTIAL" "2. always-on routing" "CLAUDE.md directive only — routing depends on the model reading it, not on per-prompt injection"
elif [ "$hook" -eq 1 ]; then
  row "PARTIAL" "2. always-on routing" "UserPromptSubmit hook only — no global directive in $CLAUDE_HOME/CLAUDE.md"
else
  row "FAIL" "2. always-on routing" "neither a sota directive in CLAUDE.md nor a UserPromptSubmit hook — routing depends on how each prompt is phrased"
fi

# Profile: report the FILENAME only. Its contents are the user's stack.
prof_found=0; prof_dangling=""
for p in "$CLAUDE_HOME"/profiles/*.md; do
  [ -e "$p" ] || [ -L "$p" ] || continue
  if [ -e "$p" ]; then prof_found=$((prof_found + 1)); else prof_dangling="$prof_dangling $(basename "$p")"; fi
done
if [ -n "$prof_dangling" ]; then
  row "FAIL" "3. stack profile" "dangling symlink(s):$prof_dangling"
elif [ "$prof_found" -gt 0 ]; then
  row "PASS" "3. stack profile" "$prof_found profile(s) resolve in $CLAUDE_HOME/profiles (names not read)"
else
  row "N/A" "3. stack profile" "none present — optional; the skills' own defaults apply"
fi

# --- B. Is this repo's own context in place? ------------------------------
if [ "$REACH_ONLY" -eq 1 ]; then
  printf '\n%s\n' "PASS $n_pass · FAIL $n_fail · PARTIAL $n_partial"
  echo "Library reach only. Full check (repo context, gates, CI): scripts/verify-setup.sh"
  rc=0; [ "$n_fail" -eq 0 ] || rc=1
  exit "$rc"
fi

section "B. Repo context"

agent_file=""
for f in AGENTS.md CLAUDE.md GEMINI.md; do
  [ -e "$f" ] && { agent_file="$f"; break; }
done
if [ -z "$agent_file" ]; then
  row "FAIL" "4. agent file present" "no AGENTS.md / CLAUDE.md / GEMINI.md"
else
  link_note=""
  for f in AGENTS.md CLAUDE.md GEMINI.md; do
    if [ -L "$f" ]; then
      if [ -e "$f" ]; then link_note="$link_note $f->$(readlink "$f")"
      else row "FAIL" "4. agent file present" "$f is a DANGLING symlink"; link_note=" DANGLING"; fi
    fi
  done
  case "$link_note" in
    *DANGLING*) : ;;
    *) row "PASS" "4. agent file present" "$agent_file$link_note — CONTENT not judged here, see docs/VERIFY-SETUP.md checks 4-5" ;;
  esac
fi

# 5a: the commands an agent file names should exist. Only the presence of a task
# runner is mechanical; whether a NAMED command resolves is check 5a in the
# prompt, and whether its CLAIMS are true is 5b, which no script can do.
row "N/A" "5. agent file is TRUE" "judgement check — run the prompt in docs/VERIFY-SETUP.md (5a commands resolve, 5b claims still accurate)"

# Capabilities, not one implementation's filename.
# First match wins; a glob loop, not `ls` — this repo's own rules/01 says never
# parse ls, and A && B || C (SC2015) prints BOTH rows if the first `row` ever fails.
lic=""
for c in LICENSE* COPYING* COPYRIGHT*; do [ -e "$c" ] && { lic="$c"; break; }; done
if [ -n "$lic" ]; then
  row "PASS" "6a. licence" "$lic"
else
  row "FAIL" "6a. licence" "no LICENSE*/COPYING*/COPYRIGHT* — nobody may legally reuse this"
fi
if [ -f .gitignore ]; then
  row "PASS" "6b. .gitignore" "present"
else
  row "FAIL" "6b. .gitignore" "absent"
fi
rdm=""
for c in README*; do [ -e "$c" ] && { rdm="$c"; break; }; done
if [ -n "$rdm" ]; then
  row "PASS" "6c. README" "$rdm"
else
  row "FAIL" "6c. README" "absent"
fi

# --- C. Are the gates real, or just configured? ---------------------------
section "C. Gates"

gates=""
[ -f .pre-commit-config.yaml ] && gates="$gates pre-commit"
[ -d .husky ] && gates="$gates husky"
{ [ -f lefthook.yml ] || [ -f lefthook.yaml ] || [ -f .lefthook.yml ]; } && gates="$gates lefthook"
n_wf=0
if [ -d .github/workflows ]; then
  n_wf=$(find .github/workflows -maxdepth 1 -name '*.yml' -o -maxdepth 1 -name '*.yaml' 2>/dev/null | wc -l | tr -d ' ')
  [ "$n_wf" -gt 0 ] && gates="$gates ci(${n_wf}-workflow)"
fi
if [ -n "$gates" ]; then
  row "PASS" "7. gate mechanisms found" "${gates# }"
else
  row "FAIL" "7. gate mechanisms found" "no pre-commit / husky / lefthook / CI workflows — nothing gates this repo"
fi

# Secret scanning: search the gate configs, do not infer from a filename.
# Plain grep, NOT `git grep`: git grep reads only TRACKED files, and the primary
# use case for this script is a repo you just scaffolded, whose configs are still
# untracked. Measured 2026-08-02 — an untracked .pre-commit-config.yaml
# configuring gitleaks was reported as "no secret scanning", a false FAIL on
# exactly the repo the check exists for.
scan_paths=""
for p in .pre-commit-config.yaml .github .husky lefthook.yml lefthook.yaml .lefthook.yml; do
  [ -e "$p" ] && scan_paths="$scan_paths $p"
done
scan_hits=""
if [ -n "$scan_paths" ]; then
  for pat in gitleaks trufflehog detect-secrets ggshield gitguardian; do
    # shellcheck disable=SC2086  # word splitting is how the path list is passed
    if grep -r -l -i -- "$pat" $scan_paths >/dev/null 2>&1; then
      scan_hits="$scan_hits $pat"
    fi
  done
fi
if [ -n "$scan_hits" ]; then
  row "PASS" "8. secret scanning configured" "${scan_hits# } referenced in a gate config"
else
  row "FAIL" "8. secret scanning configured" "no gitleaks/trufflehog/detect-secrets/ggshield in any gate config"
fi

# INSTALLED vs merely configured — three distinct states, not two.
hookspath=$(git config --get core.hooksPath 2>/dev/null || true)
hookdir="${hookspath:-.git/hooks}"
installed=0
if [ -d "$hookdir" ]; then
  installed=$(find "$hookdir" -maxdepth 1 -type f ! -name '*.sample' 2>/dev/null | wc -l | tr -d ' ')
fi
if [ "$installed" -gt 0 ]; then
  row "PASS" "9. hooks installed" "$installed non-sample hook(s) in $hookdir"
elif [ -n "$gates" ] && echo "$gates" | grep -q 'pre-commit\|husky\|lefthook'; then
  row "FAIL" "9. hooks installed" "a hook manager is CONFIGURED but $hookdir holds no non-sample hook — that is a file, not a control (run its install step)"
else
  row "N/A" "9. hooks installed" "no local hook manager configured"
fi

# 9a. A stage DECLARED in the config but never installed is a gate on paper.
# pre-commit writes .git/hooks/<type> only when `pre-commit install --hook-type
# <type>` runs, or when `default_install_hook_types` names it. Adding
# `stages: [pre-push]` to the config does NOT create the hook — verified
# 2026-08-19 on pre-commit 4.6.0: the config gained a pre-push hook, the commit
# still ran the pre-commit ones, and .git/hooks/pre-push was never created. So a
# gate can arrive in a config (via a pull, or a generator re-run) and never run,
# while check 9 above reports "hooks installed" on the strength of a different
# hook entirely. Same class as rules/10 §2.13, inside the script written for it.
if [ -f .pre-commit-config.yaml ]; then
  # Exact tokens, never a substring test: "commit-msg" is a substring of
  # "prepare-commit-msg", and a substring match would report the wrong stage.
  # `|| true`: under `set -euo pipefail` a grep that matches nothing exits 1 and
  # aborts the whole script mid-run — which is how the first cut of this check
  # silently truncated the report after check 9 and still exited 0. Watched it
  # happen 2026-08-19 before this guard existed.
  stage_tokens=$(grep -hE '^[[:space:]]*(stages|default_install_hook_types)[[:space:]]*:' \
                   .pre-commit-config.yaml 2>/dev/null \
                 | sed 's/^[^:]*://' | tr -d '[]",' | tr ' ' '\n' \
                 | grep -E '^[a-z][a-z-]*$' | sort -u || true)
  declared=""; missing=""
  for ht in $stage_tokens; do
    case "$ht" in
      # pre-commit itself is check 9's job; "manual" installs no hook at all.
      pre-commit|manual|always) continue ;;
      pre-push|commit-msg|prepare-commit-msg|pre-merge-commit) ;;
      post-checkout|post-commit|post-merge|post-rewrite) ;;
      *) continue ;;   # not a hook type we can check for
    esac
    declared="$declared $ht"
    [ -f "$hookdir/$ht" ] || missing="$missing $ht"
  done
  if [ -z "$declared" ]; then
    row "N/A" "9a. declared stages installed" "config declares no stage beyond pre-commit"
  elif [ -n "$missing" ]; then
    fixcmd="pre-commit install"
    for ht in $missing; do fixcmd="$fixcmd --hook-type $ht"; done
    row "FAIL" "9a. declared stages installed" \
        "config declares${declared}, but $hookdir has no${missing} hook — declaring a stage does not install it; run: $fixcmd"
  else
    row "PASS" "9a. declared stages installed" "every declared stage has a hook file:${declared}"
  fi
else
  row "N/A" "9a. declared stages installed" "no .pre-commit-config.yaml"
fi

# Has each workflow ever EXECUTED, and ever REJECTED anything?
if [ "$n_wf" -eq 0 ]; then
  row "N/A" "10. CI run history" "no workflows to have a history"
elif ! command -v gh >/dev/null 2>&1; then
  row "UNVERIFIED" "10. CI run history" "gh not installed — cannot read real run conclusions; a green badge is not evidence"
elif ! gh auth status >/dev/null 2>&1; then
  row "UNVERIFIED" "10. CI run history" "gh not authenticated — run 'gh auth login'"
else
  # gh's own jq (-q), not a hand-rolled grep over the JSON: a miscounting parser
  # is the failure this repo keeps finding in its own instruments.
  runs=$(gh run list --limit "$RUN_SAMPLE" --json conclusion -q '.[].conclusion' 2>/dev/null || true)
  if [ -z "$runs" ]; then
    row "UNVERIFIED" "10. CI run history" "gh returned no runs (none yet, or no access); sample size 0"
  else
    n_runs=$(printf '%s\n' "$runs" | grep -c . || true)
    n_exec=$(printf '%s\n' "$runs" | grep -cE '^(success|failure)$' || true)
    n_rej=$(printf '%s\n' "$runs" | grep -c '^failure$' || true)
    if [ "$n_exec" -eq 0 ]; then
      row "FAIL" "10a. CI has executed" "$n_runs run(s) sampled, NONE concluded success/failure — an all-skipped history is a control on paper (rules/10 §2.13)"
    else
      row "PASS" "10a. CI has executed" "$n_exec of $n_runs sampled run(s) actually concluded"
    fi
    if [ "$n_rej" -gt 0 ]; then
      row "PASS" "10b. CI has rejected" "$n_rej failure(s) in $n_runs sampled — observed doing its job"
    else
      # No hardcoded sample here. This script runs against ANY repo, and a number
      # measured on one is both wrong for the reader and rot-prone: the note used
      # to read "this repo: 0 failures in 60, 1 in 200" and was false three days
      # later once CI volume pushed that failure out of the window (rules/10 §2.10
      # — a literal in reporting output instead of a derived value).
      row "UNVERIFIED" "10b. CI has rejected" "no failures in $n_runs sampled run(s) — that is not 'never'. Widen with --runs N"
    fi
  fi
fi

# --- E. Can the findings be acted on? -------------------------------------
section "E. Actionability"

if git rev-parse --git-dir >/dev/null 2>&1; then
  origin=$(git remote get-url origin 2>/dev/null || true)
  if [ -n "$origin" ]; then
    row "PASS" "12. remote" "origin: $origin (fork-vs-upstream: check push access before promising a fix)"
  else
    row "PARTIAL" "12. remote" "a git repo with no 'origin' — fixes cannot be pushed anywhere"
  fi
else
  row "N/A" "12. remote" "not a git repository"
fi

# --- F. What does this machine's searcher silently exclude? ----------------
# ROADMAP 45. Every conclusion an agent reaches by searching a tree rests on the
# searcher's defaults, and every searcher excludes something QUIETLY. Measured on one
# 4-match fixture: `rg` at its defaults found 1, this environment's `grep` found 3,
# explicit flags found 4 — and that `grep` was a shell FUNCTION wrapping ugrep, except
# for `-z`/`-Z`, which it routed to BSD grep instead. The failure mode is the worst
# available: a clean absence, which is exactly the answer you were hoping to prove.
#
# THE PROPOSAL WAS "CHECK WHETHER ugrep IS INSTALLED" AND THAT IS THE WRONG SHAPE. The
# library requires no particular searcher, so a presence check is N/A for a non-problem
# — the kind of row people learn to skip, which docs/CONVENTIONS-LEDGER.md argues is
# worse than no row. What is worth reporting is BEHAVIOUR: given a tree with a match in
# each of the four places a default commonly skips, which ones does your searcher see?
#
# IS THE OPERATOR'S TOOLBOX IN THIS SCRIPT'S REMIT? Yes, decided 2026-09-09. Section A
# already reads $CLAUDE_HOME — this script's subject was never only the repo, it is
# "will this setup actually work here". A verification tool that reports a false
# absence is a setup defect, and it is the one defect on this list that corrupts every
# other answer an agent gives afterwards.
#
# INFO, NOT A GRADE. There is no correct answer: `rg` skipping .gitignore'd files is a
# feature. So the exclusions are named and nothing fails for them. Exactly one thing
# CAN fail — the POSITIVE CONTROL. A searcher that cannot find the plain file is not
# excluding anything, it is broken, and per `sota-shell-scripting` rules/06 §2 an
# absence from a broken instrument is not evidence. That is also the seam the negative
# control uses: SOTA_SEARCHERS names the commands to probe.
#
# WHAT THIS UNDER-REPORTS, stated so the green is not read as more than it is. This
# script runs under bash, so `grep` here resolves to the BINARY. An interactive shell
# can have `grep` as a FUNCTION or alias over something else entirely — that is not
# hypothetical, it is how the 4-match measurement above was produced — and this probe
# cannot see it. A row saying `grep` sees all four means the binary does. If your shell
# wraps it, run this section's fixture from that shell too.
section "F. Searcher behaviour (what an absence from this machine is worth)"

sf_dir=""
# `return 0` is load-bearing. As `{ [ -n "$sf_dir" ] && rm -rf "$sf_dir"; }` this returns
# 1 whenever sf_dir is empty — which it deliberately is once the fixture has been removed
# — and **a bash EXIT trap's status becomes the script's exit status**. So a machine with
# every check passing exited 1. It went unnoticed for one run because the checks were read
# through `| grep`, and `$?` after a pipeline is the last stage's (`sota-shell-scripting`
# rules/01 §3). The negative-control harness caught it on the very next run, as a
# known-good fixture that stopped passing.
sf_cleanup() { [ -n "$sf_dir" ] && rm -rf "$sf_dir"; return 0; }
trap sf_cleanup EXIT INT TERM

if ! sf_dir=$(mktemp -d 2>/dev/null); then
  row "UNVERIFIED" "13. searcher exclusions" "could not create a fixture under \$TMPDIR"
else
  # The needle is a nonsense string so it cannot collide with anything real, and it is
  # BUILT rather than written literally: a searcher that indexes this script must not
  # be able to match the file it is about to be tested with.
  sf_needle="zq$(printf 'x')7needle$(printf 'x')kv"
  # THE SYMLINK TARGET MUST LIVE OUTSIDE THE SEARCHED ROOT. The first draft put it in
  # $sf_dir/real and symlinked $sf_dir/linked -> real, inside the same root — so every
  # searcher found it by walking `real/` directly and the symlink row PASSED for tools
  # that skip symlinks entirely. A vacuous assertion (`sota-testing` rules/06 §6.3):
  # true, and not evidence. Caught by measuring the row by hand against
  # `sota-shell-scripting` rules/06 §2 an hour after this check shipped green.
  mkdir -p "$sf_dir/outside" "$sf_dir/scan/gitignored" "$sf_dir/scan/.hidden"
  printf '%s\n' "$sf_needle" > "$sf_dir/outside/behind-a-symlink.txt"
  printf '%s\n' "$sf_needle" > "$sf_dir/scan/plain.txt"
  printf '%s\n' "$sf_needle" > "$sf_dir/scan/gitignored/ignored.txt"
  printf '%s\n' "$sf_needle" > "$sf_dir/scan/.hidden/hidden.txt"
  ln -s ../outside "$sf_dir/scan/linked" 2>/dev/null || true
  printf 'gitignored/\n' > "$sf_dir/scan/.gitignore"
  # A real repo, because rg's ignore handling only engages inside one.
  ( cd "$sf_dir/scan" && git init -q . >/dev/null 2>&1 ) || true

  # Assert the fixture is what the report will claim it is. A fixture that silently
  # failed to build (no symlink support, no git) would make every searcher look
  # equally blind and the row would blame the tool.
  sf_broken=""
  [ -L "$sf_dir/scan/linked" ] || sf_broken="$sf_broken symlink"
  [ -d "$sf_dir/scan/.git" ]   || sf_broken="$sf_broken git-repo"
  # And the target must be reachable ONLY through the link, or the row is vacuous.
  if [ -e "$sf_dir/scan/outside" ]; then sf_broken="$sf_broken target-also-inside-root"; fi

  sf_searchers="${SOTA_SEARCHERS:-grep rg ugrep}"
  sf_any=0
  for sf_cmd in $sf_searchers; do
    command -v "$sf_cmd" >/dev/null 2>&1 || continue
    sf_any=1
    # Defaults only — the whole question is what the command you would actually type
    # excludes. -r for grep because a bare grep does not recurse; rg/ugrep recurse
    # already. No other flags: adding -R or --hidden would measure the fix, not the
    # default.
    case "$sf_cmd" in
      grep) sf_hits=$( ( cd "$sf_dir/scan" && "$sf_cmd" -rl "$sf_needle" . 2>/dev/null ) || true ) ;;
      *)    sf_hits=$( ( cd "$sf_dir/scan" && "$sf_cmd" -l "$sf_needle" . 2>/dev/null ) || true ) ;;
    esac
    sf_missed=""
    for sf_want in plain.txt behind-a-symlink.txt ignored.txt hidden.txt; do
      case "$sf_hits" in
        (*"$sf_want"*) ;;
        (*) sf_missed="$sf_missed $sf_want" ;;
      esac
    done
    sf_label="13. searcher: $sf_cmd"
    case "$sf_missed" in
      (*plain.txt*)
        # The positive control. Nothing else in this section can fail.
        row "FAIL" "$sf_label" "found NOTHING in the plain file — this searcher's absences are not evidence" ;;
      ("")
        row "PASS" "$sf_label" "sees all four: plain, symlinked dir, gitignored, hidden" ;;
      (*)
        # The REMEDY for each exclusion is printed once below the block, not on every
        # row: repeating a 90-character parenthetical per searcher pushed the thing
        # that differs between them (WHICH exclusions) off the right of the terminal.
        sf_names=$(printf '%s' "$sf_missed" \
          | sed 's/ behind-a-symlink.txt/ a symlinked dir/; s/ ignored.txt/ .gitignore'"'"'d files/; s/ hidden.txt/ dot-directories/')
        sf_saw_exclusions=1
        row "INFO" "$sf_label" "silently skips:${sf_names}" ;;
    esac
  done
  if [ "${sf_saw_exclusions:-0}" -eq 1 ]; then
    printf '%s            an absence from a searcher above is not evidence — reach past each\n' "$C_DIM"
    printf '            exclusion with: a symlinked dir → ugrep -R, rg --follow, find -L (BSD\n'
    printf '            grep follows neither) · .gitignore → rg --no-ignore · dotfiles → --hidden%s\n' "$C_RESET"
  fi
  if [ "$sf_any" -eq 0 ]; then
    row "UNVERIFIED" "13. searcher exclusions" "none of '$sf_searchers' is on PATH"
  elif [ -n "$sf_broken" ]; then
    row "UNVERIFIED" "13. fixture completeness" "could not build:$sf_broken — rows above under-report exclusions"
  fi
  sf_cleanup; sf_dir=""
fi

# --- Result ---------------------------------------------------------------
if [ "$USE_COLOR" = 1 ]; then
  # Zero counts are dimmed so the eye lands on what actually happened; FAIL is red
  # only when it is non-zero, so a clean run has no red in it at all.
  _c() { if [ "$2" -gt 0 ]; then printf '%s%s %s%s' "$1" "$3" "$2" "$C_RESET"; else printf '%s%s %s%s' "$C_GREY" "$3" "$2" "$C_RESET"; fi; }
  printf '\n%s · %s · %s · %s · %s · %s\n' \
    "$(_c "$C_GREEN" "$n_pass" PASS)" "$(_c "$C_RED" "$n_fail" FAIL)" \
    "$(_c "$C_YELLOW" "$n_partial" PARTIAL)" "$(_c "$C_YELLOW" "$n_unver" UNVERIFIED)" \
    "$(_c "$C_BLUE" "$n_info" INFO)" "$(_c "$C_GREY" "$n_na" 'N/A')"
else
  printf '\n%s\n' "PASS $n_pass · FAIL $n_fail · PARTIAL $n_partial · UNVERIFIED $n_unver · INFO $n_info · N/A $n_na"
fi
if [ "$n_unver" -gt 0 ]; then
  echo "UNVERIFIED is not a soft PASS: nobody watched those work. Treat them as unknown."
fi
cat <<'EOF'
Not covered here (a script cannot): whether the agent file's content is
meaningful, and whether its factual claims are still true. Run the prompt in
docs/VERIFY-SETUP.md for those, plus the one check nothing read-only can do —
whether the secret gate actually REJECTS a commit.
EOF
[ "$n_fail" -eq 0 ]
