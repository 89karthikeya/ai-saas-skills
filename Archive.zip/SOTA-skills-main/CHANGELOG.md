# Changelog

All notable changes to SOTA-skills are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/2.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Fixed

- **Probe 14b builds its own tag state, so finding 5's fix is exercised on every PR.** The
  fixture neutralises invariant 34 (shipped v1.43.1, after 34 blocked the correct v1.43.0 cut)
  by rewriting the cut's `· v<current>` claims to the synthetic version. That rewrite was
  **inert on any non-release commit**: there `v<VERSION>` is already tagged, so 34 passes
  whether or not the fixture rewrites, and deleting the fix changed nothing. The regression was
  therefore invisible to every CI run between releases and would have resurfaced at the next
  cut — a release-time gate unexercised by non-release runs (`sota-devsecops` rules/09 §2a).
  The fixture now writes an untagged `1.97.0` into `VERSION`, plus one claim about it, before
  bumping to the synthetic version, and asserts first that no such tag exists. Measured as a
  differential 2026-09-19: with the claim-rewrite removed the probe reports `EXEMPTION DID NOT
  HOLD` and `FAIL: 1 of 61`; with it restored, `PASS: 61/61`. Probe count unchanged.

- **`sota-shell-scripting` rules/06 §2f states its mechanism at the width it was measured.**
  Shipped in v1.43.1 asserting *"`git grep` calls the platform's system regex"* as a general
  fact. The **behaviour** is measured on four builds and stands; the **mechanism** was verified
  on exactly one — `nm -u` on the macOS binary. The equivalent check on an Alpine build returned
  neither an imported nor a defined `regcomp` while `nm -D` still listed 252 symbols, which is a
  fact about that instrument rather than about the binary, so it settles nothing in either
  direction. The sentence now says which build it was read from and warns against assuming the
  same linkage elsewhere. The rule's advice is unchanged, because the behaviour is what you act
  on — a mechanism asserted wider than its evidence is the defect §2f itself is about.

## [1.43.1] - 2026-09-18

**Front door checked:** word-boundary · verdict · listing and selection

### Added

- **`sota-shell-scripting` rules/06 §2e — a label that states the verdict is not evidence of
  the verdict.** §2d already covered the *conditional* twin (`cmd 2>/dev/null || echo "missing
  X"`) and its worked example even names the symptom — *"it printed the match AND the verdict
  that contradicts it"*. What was missing is the form with **no condition at all**, `cmd; echo
  "^ 0 = ..."`, which is **strictly worse**: §2d's fires only on a non-zero exit, this one fires
  always and survives any output. Four instances in one session, each contradicted by the output
  directly beneath it; the costly one asserted that a rule was **absent from the library** one
  line above output proving it was present. Sited as `sota-code-security` rules/14 §1 applied to
  your own scrollback — derive the verdict from the variable the command produced, and treat a
  line opening `^`, `(` or `<-` as the tell.

- **`sota-shell-scripting` rules/06 §2f — a word-boundary escape is a property of the machine,
  not of the tool.** Two earlier drafts of this rule were **wrong about the axis** — *"git grep
  is a third engine"*, then *"`\b` is a GNU extension, not POSIX"* — and the question *from
  which version does this behave this way?* is what exposed it. **There is no version**: git
  2.39.5, 2.45.4 and 2.47.3 all match `\b`; 2.55.0 does not. `nm -u` on the binary shows
  `_regcomp` **imported**, so `git grep` uses the platform's regex, and the GNU (`\b`, `\<`)
  and BSD (`[[:<:]]`) forms are **mutually exclusive** — neither is portable, and failing is a
  silent `0` with exit 1. Measured across three libcs with the control passing in every row.
  Cost two false absences in one session, each caught only because a second, differently-shaped
  measurement disagreed.

- **`sota-shell-scripting` rules/09 — listing and selection, split out of rules/06.** That file
  was at **498 of 500**. §5 (a lister's default page read as a population) and §5a (a selector
  answering a neighbouring question) moved out **keeping their numbers**, as rules/08 did before
  them, freeing 106 lines. The split's own hazard fired immediately: two bare `§2` references
  inside the moved text had been resolving to their containing file, and invariant 18 caught
  both the moment they landed in a file with no §2.

- **`sota-devsecops` rules/09 §2 — a fixture that simulates a *release* inherits every
  release-time check.** Those checks then fire correctly and the harness misattributes them to
  the gate under test. Second instance on the same probe — a routing check, then a version check
  whose exemption covers exactly one untagged version. Generalised from the incident that turned
  the v1.43.0 release PR red.

### Fixed

- **A dangling citation invariant 18 cannot see.** `sota-testing` rules/07 cited
  `sota-shell-scripting` rules/06 §4 — a section that moved to rules/08 two releases ago. The
  gate fails open on it because the `§` sits on a **different line** from the file name, so the
  80-character carried tail never binds them. Found by hand-reading all nine sectionless
  pointers during the split, not by any check. Corrected to rules/08 §4.

- **`scripts/lib/check-section-refs.py` now states the case it cannot see.** A bare `§N` with no
  skill named on the line falls back to the *containing* file, so a shorthand can resolve
  **successfully, to the wrong document**, and read as correct in both directions. The fallback
  is deliberately fail-open — a gate that false-positives on correct prose gets disabled — so
  this is documented rather than gated: when a file both cites a shorthand and carries a heading
  of that number, the reference is unverified, not verified.

## [1.43.0] - 2026-09-18

**Front door checked:** /sota-audit · /sota-deep-audit · control-presence matrix · independent refuter

### Added

- **`/sota-audit` — a fourth slash command: audit a codebase against the library.** The
  existing three bracket a session (`/sota-resume` opens, `/sota-close` and `/sota-report`
  close); nothing asked the middle question — *were the rules that own this surface actually
  applied?* It is a **conformance** audit, not a defect hunt, so its dominant finding is a rule
  with real surface area that was never applied, and behind it a control that is present and
  enforces nothing. Three design points, each answering a failure this library has already
  measured: **the scope is agreed first**, with a denominator printed beside every candidate,
  because the wrong scope returns *clean* rather than an error; **routing is rebuilt from the
  surfaces in the tree**, never from whatever happened to be loaded, since a session that never
  routed looks perfectly compliant against nothing, and the coverage table names the domains
  **nobody opened**; and the checklists are walked **item by item** (met · not met · not
  applicable, with the reason) because self-audit fails toward false negatives — the reasoning
  that produced the code is still loaded and will agree with itself. Findings stop for a
  decision before anything is edited; questions are batched in the two-or-three-options form
  with a recommendation. Report in the session, no file written unless asked. No script change
  was needed — `install.sh` and `verify-setup.sh` check **1d** both glob `commands/*.md`, so
  the new command installs and is checked for reachability on the next `install.sh` run.

- **`/sota-deep-audit` — the escalation, and the four things `/sota-audit` structurally cannot
  do.** Measured against the router's own seven-step AUDIT workflow rather than by impression:
  `/sota-audit` as first written covered steps 1, 3, 4 and 6, **omitted step 5 entirely**
  (decision-ledger review — all four `decision` hits in the file were about asking the operator
  a question) and **weakened step 7** to self-refutation. Three of those gaps were missing
  passes rather than missing horsepower and were closed in place: the decision ledger with
  re-measurement, the "where else does this project's knowledge live" question
  (`sota` router `rules/01` §4a), and partitioning a scope too large to hold at once (§1a).
  The two that genuinely need scale — **an independent refuter** and **a forward look at the
  plan** — became this command. Adapted from a private command that had been in use since July;
  three things changed before it could ship in a cross-harness public library: the `ultracode`
  first line became harness-neutral ("if this harness offers multi-agent orchestration, use it;
  if not, run the lenses in fresh contexts and say which"), the cost is stated up front with the
  plan and fan-out split shown **before** anything is spent, and the two written artifacts
  became opt-in — the same call already made for `/sota-audit`, since most repos it runs in are
  not yours to leave files in. It cites `rules/03` §1/§3/§4/§4a rather than restating them.

- **`/sota-deep-audit` reconstructs the threat model, and it runs *first*.** The gap was
  visible in the comparison that produced the command and was reported rather than quietly
  left: router AUDIT **step 2** was absent from `/sota-audit` and only partial here, living
  inside the security lens where it could not do its job — a finding rated without trust
  boundaries is rated in a vacuum. It is now a timeboxed pass of its own ahead of the lenses
  (`sota-threat-modeling` rules/06 §1): collect and **record what you were not given**;
  extract entry points, stores, actors and the trust boundaries the system *actually* has
  from the code rather than the docs (`rules/02` §5, §7, §8) and output the reconstructed
  DFD; write down the implied assumptions and **test each against the code that makes it
  true** — no evidence is a broken assumption, and these are usually the Criticals; run the
  component catalogs including the LLM/agent one (`rules/03` §8); then build the
  **control-presence matrix** — Present · Partial · Absent · N/A · Unverifiable, each with
  the evidence its state demands, the *searches* recorded for every Absent (`rules/06` §2).
  Three things make that matrix worth having: **Partial is the most important state** (one
  checked endpoint proves the pattern is known; the seventeen unchecked ones are the
  finding, and remediation is adoption rather than invention), **check the negative space**
  (exclusion lists, skip-auth decorators, `count = 0`, disabled tests with *security* in the
  name — a disabled control is a stronger finding than one never built, because someone
  decided), and **sample honestly with the rule stated**. Lens 3 now consumes the matrix
  instead of duplicating it, and the DFD plus matrix join deliverable A.

- **The negative-control harness now checks its own coverage claim against the run.** It
  printed `COVERED: … (28 of 31)` while carrying probes for 32, 33 and 34; invariant 17
  *requires* `AGENTS.md` and `CONTRIBUTING.md` to restate that line, so one stale literal
  reached both front doors and then **rejected the correct correction** (`sota-code-security`
  rules/14 §1 — a control asserting a number it has not earned). The literal is kept on
  purpose: invariant 17 parses it from the file and invariant 19 reads the per-id reasons
  beneath it, and **deleting it broke both, measured**. A static replacement is not available
  either — grepping the call sites under-reads, **27 against a true 31**, because the
  diff-based probes are nested inside functions, which is why `AGENTS.md` already said only
  running it is authoritative. What was missing was the comparison, so the harness now derives
  the covered set from the probes that actually ran and **fails when its own COVERED line
  disagrees**. **Its first real run was a false alarm, and that is the useful part**: it
  reported `probes ran for 27 invariants, but the COVERED line declares 31` — against a
  *correct* declaration. Probes reach the gate through three functions, not one, and only
  `probe()` had been instrumented; the diff-based checks go through `probe_committed()` and
  `probe_committed_green()`. So the control I wrote to stop a number being asserted rather
  than counted was itself counting only a third of the evidence — the same defect, one level
  in. All three entry points now record. The comparison logic was unit-tested in both
  directions (silent at 31 vs 31, fires at 28 vs 31) *before* that run, which is exactly why
  the failure was legible as a miscount rather than read as real drift.

- **Four spelled-out counts in the new commands are now declared to invariant 30.** *"Four
  things, and only these four justify the cost"* drifted to five inside the session that wrote
  it — invariant 30's exact shape, on a gate that already scans every tracked `*.md` including
  `commands/`. It was simply never declared. No new machinery; four `<!-- count-check: … -->`
  markers.

### Fixed

- **"instructions an agent executes every session" was wrong in four live places.** A command
  executes **on invocation**, not every session — the claim justifying invariant 33's urgency
  described a mechanism the library does not have, and last week's coverage-table row was
  edited to say the opposite, leaving the row contradicting the prose three lines above it.
  Corrected in `CONTRIBUTING.md`, `docs/CONVENTIONS-LEDGER.md`, `docs/INVARIANTS.md` and
  `check-invariants.sh`'s own header. **The two copies in `CHANGELOG.md` and
  `docs/ADOPTION-LOG.md` are deliberately left**: those are records of what was believed at
  the time, and editing a record destroys the trail. The 494-line figure and its 2026-09-16
  date are untouched — the measurement was right, the mechanism sentence around it was not.

- **`install.sh`'s command block still described a directory holding one file.** Its header
  explained why `/sota-report` ships user-level and never mentioned that the loop installs
  every command in `commands/` — five of them now. It names the set, and which check covers
  which (1c by name, 1d by denominator).

- **Invariant 34 — a version this repo claims for itself must exist.** A rules-file header
  naming the release a section moved in is written *before the cut decides minor vs patch*;
  guess minor, ship patch, and the prose points at a release that never existed. **Four
  occurrences, two of them three hours apart in one session** — the second written *after* the
  first was fixed, in a commit naming the mechanism. Scope measured before building: *every*
  `vX.Y.Z` is unshippable (35 unresolved, nearly all third-party), and the `v1.*` namespace
  still catches placeholder image tags — what separates ours is **grammar** (*at*/*in*/*·*
  before the version). 49 claim-shaped refs, 0 unresolved. Records are exempt; two probes, the
  second proving it stays silent on `app:v1.2.3`.

- **`sota-devsecops` rules/11 §4a — re-running a failed check destroys the evidence of why it
  failed.** rules/09 §4 covers a verdict the gate *composed*; this is the case where it did
  not know, and the explaining line is incidental output the re-run deletes. Archive before
  re-running, per-run paths not a fixed one, stderr folded in, duration beside the verdict —
  and **a flake you cannot explain is often an unread log**. `rules/09` was at 498/500, so the
  evidence half (§4–§6) split to **`rules/11-after-the-gate-fails.md`** keeping section
  numbers; invariant 18 caught 12 broken references.

### Fixed

- **`sota-performance` rules/01 §9a — the "6x regression" was 1.41x.** The reporter updated
  the field report after the run finished (3190s), and the correction changes the lesson: the
  nice penalty is real but worth only ~41%. The 6x came from **arithmetic on a progress
  percentage**, which is dominated by collection and front-loaded cases and is not linear.
  §9a now leads with that, because it generalises further than the harness detail.

- **Seven references to versions that never existed.** `rules/08`'s header and four other
  sites said the ad-hoc-side-effects split shipped in `v1.43.0`; it shipped in **v1.42.2** —
  the version was written into the prose when the file was created, guessing the next cut
  would be a minor, and the cut was a patch. Sweeping every `v1.X.Y` in tracked markdown
  against `git tag -l` found two older instances of the same shape: `rules/05` claimed
  `v1.36.4` (really **v1.37.0**) and an ADOPTION-LOG row claimed `v1.41.3` (really
  **v1.42.0**). Caught by an external field report, not by any gate.

- **`sota-kubernetes` rules/02 — the default-bindings claim is now verified, not inherited.**
  It shipped in v1.42.2 on the external audit's say-so because the fetch of the RBAC page came
  back truncated and the fetcher answered from recall. Re-fetched with a browser, reading the
  table out of the DOM: `system:public-info-viewer` is bound to *"system:authenticated and
  system:unauthenticated groups"*. **The claim holds — and the recall fallback contained a
  factual error**, listing `system:discovery` as bound to both groups, which has been false
  since v1.14. A new bullet carries that **v1.14 boundary**, because it inverts the check on an
  old cluster: before v1.14 `basic-user` and `discovery` *were* bound to
  `system:unauthenticated`.


## [1.42.2] - 2026-09-16

**Front door checked:** PROSE-REGRESSION · Coverage by area · findings about other people's code

**Routing checked:** evals/results/2026-09-16/DESC-ROUTING-v1.42.2.md

### Added — a stated convention for measuring a rule change against the previous version

The invariants are structural: an external audit found **19 wrong statements with all 33
checks green**. `evals/run-prompt-independence.py` already builds a `pre` arm from your rules
files at `--ablate-ref` (via `git show`, so it is the real prior text rather than a mirror
that drifts) and a `post` arm from the working tree — but nothing said *when* a contributor
should reach for it.

- **[docs/PROSE-REGRESSION.md](docs/PROSE-REGRESSION.md)** — the decision: what the ablation
  compares, why it is **per-change by design** (its treated cases are one per rules file the
  originating branch changed, so it exits `FAIL` rather than reporting a number when no case
  loads a file you touched — that means you forgot a case, not that the change is safe), when
  a prose edit warrants a run and the four shapes that do **not**, the cost (54 build + 54
  judge calls at defaults), and how to read a treated delta against the controls' noise floor.
- **`CONTRIBUTING.md`** — a PR-checklist line and a short section pointing at it. Deliberately
  a **convention, not a gate**: it needs an API key and ~100 model calls, and a gate that
  cannot run in CI is one people disable.


### Fixed

- **`sota-rust` rules/04 — the Tokio cancellation-safety classification was wrong in both
  directions.** `Notify::notified` was listed as cancel-safe and `Mutex::lock` was called
  safe; Tokio lists **both as not cancel-safe**, along with `RwLock::read`/`write` and
  `Semaphore::acquire`. The cancel-safe `watch` method is **`changed()`**, not `recv()`.
  Replaced with the per-operation table transcribed from the `select!` docs, **split by
  Tokio's own two reasons**: partial-I/O loses *bytes* and desynchronises a stream, while the
  lock/semaphore/notify row loses only a *place in a fairness queue* — nothing is corrupted.
  The audit half now rates them differently and states that reporting a fairness-queue
  cancellation as data loss is a **false finding**. Dated and marked per-version.


### Fixed — an external audit of v1.42.1: 18 findings verified against primary sources, 18 fixed

Every finding was re-verified before acting; **10 of 10 spot-checked citations resolve to
real text**, unlike the previous external audit where every line number was invented.

- **`sota-web-frameworks` rules/03 — two audit commands found nothing.** `grep -rln 'export
  async function (GET|POST|…)'` uses BRE, where the parens are *literal*, and the
  `process.env.(?!NEXT_PUBLIC_)` command asks POSIX ERE for negative lookahead. Reproduced
  (exit 1 / syntax error); corrected commands verified on the same fixture. Also: **`updateTag`
  is Server-Actions-only** and throws in a Route Handler, and React **does** serialize `Date`,
  `Map`, `Set`, promises and Server Functions.
- **`sota-kubernetes` rules/02 — there is no anonymous→`system:authenticated` bridge.**
  Anonymous requests get `system:anonymous` + `system:unauthenticated`. Severity now rests on
  the verbs and resources, since Kubernetes itself binds `system:public-info-viewer` to both
  groups by default.
- **`sota-databases` rules/04 — PgBouncer's matrix draws three distinctions we collapsed**:
  `LISTEN` is unsupported in transaction mode but **`NOTIFY` is supported**; `ON COMMIT DROP`
  temp tables work; protocol-level prepared plans are what `max_prepared_statements` rescues,
  not SQL `PREPARE`.
- **`sota-python` rules/04 — Django *raises*, it does not silently serialize.**
  `SynchronousOnlyOperation` is the default; blocking requires `DJANGO_ALLOW_ASYNC_UNSAFE`.
- **`sota-network-security` rules/03 — `ipBlock` and in-cluster IPs differ by CNI.** Cilium
  excludes pods and nodes from CIDR selectors by default; upstream NetworkPolicy does not.
- **`sota-security-compliance` rules/04 — the CRA conformity split is conditional.** Module A
  stays available to class I where harmonised standards are *fully* applied (Art. 32(1)–(2)).
- **`sota-frontend-design` rules/05 — standalone link text is 2.4.9 (AAA), not 2.4.4 (A).**
  2.4.4 is satisfied by link text plus programmatically determined context.
- **`sota-secrets-management` rules/05 — dotenv does not override a set variable.** Measured
  on 17.4.2; the real risk is a stray file *supplying* a variable nobody reviewed.
- **`sota-llm-engineering` — two numbers.** The tokenizer gap is **35% below** (54% is the
  inverse direction), and "wrong for four months" was **29 days**.
- **Two contradictions between skills.** The "never hold a lock across an await" absolute now
  states its async-mutex exception, which `sota-rust` already prescribed; the Python
  detached-task example now observes its exception instead of only discarding the task.
- **Two routing surfaces.** `sota-network-security` advertises SPF/DKIM/DMARC (its body owns
  them; its description did not), and `sota-c-cpp` declares the embedded *systems* layer it
  does not own — both paid for by dropping duplicate triggers, because the shared skill
  listing budget makes a new skill the expensive option.
- **`docs/WHY-IT-WORKS.md` — the self-audit was not separately measured.** `gate=False`
  removes the entire `BUILD_WORKFLOW`, so +0.062 measures the reminder bundle, not step 4.
  Isolating the terminal re-read needs an arm that has not been run.


### Added — the executable-claims slice widened to every silently-false-answer trap

`scripts/check-claims.sh` re-runs the claims a rule's advice actually rests on. It covered
filesystem and quoting traps; it now covers **every claim landed on 2026-09-15/16 whose failure
mode is a plausible wrong answer** — `rg -rn` rewriting content, a leading-dash pattern parsed
as a flag, `|| echo` firing on grep's exit 2, the `pgrep -f` **platform split**, a pipeline's
status being the last stage's, leading-dash `printf` differing between bash and zsh,
`--no-ignore` not reaching hidden dirs, two-dot `git diff` inventing a regression, and a
directory secret scan ignoring `.gitignore`. Each names the rule it backs, so a failure points
at the sentence to re-measure.

**The selection rule is stated in the ledger** so the set cannot drift into "whatever was
easy": a claim earns a test if getting it wrong changes a conclusion someone acts on.

**Watching it fail found two defects in the new tests themselves** — claim 16 reported the
rule broken because the harness runs under `set -uo pipefail`, so it was measuring its own
shell options rather than a default shell; and claim 20's fixture was entropy-poor enough to
be inert, caught by its positive control. Measured after the fixes: **22 run, 0 skipped, 0
failed** on a macOS host that has ugrep, ripgrep, zsh and gitleaks installed, up from 11 run /
2 skipped. **The run count is a property of the toolchain, not the platform** — CI's macOS
runner reports 15 run / 7 skipped and ubuntu 21 run / 1 skipped, because a missing binary
SKIPS with a printed reason rather than passing silently. Read the denominator, not the
headline; the count is deliberately not written into prose.


### Added — two gates from auditing our own control surface

- **Invariant 32 — no absence reported through a stderr-suppressed `|| echo`.**
  `cmd … 2>/dev/null || echo "missing X"` shipped in the audit checklists of nine skills; the
  `||` fires on *every* non-zero exit and the redirect destroyed the reason. Flagged inside
  prescriptive ```sh/```bash fences in `skills/**` and `commands/**`; ```console transcripts
  and `|| true` are exempt. **Measured before building: `shellcheck -S style` exits 0 on the
  exact line** (semantic, not syntactic), and linting all 161 fenced blocks yields 19
  fragment-artifact errors — a gate that opens red gets disabled, so this one is narrow.
  Known-good/known-bad: 0 hits today, **13** on the pre-fix tree. Two probes, the second
  proving it stays silent on the section that *documents* the anti-pattern.
- **Invariant 33 — every top-level area declares what gates it.** Enforcement density is
  uneven and unevenness is invisible: `skills/**` (70,200 lines) carries ~20 checks while
  `commands/**` — instructions an agent executes every session — carried two, undecided.
  A **declaration, not a ratio**: an invariants-per-KLOC floor is arbitrary and gets tuned
  until it passes, so every area must appear in a new **Coverage by area** table with its
  gates or a stated reason it is thin. Both directions, like 15. Ten areas appeared in the
  repo's first three months, so this recurs.

### Changed

- **Two more surfaces stopped stating how many CI checks are required.**
  `CONTRIBUTING.md` and `RELEASING.md` both said *"four required checks"*, which went false
  the moment the executable-claims jobs were made required (now six). Same de-rot as
  `AGENTS.md`: the count is not written down anywhere, because it has now rotted twice.
- **`AGENTS.md` no longer states how many CI checks are required.** That number rotted
  exactly once already — a job was added and never made a required check — so it now points
  at `gh api …/branches/main/protection` instead of carrying a literal.


### Added

- **`sota-shell-scripting` rules/01 §3 — scaffolding gets the same scrutiny as the payload.**
  A piped exit status let a red gate run a `git push`: `make ci | tail -10 && git push` chains
  on the *formatter's* status. **The mechanical tell is `&&` after a pipeline.** The push
  started a second concurrent gate run whose collision looked exactly like a product race —
  the tell it was the harness was duration, 1599s vs ~757s for identical code. Wait loops,
  output formatting and cleanup are where a trap survives a careful session, because the
  "am I about to believe this?" reflex never fires on a command that merely orchestrates.
  Ships with its audit half.
- **`sota-shell-scripting` rules/01 — the `pgrep -f` self-match rule was stated universally
  and is platform-scoped** (a fix, kept here beside its sibling). Measured as a differential:
  the identical waiter **never exits on procps-ng 4.0.6 (Linux)** and **exits immediately on
  BSD `pgrep` (macOS)**, with a positive control confirming macOS `pgrep -f` does find a
  separate carrier. A macOS operator testing the trap concludes it is imaginary and ships the
  loop into Linux CI. Now stated per platform, like `-r` over symlinked dirs.

- **`sota-shell-scripting` rules/06 §2 — `rg --no-ignore` is a decoy.** The table already
  showed `rg` defaults finding 1 of 4 and the full flag set finding 4 of 4; it did not say
  that **`--no-ignore` alone leaves every hidden directory excluded** while searching
  strictly *more* files (measured: 1042 vs 404 on one repo, same matches missed). The failure
  is confidence-increasing — the run that misses the matches looks like the thorough one.
  `rg PAT .` never enters `.claude/`, `.github/` or `.githooks/`; only `--hidden` does.


### Fixed — our own audit checklists were manufacturing findings about other people's code

Nine skills shipped `cmd … 2>/dev/null || echo "missing X"` in their audit checklists. The
`||` arm is meant to mean *"the pattern was absent"*. It fires on **every** non-zero exit,
and `2>/dev/null` has already destroyed the evidence of which one — `grep` exits `1` for
no-match and `2` for an unreadable path. In one arm the line printed the match it had just
found **and** "missing X" on the next line. `ls a b c 2>/dev/null || echo …` has the same
bug. The failure is *directional*: it invents findings rather than hiding them, so an
auditor sees plausible output and files it.

**13 sites fixed** across `sota-c-cpp`, `sota-dotnet`, `sota-golang`, `sota-jvm`, `sota-php`,
`sota-python` and `sota-ruby` — `grep` sweeps now use one root with `--include` globs so no
missing-path branch exists, and `ls` checks pipe to `grep -q .` so the verdict fires only on
a genuine absence. Both replacements verified in both directions. Reported from the field;
no gate in this repo could see it, because nothing executes the shell inside a fenced block.

### Added

- **`sota-shell-scripting` rules/06 §2c — a search pattern beginning with `-` is a flag.**
  `rg -c -F '- [ ]' . 2>/dev/null` reported nothing against a real 65 matches: pattern eaten
  as a flag, `unrecognized flag` on the suppressed stderr, `$?` taken after a pipe. Use
  `-e PATTERN` or `--` whenever the pattern is data. Carries a measured shell differential —
  the same `printf` **succeeds in zsh 5.9 and fails in bash 5.3**, with three different exit
  codes across four implementations, so one green run proves nothing.
- **`sota-shell-scripting` rules/06 §2d** — the checklist idiom above, written up as a rule
  with the exit-code branch that replaces it.
- **`sota-shell-scripting` rules/06 §2a — a mechanical tell for `rg -rn`.** `-rn` parses as
  `-r n`, so the `-n` is eaten and output returns as `path:content` rather than
  `path:LINE:content`. **Typed `-n` and the line numbers are missing? The content was
  rewritten.** The prior tell required judging unfamiliar code. Third independent occurrence
  with the rule installed — recorded, because the lever is not stating it more loudly.
- **`sota-performance` rules/01 §9a — a suspiciously *slow* duration indicts the
  measurement.** §9a covered only "suspiciously fast". A reporter extrapolated a 6x suite
  regression from a backgrounded run and wrote it to a durable memory file; backgrounded jobs
  on that harness carry `nice 5` against the foreground shell's `nice 0`. Ships with its
  audit half.
- **`sota-shell-scripting` rules/08-ad-hoc-side-effects.md** — `rules/06` hit its 500-line
  cap, so §3 (blast radius) and §4 (process-table exhaustion) moved to a new file, **keeping
  their section numbers**. Seam chosen by citation weight, not headings: the §2 family
  carries 25 citations against §3+§4's 8. `rules/06` is now "the check returned the wrong
  answer"; `rules/08` is "the check did damage".

### Changed

- **README surfaces the three slash commands at the top.** `/sota-resume`, `/sota-close` and
  `/sota-report` were documented at line 1016 of 1401 — past where most readers stop. They
  are the parts used most often, so they now appear with the install instructions and are
  named in the table of contents.


### Added — a git range that invents security regressions, and a scanner that reads what git hides

Intake from a session *applying* the library on a private security product. Every falsifiable
claim reproduced here before a verdict; reasoning and the two corrections in
[docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md).

- **`sota-docs-workflow` rules/03 §3a — `git diff main..pr` is not what the PR changes.**
  Two-dot **diff** compares tips, so everything `main` gained after the fork renders as a
  deletion on the branch's side. The error is *directional*: it only ever invents regressions,
  and in a lockfile an invented regression reads as a supply-chain attack. Field-reported: a
  reviewer concluded a PR downgraded a TLS library past the previous day's advisory fix, wrote
  it into a commit message and drafted a PR comment; the PR did not touch that dependency.
  Measured here on a branch four commits behind its base — two-dot reported **15 files and 742
  deletions**, three-dot and the forge's compare API reported **zero**. The rule carries the
  reason the habit survives, which the report did not state: `git log main..feature` is
  *correct* and `git diff main..feature` is not, so the same token means different things per
  subcommand. Ships with its audit half.
- **`sota-secrets-management` rules/04 — a working-tree scan is not limited to tracked files.**
  `gitleaks dir` and directory scanners generally do not read `.gitignore`, so an untracked
  artifact invisible to `git status` is still in scope for the gate. Verified on gitleaks
  8.30.1 with a positive control, *after* a first attempt using the canonical AWS documentation
  key returned "no leaks found" and would have refuted a true finding. When a secret gate fails
  while history is clean, triage **by file** before reading any diff.

### Changed — `/sota-resume` asks for a decision the same way in both places it asks

The command told the agent to present options, trade-offs, a recommendation and its reasoning
in **rule 5** (the mid-execution pause) but not in **rule 2's `NEEDS A DECISION` row**, which
said only *"State the question and your recommendation."* — and **rule 3**, the stop where the
operator actually confirms the list, said nothing about it at all. An agent following the
letter of rule 2 could hand over a bare recommendation, with no alternatives and no reasoning,
and still be compliant. That is the *first* decision point of a session and the one most
"pick one of these" moments land on, so the weaker wording governed the more common case.

- **`commands/sota-resume.md` rule 2** — the `NEEDS A DECISION` row now asks for the question,
  two or three options, and the recommendation *with its reasoning*, naming rule 5 as the form
  rather than restating it.
- **`commands/sota-resume.md` rule 3** — states that decision-shaped items arrive in that form
  at the confirmation stop, and that they are batched into that one interruption.

Deliberately **not** a third copy of rule 5's paragraph: this repo's own measured failure mode
is that a rule already stated three times still goes unfollowed, so a fourth restatement is the
anti-pattern. Both sites point at rule 5 instead.

### Fixed

- **`/sota-report` told you to write the report into the target repo's root**, justifying it
  with a fact about *this* repo (`.local.md` is gitignored here). Followed literally during a
  gate run it dirties the tree and feeds an unreviewed file to a secret scanner — which is what
  happened. It now says to write outside the tree unless both the ignore status
  (`git check-ignore -v`, which also reads `.git/info/exclude`) and the absence of a
  directory scanner have been checked.

## [1.42.1] - 2026-09-14

**Front door checked:** PowerShell · pwsh

**Routing checked:** evals/results/2026-09-14/POWERSHELL-ROUTING.md

### Changed — three rules from a session's own failures, and one that deliberately stays out

Intake from a session *applying* the library. One of the three was **licensed by an existing
rule**, which is a worse finding than a gap. Reasoning: [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md).

- **`sota/SKILL.md` principle 0 — a doc page states intent; only running it reports
  behaviour.** The taxonomy routed "what does this command do when the input is missing" to
  the documentation, because it reads as a *tool capability*. Measured: Poetry's own page says
  a desynced lock produces a "Warning" while the tool exits **1**, and a mechanism published
  from that summary had to be retracted. If the tool installs in two minutes, run it — both
  the failing and the passing case.
- **`sota/SKILL.md` routing-gap paragraph — watch the regression case fail FIRST.** It
  required a case as proof but never that the case be observed failing on the pre-change tree.
  A case written to pin a PowerShell routing gap scored 1.00 in both arms before *and* after.
  **An absent string is not an absent capability**: a model routes on meaning, so grep cannot
  answer reachability. Same doctrine as every gate here.
- **`sota-shell-scripting/rules/01` audit checklist — a VERDICT read through a pipe.** The
  build rule existed in three places and the audit half in none; its neighbours cover
  *measurements* piped into a filter and background launchers, not the pass/fail case that
  gets reported to a human. Carries the structural fix rather than another warning.

**Not added, deliberately:** a fourth copy of the exit-status rule. It fired twice in one
session *with* three copies present — a warning about a reflex does not disable the reflex.
Nor is it gateable: `shellcheck -S style` already flags the `$?` form (SC2181) in committed
shell and finds nothing, because both failures were in **ad-hoc commands that are never
committed**. A repo gate's reach stops at the tree. Before proposing a gate, ask where the
defect *lives*.


### Added — `sota-shell-scripting` covers PowerShell, and `sota-c-cpp` says where it stops

An external audit reported four domains with no owning skill. Re-derived here with a positive
control on the sweep, they were four different things, and only one earned a rules file. Full
reasoning and the two rejections: [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md).

- **`sota-shell-scripting/rules/07-powershell.md`** (new, 248 lines). This skill's premise is
  that shell hides in CI blocks, entrypoints and Makefile recipes; on a Windows runner that is
  PowerShell, and **0 of 42 skill descriptions named it**, so the skill silently stopped
  applying. Covers the missing `set -euo pipefail` (and why the obvious replacement is inert),
  three disagreeing status variables, `pwsh -File` vs `-Command`, GitHub Actions shell
  defaults, `Invoke-Expression`, execution policy, versions with EOL dates, and
  PSScriptAnalyzer. Every claim is from Microsoft Learn or GitHub's docs.
  - The headline rule is one you would not write from recall:
    `$PSNativeCommandUseErrorActionPreference` defaults to **`$false`**, so
    `$ErrorActionPreference = 'Stop'` does nothing for a failed `git`, `docker` or
    `terraform`. A control that is present and inert.
  - A first draft of the GitHub Actions section was **wrong and caught before shipping** —
    the built-in `pwsh` shell prepends fail-fast and appends `exit $LASTEXITCODE`; it is
    opting out with a custom `shell:` string that removes them, the inverse of the draft.
- **Routing — and the claimed gap did not reproduce.** The audit said PowerShell had no
  description match; grepping confirmed the *string* was absent from all 42 descriptions, and
  that was taken as a routing gap. Measured against the pre-change tree, **it is not one**: a
  Windows CI PowerShell task already routed to `sota-shell-scripting` 3 of 3, from "shell
  scripting … CI scripts … entrypoint script" alone. The first regression case written here
  pinned nothing (1.00 in both arms) and was **discarded**. The real gap is narrower and was
  found by probing harder phrasings: a task naming `pwsh` with a *competing* signal
  ("injection") went to `sota-code-security` 3 of 3 **before** and `sota-shell-scripting` 3 of
  3 **after** — now pinned as `r4_pwsh_injection`.
  **Routing checked:** evals/results/2026-09-14/POWERSHELL-ROUTING.md
- **`sota-c-cpp` states its embedded boundary.** It already carries MISRA C:2025 and
  freestanding builds, so it *half*-owned embedded work — worse than not owning it, because a
  C++ RTOS driver got language-layer advice with no statement of what was missing. Its Purpose
  section now names what no skill here covers: ISRs and reentrancy, DMA coherency, MMIO and
  `volatile`, RTOS scheduling and priority inversion, WCET, linker scripts.
- **Not done, deliberately:** CUDA/GPU is deferred with a revisit trigger; compiler/JIT
  construction is rejected (consuming a JIT is already covered in four language skills).


### Changed — invariant 11's escape hatch must now declare, not merely mention

Escape (b) matched a bare substring, so **any** added CHANGELOG line containing the stamp's
name excused a stamp move for the whole diff. Worse, it disarmed the negative control even
when the stamp had not moved: a PR whose CHANGELOG merely mentioned the token made probe 11
report the check **INERT**, so the check went unverified exactly when someone was writing
about it. That happened twice in three days — the second time in this very PR, whose README
bullet named the stamp in passing.

The escape now requires the added CHANGELOG line to name **both** the token and the stamp's
new value: a declaration that must be true, matching the design every other escape in
`check-invariants.sh` already states. It adds no magic string (a sweep entry names its date
anyway) and keeps the rolling-pass path intact — the two objections recorded in
[docs/CONVENTIONS-LEDGER.md](docs/CONVENTIONS-LEDGER.md), which is corrected here: its claim
that "in ordinary operation mentioning the token costs nothing" was false, and its "Why it is
narrow" paragraph understated the exposure.

Two probes, because a gate with a declared escape needs a known-bad for **the escape**:
**11b** (a mention that declares no date must be caught) and **11c** (a real rolling-pass
declaration must still pass, so the tightening has not collapsed escape (b) into (a)). The
comparison is made with a shell `case` rather than a trailing `grep -q`, which under
`pipefail` SIGPIPEs its own upstream — the defect behind invariant 14's five-month
false rejection. Harness: **55 probes**.

### Fixed — an external audit's two real hits, plus the one it got backwards

An unsolicited third-party audit report was taken as field-brief intake and re-derived
claim by claim. Two of its five technical claims landed, two were refuted against primary
sources, and one was right in its conclusion and wrong in its mechanism. Full ledger,
including the four rejections with the source that killed each:
[docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md).

- **`sota-devsecops` rules/03 §3.1 — a frozen-install command that fails open on a *missing*
  lockfile.** Measured on Poetry 2.4.3, not read off a doc page: a desynced `poetry.lock`
  exits 1, but with **no lock at all** `poetry install --no-root` resolves fresh, installs,
  writes a lock and exits **0** — the section's own BAD pattern at a green build. The cell is
  now `poetry check --lock && poetry install --no-root`, and a new bullet generalises the
  question to every cell in that column: *what does it do when the lockfile is absent rather
  than wrong?*
- **`sota-devsecops` rules/03 §3.1 — the Go row.** `go.mod` pins and `go.sum` authenticates;
  `-mod=readonly` has been the **default since Go 1.16**, so prescribing it implied a control
  that is already on, and `go mod verify` checks only the local download cache. The row now
  names the control that earns its place (CI failing on a dirty `go mod tidy` diff). The
  broader claim that Go builds are *not* frozen is refuted in the ledger — MVS is
  deterministic by specification.
- **pnpm guidance was two majors stale, at two sites** — `sota-devsecops` rules/03 §3.4 and
  `sota-javascript-typescript` rules/05, the second of which the report never opened.
  `onlyBuiltDependencies` was **removed in pnpm v11** and replaced by `allowBuilds`; both
  sites now also carry `strictDepBuilds` (default `true` since v10.3.0), the half that exits
  non-zero instead of warning.
- **`sota-code-security` rules/04 §6 — a claim stated above its evidence.** "recovers secrets
  byte-by-byte" is the worst case of a timing side channel, not its guarantee. Rewritten to
  the strength the primary sources support (Python's *"designed to prevent timing analysis"*
  and its types/lengths caveat; libsodium's *"the goal is to mitigate side-channel attacks"*)
  while keeping the fix unconditional — principle 3 applied to our own prose.
- **README** asserted "every fast-moving claim web-verified against a primary source" with no
  date attached, and the pnpm miss is the counterexample. Now qualified by the root
  verification stamp and pointed at operating principle 1.

## [1.42.0] - 2026-09-14

**Front door checked:** sota-resume · sota-close · sota-report · check-claims.sh · invariant 30

### `/sota-close` and `/sota-resume` — the two ends of a session, and a denominator for commands

Two more slash commands, installed by `scripts/install.sh` exactly like the first (the
installer already globbed `commands/*.md`, so it took no installer change — verified against a
throwaway `HOME`: `slash command(s) installed: /sota-close /sota-report /sota-resume`).

`/sota-resume` is the opening move: sweep every tracker, checkbox and `TODO|FIXME` marker,
classify what is actually actionable, show the table, then execute what the operator agrees to
— one item at a time, against the project's own CI entry point rather than an assumed one. Its
inventory step is written around the fact that **a clean "nothing found" is the answer the
operator was hoping for, which is exactly when to distrust it**: a `grep -r` over a symlinked
tree, an `rg -r` that is really `--replace`, and a lister capping at 30 rows all return a
confident zero at exit 0. It asks for a positive control in the same invocation and a
denominator beside the count. Its largest class in practice is **already done and never ticked
off**, where the fix is a doc correction and not code.

`/sota-report` tells the **library** what went wrong. `/sota-close` closes the **session**
down: retract first, record open items where a new session will trip over them, update the
docs and agent files the session made false, re-derive every number from its source, state
what is not done and what is blocked on whom, then commit the evidence and confirm the push
landed.

Two things in it are load-bearing and are stated in the prompt rather than assumed:

- **The order.** Steps 2–6 all *write*. Anything retraction misses is propagated by them into
  a doc, a commit message or a hand-off, where the next session reads it as established.
- **A summary is not a source.** By the end of a session the context has usually been
  compacted, so "what happened" would be reconstructed from the assistant's own earlier prose
  about the work — the weakest check available (router principle 7). Every step is executed
  against an artifact instead: `git diff`, `git log -S`, the file on disk, the command re-run.

It also splits **delete vs supersede**, which is where this pass usually goes wrong: delete a
line that states *current state* (a caveat beside a wrong line leaves both readings live and
the reader picks one); supersede a line that is a *record* (a changelog entry, a measurement,
a ledger verdict), because editing a record destroys the trail showing the number moved.

**verify-setup check 1d — commands match the checkout.** Check 1c proves one command, the one
whose absence costs this library its only feedback channel. 1d is check 1's *denominator* idea
applied to `commands/`: installed versus what the checkout ships. A `git pull` refreshes every
existing symlink and creates none, so a command added upstream stays uninstalled and silent —
the identical failure that made check 1 grow a denominator after it printed "41 skills" over a
tree of 42. It reported `PARTIAL … missing: /sota-close` on the author's own machine before
the link was made, `PASS … all 2 installed` after, and `all 3 installed` once `/sota-resume`
joined — the count is read from the checkout, so it needs no maintenance. PARTIAL rather than FAIL: a missing
workflow command costs a workflow. Probed (`a shipped command is not installed`), which needed
the fixture to ship **two** commands — with one, 1c and 1d break on the same removal and 1d's
probe cannot distinguish itself from 1c's. `PASS: 52/52` on the committed tree, with `1d` in the harness's own printed
coverage list.

**A run whose script was edited mid-flight is not evidence.** The first harness run reported
`52/52` and the new probe caught — but its printed coverage line said `1, 1c, 2, …`, omitting
the check it had just probed, because the coverage line was edited *while bash was still
reading the script*. Part A also reads the **committed** tree, so that run never tested the
widened invariant 18 scope at all. It was discarded and re-run against the commit rather than
cited; the tell was the summary contradicting the probe two lines above it.

**Corrected 2026-09-14, same day, by measuring the mechanism that paragraph asserts.** The
edit was made with `perl -pi`, which does **not** edit in place: it writes a new file and
renames it over the old one, so the running `bash` keeps the **original inode** open and never
sees the change. Differential, one variable:

    cat > script   inode UNCHANGED   the running script printed "EDITED LINE!!"
    perl -pi       inode CHANGED     the running script printed "ORIGINAL LINE"

So the claim above is wrong in a way that matters: the run was **not** incoherent. It executed
the entire original script start to finish, and its `52/52` was a real verdict on the old
script. The stale coverage line is the *expected* output, not a symptom. What actually
disqualified it stands and is the second sentence: part A reads the **committed** tree, which
did not yet carry the widened invariant 18 scope — so it never tested the one change most
likely to break a probe. Discarding it was right; the reason given was not.

Left standing rather than rewritten, because a changelog entry is a record. The general form
is the same write-new-and-rename this library already documents for symlinks and hard links
(`sota-shell-scripting` rules/05 §3b/§3c), with a third consequence: **an in-place editor is
invisible to a program already running from that file.**

**Invariant 18's scope gained `commands/*.md`**, because these files ship to machines where
the reader has no checkout to resolve a citation against. It earned its place on the first
run: a `§2b` in this command's own first draft resolved nowhere, while the `§5` beside it
**passed for the wrong reason** — the fail-open resolver tries the containing file, and the
command has a `## 5.` section of its own. Both citations now name the skill explicitly.

### Invariant 14 could reject a correct release, and did — a pipefail SIGPIPE

Found by this cut, on this release. Invariant 14 verifies every declared front-door term
appears in the release's own CHANGELOG entry. The per-term test was
`printf | grep -v | grep -qiF`, and **`grep -q` exits on its first match and closes the
pipe** — so the upstream `grep -v` dies of `SIGPIPE` (141), and `set -o pipefail` makes that
the pipeline's status. Four of five declared terms were reported *"absent from the release's
own entry"* while sitting in the entry's first heading.

**It is position- and size-dependent**, which is why it survived every release since v1.19.7.
The race only exists while `grep -v` is still writing when `grep -q` exits — so it needs a
section larger than the pipe buffer, and a term near the top. `invariant 30`, 130 lines
further down, passed in the same run. Falsifier stated before measuring, both halves held: at
20,000 lines the early term fails and the late one passes; at three lines both pass, because
the whole input fits in the buffer. Padding this entry to 3,498 lines made **all five** fail,
including the one that had just passed.

**It fails closed** — no bad release was ever waved through. That is not as reassuring as it
sounds: it blocks a *correct* release, and the quickest way back to green is to delete the
term from the declaration, which silently weakens the gate this check exists to be.

Fixed by matching with a bash built-in — `[[ $sec_body != *"$t"* ]]` under `nocasematch`,
the same substring test `grep -iF` performed, with no pipeline to carry a status. The entry
minus its declaration line is computed once instead of re-piped per term.

**Probe 14b — and it shipped broken, caught by CI on the very next PR.** Its first draft only
padded the CHANGELOG, and passed locally purely because it ran on the release branch, where
`VERSION` already differed from the merge base. On any other branch invariant 14 reports *"not
a release commit"* and never runs, so the probe went green on a check that had **skipped** —
precisely the false pass `probe_committed_green` exists to refuse, and it refused it:
`FALSE PASS: green, but the exempting check never said so`. The fixture now builds its own
release (VERSION, `plugin.json` and the top CHANGELOG section together) so invariant 14 fires
wherever it runs. **A local green on a diff-based check is one tree at one moment**
(`sota-code-security` rules/12 §1d); the probe written to guard a defect was itself an
instance of the class the same release documented.

Two more defects in that fixture, both caught by running it rather than reading it: it renamed
only the `[1.42.0]: ` label and left the URL pointing at the old tag (invariant 23: *"does not
point at /releases/tag/v99.0.0"*), and a first dry run reported the gate skipping because the
fixture commit had been rejected by the pre-commit hook and never landed — the gate was reading
an uncommitted tree. Re-verified as a differential under the fixed fixture: the pre-fix code
says `NOT IN THIS RELEASE: "Kubernetes"`, the fixed code says `ok (1 terms declared, all
resolve)`.

**Probe 14b**, the direction probe 14 cannot see. Probe 14 proves a *missing* declaration
fails; nothing proved a *valid* one passes. It pads the top section past the pipe buffer,
leaves the terms at the top, and asserts invariant 14's own `ok (N terms declared, all
resolve)` line — a bare exit 0 would pass on a check that merely skipped. Verified as a
differential on identical input: the pre-fix code reports all five terms absent, the fixed
code reports `ok (5 terms declared, all resolve)`. It pads the existing section rather than
adding a `## [99.0.0]` heading, which would push the real top version below it — untagged
until the merge — and fail invariant 21 for an unrelated reason. `PASS: 53/53` on the committed
tree, both positive controls first, with probes 14 and 14b catching in opposite directions.

### `scripts/check-claims.sh` — the claims the advice rests on, re-run every CI run

**This gate shipped without release notes and is being written up at the cut that found it.**
It landed in #373 with 305 lines of harness and a two-OS CI job, and the CHANGELOG got three
sections about the *intakes* that arrived alongside it and none about the gate — a capability
invisible in the release notes and, until now, absent from `README.md` and `docs/INDEX.md`
too. That is the exact class the front-door check in [RELEASING.md](RELEASING.md) §2b exists
to catch, and it caught it.

**What it does.** `skills/` is full of sentences claiming something was measured — the word
alone appears on ~200 lines, and the count moves by a dozen depending on which searcher and
flags you ask with, which is its own argument for executing the claims rather than counting
them. A few dozen are executable in a temp directory in milliseconds, and those are the ones
that rot silently when a tool changes. The harness re-runs **13** of them on **Linux and
macOS** every CI run — both legs, because several are *platform splits* and one runner can
only ever confirm its own half.

**Scope is deliberate and narrow**: deterministic and platform-split only. Not network claims
(an `endoflife.date` row changes by design, so asserting it makes CI red on a correct world)
and not claims costing live API calls. A missing binary **skips with a reason**; **zero claims
executed fails**, because `0 run, 0 failed, exit 0` is the signature of a gate that verifies
nothing. The Linux leg installs `ugrep`, `ripgrep` and `zsh` first — without that, claims 5
and 7 skipped on *both* runners and the matrix verified 8 of 11 while appearing to verify all
of them.

**It refuted one of its own rules on the first run.** The library said an empty value in a
filter removes the filter rather than matching nothing — true, and the rule generalised it to
every `--filter`-shaped flag. Claim 8b measured the other half: `ps -p ""` is **rejected**
(non-zero exit, no rows), it does not list every process. A **pattern** filter drops an empty
value and widens; an **identifier** filter refuses it. `sota-shell-scripting` rules/06 §2b was
corrected to say which is which — a rule made narrower by the instrument built to check it.

### Invariant 31 — new rule sections ship with an entry in the intake ledger

This closes a gap found by auditing this repository's own gates, and the honest statement of
it is blunt: **all thirty other checks assert structure, consistency or a declaration, and
none of them looks at whether a rule is true.** That is not fixable in general — *"is this
claim correct"* is semantic, and a fuzzy gate gets disabled, leaving you worse off than the
prose it replaced ([docs/CONVENTIONS-LEDGER.md](docs/CONVENTIONS-LEDGER.md)).

So it gates the part that **is** mechanical: whether the rule went through review at all.
`docs/ADOPTION-LOG.md` is where an idea's verdict and reasoning are recorded. An **external**
proposal always lands there. A rule its author both *found and adopted* never does — and that
is precisely the path that skips scrutiny. `sota-code-security/rules/12` §1d was authored and
adopted in one session, shipped on **30 green checks**, and an adversarial read then returned
**eleven** defects, including a `§` reference that resolved cleanly — invariant 18 green —
while its target grounded the opposite prior.

It gates the record, not the judgement: the same shape as invariants 14 and 29.

**A moved heading is not a new rule.** This repo splits rules files regularly and a split
re-adds every heading it carries, so a heading that existed in *any* `skills/*/rules/*.md` at
the merge base is exempt. Without that the check would fire on every split, open red, and be
disabled — the exact failure the ledger warns about. There is deliberately **no manual escape
hatch**: the exemption removes the only large false-positive class, and an escape nobody can
trip is a checkbox.

**Probes 31 and 31b** — a new section with no ledger entry (must fail), and a relocated
heading with no ledger entry (**must stay green, and say so**). The second needed a new
harness helper, `probe_committed_green`: a bare `exit 0` would have proved nothing, because a
check that *skipped* is also green, so it asserts the exempting check's own ok-line. 28 of 31
checks are now probed.

Verified by hand in all three directions before the probes were written: new section without a
ledger entry **fails** with the right diagnostic; the same section with one **passes**; a
relocated heading is **exempt**.

### Invariant 30 — a declared count must agree with the list it counts

Closes ROADMAP item 56, and removes the constraint that had blocked it for exactly one day.

**`AGENTS.md` restructured first, because it was the blocker.** The 29-row invariants table
moved to **[docs/INVARIANTS.md](docs/INVARIANTS.md)**. `AGENTS.md` loads into *every* session
under a 200-line cap and sat at **199**; every new invariant cost it a row, and the cap had
been breached by exactly that — twice landing at 201 and 202, and hitting 200 twice more
while editing this session (a breach never lands, so the total is not recoverable from git).
Now **169**, and the reference grows
freely. Nothing was dropped — the table moved whole, and `AGENTS.md` keeps the operational
half a session actually needs.

Invariant 17's enumeration assertion was pointed at `AGENTS.md` and *followed the table*. It
reported the empty list loudly on the first run after the move, which is the check working;
it now reads `docs/INVARIANTS.md`, and `docs/WHY-IT-WORKS.md` joined its doc set too.

**The gate is opt-in, and that was a measurement rather than a preference.** A sweep for
`<number-word> <plural-noun>` across the front-door docs returns ~200 hits, nearly all
historical prose in CHANGELOG and ADOPTION-LOG entries that must never change. A strict
auto-detecting rule would open red and be disabled, which is worse than none. So the pairing
is declared next to the claim, where it travels with the prose:

```markdown
Twenty-nine classes of defect survive every linter, ...
```

The marker names the pattern, the claim is the next non-empty line, and the scope runs to the
next heading. Occurrences are counted, not matching lines, so a separated inline list works
with a `+1` offset. Three markers ship: the README's audit classes, the roadmap's item total,
and the conventions ledger's enforced list.

**Probes 30/30b/30c** cover the number edited down, **the list grown with the sentence left
behind** (the direction that actually happens), and every marker deleted — which must report
`SCOPE EMPTY`, not `ok`. 27 of 30 checks are now probed.

### Three things this found while being built

- **The first parser was written against the one sample in front of it.** It read
  `Twenty-nine` correctly by luck and read `Eleven classes` as a single unparseable token, so
  it caught the real historical defect with the **wrong diagnostic**. Probe 30 asserts on the
  comparison's own wording and would have reported `NOT CAUGHT` — which is how it surfaced.
  This is `sota-code-security` rules/15 §2.1 aimed at this repository's own gate.
- **The conventions ledger had drifted a third time** — heading 30, list 29 — the exact
  recurrence its own correction note describes, and the note explains why: invariant 17 reads
  the stated count and never the list. It is now gated.
- **Two more live stale counts**, both fixed: `docs/ROADMAP.md` *"Of 55 items"* (a sentence
  invariant 26 cannot see, since 26 reads only the open set) and `docs/WHY-IT-WORKS.md`
  *"Fourteen invariants"* — **sixteen behind**, because that file was in no gate's doc set.

### A probe went inert because the thing it guards got healthier

Restructuring `AGENTS.md` from 199 lines to 169 **silently disarmed probe 24**, and the
negative-control harness caught it on the very next run. The probe appended exactly one line
to breach a 200-line cap — which breaches only from 199. At 169 the same mutation stopped
breaching anything, invariant 24 correctly passed, and the probe reported `NOT CAUGHT: INERT`.

This is a shape the library did **not** name until this change — verified by sweep with a
positive control, not assumed: **a control whose strength decays as the thing it guards
improves**, with no red build at the moment of decay. Nothing
was wrong with the gate, and nothing was wrong on the day the probe was written. The probe now
measures the file and pads to the cap from wherever it is, printing both numbers.

Worth stating plainly because it cuts against intuition: **the health improvement and the
control weakening were the same edit**, and only a harness that re-derives its own mutations
each run can see that.

Landed as a rule: **`sota-code-security/rules/12` §1d**, the blind sibling of §1b's drifted
literal. §1b's case is caught by *assert the mutation took*; this one passes that guard,
because the mutation really does apply. Field report III called this class *"already in the
library"* — checked with a positive control and two sweeps, it was not
([docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md)). It was accepted unverified during the intake
because it sat in the report's *"what worked"* section rather than among its proposals:
**a report's non-proposal sections make claims about the library too, and they arrive
without the framing that triggers a check.**

### The rule we wrote for ourselves went through the intake it had skipped

`rules/12` §1d was authored here and was about to ship on green gates. An independent
adversarial pass — prompted to kill it, defaulting to REFUTED — returned **11 findings**, and
**all 30 invariants were green on all 11**. The gates check structure: the line cap, a
checklist present, `§` references resolving. **Nothing here checks whether a rule is true.**

Three of the findings are worth naming beyond this release:

- **Invariant 18 proves a `§` reference *resolves*; it can never prove the target says what
  the citing sentence claims.** §1d cited `rules/15` §2.1 for a prior that §2.1 grounds the
  opposite way — on *recency of authorship*, where this case has the probe as the **older**
  artifact. Green check, wrong claim.
- **A default that inverted an existing tool's semantics.** *"`NOT CAUGHT` is a claim about
  the probe until proven otherwise"* would have taught readers to dismiss inert gates — the
  failure that string exists to reveal. Now a disambiguation, resolved by asking whether the
  mutation crossed the threshold.
- **A self-contradiction shipped across two files in one branch** — the probe comment and this
  CHANGELOG called the class *"the shape the library already names"* while
  [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md), in the same branch, correctly said it did not.

The load-bearing claim survived: `AGENTS.md` was **exactly 199 lines** at the commit that
introduced probe 24, so it was effective at birth and genuinely decayed rather than being born
broken — with a margin of **one line** from day one, which the rule now says.

**Standing change:** a rule authored *and* adopted in the same session is the highest-risk
change in a PR, not the safest.

### `/sota-report` — the field-report ask, shipped where it is reachable

The library has no telemetry and learns nothing from use unless the session that used it says
so. That ask now ships as a slash command rather than a doc you have to go and find:
**`/sota-report`**, run at the *end* of a working session in the project that hit the problems.

- **`commands/sota-report.md`** is the single source of the prompt text; installed by
  `scripts/install.sh` (and therefore `update.sh`) into `~/.claude/commands/`, symlinked so an
  update refreshes it, snapshotted under `--copy` like the skills.
- **User-level, never project-level, on purpose** — the report is written in the *other*
  project, about work done there, so it belongs to the person rather than a checkout. It is
  therefore not derived from `--project`'s target either.
- **[docs/FIELD-REPORT-PROMPT.md](docs/FIELD-REPORT-PROMPT.md) no longer repeats the prompt.**
  It holds the reasoning — why each of the four checks exists, with the intake failure each
  one prevents — and points at the command. Two homes for one rule is how they drift.

**The report is stamped with the version that produced it, and an old version is not a reason
not to send one.** The evidence is bound to the version that made it — so `/sota-report`
records the installed VERSION and install type, and explicitly **does not offer to update and
re-run**: the session already happened under the old skills, updating cannot re-run the work,
and a fresh stamp on old behaviour is worse than an honest old one, because the stamp is what
triage trusts.

Triage does not need the reporter to be current. Measured 2026-09-14 over a genuine month
(`v1.22.5` → `HEAD`): **93 of 271 rules files changed — 66% untouched**, so a month-old report
is usually about text that still ships verbatim. The check is one command —
`git log --oneline v<theirs>..HEAD -- <the file they cited>` — and an empty result means the
finding applies as written. Where the text *did* change, all three outcomes earn a ledger
line, including "already fixed": that is the only signal this library gets that a fix reached
a user. Full triage guidance, including why finding *type* predicts version-sensitivity better
than age does, in [docs/FIELD-REPORT-PROMPT.md](docs/FIELD-REPORT-PROMPT.md).

**The extract is a file, and the submit command is printed, not run.** It is written to
`FIELD-REPORT-*-EXTRACT.local.md` (gitignored by the same rule) so you can read the exact bytes
before anything leaves the machine, and the command prints a ready
`gh issue create --body-file …` line plus the template URL for anyone without `gh`. Two
best-effort checks run **only if you say you want to submit** — a version-delta note and a
duplicate search — both silent on failure, neither blocking, and never on the report itself:
this library makes no network request unless a human asked for one.

**Reports from anyone but the maintainer.** A new
[field report issue template](.github/ISSUE_TEMPLATE/3-field-report.yml) gives the library its
only channel from people who use it. Its fields are what intake actually needs — what
happened, the mechanism, **whether the rule was already loaded** (the highest-value field),
what caught it, the proposed rule, and a self-graded confidence.

**The command prints an extract and is forbidden from posting it.** Not discouraged —
forbidden: print and stop, no `gh issue create`, no API call. This repository is public and
issues are indexed, cached and mirrored; per this repo's own `.gitignore`, field reports
*"routinely name private repos, internal hosts and customer detail"*. The extract drops
transcripts, appendices and real paths — most of the disclosure risk lives there, and it is
the part a maintainer who cannot run your repo needs least. **The gap between "I generalised
it" and "a human confirmed it is safe" is where a leak lives**, and no genericisation pass by
the model that just wrote the private detail closes it.

**`verify-setup.sh` check 1c — the report command is reachable.** An install where the skills
reach the machine but the command does not is a library that keeps working and can no longer
be told when it is wrong. Four states, not two: a live symlink (PASS), absent or dangling
(FAIL), a `--copy` snapshot that will not update (PARTIAL), and a file that is not ours, left
alone. Two negative-control probes cover it — absent, and **dangling**, which is a separate
branch because `-e` follows a symlink.

**A dead branch caught by feeding it the input, not by reading it.** The first draft tested
`[ ! -e ]` before `[ -L ]`, so a dangling link took the "not installed" path and the
dangling-specific message was unreachable — it reported the wrong cause for a link that
exists and points nowhere (`sota-code-security` rules/15 §2.2: prove every branch reachable).

The four checks it front-loads are each a real intake failure, not a hypothetical: searching
in the wrong vocabulary against a working instrument; proposing a rule for a file that does
not own the topic; reporting "refuted" from a harness that reaches nothing; and asserting a
mechanism from one artifact.

**A bug caught before it shipped:** the installer function first used `$CLAUDE_HOME`, which
does not exist in `install.sh` — it would have expanded to empty and written to `/commands`.
Found by checking that every variable used was defined, then dry-run against a throwaway
`HOME`.

### Field report III — a principle corrected, and a mechanism its reporter refuted

Four proposals about **epistemics under correction pressure**, and the most valuable item was
not one of them. See [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md) for the full verdicts.

- **Operating principle 3 corrected.** It said *"'independent' means a different failure mode,
  **not a different phrasing**"* — right for its original case (two `grep -r` runs over a
  symlink farm are not two methods) and wrong as the last word on absence. The reporter
  declared a gap after searching *"one instance | a single observation"* **with a working
  positive control**, while the corpus says *"one sample"* in six files including a named
  failure mode. It now carries their formulation: **a control proves the instrument works; it
  does not prove the query asks the corpus's question.**
- **Operating principle 0 — a retraction is a claim and carries the same burden.** A wrong
  claim gets challenged; a wrong retraction sounds like humility and is waved through —
  **nobody audits a confession.** Field-reported: a *correct* statement withdrawn with the
  falsifying evidence on screen, then re-corrected. **The moment after being corrected is the
  highest-risk moment in a session**, and every other rule pointed only at the original claim.
- **`sota-shell-scripting/rules/01` §2b — a non-zero exit is evidence about one attempt, not
  about the world.** A push reported `[remote rejected] … is at 8a93e40` where `8a93e40` was
  the commit it was sending; the branch was fine. Every reflexive remedy — re-push, `--force`,
  `reset --hard` — is destructive to a branch that is fine. **The mechanism is labelled
  unverified**: the reporter tried twice to reproduce it, stated the falsifier first, and
  failed both times, because git's local transport has no retry — the environment could not
  reach the defect.
- **§2a extended** — a live task's output file is a *buffer*: short, truncated and complete are
  the same bytes. Plus: do not write to a resource a live task owns, and print a denominator
  when a task-log grep returns zero.
- **`rules/15` §2.1 third bullet** — a claim stated at a coarser grain than its evidence. The
  two existing members are about a *thing you built* generalising; this one is about a
  **sentence**.
- **`rules/12` §1a.1 — a failed reproduction is an absence claim, and needs the same two
  arms.** §1a already demanded an allow arm beside a deny arm for a *control*; nothing pointed
  it at an *experiment*. The new half is the reporting consequence: *"it did not reproduce"*
  carries principle 3's heavier burden but **does not feel like a search**, so the rule never
  fires — and a refutation passes unchallenged in a way *"no instances of X"* would not. Tell:
  **a null arriving instantly and identically on both runs**. Label it *"did not reproduce
  here"*, never *"refuted"*.

**Correction to the entry above, same day.** `rules/01` §2b shipped saying §2's mechanism was
*not established*. The reporter then reproduced it with a control arm (alpine 3.22, git
2.49.1, real `git-receive-pack --stateless-rpc`, POST delivered twice): control exits 0 and
advances the ref, test exits non-zero **while the write lands**, quoting the value just
written. §2b now records that, **as field-reported rather than measured here**. The wider
generalisation stays plausible and unproven — one protocol is not the class — and the rule
depends on neither.

### `verify-setup.sh` reads better on a terminal, and identically to a machine

Colour and a status symbol per row (`✔ PASS`, `✘ FAIL`, `▲ PART`, `? UNVR`, `ℹ INFO`,
`· N/A`), dimmed evidence so the status and label carry the scan, bold section headers, and
summary counts where a zero `FAIL` is grey rather than red — a clean run has no red in it.
New `--no-color`; `NO_COLOR` and `TERM=dumb` already honoured.

**The TTY gate is load-bearing, not polish.** `check-negative-controls.sh` part B asserts on
lines that *start with* the status word — `case "$line" in (FAIL*"$needle"*)` — and **twelve
probes depend on it**. Those probes capture output through `$( )`, so stdout is not a TTY and
the plain branch runs. Decorating unconditionally would have turned all twelve into silent
FALSE PASSes: a gate that looks fine and checks nothing. Verified by diffing the piped output
before and after — identical but for the §F change below.

**§F deduplicated.** A 90-character remedy was repeated on every searcher row, pushing the
part that actually *differs* between them — which exclusions each one has — off the right of
an 80-column terminal. The remedy now prints once beneath the block.

### The remaining four lessons out of that file, each re-verified

The four an earlier pass had wrongly counted as covered. **The miscount is the first finding:**
a loose pattern sweep said 15 of 19 rules were duplicated; opening the hits showed four were
false positives — the "JS-rendered" hit was a passing *example* inside our own text, "hard
links" matched an unrelated `fs.protected_hardlinks` sysctl. **Counting grep hits is not
checking coverage.**

- **`sota/rules/01` §3 — an empty page is a fact about your fetcher, not the source.**
  Reproduced live: a client-rendered page returned **200 with 2 words** of visible text while
  the API behind it returned **1.85 MB / 124,872 words**. Look one level down (`/api/`,
  `__NEXT_DATA__`, a sitemap) before calling a source unreachable.
- **`sota-llm-engineering/rules/01` §8a — a completeness rubric cannot tell "correctly
  declined" from "omitted".** Verified against our own retained artifact: a guided arm scored
  **0.00 on ten items** for asking a clarifying question its guidance prescribes. If the arm
  that should be better scores catastrophically worse, suspect the scoring — and retain the
  artifact, because an eval storing only `artifact_len` cannot diagnose its own anomaly.
- **`sota-shell-scripting/rules/05` §3c — a hard link does not survive an atomic rename.**
  Executed: same inode, then `mktemp`+`mv` leaves the link on **v1** while the file reads
  **v2**, no error, no broken link. Strictly worse than a symlink, whose failure is loud.
- **`sota-devsecops/rules/03` §3.6b — a scanner built against an older toolchain fails as
  noise, not as a finding.** Mechanism verified in a container; the tells are toolchain-owned
  paths and a message naming a version. Record the scan as **not run**, not as clean.

### Two lessons taken out of an operator's global agent file

An audit of the operator's own always-loaded `~/.claude/CLAUDE.md`, prompted by asking what in
it might conflict with this library or cause it to be skipped. **366 of 411 lines (89%)
duplicate library content; 15 of 19 rules tested were already in `skills/`.** Two were not,
and they are taken **before** anything is removed from that file — an idea living only in one
person's config is invisible to everyone else, and deleting it without intake loses it.

- **`sota-devsecops/rules/09` §2b — which binary, and over what.** A third axis of gate reach
  beside §2 (scope drifted sideways) and §2a (reach stops at the artifact). A Homebrew `cargo`
  shadowing a rustup shim made `cargo fmt --check` **exit 0 while ignoring every nightly-only
  key** in `rustfmt.toml`; separately `--manifest-path` narrowed coverage so local passed what
  CI rejected. A check's exit code says it ran, never what it ran *over*.
- **`sota-devsecops/rules/03` §3.6a — a clean run from one scanner is not coverage for
  another's question.** `govulncheck` 1 advisory vs Dependabot 19 alerts on the same tree,
  neither wrong: reachability-of-a-symbol versus version-in-the-graph. The library had the
  triage half and not the inverse.

**One divergence found and deliberately left open:** that file and `sota-shell-scripting`
rules/06 §2 both carry a `grep -r`/`-R` symlink table and they **disagree** — the library's
later refinement distinguishes a symlinked dir *as the argument* from one *met in traversal*.
Flagged rather than silently resolved; one of the two measurements should be re-run.

### Field report II (InterdictOps) — reasoning that survived a passing test

Report I was about **instruments**; this one is about **reasoning that survived contact with a
passing test** — the tool worked, the output was read correctly, and the conclusion was still
wrong. Three proposals adopted, one deliberately left as no-rule. Every falsifiable claim
reproduced first ([docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md)).

- **`sota-code-security/rules/15` §2a — the instrument that speaks only on failure.** A
  verifier, linter, validator, type checker or admission controller reports **one bit**. *"It
  fits"* and *"it fits with four bytes to spare"* are byte-identical, so a green run cannot
  support a claim about headroom or about a change that stayed within a limit.
  **Adopted with a correction that makes it cheaper:** the report said to *induce the
  failure*; reading `kernel/bpf/verifier.c` shows a successful load **does** emit
  `stack depth max D`, gated behind `BPF_LOG_STATS` in the caller's `log_level`. The margin is
  on the happy path — you have to ask for it. Look for the verbose/stats mode first; induce the
  failure only where none exists.
- **`sota-rust/rules/07` §1b — source shape is not a proxy for compiled behaviour.** Measured
  on rustc 1.97.1 with a control: a plain single-call helper is **absent** from the assembly at
  `opt-level=3` (grep 0, versus 2 at `-O0`) while an `#[inline(never)]` neighbour still shows
  three call sites. So "I extracted a helper so the locals would not overlap" is not evidence —
  field-reported, the verifier's numbers were identical before and after such a refactor.
- **`sota-devsecops/rules/03` §3.9 — compare capabilities, not version numbers.**
  *Version ≥ X implies feature X* holds only where the distro tracks upstream and is **false
  for backporting enterprise distributions**, which have the largest install bases — they
  backport *because* of that. Reproduced exactly: AlmaLinux 8's
  `kernel-headers-4.18.0-553.162.1.el8_10` declares `BPF_MAP_TYPE_RINGBUF` (upstream 5.8) and
  `BPF_PROG_TYPE_LSM` (upstream 5.7). Cost in the field: a support matrix shipped with RHEL 8
  wrongly excluded, then retracted.
- **`CONTRIBUTING.md` — when a rule keeps being broken, change the construct, not the
  warning.** The report proposed **no rule** and that was accepted as stated; it is guidance
  about how this library is written, so it is not in a skill. Five data points across two
  parties now, including two from this session's own work.

### `sota-shell-scripting/rules/05` §3b — in-place edit on a symlink

Two idioms treated as interchangeable, differing **exactly on the dangerous axis**. Measured
2026-09-13 on macOS (`/usr/bin/sed`, BSD; perl v5.34.1), editing a symlink:

| implementation | `-i` on a symlink | exit |
|---|---|---|
| **BSD sed** (macOS `/usr/bin/sed`) | refuses — `in-place editing only works for regular files` | **1** |
| **GNU sed 4.9** (Debian) | **silently replaces the link with a regular file** | **0** |
| **BusyBox sed 1.37.0** (Alpine) | **silently replaces the link with a regular file** | **0** |
| **perl -pi** (5.34.1) | **silently replaces the link with a regular file** | **0** |
| GNU sed `-i --follow-symlinks` | edits the **target**, link preserved | 0 |

In every silent case the target is never modified, so the two paths diverge without a word.

**Corrected 2026-09-13, after GNU and BusyBox were measured in containers.** The first
version of this rule had GNU `sed` marked *not verified* and drew the contrast as
*perl converts, sed refuses* — which made `sed -i` look like the safe idiom. It is not.
**`sed -i` is safe only on BSD**, and the split runs the wrong way: a macOS developer sees
the refusal, concludes the idiom is safe, and ships a script that destroys symlinks silently
in CI. The rule now says never to rely on the refusal, and to enumerate regular files
(`git ls-files -s | awk '$1=="100644"'`) instead. `--follow-symlinks` is GNU-only.

It earns a rule because the idiom that does this is the one reached for to edit many files at
once, and a tracked symlink is just another path in that list. Field-reported the same day:
`git ls-files '*.md' | xargs perl -pi -e …`, run to hand-test a probe, converted this
repository's own `CLAUDE.md` and `GEMINI.md` into regular files, and `git add -A` staged the
type change before it was noticed. **`git status` reports this as `T`, not `M`.**

Worth recording alongside it: **invariant 24b, which exists to catch exactly that symlink
breakage, read the index (`git cat-file -p :CLAUDE.md`) while the damage sat in the
worktree** — so it reported ok on a correct copy. A control that reads a different copy than
the one you changed cannot see the change.

**What the gate cannot see, written down rather than discovered later:** the scope is
positional, so prose between the list and the next heading that contains the pattern counts as
an item. Not hypothetical — it happened while landing this check, in a sentence *describing*
the marker, where writing the literal separator added a phantom entry to the list the sentence
was about.

## [1.41.2] - 2026-09-13

**Front door checked:** EOL date · denominator · selector · constrained · sells the remedy

### Field report III (InterdictOps, 2026-09-13) — six proposals adopted, one reported as evidence

An intake pass over a field report from a session that **used** the library. Its value is in
the framing: for four of its eight failures the relevant rule was already in context and was
broken anyway, so those four are evidence about *rule shape* rather than coverage. Every
falsifiable external claim was reproduced against a primary source before anything was
adopted — see [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md) for the full verdicts and the
placement reasoning.

- **`sota/SKILL.md` principle 1 + `sota-devsecops/rules/03` §3.9 — record the EOL date beside
  any third-party version.** The mechanism, not another instruction to be careful: a version
  number can be recalled with no felt uncertainty, so rules that trigger on doubt cannot fire;
  an EOL date cannot be recalled, so requiring the column forces the lookup. A row past its
  EOL is **removed, not corrected** — an unsupported branch can answer the opposite of the
  current one. Reproduced: 7 of 7 rows in the report's matrix, 5 stale, via `endoflife.date`.
- **`sota-rust/rules/07` §1a — on a constrained target, a style lint's premise may be false.**
  A real gap; the skill had nothing on eBPF, `no_std`, embedded or WASM. Worked case: a
  warn-by-default clippy lint suggesting an owned argument spent 52 bytes of a **512-byte**
  BPF stack (`MAX_BPF_STACK`, verified in `include/linux/filter.h`) and the program stopped
  loading. Carries the linguistic tell — *"mechanical", "trivial", "style only"* license
  skipping the analysis that would justify them.
- **`sota-devsecops/rules/09` §2a — a gate that stops at the artifact cannot see a defect that
  starts at load.** §2 covered the lateral blind spot; this is **depth**. Four gates green on
  an object the kernel verifier refused. Name each gate's terminal artifact and ask what runs
  after it.
- **`sota-shell-scripting/rules/06` §2 — print a denominator where a positive control is
  unavailable.** Bytes, members, total files, in the same invocation. Closes the case a
  positive control cannot reach: an extraction or fetch into a blob you have never opened.
- **`sota-shell-scripting/rules/06` §5a — the selector picked a different member than the
  question named.** Sibling to §5: that one returns *less of the right population*, this one
  returns *all of a neighbouring one* — nothing truncated, exit 0, no rule broken.
- **`sota-code-security/rules/15` §2.1 — a suspiciously clean result from a fresh instrument.**
  The inverse of the existing tell: the file trained the reader on *red* and *implausible*
  results, and a perfect correlation reads as strong evidence instead of as a warning.
- **`sota/SKILL.md` principle 3 + `sota/rules/03` §2 — weigh a source that sells the remedy.**
  No coverage previously. Sources converging on the conclusion that sells their own product
  are one hypothesis held by several interested parties, not corroboration.

### The stale-claim sweep the cut is for — four counts, none of them gated

Every number below was **correct when written** and went stale silently. None is reachable
by an invariant: invariant 6 counts the `skills/` tree, invariant 17 counts claims about the
*scripts*, and a count whose denominator is a **list in the same document** has no gate.

- **`README.md` said "Eleven classes of defect"** above a list of **26** — correct on
  2026-08-27 (verified by counting the list at that commit), fifteen behind seventeen days
  later. Now **twenty-nine**, after this release adds three. The first correction written was
  itself stale within the hour, which is recorded in the line: recount, *then* restate.
- **`AGENTS.md` said the router was 420/500**; it was **432**. The same sentence also
  contradicted itself — "wrong a SEVENTH time" beside "Wrong **six** times".
- **The router's context budget said rules files run 77–497 over 270**; **271** files, max
  **500**. True on 2026-09-11, false on 2026-09-12 when `rules/16` landed.
- **`docs/ROADMAP.md` said "All 55 items"** the moment a 56th was added.

**ROADMAP item 56 opened:** gate a spelled-out count against the list it counts. It passes
this repo's three filters (has it failed · silently · mechanically checkable) and is a row
rather than a commit because invariant 19 demands a known-bad probe and `AGENTS.md` sits at
**199/200** with no room for a 30th invariant's table row.

Also: README hero line count 68k → 69k (invariant 6).

## [1.41.1] - 2026-09-13

**Front door checked:** saturated measure · AACR-Bench · near chance

**We were wrong in our own documentation for four months, and this release says so.** A
patch: one new rule section inside an existing file, plus corrections to published claims.

### `sota-llm-engineering/rules/01` §8a — a saturated measure is a fact about the instrument

New rule, and it is this repository's own mistake generalised. **When both arms score at the
ceiling you have learned nothing about the treatment** — 1.00 with and 1.00 without means
*this instrument cannot tell these conditions apart*, which is a claim about your eval, not
about your system.

The failure is expensive because it **closes the question**: read 1.00/1.00 as *solved*, stop
measuring, publish it, and write down an instruction not to build another instrument — and
the belief is now self-sealing, because the only thing that could overturn it is forbidden.

What the rule asks for: report the **absolute score before the delta**; register a control
arm at **≥0.95 as a void condition**, not a null; make **chance a known constant** by
balancing classes rather than inheriting a base rate; and **prefer an instrument you did not
build** once yours stop discriminating, because you authored the fixture, the rubric and the
difficulty. The tell to watch for in your own writing is the phrase *"both arms scored
perfectly, so…"* — whatever follows that comma is usually a claim the data cannot carry.

Confirmed absent before it was written: `saturat*` appeared **nowhere** in the skill that
owns eval design, across two vocabulary sweeps with a positive control.


### A correction to our own published position: "do not build a tenth instrument" was wrong

We had written, in three places, that audit recall and precision were **exhausted at nine
instruments** and that a tenth should not be built. A tenth was built this session
([COMMENT-TRIAGE](evals/results/2026-09-12/COMMENT-TRIAGE.md), on the external Apache-2.0
AACR-Bench), and building it was right.

**The lift conclusion survives** — it read a registered null too, so ten instruments now
agree on +0.00. **The word "exhausted" does not.** It rested on precision reading **1.00 in
both arms**, taken to mean "perfect, no headroom". On an instrument that discriminates, both
arms sit **near chance** (0.517 / 0.542 against a constructed 0.500). **1.00/1.00 never meant
perfect — it meant the instrument could not tell.**

Superseded rather than edited away, per the rule for dated prose:
`evals/results/RESULTS.md`, `docs/WHY-IT-WORKS.md` (whose "accuracy, on every instrument
built so far, is saturated in both arms" is now false), and
`evals/DESIGN-real-repo-audit.md`. The README's front-door claim that a frontier model
"recognises these classes unaided" is **qualified against ourselves**: still +0.00 on lift,
but the stronger reading — that finding these things is easy — is not supported by a measure
that can actually discriminate.

**The standing instruction is now the opposite of the struck sentence: never close an axis
on a saturating measure.** Both arms scoring perfectly is a fact about the instrument.

### Open threads closed by operator decision — the actionable set is empty

- **`rules/03` §4's *"default to REFUTED when ambiguous"*** — the measured price is recorded
  as a known property; the **rule stands unchanged**. One model, one day, 40 of 2,145
  records, on a *different task* from the one §4 governs, is not grounds to re-tune it.
- **Invariant 11's substring escape hatch** — accepted as a known limitation. The
  negative-control harness detects it immediately, which is how it was found.
- Together with the roadmap (54 of 55 closed, item 5 dormant behind a cron until 2027),
  **nothing in this repository is waiting on a decision.**

## [1.41.0] - 2026-09-12

**Front door checked:** AACR-Bench · position drift · partition

**An external intake, and the first non-saturating look at a claim we had closed.** Three
ideas adopted from [alibaba/open-code-review](https://github.com/alibaba/open-code-review)
(Apache-2.0, licence checked before planning). Minor: `run-comment-triage.py` is a new
runnable surface.

### Two rules — `sota/rules/01` §4b and §1a

**§4b — position drift.** A finding that is right about the defect and wrong about where it
is. `rules/03` §2 already *required* the location be "exact, clickable, reproducible" and
nothing *checked* it — this library's most common gap shape, a stated rule with no probe.
Absence confirmed with two independent vocabulary sweeps and a positive control, not one
grep. Placed **before** the adversarial pass on a cost argument: the check takes seconds,
refutation is expensive, and a finding that cannot be located does not deserve a refuter.
Corroborated from our own history — **invariant 18** exists because ~1,300 prose `§`
references drifted silently here, with 20 more caught during a single rules-file split.

**§1a — partition an oversized changeset, don't skim it.** We covered only the authoring
half (keep PRs small); the reviewer's half was missing. Enumerate units mechanically,
bundle files that must be judged together, give each bundle fresh context, and **report the
denominator** — a findings list with no coverage statement is indistinguishable from a
partial one. The sharp edge is ours, not theirs: **partition is not sampling**, because
"is this change safe to merge" has no defensible sample.

### A new instrument, because ours saturate — and a registered null

`evals/run-comment-triage.py` + `evals/cases/comment-triage.jsonl`, built on **AACR-Bench**
(Alibaba Aone, Apache-2.0): 2,145 expert-labelled review comments over 200 PRs, 50
repositories, 10 languages.

**Why.** Our audit-precision measure was 30 claims scoring **1.00 in both arms**, and the
audit axis was closed at +0.00 across nine instruments. A measure that saturates has not
shown the treatment does nothing — it has shown it cannot tell.

**Result, pre-registered and committed before the run existed:**

| arm | accuracy | recall REAL | recall NOT_REAL |
|---|---|---|---|
| bare | 0.517 | 0.500 | 0.533 |
| with `rules/03` §2+§4 | 0.542 | 0.317 | 0.767 |

**+0.025 is a registered NULL**, and the registered trap fired underneath it: the
pre-registration forbade claiming a lift if label-1 recall fell more than 0.05, and it fell
**0.183**. The guidance produces a **threshold shift** — +0.234 on rejecting wrong comments,
−0.183 on accepting right ones — which is a more skeptical reviewer, not a better one.

**Writing that trap down in advance is the whole point.** Accuracy alone read "+0.025, a
small positive"; on the source set's real 70/30 mix the same behaviour would have printed as
a loss. Three headline numbers from one run, decided by choices made before it.

**The instrument did its job:** neither arm saturated — both are **near chance** on a set
where chance is exactly 0.500 by construction. Set against the 1.00/1.00 it replaces, the
honest restatement is that we never had evidence of audit precision, only a measure too easy
to discriminate. Zero parse failures in 240 calls.

Also recorded: their **deterministic path-scoped rule matching** is adopted *in principle,
not in mechanism* — Claude Code owns skill activation, so we cannot bind rules to paths, but
their critique of language-driven selection is independently confirmed by our own
measurement the same day, where a single token moved an unrelated case 3/3. Their
"reflection module" is **rejected: already covered** by `rules/03` §4.

Validating the source corrected it: the repo README presents AACR-Bench as "1,505 annotated
ground-truth issues", implying defect detection; the dataset's own card says it is a
comment-*triage* set. Their benchmark figures are vendor self-reported and not reproduced
here.

## [1.40.7] - 2026-09-12

**Front door checked:** ROUTING-SHIFT · ROUTING-FIX-DEVSECOPS · re-route

**Routing checked:** evals/results/2026-09-12/ROUTING-FIX-DEVSECOPS.md

**The roadmap is worked out.** One routing defect fixed and measured, the backlog closed to
an empty actionable set, and a documentation sweep that retired a claim this library was
making about itself. No new skill, script, command or hook — a patch.

### Documentation sweep — one claim retired, one count wrong a seventh time

**`docs/CONTEXT-MANAGEMENT.md` said activation was the least measurable thing in the
document, and that is no longer true.** It claimed the `desc-routing` eval reads +0.00
(saturated) and cannot distinguish two descriptions, so activation changes are "reasoned,
not measured". The first half still holds for that 10-case set; the conclusion does not.
The regression set moved **0.667 → 1.000** on this release's description edit and the
ROUTING-SHIFT fresh arm moved **0.750 → 1.000**. Superseded in place rather than edited
away, per the repo's rule for dated prose.

**`AGENTS.md` said the router was at 410/500 lines; it is at 420** — wrong a **seventh**
time, in the very file that warns it has been wrong six times and says to re-count with
`grep -c ''`. The lesson is holding up badly: a number that must be re-measured by hand
after every edit is not a convention, it is a pending defect.

Also indexed: **ROUTING-SHIFT** and **ROUTING-FIX-DEVSECOPS** now reach `docs/INDEX.md`
and the `evals/results/RESULTS.md` scoreboard, where previously they existed only as a
roadmap row — the same "measured but unreachable" shape the index exists to prevent. The
INDEX row for the **re-route** hook clause now carries the measured number instead of only
describing the mechanism.

**A gate hole found by the harness, recorded not fixed.** Invariant 11's escape hatch is a
bare substring match over added CHANGELOG lines, so prose that merely *mentions* the
verification stamp excuses a stamp move for the whole diff — which this release's own
changelog did, and `check-negative-controls.sh` caught within a minute by reporting probe 11
**INERT**. The looseness and the argument against each available fix are written up in
[docs/CONVENTIONS-LEDGER.md](docs/CONVENTIONS-LEDGER.md).

### Roadmap: item 1 closed permanently, item 5 made dormant — the actionable set is empty

**Item 1 (distribution) is closed by operator decision, not by completion.** The work it
tracked is real and partly done — the awesome-ai-plugins listing merged 2026-08-26, the
salience write-up shipped 2026-09-01 — but what remained is a person's hours and nothing an
agent can move. It sat at or near the top of the priorities table for seven weeks without
once being actionable. A row no session can act on is a recurring reminder, not a backlog
item. Closed as **won't track**; it must not be reopened or replaced.

**Item 5 (the 6-month accuracy sweep) stays open but is dormant until 2027-01-08** and is not
to be surfaced before then. Nothing needs to track it: `.github/workflows/freshness.yml` runs
`check-freshness.sh` at 06:00 UTC on the 1st monthly, and that script exits 1 once
the root verification stamp (2026-07-08) passes its six-month window — so the first red run is
**2027-02-01**, unprompted. Verified by reading both files, not assumed.

Of 55 items, 54 are closed and the 55th is asleep behind a cron.

### Invariant 26 accepts a singular open count

The open count reached **1** and the header pattern matched only `**Only N are open**`, so a
correct document failed as *"no header found"* — a misleading diagnostic for a grammar
mismatch. The pattern now accepts `is` as well. **Widened, not loosened**: the count and the
list are both still required, and all three failure arms were watched to fail before the
change shipped — a header count disagreeing with its list, a header naming an item no row
marks open, and a ledger row marked open that the header omits.

One of those checks initially *passed*, which was **the probe's fault, not the gate's**: the
mutation targeted `| 2 | **CLOSED` while the row actually reads `| 2 | **Real-repo audit eval
— CLOSED`, so nothing was mutated and an inert probe reported a healthy gate as silent. Re-run
with the mutation asserted, it failed correctly. The repo's own rule — a probe asserts its own
mutation landed — earned itself again.

### `sota-devsecops` description — the trigger defect item 48 found, fixed

Item 48's measurement found that *"the pre-commit hook passes locally but the same check fails
in CI"* routed to `sota-shell-scripting` **3/3 from a cold start** and never reached
`sota-devsecops`, whose `rules/09` §5 owns exactly that topic. The description now names the
case (*"and a pre-commit hook that passes locally but fails in CI"*) and carries the keywords
*pre-commit, local vs CI* — 915 → 995 of 1024 characters.

Measured on three instruments: the regression set **0.667 → 1.000**, the 10-case set
**0.900 → 0.900** with `q8_bash_review` still `sota-shell-scripting` 3/3, and
`run-routing-shift.py`'s fresh arm **0.750 → 1.000**.

**The routing check caught a regression on the way.** The first phrasing read *"a pre-commit
hook **or gate**"*, which fixed the target case and **broke** a `sota-code-security` case whose
prompt contains *"after every gate run"* — it moved to `sota-devsecops` 3/3 in **both** arms.
Deleting two words restored it. **One token moved a case 3/3**, and **neither `desc-routing`
set saw it**: that case lives only in `routing-shift.jsonl`, so a check limited to the set
invariant 29 names would have shipped it — the v1.35.0 pattern precisely. Run every routing
instrument you have, not only the declared one.

## [1.40.6] - 2026-09-12

**Front door checked:** sixteen shapes · no build at all · rules/16


**Three open items worked to the end of what they could honestly reach.** A rules file split,
a measurement that found something nobody registered, and a design that corrected a false
claim in its own roadmap row. No new skill, script, command or hook — a patch.

### `sota-code-security/rules/16` — the catalogue, split out of `rules/10`

`rules/10` was at 484 of 500 lines with two classes queued behind it. §2 — the catalogue of
**sixteen shapes** a control takes when it is present, looks enabled and enforces nothing —
now lives in **`rules/16-where-no-ops-hide.md`**. `rules/10` keeps the *method* at 230 lines.

The seam was chosen by **inbound citations**, not by line count: §2 was 54% of the file and
~70% of its references. The more expensive seam was taken deliberately (~44 rewrites against
~18) because catalogues are what grow and both queued classes are §2-shaped. **Section
numbers are unchanged across the move**, so every citation became a pure path substitution —
`rules/10 §2.7` is `rules/16 §2.7`.

Invariant 18 fired three times during the split and none of it was reachable by the regex:
it crashed on the new file until `git add`, then caught **20 bare `§2.x` pointers** in `.py`,
`.sh` and `SKILL.md` that resolved only because they sat *inside* the file being split, then
a same-file reference whose heading is a range.

### ROADMAP 49 — decay measured, and an anomaly reproduced

The 2026-07-14 run could not have detected decay at any depth: the anchor was 83,958
characters against 12,997 of filler, **0.15:1**. Its recorded fix — author more filler —
prices at ~580 additional pairs. Anchoring on principle 5 alone flips that to **4.12:1** for
the cost of one flag.

Result: **no decay** between K=12 and K=30 (0.80 at both), with the lean anchor holding a
+0.40 gap over control, so the registered floor-effect void condition did not trigger.

And the finding nobody registered, reproduced across two independent runs: at **K=0** the
anchor arm returns ~1.2k characters and scores **0.00** — **no build at all** — where its
own K=12/K=30 builds run 17–23k, and the same anchor plus *one reminder line* on the task
turn returns ~25k and scores 0.80–1.00. Depth *helped*. **The mechanism is not claimed**:
the runner stores only response lengths, so the 1.2k reply cannot be read, and that gap is
recorded as the blocker rather than papered over.

### ROADMAP 48 — designed, and a claim in its own row corrected

The row asserted that the harness for the measurement already existed. It does not —
`run-desc-routing.py` is single-turn and `run-decay.py` scores a build, not a routing choice.
The full design is recorded with two risks registered first: a narrow detectable range above
an already-0.90 fresh arm, and the fact that an eval has no Skill tool, so it measures what
the model *says* applies.

### Changed

`AGENTS.md`'s denominator example embedded a live count and had gone stale four times
(261 → 262 → 270 → 271). It is now `ok (N rules files)` — the number carried no meaning in an
illustration of an output format.

Open set **4** — 1, 5, 48, 49.

## [1.40.5] - 2026-09-12

**Front door checked:** lean loading · conflict rate · re-route


**Three open roadmap items moved, two closed, and one correction to a cause this project
had already warned itself about.** All inside existing surfaces — a patch.

### ROADMAP 47 — closed. The conflict rate at **lean loading** is 0.000 verified

ROADMAP 39 measured a ceiling by giving the judge every `rules/*.md` of both skills. This
measures the floor — `SKILL.md` only, what BUILD step 2 opens before any rules file — with
**both arms on the same tree on the same day**, which is the design's whole point.

| arm | corpus | judge-reported | hand-verified |
|---|---|---|---|
| full | 1,546,535 chars | 0.471 | not computed |
| **lean** | **147,116 (9.5%)** | **0.176** | **0.000** |

**Loading lean cuts the judge-reported conflict rate 63%**, and all six lean-reported
conflicts refute on reading the quotes against the files — five of them in the two classes
the judge cannot resolve because it is blind to the router by design.

Both decisions the item was parked on were settled with reasons rather than deferred again:
lean means `SKILL.md` only, because choosing index-matched rules files is the *measurer's*
judgement and the measurer holds the hypothesis; and the judge stays blind to the router,
because "does the resolution work?" is a different question.

*Not established, and said so:* the lived rate (it sits between the arms), and the full
arm's verified rate, which needs eight pairs hand-read and is left blank rather than
estimated. The full arm is also **not** a before/after against 0.353 — the corpus grew 50k
characters in between, partly from rules added the same day.

### ROADMAP 48 — the re-route clause shipped

Its trigger fired: a third and fourth observation, both in one pair of field reports. The
fix went into the **re-injection hook**, the only surface that fires *after* a session has
changed shape — *"Routing is per task SHAPE, not per session"*. Verified against a live
install that an existing hook is detected stale by exact text, so `update.sh` offers the new
wording. The item stays open for its measurement half.

### ROADMAP 49 — the blocker was the wrong one

Measured: anchor 83,958 chars against 12,997 of filler, 0.15:1. Diluting by authoring needs
~580 filler pairs — a dead end, and why the item sat since July. The item's own alternative,
a deliberately smaller anchor, was never priced: a lean anchor flips the ratio to ~3:1 using
existing filler, for one flag, and measures the more honest question. First move revised.

### ROADMAP 53 — closed: keep the trigger-keyword tails

The measured null is deliberately not the reason. Cutting doesn't fix what it was proposed
to fix (8 of 42 descriptions kept at the default, 12 without, 42 with the setting); the null
is loose (~0.26 per-case bound) against a change to all 40 descriptions; and 59% of the
tails' terms appear nowhere else.

### Fixed

- **A cause corrected.** The `HTTP 402` that stopped a run was written up as exhausted
  credit; the balance was fine and it was a provider fault (`/api/v1/key` → 200, `limit:
  null`). `evals/DESIGN-real-repo-audit.md` already carried the warning — *"a reader would
  have concluded 'out of credit' and topped up an account that was never the problem"* — and
  the write-up did exactly that. The separate 2026-09-09 incident is flagged as **not**
  re-verified rather than silently amended.

### Added

`--lean` on `run-conflict-rate.py` (the v3 its own docstring promised), documented in
`evals/README.md` after invariant 25 rejected the first commit for leaving it undocumented.

Open set **5** — 1, 5, 48, 49, 55.

## [1.40.4] - 2026-09-12

**Front door checked:** implausible · BASH_SOURCE · correctly refuses · passing hook


**Two field reports from one session, the second retracting part of the first — which
arrived while the first was being implemented, and landed in time.** Plus the answer to
ROADMAP 53 and the plugin listing-budget work. All of it lives inside existing surfaces, so
this is a patch.

### The headline: `sota-code-security` rules/15 §2.1 gains a sixth failure mode

The five there describe instruments that are *durably* wrong. None described the **temporal
asymmetry**: during verification the harness is almost always **newer** than the thing it
tests, so the prior belongs on it — and rarely lands there, because a harness fault and a
real finding arrive through the same channel, a red result. Field-measured over one session:
**seven harness errors, seven outputs that read as findings about the subject, four acted on**
before being caught.

The load-bearing half is the tell: **not that the result is red, but that it is
implausible.** Red is expected during verification; *"that cannot be true"* is the signal —
a scan reporting zero entries in a tree you just listed, a formatter objecting to indentation
that matches every other file, a process query returning the whole machine.

### Added

- **`sota-shell-scripting` rules/06 §2a — `rg -r` is `--replace`, not recursive.** The
  `grep -r` symlink trap inverted: that one fabricates a false *absence*, this one fabricates
  false **content** — every match rewritten to the next argument, exit 0. The reporter hit it
  twice in one session *after* writing it into their own notes.
- **`rules/06` §2b — an empty command substitution removes the filter.** `ps -p "$(pgrep …)"`
  with no match becomes `ps -p ""`, which lists **every process**, exit 0. Quoted correctly,
  so no linter flags it. An implausibly *large* result is the same tell as a suspiciously
  clean zero.
- **`rules/05` §3a — sourcing a script to test one function relocates it.** `BASH_SOURCE`
  appeared **zero** times across all 41 skills. The silent variant is the dangerous one: the
  script `cd`s itself out of the repo and every `git` call fails while emitting a correct
  diagnostic about healthy code.
- **`rules/04` — killing a backgrounded build orphans the compiler**, and the next run's
  contention over `target/` then reads as a defect in the change under test.
- **`sota-code-security` rules/15 §3a — the guard that correctly refuses and says nothing.**
  A stray `.swp` file falsified one conjunct of a three-clause guard, so a clean 23-of-23
  gate run wrote no evidence record **and printed nothing**. Not an inert control and not a
  dead path: the branch is reached and mute, and the fixes are opposites — an inert control
  must start enforcing, this one must keep refusing and start explaining.
- **`sota-devsecops` rules/09 §4 — a warning on a *passing* run needs its transport
  verified.** Every wrapper that suppresses output suppresses it on success. Verified against
  the installed pre-commit **4.6.0**: `run.py:217` emits only
  `if verbose or hook.verbose or retcode or files_modified`. It discards a
  passing hook's output entirely, so a seventeen-minute twenty-three-gate run
  arrives as the single word `Passed`.
- **`rules/12` §1** — the commonest cause of "the mutation did not take" (a substitution that
  matched nothing) now leads the list, with the stronger fix: assert the pattern is present
  *before* writing, which fails at mutation time.
- **Router principle 7** — a verbatim file copy injected into context earlier in the session
  is not a primary source either.

### Fixed

- **A rule adopted from report I was retracted the same day, by its own author.**
  `sota-devsecops` rules/09 §5 already owned "reproduce the gate's exact invocation". The
  duplicate clause was removed from `sota-shell-scripting` rules/03 §7 and replaced with a
  cross-reference. Recorded with the reviewer's share: the gap was verified *inside the file
  the report named*, and nobody asked which skill **owns** the topic — a negative claim about
  the library needs the same positive control as one about a codebase.

### Also

ROADMAP **53 answered** (the `Trigger keywords:` tails buy no measurable matching value:
Δ +0.000, 0 of 10 cases moved — recommendation is still to keep them, because cutting them
does not fix the budget and the setting does), **54 closed** (the plugin now reports the
listing budget it cannot set), **55 opened** (`rules/10` is at 484/500 with two classes
queued behind a split). Open set **7** — 1, 5, 47, 48, 49, 53, 55.

## [1.40.3] - 2026-09-11

**Front door checked:** skillListingBudgetFraction · listing budget · name-only · discovery ratchet


**Most of this library's descriptions were never reaching the model, and now the installer
fixes it.** Everything here lives inside surfaces that already existed — a step inside
`install.sh`, a check inside `verify-setup.sh`, a corrected rule — so this is a patch.

### The finding (ROADMAP 52)

Settled by reading the shipped `claude` binary (2.1.268), not by inference. Claude Code
reserves a per-turn **listing budget** of
`Math.max(1, Math.floor((contextTokens ?? 200000) * 4 * skillListingBudgetFraction))`, the
fraction defaulting to **0.01** — 8,000 characters at a 200k context, shared across every
installed skill. This library's 42 descriptions need **38,240**.

Over budget it does **not** shorten descriptions. Entries are **ranked** and the ones that
do not fit render as a bare `- name` with no description at all — all-or-nothing per skill.
The ranking is `usageCount * max(0.5 ** (daysSinceLastUse / 7), 0.1)`, so a never-used skill
scores **0 and is dropped first**: a **discovery ratchet**, invisible because unused and
unused because invisible. Confirmed live — roughly 20 of 42 skills were listed **name-only**
in the session that found it.

A separate per-skill cap (`skillListingMaxDescChars`, default 1536) *does* tail-slice, but
no description here exceeds it. The tool's own warning text calls both "truncation", which
is how the two get conflated.

**Why the library still worked:** the router is used every session so it ranks top and keeps
its description, and a name-only skill stays invocable **by name** — which is exactly what
the router's routing table does. Always-on routing is the mitigation, not a nicety. What was
lost is *direct* auto-selection when the router has not fired.

### Added

- **`scripts/install.sh` offers to set the fraction**, on install and on `--update`. It
  measures the descriptions actually linked rather than assuming a number, sizes against a
  200k context with headroom, asks first, backs up, and writes *through* a symlink. It never
  lowers a value you already set. Works out to ~0.07 here.
- **`scripts/verify-setup.sh` check 1b** reports the arithmetic, INFO-only — check 1 answers
  *is it installed*, 1b answers whether the description reaches the classifier.
- **`docs/VERIFY-SETUP.md`** gains the prompt step a script cannot do: count the entries in
  *your own* listing that have no description. The script sees the corpus on disk; only the
  agent sees what arrived.

### Fixed

- **`sota-skill-security` rules/03 §1 corrected.** It shipped in v1.40.2 saying a cap is
  enforced by *skip or shorten*; the third shape — drop the description, keep the name — is
  the one that matters, because it is invisible from every direction the other two are found
  from. Added: where a ranking decides who keeps a description, the ranking is the real
  classifier.
- **The router's context-budget guidance was wrong.** It said "each rules file is 200–310
  lines"; re-measured over all 270, the real spread is **77–497, median 237**, and half the
  files fall outside the stated range. Sizing 2–5 files by that range could be off by 5x.

Roadmap: **52 closed**, **53 opened** (should the corpus be smaller — the keyword tails are
~13k of 38,240 chars, and size now decides how many entries keep a description at all). Open
set **6** — 1, 5, 47, 48, 49, 53.

## [1.40.2] - 2026-09-11

**Front door checked:** vulnerability report · listing budget · no-skill · severity rubric · ipBlock


**A backlog session: three measured conflicts repaired, a dead instrument found, and one
external intake.** No new skill, no new script, nothing new to run — every change lives
inside a surface that already existed, so by the measured rule in
[RELEASING.md](RELEASING.md) this is a patch.

### Fixed — the instrument behind the +0.509 headline could not start

`evals/run-prompt-independence.py` crashed loading its own case file. Its `load_cases`
skipped blank lines and `_comment` objects but not `#` lines, and it was the only loader in
`evals/` that did not — while all 23 case files open with a `#` banner. Invariant 28
(2026-09-09) then required every case set to declare a `SELECTION RULE`, the header was
added as `#` comments, and `json.loads()` raised on line 1 from that commit onward. **A gate
added for one purpose broke an instrument.**

CI never saw it: `main()` calls `key()` before `load_cases()`, so with no
`OPENROUTER_API_KEY` the runner exits at the credential check, and `smoke-runners.py` scores
a `SystemExit` as *alive* — correctly, since a usage exit is legitimate. The published
**+0.509** is unaffected (that run was 2026-08-31, nine days before the break); what was
lost was the ability to re-run it. Fixed and asserted to load exactly the 6 cases the
headline is stated over, with the empty-set guard re-checked so the repair did not loosen
an assertion.

`smoke-runners.py` now injects a **dummy** credential so the gate reaches the same depth on
CI as on a maintainer's machine — safer than a real key, since `urlopen` is stubbed, no
runner uses `requests`/`httpx`/`http.client`, and a fake spends nothing. Watched to fail
under CI conditions before being trusted.

### Fixed — the three cross-skill conflicts the 2026-09-09 measurement confirmed

- **NetworkPolicy egress, repaired on both sides.** `sota-sandboxing` rules/03 R3.4 selected
  an in-cluster backend with `ipBlock`; pod IPs are recycled, so a CIDR grants whatever
  lands in the range next. It now selects by identity (validated as parsing to a single
  AND-ed peer). `sota-network-security`'s *"never a bare CIDR"* said nothing about scope and
  is unsatisfiable for destinations **outside** a cluster, where vanilla NetworkPolicy has
  no identity selector; rules/03 §3 R3a now scopes it — identity in-cluster with no
  exception, `ipBlock` outside as a documented exception carrying its reason.
- **Severity precedence.** The router resolved the finding *format* against per-skill
  variants and said nothing about severity, while four skills ship their own rubric. The
  cross-domain model is now the floor; a per-skill **severity rubric** may refine it inside
  that skill's domain and must say so. Cheaper than the roadmap predicted — the natural home
  is the router header, outside both eval pins, verified by running all three guards.
- **Prop spreading.** `sota-frontend-design`'s unconditional *"spread the rest"* now states
  the exception, with its audit half aimed at the call sites where the injecting spread is
  actually written.

### Added — rules inside existing skills

- **`sota-security-compliance` rules/04 §3a — triaging a vulnerability report someone else
  sent you.** The skill had the CVD intake obligation and the outbound Article 14 clocks and
  nothing for the decision between them, which is on the critical path because the clock
  runs from *awareness*. Anchored on ISO/IEC 30111:2019 and 29147:2018, both read at source.
  Includes the 2026-specific step — confirm the code a report cites actually exists.
- **`sota-skill-security` rules/03 §1 and §1a.** A description length cap is enforced either
  by skipping the skill or by silently truncating it, and they need different checks; where
  the **listing budget** is shared across everything installed, a neighbour's bloat eats
  trigger words you wrote correctly. §1a separates a description defect from a body defect
  (run it model-routed and by name), keeps a **no-skill** arm, and says to delete guidance
  that no longer beats it.

### Changed — documentation corrected against the tree

Four trailing records that outlived their work: the roadmap's own *"what is open?"* command
returned **0** against a real 2 after the marker convention changed under it; a rejected
competitor comparison sat under a heading saying *open*; a pre-registration read *"not yet
run"* beside its own results; and a blocked-runs note still said two items stayed open.
`AGENTS.md`'s probe count (43 → **44**) and denominator example (262 → **270** rules files)
re-measured. The conventions ledger's *"20 enforced"* row is now dated and marked a floor,
since invariants 21–29 landed after it and it has not been recomposed.

### Intake

**MadAppGang/magus** (MIT, checked from the API first): two adopted into
`sota-skill-security`, one deferred with a trigger, and **ROADMAP 52** opened — our 42
descriptions total 37,330 characters, and whether that reaches the model intact depends on a
budget formula we could not verify on the version we run. Rejected its 250-character ceiling
with reasons, and recorded that its own cited evidence is not published.

Roadmap: **46, 50 and 51 closed**; **49, 50, 51 and 52 opened**; open set **6** — 1, 5, 47,
48, 49, 52.

## [1.40.1] - 2026-09-10

**Front door checked:** process table · asserted over a pool · the revert · parentage


**Three field briefs and a session self-intake.** Everything here is a rules addition or a
correction inside an existing surface — no new skill, no new invariant — so by the measured
minor-vs-patch rule this is **patch** material.

### Added

- **`sota-shell-scripting/rules/06` §4 — a backgrounded wait loop exhausts the process
  table** (#342). Blast radius as the library stated it was **entirely disk**; this is the
  resource whose exhaustion disables the tools you would use to recover, including `ps`,
  `killall` and `echo` in a fresh shell. Two of our own rules came one predicate short: §1
  had the `pgrep -f` self-match but framed the cost as a *burned timeout*, not unbounded
  spawning.
- **`sota-shell-scripting/rules/06` §5 — a listing tool's page is not a population** (#343).
  Measured on a repo with 330 merged PRs: `gh pr list` with **no flag** returns **30**, a
  *default* cap, exiting 0 with empty stderr. The two ways to get it wrong are the cap you
  never set and the cap you set for a different question. Includes the cap-equality control
  (a result whose size equals the limit is a page) and the reconciliation rule — the
  server-side count read 330 and a `--paginate` read 339, because the corrected command had
  silently changed **predicate** (`state=closed` includes closed-unmerged).
- **`sota-shell-scripting/rules/03` §3a — the wrapper that shadows what it calls** (#344).
  §3 was written entirely from the attacker's side; the mirror is a directory *you* control
  holding a file *you* wrote that shadows a command *your own file* calls. Three namespaces,
  **two failure modes**: a `PATH` shim has no bound at all and fills the process table,
  while a shell-function override is one process that bash lets **segfault** (`FUNCNEST`
  unset by default) and zsh stops cleanly at 700. The bounded form is the one you try first,
  which is why it misleads.
- **`sota-testing/rules/06` §6.3 — the revert is part of the mutation probe** (#345). An
  `inject && run && revert` chain strands a permissive no-op in a security control if the
  shell dies between the second and third step, and the wrapper reports it as a clean pass.
  Verify the revert against the source of truth, never the exit status.
- **`sota-testing/rules/07` §7.9 — a threshold measured on one population and then
  asserted over a pool** (#345). A floor fires with **no code change** when the denominator gains a
  new corpus, language or tenant. Dilution is the one cause a pooled metric cannot
  distinguish from the cause its author imagined.
- **`sota-testing/rules/04` §4.8 — the green run that quietly ran fewer tests** (#345). A
  stopped container runtime turns tests into **skips**, not failures: 30 tests vanished at
  **0 failed**, and the only moving number was a count.

### Changed

- **`sota-testing/rules/07` §7.4 now states its scope** (#345). *"Failures unique to parallel
  runs are isolation bugs, never just rerun"* is right for workers inside one invocation and
  the **opposite** of right for two independent suites sharing one database — where
  re-running the failing subset in isolation is the correct diagnosis. The rule was pointing
  the wrong way for the adjacent case.
- **Benchmark chart reworked** (#340) — one banded `unguided model` baseline row instead of
  two rows with different numbers, plus GitHub star counts for each compared library.
- **`docs/ADOPTION-LOG.md`** gains four rows; **all four** are marked `· unreleased` and need
  the version at cut time (`grep -ni '· \[\?unreleased' docs/ADOPTION-LOG.md` — RELEASING.md
  step).

### Fixed

- **`rules/06` §4's field figures were attributed to the wrong cause** (#344). Parentage was
  unmeasured when §4 shipped — the entry said so — and once measured it pointed at a
  self-recursive `PATH` shim, not at the backgrounded wait loops also running that hour;
  deleting one file took the process count from 11,143 to 691. **The tell was inside the
  published number**: a `zsh` wait loop spawns `zsh`, `sleep` and `pgrep`, never 10,700
  `/bin/sh`. §4's mechanism and remedies are unchanged and independently sound; its figures
  are now labelled the process-table-exhaustion **signature**, with both causes
  cross-referenced and the checklist asking for parentage before blame.
- **A stale `· v1.41.0` marker in `docs/ADOPTION-LOG.md`** (#343) naming a tag that does not
  exist. Because it named a concrete version rather than `unreleased`, the release
  checklist's own `grep '· unreleased'` returned **0** and would never have corrected it.
- **The `sota-shell-scripting` rules index** (#343, #344) had never picked up §4, and
  `sota-testing`'s had not picked up the new sections.
- **A fail-open `§6.3` reference** in `sota-testing/rules/07`, caught by invariant 18 during
  the edit — the section lives in `rules/06`.

### Documentation

- **`README.md`** — the *ad-hoc command* class now carries the listing-cap count and the
  **process table** (two causes, one signature, separated only by **parentage**), and the
  *your own scorer or benchmark* class carries the pooled-threshold failure and **the revert**
  half of a mutation probe. `docs/INDEX.md` gains six rows. No invariant catches a *missing*
  feature, only a wrong number, which is why this is a manual pass every cut.
- **`docs/ROADMAP.md`**: item **48** opened (routing treated as done-for-the-session rather
  than per task shape — observed twice, both times a rule that existed and was never
  loaded); the field-brief tally corrected from *six briefs, 31 of 32* to **nine briefs, 37
  of 38**; open set 4 → **5**.
- **`evals/results/2026-09-08/SUPERPOWERS-HEAD-TO-HEAD.md`** (#341) records the five-mode
  audit confirming the low completeness score is **not** a defect on our side.

## [1.40.0] - 2026-09-10

**Cross-tool agent instructions.** A field tip about alternating Codex and Claude Code over
one project turned into a freshness correction that inverted its own conclusion twice — both
times because a claim was checked instead of assumed.

### Added

- **`gen-agents-md.sh --siblings`** — writes a `CLAUDE.md` **pointer** (`@AGENTS.md`) beside
  the generated `AGENTS.md`. Not a copy: `AGENTS.md` stays the single source of truth. The
  native import is preferred to `ln -s AGENTS.md CLAUDE.md` because **creating a symlink on
  Windows needs Administrator or Developer Mode**, so a symlink is not portable.
- **Sibling reporting, unconditional** (no flag needed, because a report writes nothing).
  Every run says what state the sibling entry points are in, and **never modifies an existing
  file**: `MISSING` with the exact line to add · `ok` when it already reaches `AGENTS.md` ·
  `ACTION` when it holds your own content and never mentions it · `ACTION` when it holds only
  the bare text `AGENTS.md` (a symlink checked out as a plain file — `core.symlinks=false`,
  or Windows without Developer Mode — which instructs nothing) · `ACTION` on a dangling
  symlink. Each branch tested, including that a user's first line survives.
- **`docs/VERIFY-SETUP.md` check 4a — "did it actually LOAD?"** Presence is not loading:
  `/context` under *Memory files* in Claude Code, `/memory show` in Gemini CLI, and the
  `InstructionsLoaded` hook where a log is wanted. Names the three silent non-load paths.
- **`sota-docs-workflow/rules/01` §10** gains the native import as option 1, the Windows
  symlink-privilege failure mode, and the trap that an **external `@` import declined once
  stays disabled and never asks again**.

### Changed

- **`GEMINI.md` is now opt-in behind `--legacy-gemini`, and Claude Code is the only
  mainstream tool still needing a pointer.** Measured on a real machine 2026-09-10: Gemini
  CLI 0.59.0 headless exits `IneligibleTierError: This client is no longer supported for
  Gemini Code Assist for individuals … migrate to the Antigravity suite`, so the 2026-06-18
  retirement is **in force**. Antigravity's own bundled docs say it discovers
  *"Directory-Based Rules (`GEMINI.md` / `AGENTS.md`)"* — the successor reads **`AGENTS.md`
  natively**. Tool lists in `README.md` and `rules/01` §7 now name **Antigravity CLI** with a
  one-line EOL note, which is what this repo's no-rot-pins policy requires.

### Fixed

- **`docs/CONTEXT-MANAGEMENT.md` carried two stale cells** against its own instruction three
  lines below them (*"re-measure, never carry it forward"*): the router read **399/500** and
  is **410**, and its token figure was measured when it was 399. The line count is corrected;
  the token cell is marked **STALE — do not quote** rather than estimated, because
  `count_tokens` was unavailable and a chars/4 estimate under-reads Claude by ~54%.

### Notes

- **A claim of mine was refuted mid-change and is recorded as such.** I asserted Gemini CLI
  had no import directive for `GEMINI.md`. Wrong — `gemini-cli` `docs/reference/memport.md`
  is an entire page about `@file.md` imports, and `docs/cli/gemini-md.md` documents a
  `context.fileName` **list** accepting `AGENTS.md`. The bad claim came from reading two docs
  that happen not to mention it: **an absence needs a second method with a different failure
  mode**, and two shallow reads of one doc set is not that. Committed while editing the file
  that describes exactly this error.
- **No invariant can see a tool going away.** All 29 gates and 43 probes were green while the
  tool lists named a CLI that had stopped serving individuals three months earlier. Only a
  person noticing, or a run failing, catches that class.
- Confirmed while checking: the Agent Skills spec's `description` cap really is **1024
  characters**, so invariant 4 and its attribution are correct. The 500-line cap's sibling is
  a **token** budget (body < 5,000 recommended) — there is **no byte/file-size limit** in the
  spec or in Claude Code's docs.

**Front door checked:** Antigravity CLI · siblings · did it actually LOAD

## [1.39.0] - 2026-09-10

**The open roadmap set worked end to end (2026-09-09): 8 open → 4.** Three items were parked
on a *decision*, and taking each one changed the answer the row had proposed. A fourth was
parked on a *measurement*, and the measurement reads negative.

### Added

- **Invariant 29 — a release that changes a skill `description` declares a routing check**
  (ROADMAP 44). A description is the entire auto-load classifier, so adding or editing one
  competes for every neighbour's traffic: `sota-skill-security` (v1.35.0) took
  `r1_token_count` from `sota-llm-engineering` 3/3 to 0/3 and was live for a day with
  invariants 4, 7 and 15 all green. **Not a CI gate on the routing run** — routing costs
  live calls, and a gate expensive enough to be disabled is worse than none. It gates the
  **declaration**, as invariant 14 does for the front door: it fires only on a release whose
  extracted `(name, description)` **map** differs from the merge base's, and the
  `**Routing checked:**` line must name an artifact that exists *and* mentions
  `desc-routing-regressions`. `RELEASING.md` gains §2c. Comparing the map rather than the
  diff is deliberate — a folded block, a rename and a deletion all change routing without
  touching a line beginning `description:`.
- **`scripts/verify-setup.sh` section F — what this machine's searcher silently excludes**
  (ROADMAP 45). Behavioural, not a presence check: a four-match fixture under `$TMPDIR`
  (plain, behind a symlinked dir, `.gitignore`'d, hidden) and one row per searcher naming
  what it skipped. Every row is **INFO** — `rg` skipping ignored files is a feature — and
  exactly one branch can FAIL: the **positive control**, because a searcher that cannot find
  the plain file makes every absence it reports worthless. `SOTA_SEARCHERS` selects what is
  probed. The script's read-only claim is amended rather than quietly broken.
- **`evals/run-conflict-rate.py`** (ROADMAP 39) — v2 of `run-routing-recall.py`, which named
  this and left it out because it needs a judge. Gold-set compositions, pairwise expansion,
  both skills' full corpus labelled by path, a judge calibrated **in the same batch** against
  a planted contradiction and a benign pair (VOID and no rate printed if they do not
  separate), and four guards each watched to fail.

### Changed

- **Invariant 25 gained a runner half** (ROADMAP 41). The row proposed per-(file, flag)
  documentation; that was **rejected** — `evals/README.md` is organised by the question each
  instrument measures, not by runner, and it would reopen the red-on-27 problem one level
  down. The unit that actually goes missing is the **runner**, so every `evals/*.py` must be
  named in `evals/README.md`, boundary-anchored. It opened red on two live misses,
  `run-unscoped-audit.py` and `run-build-safe-arms-guided.py`, then caught
  `run-conflict-rate.py` the same day. `MAX_UNDOC` 27 → **21**.
- **`sota-code-security`'s description now claims the control-verification question**
  (ROADMAP 12), against the artifact: *"even when that control lives in a shell script, a CI
  step or a config file"*. Measured: the verification half of a 12-case set routed at
  **0.500** against **1.000** for the vulnerability half, with all three misses unanimous and
  all naming a script. The clause moved it to **0.611** at no cost to the other half, and
  the **set** metric shows `sota-code-security` is never omitted — so **no skill split**.
- **Negative-control coverage 23 of 28 → 26 of 29.** Invariants 11 and 14 were exempt as
  *"diff-based: they compare against a merge base"*. That reason was **false** — a worktree
  lacks a **commit**, not a merge base — and writing check 29's probe produced the mechanism
  that closes them. `EXPECTED_UNPROBED` shrinks from `5 9 11 12 14` to `5 9 12`.

### Fixed

- **Check 29's escape hatch could never fire**, found by its own probe 29b on the first
  build: the CHANGELOG section was piped to `python3 -` while the script arrived on the same
  stdin via a heredoc, so the declaration was always empty and a *correct* release would have
  been failed. Probe 29 passed on that build, because the no-declaration branch was the only
  reachable one — the argument for probing **both** sides of an escape hatch.
- **Section F's first fixture was vacuous**: its behind-a-symlink file also sat inside the
  searched root, so searchers that never follow a symlink passed the row. The target now
  lives outside the scanned root.
- **`sota-shell-scripting` rules/06 §2 was wrong about `grep -R`.** Measured against a target
  reachable only through the link, with a positive control that the file is readable that way
  and `find -L` as a second method: **BSD grep 2.6.0** (macOS `/usr/bin/grep`) follows a
  symlinked dir met in traversal with **neither** `-r` nor `-R`, and follows one named as the
  argument only with a trailing slash. The old table had been measured through ugrep and
  generalised to "grep". Now named per binary, checklist included.
- **`verify-setup.sh` exited 1 on a machine where every check passed** — section F's EXIT
  trap ended in a failing test, and a bash EXIT trap's status becomes the script's. It
  survived one run because the output was read through a pipe. Caught by part B of the
  negative-control harness as a known-good fixture that had stopped passing.
- **`docs/CONVENTIONS-LEDGER.md`'s enforced list said 28 and enumerated 25** — invariants 26,
  27 and 28 were gated, described in its own table, and missing from the list above it.
  Invariant 17 reads the stated *count*, which was right both times.

### Measured

- **GATE-ABSORPTION = +0.062** (SE 0.019, **95% CI [+0.024, +0.099]**, 7 tasks × 4 arms × 3
  samples, temp 0.7) — **ROADMAP 43, H1 confirmed.** Under 400 lines of competing rules
  prose, removing the router's terminal self-audit costs **−0.05**; the gate recovers
  +0.062. The **first confidence interval in this repo excluding zero on BUILD step 4**,
  measured against a **+0.05 threshold registered before any call** and deliberately not
  moved toward the +0.04 item 32 had already seen. The registered ±0.02 noise band was
  *checked*, not assumed — observed SE 0.019 — while the within-arm per-sample spread is
  0.071 mean / 0.300 worst, which is why n=1 could not resolve this.
  **One prior claim did not survive:** item 32's *"item 25 replicates"* rested on a
  PAD-DELTA of −0.03; at this power it is **+0.01**, so with the gate on, this much
  competing prose costs nothing measurable. Superseded in place, never edited.
- **Conflict rate 0.176 verified** (0.353 judge-reported, 17 pairs × 3 samples) —
  **ROADMAP 39**, the first measurement of the one failure mode with a real incident
  behind it. **H1 (conflicts are rare) is refuted**: it required ≤ 0.10. `--verify` killed
  **3 of 11** reported conflicts as fabricated quotes — sentences absent from the files
  named — and the hand read killed two more, both because the judge sees a *pair of skills*
  and not the router, which is where conflict resolution lives. It is a **ceiling**: the
  judge saw every rules file of both skills where a session loads lean.

### Notes

- **Two pre-registered runs stopped on `HTTP 402 Payment Required`** and neither partial is
  reported as a number: the conflict rate at 10 of 17 pairs, GATE-ABSORPTION at 8 of 28
  arm-cells. Items **39 and 43 stay open, blocked on account credit and nothing else**; both
  registrations stand unchanged, so a re-run needs no new one.
  See [RUNS-BLOCKED-ON-CREDIT.md](evals/results/2026-09-09/RUNS-BLOCKED-ON-CREDIT.md).
  **Both were re-run on 2026-09-10 once credit was restored** and both produced their
  registered numbers, above.
- **Invariant 17 now reads `README.md`, and counts spelled out in words.** README was the
  one document describing the gates that nothing validated — it said *"Twenty-five
  invariants"* against a script with 29, across at least four releases. Neither the file
  nor the word form was in scope; both are now, each watched to fail.
- **Invariant 2 now requires exactly one `## Audit checklist`.** Five rules files carried
  two, stranding six audit bullets in a block a reader has already scrolled past. The
  last-heading test passed on every one of them.
- **`sota-shell-scripting` rules/06 §2 corrected**: BSD grep 2.6.0 (macOS `/usr/bin/grep`)
  follows a symlinked directory met in traversal with **neither** `-r` nor `-R`. The table
  had been measured through ugrep and generalised to "grep". Re-measured against a target
  reachable only through the link, with a positive control and `find -L` as a second method.
- **The Superpowers head-to-head is now in the front-door chart**, plotted with the
  unguided arm of *its own* run so the −0.04 cannot read as a win.

**Front door checked:** GATE-ABSORPTION · conflict rate · searcher

**Routing checked:** evals/results/2026-09-09/ROUTING-REGRESSION-RUN.md

**Docs only (earlier entry)** — a post-release sweep after five releases in one day, every
replacement number measured rather than scaled.

### Fixed

- **The priorities table pointed at an item closed earlier the same day.** Priority 3 was
  *"item 38 — price over-selection in tokens"*, which v1.37.0 closed with a measured figure.
  It now points at **item 45**. This is the **third** instance of the same
  summary-drifts-from-its-ledger shape in one session (item 12 on 2026-09-07, item 32's
  follow-up this morning, item 38 now) — the pattern is not a coincidence, it is what a
  hand-maintained summary over a ledger does under active work.
- **`evals/README.md` said the GATE-ABSORPTION arm was "Not yet run".** It ran on
  2026-09-06/07 and read **+0.04** against a registered +0.05 threshold and a ±0.03 null band
  — underpowered, not answered. The entry now says so and points at the write-up, and notes
  that the ROADMAP 43 follow-up needs its **own** pre-registration, since reporting it against
  the original threshold would not be one.
- **Roadmap header claims:** *"as of 2026-09-07"* → 2026-09-08, and *"All 44 items"* → 45.
- **Cap watch re-measured after five splits.** `sota-shell-scripting/rules/01` has left the
  list entirely — 498 → 366 → 502 → **343**, split twice in one day. The row now carries the
  two lessons both splits produced: *pick the seam from the citations, not the headings* (the
  seam the row itself once proposed was 114 lines against 384, while counting external
  references broke **zero** of them), and *a file that hits the cap twice in a day was two
  files*. Watch next: `sota-code-security/rules/10` at 484 and `rules/11` at 474.
- **The field-brief tally is now counted, not carried.** Six briefs landed **31 of 32** from
  the release entries (7/7 · 4/4 · 6/7 · 6/6 · 4/4 · 4/4), plus both 2026-09-08 intakes in
  full.

### Added

- **Invariants 27 and 28, and an AUDIT pass for knowledge that lives only in an agent's
  memory.** Same shape as 26, two files further out. **27** — an `ADOPTION-LOG` deferral must
  name its revisit trigger: the log's own rule said so in prose, and prose drifted (the
  roadmap said *"the deferred row"*, singular, while three existed and one had resolved the
  day before **in a different entry**). Deferrals now carry `**DEFERRED —` plus the
  condition. **28** — every `evals/cases/*.jsonl` must declare a `SELECTION RULE`: the
  convention held at 20 sets, then two were added and one skipped it —
  `prompt-independence.jsonl`, whose rule lived in its results doc and not in the case file,
  in the set backing the **+0.509** headline. Both watched to fail on asserted mutations, and
  both probed.
- **`sota/rules/01` §4a + router AUDIT pass 5 — knowledge that lives only in an agent's
  memory.** An assistant's private store is genuinely useful and some of it *must* stay
  private (which binary `grep` really is, which commands the harness refuses, anything a
  public repo's denylist would reject). The audit question is narrower: **is anything in
  there a fact about the repository that the repository does not have?** If so it is
  invisible to review, absent from a fresh clone, and gone when the store is cleared. The
  §AUDIT hash pin fired and forced a re-read of `rules/01` §5 before it was bumped, which is
  what that pin is for.
- **Invariant 26 — the roadmap's open set must agree with itself.** The answer to a drift that
  happened **three times in one session**: the priorities table pointing at work its own ledger
  had already closed (items 12, 32's follow-up, and 38). The root cause was not carelessness —
  **status was written in three places and only one was a fact.** The `**OPEN` marker on a
  ledger row is now the single source of truth; the header's open list and the priorities table
  are derived, and the invariant asserts the derivation: the stated count equals the listed
  numbers, the listed numbers equal the rows marked `**OPEN`, and every `**Item N**` cited in
  the priorities table is one of them. Fails closed on an empty open set. It found a **fourth**
  live inconsistency the moment it was written — the header listed 8 open where only 5 rows
  carried the marker, because items 1, 5 and 12 predated the convention; those rows are
  normalised here. Each of the three assertions was watched to fail independently before the
  check was trusted, and the known-bad probe replays the drift that actually happened (a
  priorities row pointing at a non-open item), not the easiest one to break.
- **The priorities table now says what it is.** *A view, not a record* — it keeps ordering,
  what a session would do first, and cost, which no machine can check, and it may **cite** an
  item without ever restating whether that item is open. The generalisable rule: a summary may
  order, prioritise and explain, but must not restate a fact the detail already carries; a
  citation is checkable and a paraphrase is not.
- **Router operating principle 3 — "independent" means a different failure mode, not a
  different phrasing.** The principle already asked for a second independent method before
  asserting an absence. Field-reported: two searches of the same tree agreed on **zero** and
  both were wrong, because both were `grep -r` over a directory of symlinks, which `-r` does
  not follow. A second method that shares the first's failure mode is one method. The only
  check that works is a **positive control in the same invocation** — search for something you
  have already seen there, and if the control returns nothing the instrument is broken and the
  absence is not evidence.
- **`sota-shell-scripting` rules/06 §3 — build output is the trap.** `target/`,
  `node_modules/`, `.venv/`, `vendor/`, `build/`, `dist/` reach tens of gigabytes and are what
  a naive recursive copy takes; redirect the tool's output instead of copying. And **a full
  disk is not a clean failure**: on a VM-backed container runtime the guest disk is a sparse
  file on the host's, so exhausting the host surfaces *inside* the VM as I/O errors that can
  corrupt the filesystem and image store — minutes later, in an unrelated command.
- **`sota-detection-engineering` rules/01 §8 — enforce the citation, and record the blind
  spot.** A source field that is optional is absent by the time anyone needs it, so enforce it
  the way a runbook link is enforced. And **record what the detection cannot see**: the same
  paper that supplied one technique also described a wrapper variant evading all three of its
  own signals. Writing that down is what stops a rule being credited with coverage it lacks.

### Changed

- **`docs/CONVENTIONS-LEDGER.md` now describes invariants 26–28, not just counts them.**
  Invariant 17 gates the *count* in that file's heading, and the count was right while the
  substance was missing — the ledger's whole purpose is the audit trail of what earned a gate,
  and three had been added without a row. Each is recorded against the same three filters
  (has it already failed · is it silent · is it mechanically checkable). Its
  *"Gated after this ledger was derived"* heading also said **(2)** over **one** row; now (4)
  with four.
- **The memory store was audited against the repo, and the naive method lies.** 148 distinct
  measured claims across 50 files, checked against a 16.4M-character corpus: a literal scan
  flagged **11** as memory-only and **every one checked was in the repo under different
  wording** — "10 of 32" is written there as *"10 of the old 32 freshness cases"*. Verdict:
  **zero memory-only repository facts**, but only a second method with a different failure
  mode (search a distinctive neighbouring phrase, not the numeral) establishes that. The
  method is now part of §4a, because the check is worthless without it.
- **`docs/CONTEXT-MANAGEMENT.md`'s token table now says what it is not.** The 5,000-token
  figure is a **stage-2** budget for a `SKILL.md` body — what compaction re-attaches — while
  `rules/*.md` are stage-3 resources the spec gives no budget at all. Several rules files sit
  above 5,000 by design and are deliberately absent from the list (`sota/rules/03` ~7,400,
  `sota-code-security/rules/14` ~7,100, `rules/11` ~7,000, all `bytes/4`, measured
  2026-09-08). Listing them would imply a ceiling the same file explicitly denies. It reads
  as *"the router is the one to watch"*, not as a census.

## [1.38.0] - 2026-09-08

**Front door checked:** name what the OK is about · silently excludes · ad-hoc command

**Minor** — one new rules file, one general rule that the rest hang off, and nine placements.
Two intakes landed together because they are the same failure at two altitudes: statements
that are **correct** and still mislead.

### Added

- **`sota/rules/03` §2 — a status can be TRUE and still be about the wrong subject.** The
  evidence standard already says validate a claim against a primary source; this adds
  **validate what the claim is ABOUT**. Field-reported, six in one session, every one
  literally true: *"exit code 0"* was the **wrapper's** (and arrived 17 seconds into a
  41-minute run); *"no advisories for this package"* was true of **the database that was
  opened**; *"the harness returned no result"* was true of **a container that never
  started**; *"38,861 passed"* was true of **the tree fifty minutes earlier**. Not the
  semipredicate problem — the value is unambiguous and the *subject* shifted, so looking
  harder at the number cannot find it. **When a check reports OK, name what the OK is about.**
- **`sota-shell-scripting/rules/06-ad-hoc-commands.md`** — the commands nobody commits. Split
  out of `rules/01`, which hit the cap **twice in one day** (498 → 366 after the constructs
  split, back to 502 as this intake landed, now **343**). Both seams chosen by citation count,
  and both times **§3 stayed put** — 6 external references against 2 for everything that
  moved. *A file that hits the cap twice in a day was two files.*
- **`sota-shell-scripting` rules/01 §2a** — a background job's completion signal is about the
  **launcher**. The two shell rules we had (`$?` after a pipeline, `cmd; echo`) are about
  *your* shell; here the shell was fine and a different process was told about a different
  subject. Wait on a sentinel the job writes last.
- **`sota-code-security` rules/13 §6** — an empty result that never names its store. 6,491
  advisories in one SQLite file, every default reader opening another, proven by the same call
  returning **13** and **0**. Silent because `[]` is a legitimate answer.
- **`sota-code-security` rules/14 §8** — a *real* control reverted by a neighbouring automated
  step into a state legitimate in another phase. "Timestamped only" is correct between
  releases, so only `--require-signature` separated healthy from destroyed.
- **`sota-testing` rules/04 §4.8** — a harness that could not start is indistinguishable from
  one that ran and found nothing, and only the second is a conclusion about the target.
- **`sota-testing` rules/07 §7.7 / §7.8** — a long run is scoped to the revision it started
  from; and **when a ratchet fires, the fix is never to re-record it** — the failure message
  offers exactly the action that destroys the signal.
- **`sota-devsecops` rules/07 §7.7** — prune/`fstrim` on a shared runtime is a change needing
  a restart and a smoke test, with foreign-owned resources enumerated first.
- **`sota-detection-engineering` rules/01 §8** — provenance, and **separating the attack's
  mechanism from the author's instrumentation**: a rule keyed on a paper's demo filename and
  printed marker detects the demo. 0 hits across all 8 files for
  `provenance|cite|arxiv|demo|scaffold`, control live.

### Changed

- **The absence rule got sharper, and the sharpening is not "switch tools".** Measured on one
  tree holding four matches: `rg` defaults found **1**, the environment's `grep` found **3**,
  explicit flags found **4** — so preferring ripgrep would have made the under-report *worse*.
  `-r` skips symlinked directories met **during traversal** where `-R` follows them. And the
  `grep` in that environment was a shell **function** running `ugrep -G --ignore-files --hidden
  -I …`, except `-z`/`-Z`, which it routed to **BSD grep** where `-z` means null-data — two
  programs answering to one name, with a flag deciding which. So the rule is: **name your
  searcher, its flags and its exclusions in the same sentence as the count**, and control a
  sweep with a known-present term **in the same invocation**. Every searcher
  **silently excludes** something; which something differs by tool. A capability note (ugrep
  `--bool`, verified; ripgrep's speed and gitignore defaults; `ast-grep` for constructs) rather
  than an instruction to install anything.
- **An ad-hoc command can destroy what it was checking** (rules/06 §3). We covered such
  commands producing false findings and never producing *damage*: a check copied 40 GB into a
  container on a host at 99%, corrupting the runtime and costing ~64 GB of images. The check
  never ran.

### Fixed

- **A defect of ours, shipped in v1.36.3 and found while landing this.** A scripted checklist
  insert whose replacement text contained its own anchor merged two lines into
  `…file:line@commit,**Finding quality**` and duplicated the bullet under it, in
  `sota/rules/03`. No gate could see it; only re-reading the file could.

### Notes

- **"Check whether ugrep is installed" was rejected as a `verify-setup` check** — a presence
  check is the wrong shape, since the library requires no searcher and a check that is
  routinely N/A gets skipped. It passes all three of the conventions ledger's filters though,
  so it is **ROADMAP 45**, to be decided as a *behavioural* probe rather than dismissed.
- Open roadmap items **7 → 8** (45 opened).

## [1.37.0] - 2026-09-08

**Front door checked:** fit to this measure · the secure use has to be the easy one · over-selection

**Minor** — one new rules file, and three open roadmap items answered by *running* them
rather than by reasoning about them. Two of the three answers are unflattering, and are
published that way.

### Added

- **`sota-shell-scripting/rules/05-constructs-and-cleanup.md`** — arrays, IFS, `trap`/`mktemp`
  cleanup, test constructs/printf, and globbing, split out of `rules/01` (**498 → 366**, new
  file **141**). **The seam was chosen from the citations, not the headings.** The roadmap had
  proposed §1–§2 vs §3–§3a; measured, that is 114 lines against 384. Counting instead what
  other skills actually cite — **4 external references at §3/§3a and zero at §4–§8** — put the
  cut after §3a, so **§3 and §3a never moved and no external reference broke**. The hand-walk
  still earned its keep: a bare `§2` inside the moved text meant `rules/01` §2 (SC2155) and had
  begun resolving to the new file's own §2. Invariant 18 passed it, because it resolves
  *somewhere* — the fail-open residual, third split running.

### Fixed

- **A skill added in v1.35.0 had been stealing a neighbour's routing for a day.** Running the
  regression set for only its second time, `r1_token_count` had inverted from
  `sota-llm-engineering` **3/3** to `sota-skill-security` **3/3**. Cause, read from the two
  descriptions: `sota-skill-security` contains *"instruction file"* twice and neither *"token"*
  nor *"budget"*, so the classifier matched r1's **noun** over its **question**. Fixed with one
  keyword on the side that owns the question (`instruction file size` → `sota-llm-engineering`,
  998 → 1021 chars); re-run **1.00 in both arms, both cases**. Opened as **ROADMAP 44**:
  invariants 4, 7 and 15 check a description exists, is short enough and is indexed, and
  **none checks whether it takes traffic from a neighbour**.
- **`sota-api-design` rules/01 §13 — the secure use has to be the easy one.** From the
  Trail of Bits `sharp-edges` deferral, adjudicated by reading both candidate files in full.
  **Rejected as new material** — the substance is already in `sota-code-security` rules/14 §6a
  (a parameter selecting a trust boundary defaults to the closed side) and rules/02 (`alg`
  pinning). **Adopted as a pointer**, because the gap was reachability: someone designing an
  API opens `sota-api-design`, not the audit skill. Three lines, both citations, no restatement.

### Measured

- **ROADMAP 38 — over-selection priced, and it is not "a router note".** Counted with
  `POST /v1/messages/count_tokens` over the 2026-09-06 routing run: **mean 10,738 extra tokens
  per task, +109%** on the `SKILL.md` load (median 11,838, max 20,071; pooled 98,673 gold vs
  107,375 over-selected). The item's registered rule was *"a few thousand tokens → a router
  note"*; this is an order of magnitude past it. But padded context measured **−0.01** and
  **−0.03**, so it is a **token, latency and money** cost, **not** a quality one. Both
  single-skill controls over-select exactly zero — the cost is entirely in multi-domain tasks.
  A floor, not the bill: `SKILL.md` only. No currency figure, deliberately.
  ([OVER-SELECTION-COST](evals/results/2026-09-08/OVER-SELECTION-COST.md))
- **ROADMAP 40 — the Superpowers head-to-head, run at last, and we are not calling it a win.**
  `obra/superpowers` @ pinned `b36e0829`, 7 cases, n=1, temp 0: SOTA **0.987**, unguided
  **0.637**, Superpowers **0.599** — **−0.39 vs SOTA, −0.04 vs unguided**. Against this repo's
  measured **±0.03** noise floor at n=1 that second number is **no measurable difference from
  no guidance at all**, and the honest reading is about our instrument: Superpowers is *process*
  guidance, these cases score a *built artifact's* domain coverage, so a low score is evidence
  about **fit to this measure**. It settles that the two are not substitutes; it does **not**
  settle the claim the outside assessments actually made — that a methodology beats a corpus —
  which would need an instrument we do not have, and building one to score a competitor is not
  a neutral act. Recorded as its own block in `RESULTS.md` rather than a row in the ranked
  table, because its unguided arm reads 0.637 where that table's reads 58% and merging them
  would imply a comparability this does not have.
  ([SUPERPOWERS-HEAD-TO-HEAD](evals/results/2026-09-08/SUPERPOWERS-HEAD-TO-HEAD.md))

### Notes

- **Two of the three runs answered against interest.** Over-selection is larger than the
  "router note" threshold that would have let it be dismissed; the head-to-head returns a
  number we cannot honestly publish as a win. Both are in the scoreboard.
- Open roadmap items **8 → 7** (38 and 40 closed by running them, 44 opened by the run that
  closed 38's sibling). Item 40 vacated priority 2; **44 takes it** — and it is a *decision*
  first, not a build: routing costs live calls, so a per-PR gate would be the expensive kind
  that gets disabled.
- **`sota-shell-scripting/rules/01` is no longer the tightest file** — 366 after the split.


### Also in this release — the roadmap ledger repair

Landed before the work above: two drifts in `docs/ROADMAP.md`, both introduced by this week's
own releases, and both the summary-drifts-from-its-ledger shape the same file carried for
item 12 until 2026-09-07.

### Fixed

- **The priorities table pointed at work with no ledger row.** Priority 4 cited *"item 32's
  follow-up"*; item 32 is closed, and the follow-up existed only in that one cell. It is now
  **item 43**, with its own row carrying the part a summary cell cannot: that this is a **new
  experiment needing its own pre-registration**, not a re-run, and that **reporting it against
  item 32's original threshold would be invalid** — a threshold chosen after seeing +0.04 is
  not a pre-registration. The open count moves 7 → 8.
- **The cap-watch row was a day stale, in a week where three files moved.** It still read
  `sota-shell-scripting/rules/01` **490** (now **498**) and `sota/rules/03` **428** (now
  **447**), and omitted `sota-devsecops/rules/01` at **450**, which v1.36.1 made the fifth
  largest file in the library. Every number re-measured with `grep -c ''` this session, and
  the row now says the thing that matters more than the numbers: **a row of line counts goes
  stale within a day of active work, so re-measure it rather than reading it.**

## [1.36.3] - 2026-09-08

**Front door checked:** discovery is not collection · output delta · healthy fallback

**Patch** — rule text inside existing surfaces. The sixth field brief in this series, from
removing an orphaned CI CronJob and repairing the monitoring gap that had hidden it. **All
four proposals adopted**, plus the minor it offered without one. Full evaluation, including
how strong each item's evidence actually is:
[docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md).

### Added

- **`sota-code-security` rules/14 §4b — the stage that reports success is not the stage that
  failed.** §4 covers a control whose *trigger never fires*. This is one layer on: the control
  ran, failed, and said so — in a field nobody read, while a different field on the same
  screen read as success. `workflow-controller targets: 1` reads as working; the next line was
  `health=down`. **The earliest stage's signal is the one that looks like a summary**, because
  it is a count and it renders first. **Discovery is not collection**, and the same split is
  enumerate-vs-process, connect-vs-authenticate, resolve-vs-fetch, schedule-vs-execute,
  register-vs-invoke: accept the downstream artefact, never the pipeline's own readiness. Its
  corollary gets its own bullet — **repairing an inert control needs an output delta, not a
  green light**: three affirmative signals were green while nothing was collected, and only
  `0 → 54` series told repaired from broken.
- **`sota-devsecops` rules/10 §3a — "unreached" proves nothing about a fallback**, plus a
  clause in §6 bucket A. This one **corrects a rule shipped the day before**. `rules/10` proves
  a candidate unreached and deletes it on that evidence — sufficient for a dependency, whose
  job is to be *called*, and not for anything whose job was to be *available*. Being unreached
  is what a **healthy fallback** looks like, so the proof returns the same green for "safely
  obsolete" and for "the safety net nobody has needed yet". The field case turned on a
  different question entirely: the orphaned cache was deletable only because the mirror that
  replaced it was 3.3 hours old, inside its refresh window — **had it been stale the correct
  action was the opposite one**. A DELETE candidate that was redundancy now needs the successor
  named and measured this session, or it is KEEP.
- **`sota-observability` rules/02 §7 — a port declaration does not state the protocol spoken on
  it.** A container advertising `metrics:9090` says nothing about TLS; scraping HTTP where
  HTTPS is served returns `400 Client sent an HTTP request to an HTTPS server`, which reads as
  a broken exporter. Probe both ways before writing the scrape config, accept the target on the
  series arriving rather than on discovery, and where the certificate is self-signed by the
  component's own issuer say so beside the flag that skips verification — no CA bundle can
  verify it and mounting one is theatre.
- **`sota-kubernetes` rules/04 §7a — what you wrote is not what lands.** A transformer can
  override the `namespace:` in your manifest; the namespaced lookup then returns nothing, which
  reads as *"never applied"* rather than *"wrong place"*. Render and grep the render; run
  `kubectl get <kind> -A` before any absence claim. Includes the brief's un-proposed minor —
  **GitOps prune-by-omission**: functional deletion is removing an object from the rendered
  set, not deleting its files, which also means an object can be gone from the cluster while
  its manifest is still in the repo.
- **`sota/rules/03` §2 — a correlation across the whole population is still not a mechanism**,
  placed immediately *before* the existing N-of-N material, which is the point. §2 already asks
  for N-of-N reproduction, so a reader could carry that authority across to a *correlation*,
  where it does not hold: repeating an **observation** bounds noise, while observing that N
  members **share a property** bounds nothing. 8 of 8 working scrape objects sat in one
  namespace and the only one elsewhere collected nothing — a perfect correlation whose
  inference was wrong, refuted by one query against the collector's target list.

### Notes

- **Evidence strength is recorded per item rather than flattened.** #2 rests on one case that
  turned out fine, which is weaker than an incident. #4 is a near-miss caught before acting.
  #1 and #3 come from a single monitoring stack — the *shape* of #1 generalises to any
  discovery-then-collect pipeline, the specifics of #3 are Kubernetes-flavoured and were placed
  in the Kubernetes and observability skills rather than promoted. **None met the
  two-independent-sources bar for a cross-cutting home, and none was given one.**
- **Invariant 18 caught a stale reference in this very change**: a new paragraph cited
  `rules/03` §3.9.5, which moved into `rules/10` as §5 in v1.36.0 — the day before. The gate
  reported it before the first commit.
- **The brief confirms the previous intake's verdict from the outside.** It opens by agreeing
  that pointing its watcher proposal at `sota-code-security` rules/15 §2.2a rather than
  restating it was right, *and* that the reason it missed that section is the reason the note
  gave: it lives in a skill that workflow never loads. That is the UNREACHABLE diagnosis being
  confirmed by the person it was made about.

## [1.36.2] - 2026-09-08

**Front door checked:** searched nothing · separator-specific · routing gap

**Patch** — a **routing gap** closed in the trigger, not the text. The rule that would have
prevented a defect in this repo was already written, in the right file, with the right
remedy. It never fired, because nothing loaded the skill.

### Fixed

- **`sota-shell-scripting`'s description named shell *artefacts* and never the *act*.** It
  listed scripts, CI blocks, entrypoints and Makefile recipes — so it did not fire for the
  thing that actually goes wrong most often: an **ad-hoc command you type to check a claim**.
  A maintenance session ran `grep -lEi "$p" $L` with `L=$(ls …)` in zsh, where an unquoted
  expansion does **not** word-split; the whole newline-joined list went as one impossible
  filename, the sweep **searched nothing**, and the empty result was read as a coverage
  answer. Twice, and reported. `rules/01` §3 and §3a already carried the deviation (verified
  against the zsh Options manual), the exit-2 tell, the `NOMATCH` case *and* the
  positive-control remedy. **UNREACHABLE, not absent** — the same shape as the token-counting
  mis-route of 2026-08-27, and fixed the same way: the description now names the act, the
  absence (`"no matches"`, `"nothing found"`, `"0 results"`), and the moment — *before
  trusting any conclusion a shell command produced*.
- **Router cross-cutting rule 17 pointed at the wrong section.** It says shell hides "in the
  one-liners you type to verify a claim" and then sent the reader to `rules/01` §3. **§3a** is
  the section for *pasted and agent-issued commands*, which is exactly that case. Repointed,
  and its parenthetical no longer implies the failure is always loud: a failed glob is silent
  and fakes a clean result.
- **A regression case pins it**: `r2_absence_sweep` in
  `evals/cases/desc-routing-regressions.jsonl`. **Not yet run** — the before/after number
  costs live calls and has not been authorised, so it is recorded as absent rather than
  assumed.

### Changed

- **`rules/01` §3 now shows the shape that actually bites an audit sweep.** Every example in
  it was a space-separated *flag string*; the shape a sweep builds is a **newline**-separated
  file list from `$(…)`. Both fail by joining, but the file-list case fails by searching
  nothing while looking like a clean tree. **The remedy is separator-specific and this is the
  trap inside the trap**: `${=var}` — §3's own fix for the flag-string case — is *wrong* for a
  file list, because it splits on spaces too. Measured on this machine: with one filename
  containing a space, `${=files}` returned **1 hit where 2 were due** and warned about two
  paths that do not exist; `${(@f)…}` returned both. §3a's table row now carries the same
  distinction.

### Notes

- **This is the second time a rule of ours was present, correct and unreached**, and both were
  fixed in the classifier rather than the prose. The generalisable part is in
  [docs/INDEX.md](docs/INDEX.md): *fix the trigger, and pin it with a regression case* — a
  description that enumerates artefacts will not fire on an activity, and most of what an
  agent does to *check* something is an activity.
- **`sota-shell-scripting/rules/01` is now at 498/500.** Roadmap item 13 no longer lists it as
  a watch item: it is **the split**, and the next addition must offload first. The seam is
  already in its own headings — §1–§2 (shebang, `set -e` semantics) vs §3–§3a (quoting and the
  zsh deviations), which is also the half other skills cite.

## [1.36.1] - 2026-09-08

**Front door checked:** never persist raw · agent session transcript · constant time is a property of the emitted code

**Patch** — rule text inside existing surfaces, one verifier check, and the docs sweep that
was sitting in `[Unreleased]`. Two intakes from independent sources converged on one
subject: **what an agent's own tooling does to the controls the rest of the library
assumes**.

Sources: a field brief from a session that used this library on another repository and had
an incident there, and an operator-requested review of
[trailofbits/skills](https://github.com/trailofbits/skills) (83 skills). That repo is
**CC-BY-SA-4.0** — share-alike, incompatible with this library's CC BY 4.0 — so it was
mined for **idea classes only, with no text reuse**; the licence was read from the API
before anything was planned. Full evaluation of both, with what was rejected and why:
[docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md).

### Added

- **`sota-secrets-management` rules/03 §2.1 — never persist raw.** Redacting types need
  producer control, so for text whose producer you do **not** own — a swept corpus, shell
  history, a crash dump, an **agent session transcript** — the guidance silently degraded to
  shape-scrubbing, and shape-scrubbing is an enumeration. Field evidence: a shape-redaction
  fix **defeated by its own regression test on the first run** (a GitLab PAT, a Slack webhook
  URL), then a key that is bare 64-character hex with **no prefix to match at all**. The rule
  is to persist a digest plus a structural skeleton — leak-proof by construction rather than
  by list — and it states the shape channel as a real if narrow disclosure instead of
  claiming zero leak.
- **`sota-secrets-management` rules/04 §7 — agent session transcripts are a credential
  store.** Verified observation: a harness loaded a repo's `.env` under a header claiming
  *"project instructions, checked into the codebase"* when it was untracked, gitignored and
  mode `600` — every clause falsified with a command — putting four live keys verbatim into
  `~/.claude/projects/**/*.jsonl`. Inventory the path, scope the scan before running it,
  treat any tool that sweeps it as a secret-processing tool, and note that **a tool whose
  input path is outside the repo has a surface that changes with no commit to the repo**.
  Carries its own calibration: owner-only to owner-only on one machine is an expanded
  surface, **not** a disclosure, and not on its own a reason to rotate.
- **`sota-devsecops` rules/01 §1.5a — AI coding agents are CI actors holding your token.**
  Zero prior coverage. Triggers a non-collaborator can fire; following the value rather than
  the syntax; tool allowlists judged by what their members *compose* into (`echo "$(env)"`);
  sandbox and auto-approve flags read as the control they are; agents invoked two `uses:`
  levels down spending the caller's token.
- **`sota-code-security` rules/04 §6.1 — constant time is a property of the emitted code.**
  The library had the *wiping* half (`memset` is dead-store-eliminated, hence `explicit_bzero`)
  and never generalised it. Secret-dependent `/` and `%` lower to variable-latency
  instructions, and "I made the divisor constant so it strength-reduces" is an optimiser
  courtesy that varies by compiler, target and level — `-Os`/`-Oz` both betray it and ship.
  Read the disassembly across the matrix you ship; verify a hand-written multiply-shift over
  the whole input domain, since an off-by-a-power-of-two reciprocal agrees for millions of
  inputs before it diverges.
- **`sota-code-security` rules/15 §2.2 — a scanner's default configuration can exclude its
  most valuable detector.** Distinct from a threshold *you* chose being too coarse
  (`sota-devsecops` rules/09 §6): here you chose nothing and the silence is the vendor's.
  Print the effective configuration beside the verdict and name the families that did not run.

### Fixed

- **A rule of ours was unsafe at a sink it did not name.** `sota-devsecops` rules/01 §1.5
  taught `env:` indirection as *the* fix for expression injection. That is right for a
  **shell** sink. For a sink that consumes the value as **instructions** — an AI-agent
  prompt, a template engine, an `eval` — reachability is unchanged and the `${{ }}` that
  reviewers and `zizmor`/`actionlint` key on is *gone*, so the dangerous configuration now
  reads as clean YAML. §1.5 now names the sink class its defence neutralises. Found by the
  external review, which is the first time an outside source has identified a rule of ours
  that *causes* a miss.
- **`verify-setup.sh` check 1 printed a number with nothing to compare it against.** It
  counted installed `sota*` skills and passed. On this machine it read **41** while the
  checkout held **42** — `sota-skill-security`, added in v1.35.0, had no symlink — and the
  run said PASS. `install.sh` does link every skill and *is* the updater, but **a `git pull`
  updates existing symlinks and can create none**, and nothing invokes the verifier, so an
  incomplete install has no symptom: a missing skill looks like the model simply not
  choosing it. Check 1 now computes the source-side denominator and reports **PARTIAL** with
  the missing names. Watched to fail before being trusted: armed it reports the missing
  skill, neutered it returns to **PASS while printing "(source offers 3)"** — the number on
  screen, unread, which is `sota-code-security` rules/11 §2.2 committed by this repo's own
  verifier.
- **`install.sh` — and therefore `update.sh` — now runs the verifier itself.** Pointing at it
  in the closing banner was not enough: nothing invoked it, so nobody ran it. Every install
  and every update now ends with `verify-setup.sh --reach-only` (new flag: section A only),
  because *"linked 42 skills"* is what the installer **did** and reachability is what the
  agent **gets**. It is **read-only and never fatal** — a non-zero verifier must not abort a
  successful link run — and `--no-verify` opts out. **The first draft of that check was
  itself inert where it mattered most**: it resolved the source tree from `$REPO_ROOT`, so
  run from a user's own project there was no `./skills`, the denominator stayed 0, the
  comparison silently did not happen and the row still said PASS — location-dependent
  silence (`sota-code-security` rules/11), committed by the fix written for it. It now
  resolves the library from the script's own path, verified from inside and outside the
  checkout. Scoped to section A on purpose: the
  repo-context, gate and CI sections describe whichever directory the installer was invoked
  from, and a report that is routinely red for irrelevant reasons is a report people learn to
  skip ([docs/CONVENTIONS-LEDGER.md](docs/CONVENTIONS-LEDGER.md)). Watched both ways:
  `--reach-only` exits 1 on a broken install and 0 on a good one.

### Changed

- **`scripts/check-negative-controls.sh`: 32 → 33 probes**, all caught. The new one needed a
  new assertion shape: check 1's incomplete-install branch reports **PARTIAL**, and
  `verify-setup` exits on `n_fail` alone, so the existing `vs_probe` — which demands a
  non-zero exit — would have read a working branch as INERT. `vs_probe_partial` asserts the
  row instead of the exit code, and still refuses a catch for the wrong reason.

### Notes

- **Three claims in the incoming brief did not survive reproduction**, and all three were
  read-truncation or sweep faults rather than reasoning errors: it described a two-tier list
  that has three items (it had read to line 60 of a list that continues), it reported that
  *nobody* covers agent transcripts when the file it proposed already said "AI tool
  transcripts" one clause deep, and it concluded the installed tree is a build artifact when
  it is 41 symlinks into this repo. The proposals were sound; the sentences around them were
  not — the same pattern as the v1.35.2 brief.
- **An install that is 41 of 42 is a coverage claim's denominator**, and it silently weakened
  the brief's own sweep: the one skill with no symlink was `sota-skill-security`, which owns
  the instruction trust boundary — the exact mechanism of its own transcript finding.
- **Deferred with triggers written down**, both from the external review: misuse-resistant
  API design as a producer-side control (the idea exists 11 times in the library as a
  *consumer*-side heuristic and, on a file-level sweep, not in `sota-api-design` at all), and
  triage discipline for an *incoming* vulnerability report (our coordinated-disclosure
  coverage is the obligation, not the triage).


### Also in this release — the post-release docs sweep

Run before the intakes above: a pass over the prose that no gate reads, checked against the
tree rather than against itself.

### Fixed

- **The roadmap's summary table contradicted its own ledger.** `docs/ROADMAP.md` carries a
  "Start here next session" priorities table above the full item ledger. Item 12's
  *priorities row* said its trigger was unmet — "it needs a sixth verification file in
  `sota-code-security` and there are **5**" — while the *ledger row*, a few hundred lines
  below in the same file, had said since 2026-09-06 that `rules/15` is the sixth and the
  trigger **fired**. Re-counted from the tree: `rules/10`–`15`, **6 files, 2,171 lines**. The
  summary is the half people read and the half nothing regenerates, so it is the half that
  drifts.
- **Four counts were stale, every replacement measured.** `skills/sota/SKILL.md` **398 → 399**
  (`grep -c ''`; `AGENTS.md` says this figure has now been wrong six times, so the count is in
  the sentence beside the instruction to re-count it). `rules/*.md` **261 → 268**. Invariant
  1's enumeration **305 → 310 files**. Item 12's verification cluster **5 files / ~1,500 lines
  → 6 / 2,171**.
- **`docs/CONTEXT-MANAGEMENT.md` reported the router at 484/500 in three places.** It is
  **399/500** — 101 lines of slack, not 16 — and its token cell said 16,442 / 3.3× where the
  measured post-offload figure is **13,415 / 2.7×** (`count_tokens`, `claude-sonnet-5`,
  2026-09-02). The file's own supersede block already carried the right numbers; the cells a
  reader hits *first* carried the old ones. Dated measurements inside the supersede blocks
  were left exactly as written.
- **The roadmap's priorities table had two rows numbered 3**, and its "as of" date was a week
  behind its contents.

### Changed

- **`RELEASING.md` §2b now lists four ways the `Front door checked:` line bites, not two.**
  Both new ones were hit at the v1.35.2 cut and both were read out of the check rather than
  guessed: invariant 14 parses the line with `tr '·,;' '\n'`, so **a comma inside a term
  splits it** (`floor, not a ceiling` declared as two terms — both happened to resolve, so it
  *passed* while the declaration did not say what it meant; the tell is a `N terms declared`
  count higher than the number of `·` typed); and the match is `grep -qiF`, which is
  **line-scoped**, so **a term wrapped across two lines in `README.md` does not match** even
  though the prose reads fine. That one bit twice in a row.
- **The field-brief adoption rate is now counted rather than recalled.** The roadmap's
  argument for priority 1 cited two briefs; counted from the release entries, the last five
  landed **27 of 28** — 2026-08-26 **7 of 7**, its follow-up **4 of 4**, v1.32.3 **6 of 7**,
  v1.34.0 **6 of 6**, v1.35.2 **4 of 4**. The row also now records what to *ask* a brief for,
  which has sharpened twice: the rules of ours that caused the defect, and its
  already-covered reports — a rule earning its place is invisible from inside the repo.
- **`docs/INDEX.md` gained two rows** for capabilities that shipped in v1.35.2 and v1.36.0
  with no index entry: auditing what a repo carries but never runs (`sota-devsecops`
  rules/10), and pinning a version nothing can watch (rules/03 §3.7.1 + rules/09 §6).
- **Cap watch re-measured (roadmap item 13).** Every number from `grep -c ''`:
  `sota-shell-scripting/rules/01` **490** is now the tightest file in the library and the next
  reactive-split candidate; then `sota-code-security/rules/10` **484**,
  `sota-docs-workflow/rules/01` **477**, `sota-code-security/rules/11` **474**. The row's
  opening list still carried `rules/12` at **498**, a pre-split number its own narrative
  contradicted two sentences later.

### Notes

- **`scripts/check-negative-controls.sh` re-run today: `PASS: 32/32`**, and its printed
  coverage list matches the one restated in `AGENTS.md` (invariants 1, 2, 3, 4, 6, 7, 8, 10,
  13, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25 — 20 of 25; the five unprobed need state a
  worktree lacks). The claim is dated to the run, not carried forward.

## [1.36.0] - 2026-09-07

**Front door checked:** declared but never reached · inert-dependency sweep · a grep is not proof

**Minor** — one new rules file, no new guidance. `sota-devsecops` rules/03 §3.9 becomes
`rules/10`, because the previous release let the line cap decide where two rules lived.

This closes ROADMAP item 42, opened at the v1.35.2 cut hours earlier. The trigger was
explicit: v1.35.2 put `03-dependencies.md` at **487/500**, and the cap — not the argument —
chose two placements in it. A file that decides your content twice is done absorbing.

### Changed

- **`sota-devsecops` rules/03 §3.9 → `rules/10-inert-dependencies.md`.** The
  declared-but-not-reached sweep — reachability from a real entrypoint rather than import
  presence, the per-ecosystem tools and each one's blind spot, deletion-as-proof, the
  leverage ratio, upstream health from a live primary source, the four-bucket
  classification, and why "unused" is an absence claim for which **a grep is not proof** —
  is now its own file. Same content;
  the subsections renumbered §3.9.1–§3.9.7 → §1–§7, matching the `rules/05` §5.6 → `rules/09`
  precedent (a single section with named subsections becomes a file numbered from 1).
  **rules/03 487 → 316, rules/10 179.** Both are back under half the cap.
- **The front door names the sweep.** `README.md`'s class list called it "dependencies
  declared but never reached" and linked `rules/03`; it now says **inert-dependency sweep**
  and links the file that holds it.

### Fixed

- **Two defects the reference sweep turned up that no gate could see.** A repointed line in
  `evals/README.md` left `rules/03` dangling on the line above its replacement — found by
  reading the result, not by running the checker. And `sota-sandboxing` rules/05 carried a
  pre-existing `sota-devsecops` rules/03 **§3** that resolved nowhere (there is no `## 3`;
  install-time execution is §3.4) — invariant 18 is deliberately fail-open, so it had never
  complained.
- **`docs/ADOPTION-LOG.md` described invariant 18's scope wrongly.** It said the check reads
  "`skills/` only", which was its *original* scope; it was widened on 2026-09-04 and now also
  reads `evals/*.py`, `evals/README.md`, `scripts/*.sh` and `scripts/lib/*.py` — which is how
  this split's broken reference in `scripts/check-invariants.sh`'s own header was caught. The
  sentence now states the real scope **and** what is still outside it (`docs/`,
  `evals/cases/*.jsonl`, `README.md`, `CHANGELOG.md`), since that is the part the note exists
  to cover.

### Notes

- **The reference cost, measured for the third time.** Invariant 18 reported **16 findings**
  on the first run after the move — **14 of them pre-existing references across 11 files**,
  including two eval runners and `check-invariants.sh`'s own header comment; the other two
  were in the new file's own header. **Six further files were repointed by hand and the gate
  never reported one of them**: five are outside its scope (`README.md`, `docs/INDEX.md`,
  `docs/MAINTENANCE.md`, `evals/cases/reimplement.jsonl`, `evals/cases/dead-path.jsonl`) and
  one — `skills/sota/rules/04-library-map.md` — is *inside* it and resolved **fail-open**,
  because the citation read `03 §3.9` without the `rules/` prefix the checker keys on. The
  hand-walk remains the majority of the work on any split.
- **One reference correctly did not move.** `sota-mobile` rules/04 cites "rules/03 §3.9" —
  that skill's *own* token-lifecycle section. It resolved cleanly and was left alone; a
  blanket find-and-replace on `rules/03 §3.9` would have broken it. This is the fail-open
  case the last two splits also hit, and it is the argument for reading every hit rather
  than trusting the gate's silence *or* a regex.
- **History is not repointed.** `CHANGELOG.md`, `evals/results/` and the dated
  `docs/ADOPTION-LOG.md` rows keep their `§3.9` pointers — they record where an idea landed
  at that release. The translation map in the adoption log gains a row instead.
- **`docs/CONTEXT-MANAGEMENT.md` lost a row.** `03-dependencies.md` was listed as exceeding
  the per-skill 5,000-token compaction cut at ~7,300; by the same `bytes/4` method it is now
  ~4,850 and `rules/10` ~3,450, both under it. Splitting for the *line* cap moved the *token*
  number too.

## [1.35.2] - 2026-09-07

**Front door checked:** unwatchable · bespoke watcher · Minimal Version Selection

**Patch** — a field brief on pinning, landed in full. Four proposals adopted, two of them
corrected on reproduction, and one of the brief's supporting premises refuted outright.

Source: a session that used the library to pin and deploy a Caddy-based API gateway on
self-hosted Kubernetes. The fifth brief of this shape, and the highest-yield intake channel
the library has. Full evaluation, including what was verified before anything was written:
[docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md).

### Added

- **`sota-devsecops` rules/03 §3.7.1 — a pin nothing can see is a freeze, not a pin.** §3.7
  audited only the *absence* of update automation and assumed Renovate/Dependabot was the
  mechanism. That assumption has a hole: it only works for versions a bot can parse. A
  version embedded in a build-tool invocation — `xcaddy build v2.11.4 --with plugin@v0.1.0`
  in a `RUN` line, and the same shape in Bazel/Make args, `go install tool@version` and a
  `pip install x==y` inside a Dockerfile — is pinned and **unwatchable** by construction.
  Before the pin it drifted to latest on every rebuild; after it, it is frozen forever, and
  **both states are silent** — pinning merely converts an unreviewed drift into an
  unreviewed freeze while sounding finished. The rule: every pin names the mechanism that
  will tell you it is stale, and "Renovate" counts only once you confirm the bot parses
  *that file and that line*. Verified against primary sources: `customManagers` (regex plus
  an explicit `datasourceTemplate`) is Renovate's supported answer, and Dependabot has no
  equivalent — its ecosystems are manifest-shaped, so it reads a Dockerfile's `FROM` and
  not its `RUN` args. With no bot that can see the pin, the alternatives are a watcher or a
  written acceptance of the freeze with an owner and a review date.
- **`sota-devsecops` rules/09 §6 — a bespoke watcher inherits the publishing conventions of
  what it watches.** The watcher you write because no bot could see the pin is an
  instrument, and silence is a watcher's *normal* state — so an entry that can never report
  is indistinguishable from one with nothing to report. Two field failures, both green:
  a watcher querying `GET /repos/<o>/<r>/releases/latest` takes a **404** from a project
  publishing git tags and zero GitHub releases and skips that entry every run forever, and
  a "more than one minor behind" threshold reported **OK** for the `v2.11.4 → v2.11.5`
  patch that was the entire reason the pin existed. Reproduced against the live API:
  `mholt/caddy-ratelimit` has 0 releases, the single tag `v0.1.0`, and `releases/latest`
  answers `404 Not Found`. Four audit axes, and a pointer to `sota-code-security` rules/15
  §2.2a rather than a restatement of it — the four-state watcher model was already written,
  in a skill nobody writing a version watcher loads.
- **`sota-golang` rules/07 §4 — `require` is a floor, not a ceiling.** Nothing in the
  library explained Go's version-selection semantics, which makes a common review claim
  false. Under Minimal Version Selection the build takes the **highest** version required
  anywhere in the module graph and a `require` line states a *minimum*, so `require foo
  v1.2.3` cannot cap `foo` — it is an exact pin only for a leaf dependency nothing else
  requires. Used deliberately the floor is the right tool for forcing a CVE fix, and it
  goes inert once upstream requires the fixed version anyway.
- **`sota-devsecops` rules/03 §3.7.1 — pin while the pin is still a no-op.** The cheapest
  moment to pin is when the pinned version is already what resolves: the pin is then
  provably inert, and an SBOM diff showing the artifact component-for-component identical
  is the receipt. Never pin and upgrade in one change — that regression has two candidate
  causes and no build separates them. Read the version from the resolver that will actually
  run (`proxy.golang.org/<module>/@latest`), not from GitHub's `releases/latest`, which
  answers a different question.

### Fixed

- **Two of the brief's own claims did not survive reproduction, and shipped corrected.**
  It proposed that capping a Go dependency needs `replace` **or** `exclude`; the modules
  reference says an excluded version's requirement is redirected to the *next higher*
  version, so `exclude` moves selection **up** and cannot cap either — only `replace` caps,
  and that is what rules/07 §4 now says. It also cautioned that `sort -V` might be missing
  from the watcher's container; measured the same day, the *inversion* is real (plain `sort`
  ranks `v2.9.1` above `v2.11.4`) but BusyBox 1.37.0 in `alpine:latest` **does** support
  `-V`, so the rule ships as *verify the comparator in the image it runs in*, with the
  measurement stated in both directions.
- **A premise the proposal leaned on was false.** "Pin while the pin is a no-op" was offered
  as "the same reasoning as one-variable-at-a-time elsewhere in the library" — that
  reasoning is nowhere in the library (0 hits across all 42 skills for every phrasing
  tried), which made the proposal larger than advertised rather than smaller. It is now
  stated rather than cited.

### Notes

- **Three rules were reported as firing correctly in the field and are unchanged**, which is
  the half of an intake that is otherwise invisible: rules/03 §3.9.5 (a recent `pushed_at`
  with no release in two years is still drifting), `sota-code-security` rules/15 §2.1 (a
  probe that exercises a neighbouring property — `curl -H "Host:"` does not set TLS SNI, so
  a `000` measured handshake rejection, not the service), and router principle 3 (all three
  of the session's probes failed *toward* a false negative, which is why the principle pays).
- **`03-dependencies.md` is now at 487/500** and the cap, not the argument, chose two
  placements in this release. The offload is §3.9 (~167 lines) and it is deliberately not
  bundled here — 42 `§3.9` references live outside the file. Opened as a roadmap item.

## [1.35.1] - 2026-09-07

**Front door checked:** badge alt text · over-selection · conflict rate

**Patch** — two stale claims, one check extended, and four roadmap items opened. Nothing
new to run.

The post-release sweep after v1.35.0. It has found something at every cut this session,
and this time both findings were counts that a gate was *almost* watching.

### Fixed

- **The README badge alt text was stale.** Its number said 42 while its `alt` text said 41. A count bump had
  updated the machine-readable half and not the human-readable one. **Invariant 6 checked
  only the number** — so the half a screen reader announces, and the half that survives
  when the image 404s, was the stale one. The check now reads both, watched to fail on
  the real defect before being wired in.
- **The router's library-map pointer said "for all 40 skills"** while its own opening line
  said 41 and the map lists 41. Nothing checks a count stated in prose beside a link.

### Opened

- **ROADMAP 38 — over-selection is measured but its cost is not.** Routing precision is
  0.569 (0.45 against gold sets transcribed from the router's own rules), but ROADMAP 25
  measured a padded context at −0.01 and item 32 at −0.03. On current evidence this is a
  **token, latency and money** cost rather than a quality one. **The next step is
  arithmetic, not an eval** — price the over-selected sets with `count_tokens`, never
  chars/4. If it is a few thousand tokens per task it is a router note, not a project.
- **ROADMAP 39 — conflict rate has never been measured.** The only one of the four
  routing failure modes with a real incident behind it: two rules in this library
  contradicted each other in a live build, which is why the router carries a
  conflict-resolution clause. Needs a judge, so pre-register first.
- **ROADMAP 40 — the Superpowers head-to-head is staged but not run.** Both external
  assessments rest their verdict on that comparison and we have never made it.
- **ROADMAP 41 — invariant 25's ratchet cannot see a whole new undocumented runner.**
  Demonstrated twice now: `run-routing-recall.py` shipped with six flags and the
  undocumented count did not move, because every one of its flag names already appeared
  in `evals/README.md` from other runners. The honest fix is per-(file, flag)
  documentation; whether that is worth more than the blind spot is the open question, and
  the limitation is already stated beside the check.

## [1.35.0] - 2026-09-07

**Front door checked:** sota-skill-security · trust boundary · change surface · GATE-ABSORPTION

**Minor** — a new skill (42), and a new eval instrument. A new skill is sufficient for a
minor and always has been.

Two external assessments proposed ~13 additions. **Four landed. Five were refuted by
measurement or by reading the tree — including the reframing I proposed myself.**

### Added

- **`sota-skill-security`** — the supply chain of things that tell an agent what to do.
  The one item both assessments got right and the only gap that survived two concept
  sweeps at zero hits. A skill is executable influence: it does not run in the
  interpreter, it runs in the model, and **a malicious dependency has to be invoked while
  a malicious skill only has to be loaded**. Three rules files: provenance and
  installation (pin it, review the *closure* not the entry point, a description change is
  a behaviour change); the trust boundary and capability (**anything a PR can edit is
  inside it** — instructions from an untrusted repo are data, not orders); authoring and
  auditing (a skill is a control, and *confidently wrong* is the dangerous failure).
  - **It caught its own author on the first gate run.** The initial description was
    **1308 characters against the 1024 cap** — a skill that would have been installed,
    correct, and silently never loaded, which is exactly what its own `rules/03` §1 warns
    about. Trimmed to 984.

- **`evals/run-routing-recall.py` + 10 gold-set cases** — routing **recall and precision**
  over a set, where `run-desc-routing.py` only scores a pick-one decision. `--selftest`
  carries five scorer references including the discriminating one (a *pick-everything*
  answer must lose precision, or the runner adds nothing over top-1) and was watched to
  fail on a mutated scorer. Guards abort on an empty catalogue, an empty case file, and
  **a gold set naming a skill that does not exist** — which would cap recall below 1.0
  forever and read as a routing failure rather than a case-authoring bug.

- **`sota-docs-workflow/rules/03` §5a — the change surface is a design decision.** No
  drive-by reformats (they destroy the diff *and* misattribute `git blame` permanently), a
  stated generated-file policy with generated lines in their own commit, decomposition
  **by reviewability rather than line count**, migrations sequenced so every commit is
  rollback-safe, revert-vs-fix-forward by blast radius, and keeping mechanical moves
  separate so `git bisect` does not land on a 4,000-line reformat.

- **`sota-architecture/rules/06` §6 — flag rollout meets version skew.** A progressive
  rollout means two app versions run at once, so the **contract step must be ordered after
  flag removal**. Contracting while the old path is still reachable is the outage that
  presents as *"the rollback made it worse"*.

- **Superpowers added to the competitor manifest** at pinned SHA `b36e0829` — named by
  both assessments as the methodological competitor, and the one repo our head-to-head
  instrument was not pointed at. Licence (MIT) and all four file paths read from the
  GitHub API, not from the assessment, with a caveat recorded in the manifest that it is
  process guidance measured by a domain-practice yardstick.

### Measured

- **Routing recall 0.975, precision 0.569, over-selected in 8 of 10 cases**
  ([ROUTING-RECALL](evals/results/2026-09-06/ROUTING-RECALL.md)). **This refutes the
  reframing it was built to test.** Both assessments called MCP security, agent
  engineering and browser verification missing skills; I argued they were *unreachable*
  rather than absent; the second assessment adopted that and built a framework on it.
  All three shapes route at **recall 1.00**. The knowledge is found every time. Against
  gold sets **transcribed from the router's own composition rules**, precision is 0.45 —
  the model loads roughly twice what the router says to load — while two single-skill
  controls score 1.00/1.00.

- **ROADMAP 32 closed as measured-and-underpowered**
  ([GATE-ABSORPTION](evals/results/2026-09-06/GATE-ABSORPTION.md)). `with` 1.00,
  `with+pad` 0.97, `pad-nogate` 0.93 → **GATE-ABSORPTION +0.04**. The registered H1
  needed ≥ +0.05, so **H1 is refuted by my own rule**; H0's null band was ±0.03, so H0 is
  unsupported too. The result lands in the dead zone between the two bands: underpowered,
  not null. The registered ceiling risk did not materialise, and item 25 replicated
  (−0.01 → −0.03).

### Rejected, with the evidence

- **MCP security, agent engineering and browser verification as new skills** — refuted by
  the routing measurement above.
- **A `routing contract` YAML in skill frontmatter** — would be **inert**. Frontmatter is
  two fields and only the description auto-loads; `covers:`/`requires:` would be read by
  nothing while looking exactly like a routing system, and invariant 4 would pass it. The
  router already carries **21 hand-written composition rules**.
- **Incident response** — `sota-detection-engineering/rules/06` and
  `sota-privacy-compliance/rules/06` both exist and the router routes to them by name.
- **Scala/Elixir/IDP depth** — `README.md` already declares these out of scope.
- **Flag lifecycle — my own recommendation, and it was wrong.** I reported `flag
  debt|flag lifecycle` at 0 files and proposed adding it; `rules/06` §6 already requires
  an owner, an **expiry ticket at creation**, removal within weeks, and names the 2^N
  stale-flag anti-pattern. I searched for the words, not the concept — the same mistake I
  had just corrected in someone else.

## [1.34.0] - 2026-09-06

**Front door checked:** rules/15 · rules/09 · unconsumable · termination message

**Minor** — two new rules files are surfaces a reader can load and cite. Everything in
them already existed or arrived with this release; nothing was invented to fill them.

A field brief from a live container-pipeline incident — six proposals, all six landed,
**two of them in a different form than proposed** because reading the neighbouring text
showed the proposal was aimed at the wrong file or would have loosened an existing gate.

### Added

- **`sota-code-security/rules/15-instruments-and-guards.md`** — `rules/12` split at the
  seam its own subtitle named (*"the mutation probe, **and** the things that do the
  checking"*). `rules/12` keeps proving a **specific control** works (§1, §1a, §1b) at
  **211** lines; `rules/15` takes **your instrument is a control** (§2) and **the guard
  that is an instance of what it guards** (§3) at **355**. Section numbers are unchanged
  across the move, so a citation that named a section still names the same content.

- **`sota-devsecops/rules/09-gates-that-hold.md`** — `rules/05` §5.6 had reached **284**
  lines, over half that file, and took two more subsections in this release. The scanners
  stay in `rules/05` (**226**); whether any of it actually *gates* is now its own file
  (**343**), with the five subsections numbered §1–§5 for the first time.

- **A gate only gates if failing it makes the artifact unconsumable** (`rules/09` §3). If
  the build publishes to an identifier a deploy watcher can already consume, the gates
  after that publish decide only whether the artifact is *annotated*. The deploy then
  fails at the consumer with a **verification** error whose cause is three steps upstream
  in a different subsystem — so a vulnerability failure reliably sends the operator to the
  signing path. Build to a candidate, promote after the last gate, and make the candidate
  **structurally unable to match the watcher's allow-pattern**: *"it is a different
  string"* is not a control. Includes the state-advance trap that makes it
  self-amplifying — a "last built commit" marker behind the failing gate never advances,
  so the scheduler republishes forever.

- **A verdict that lives only in a garbage-collected log does not exist** (`rules/09` §4).
  A step that separates *policy violation* from *infrastructure error* and `echo`s the
  distinction has produced a diagnostic with the lifetime of a pod; what survives is
  `Error (exit code 1)`. **Corrected against the Kubernetes docs before landing:** the
  brief cites the 4096-byte kubelet cap on a **termination message**, but the total across
  containers is **12KiB divided equally** — a 12-container pod gets **1024 bytes each**, and
  CI pods have init containers and sidecars. Budget from the container count. `FallbackToLogsOnError`
  (2048 bytes or 80 lines, whichever is smaller) is named as the cheaper option when you
  do not control the step's script.

- **A step copied between sibling pipelines rebinds to names the destination may not
  declare** (`sota-devsecops/rules/01` §1.11a). Late-bound references resolve at
  submission, not by the parser, so a copied block passes YAML validation, schema
  validation, lint and pre-commit while being unrunnable. §1.11 proves a pipeline has
  *ever* run; this is the case where N siblings exist and only one was proven.

- **A consumer at the end of a pipe succeeds on empty input**
  (`sota-shell-scripting/rules/01`). `pipefail` fixes the status; this is about the value
  you keep. A guard hashing a failed `skopeo inspect` got `e3b0c44…` — the hash of
  nothing — non-empty, well-formed, never equal to a real digest, so it refused **every**
  publish. Carries the brief's own warning: **do not pattern-match the fix**, because the
  same guard with no pipe is correct as written and a grep sweep would "fix" it.

### Changed

- **`sota-code-security/rules/15` §2.2 — a classifier's "everything else" branch must be
  proven reachable.** Landed as an extension rather than the new section the brief
  proposed: §2.2 already required a negative control for anything that classifies. What
  was genuinely missing is *order* and *default* — **test the definitive signal first**
  (an infrastructure error is conclusive; a finding-shaped pattern is a heuristic), and
  **default the unknown case to the safe classification**, because *"I could not tell"*
  must never render as *"it was your code"*.

- **`sota-code-security/rules/11` §2.1 — a rate over a window longer than the phenomenon.**
  Also landed as a cross-reference rather than a new rule: `sota-observability` rules/02 §4
  already says averages hide what matters. The gap was **reachability** — that rule is
  about *designing* a metric, and nothing routes a debugger to it. ~4.2 errors/s over an
  hour concealed 14,977 in one minute, and a correct fix was retracted on the strength of
  the mean. The per-event cost is the discriminator: **12 µs and 12 s are different
  mechanisms with identical counts.**

### Fixed

- **`README.md` had a link whose text and target disagreed** — it read `rules/15 §2.2a`
  and pointed at `12-verifying-the-verifier.md`. Invariant 8 checks a link *resolves*, not
  that it resolves to what the text claims, so it passed.

### What the split cost, measured

Recorded because *"can we split reliably?"* was the question, and the answer has a number.
**16 `§` references needed repointing; invariant 18 caught 10** — the other **6 resolved
fail-open** against a co-named skill, exactly the residual documented after the
`sota/rules/01` split. Worse, **22 bare `rules/12` pointers carry no section at all**, so
no gate can see them; each was walked by hand and decided on meaning (probe half vs
instrument half), and 15 of them moved. The gate makes the split *safe*; it does not make
it *automatic*.

## [1.33.1] - 2026-09-06

**Front door checked:** invariant 24 · invariant 25 · ratchet

**Patch** — two CI invariants and doc corrections, all inside surfaces that already
exist. A CI invariant on its own has shipped in a patch four times (8, 9, 11, 21), and a
reader of these notes gains nothing new to run.

Both invariants came from items opened the previous day, and in both the work was
**deciding what the check should be** rather than writing it — each item's own proposed
design turned out to be wrong.

### Added

- **Invariant 24 — `AGENTS.md` stays under its own 200-line cap, and keeps its symlinks.**
  That file says *"keep it under 200"* because `CLAUDE.md` and `GEMINI.md` symlink to it,
  so it loads into **every** session — and it had broken its own rule **twice in two
  days** (201, then 202), each time from adding an invariant's own table row, each time
  caught only because someone ran `awk` by hand.
  - **ROADMAP 35 asked for a decision before a check, and that was the right order:
    gating a *target* is a category error.** It is a **cap** — the file already stated it
    as an imperative with a named escape (move detail to `CONTRIBUTING.md` behind a
    pointer), which is exactly invariant 1's shape. What changed was the sentence calling
    it *"ungated, and a different constraint from invariant 1"*, not the number.
  - **It checks the premise, not just the arithmetic.** The 200 only *matters* while the
    symlinks make the file load every session, so the gate asserts `CLAUDE.md`/`GEMINI.md`
    are still mode `120000` and still point at `AGENTS.md` — `sota-code-security` rules/10
    §1's **proxy question**, aimed at one of our own gates. A cap enforced on a file
    nobody loads passes forever while its reason has quietly gone.
  - Watched to fail on four shapes: exactly 200, 202, a copy in place of a symlink, and a
    symlink re-pointed elsewhere. Then it **caught its own author on the first run** —
    adding rows 24 and 25 to the invariant table took the file to 201.

- **Invariant 25 — undocumented eval flags may not grow.** A **ratchet**, not a rule.
  `--no-gate-arm` shipped in v1.33.0 documented in the root README's index and in the
  runner's `--help`, and **not** in `evals/README.md` — the file a person opens to learn
  what an instrument measures. Invariant 14 cannot catch that: it accepts a declared term
  in `README.md` **or** `docs/INDEX.md`, and either satisfies it.
  - **Two designs were rejected, and both were in ROADMAP 36's own text.** The strict form
    (*every flag is documented*) was **measured first**: it opens red on **27** pre-existing
    (file, flag) pairs, nearly all generic plumbing — `--json`, `--report`, `--build-model`,
    `--judge-model`. A gate that opens red on 27 things it does not care about is one
    someone disables, which [CONVENTIONS-LEDGER](docs/CONVENTIONS-LEDGER.md) calls strictly
    worse than no gate. The "cheaper alternative" — adding `evals/README.md` to invariant
    14's resolution set — would have made 14 **looser**, since a third accepted location
    weakens it; it would have damaged the gate it was meant to reinforce.
  - **It fails closed on an empty scan.** A drifted regex would otherwise find zero flags,
    compare 0 against the pin, and pass on every possible input — the defect
    `sota-code-security` rules/11 **§2.2a** describes, which this repo added four days ago,
    applied here to its own newest gate.
  - Watched to fail on three shapes: a newly added undocumented flag, a *slack* ratchet (a
    flag documented without lowering the pin), and the empty scan. **32 probes, 20 of 25.**
  - **It then caught its own author, in a way worth recording.** "Documented" means the
    flag string appears *somewhere* in `evals/README.md` — so writing `--some-flag` inside
    a sentence explaining that it is undocumented satisfies it. The first draft of that
    file's new contributor section listed five example flags, and the ratchet reported the
    count falling **27 → 10**: seventeen flags banked as documented on the strength of a
    sentence saying they were not. `sota-testing` rules/06 **§6.3** — an assertion keyed on
    something that is true but is not evidence. **The slack direction failing is what
    surfaced it**, which is the argument for gating both directions of a ratchet. The
    limitation is now stated beside the check (`rules/12` §2.1, *state the traversed path
    beside the probe — or beside the scan*).

- **`evals/README.md` now tells a contributor what invariant 25 expects**, in *Extending* —
  a flag added to a runner has to end up in that file, and *why* it is a ratchet rather
  than a rule. The gate exists to push documentation into that file, so that file had to
  say so.

- **A harness convention for the FALSE PASS above**, in *Harness conventions*: a verdict
  computed through a pipe can contradict the buffer it read, reading that contradiction
  localises the fault to the comparison, and de-piping an **anchored** assertion into a
  flat glob loosens it rather than fixing it.

### Fixed

- **The negative-control harness could accuse a healthy gate.** CI reported probe 4 as a
  **FALSE PASS** on 2026-09-06 while the probe's *own* diagnostic line printed the expected
  string — `got: OVER 1024 (1661 chars): skills/sota-golang/SKILL.md` — read out of the
  same variable the verdict had just tested. Both cannot be true of the same content, so
  the fault was in the comparison, not the gate.
  - The verdict was `printf '%s\n' "$GATE_OUT" | grep -qF -- "$want"`. `grep -q` exits the
    instant it matches, which is the shape `check-invariants.sh`'s own header warns about
    (*"never `grep -m 1`/`head` on a pipe in here"*) and the likeliest cause under
    `pipefail` — but **the precise signal is not established and is not claimed**: it
    appeared only on the CI runner, the same commit passed **29/29** on macOS bash 3.2, and
    a 400 KB synthetic reproduction would not trigger it locally.
  - **The fix does not depend on knowing which.** Both verdicts now match in pure bash with
    no pipe, no subprocess and no grep dialect, so they can only fail on content. Part B's
    assertion is **anchored** (the expected text must appear on a `FAIL` line, not merely
    somewhere after one), so it iterates lines via a here-doc rather than flattening to a
    glob — a flat glob would have accepted a match on a different line, which loosens a
    probe instead of fixing it. Both matchers were then shown to accept a correct
    expectation *and reject a wrong one*.
  - The lesson is the uncomfortable one: **this is the harness that exists to prove our
    gates can fail, and it was itself capable of reporting a wrong answer** — the exact
    class `sota-code-security` rules/12 §2 puts on the instrument. It had run green 6 times
    before this.

- **`AGENTS.md` was 201 lines against its own "keep it under 200" rule** — it symlinks to
  `CLAUDE.md`/`GEMINI.md` and loads into every session, which is why the rule exists. It
  crossed the line twice in two days (invariant 22's table row, then invariant 23's) and
  nothing reported it either time. Reflowed to **199**; the rule now names the command to
  re-check with. Recorded as **ROADMAP 35**, because a target nothing checks is the shape
  this repo gates — the open question is whether 200 is a cap or a target.
- **`AGENTS.md`'s denominator example read `ok (261 rules files)`** against a tree with
  **262**. It is sample output in the one paragraph that tells you to print your
  denominator.
- **`evals/README.md` never got `--no-gate-arm`.** It shipped in v1.33.0 documented in the
  root README's index and in the runner's `--help`, but not in the harness's own front
  door — and that file's ROADMAP-25 entry still closed with *"nobody has run it with the
  gate off"*. Invariant 14 resolves front-door terms against `README.md`/`docs/INDEX.md`
  only, so it could not catch this. Recorded as **ROADMAP 36**.
- The runner's docstring now names all four arms, and
  [COMPLETENESS-PADDING](evals/results/2026-09-01/COMPLETENESS-PADDING.md) carries a dated
  update pointing at the pre-registration — **superseded, not edited**: its −0.01 stands as
  published, and its "nobody has run it with the gate off" is still true.

## [1.33.0] - 2026-09-06

**Front door checked:** invariant 23 · link reference · GATE-ABSORPTION

**Minor** — the release notes give a reader something new to run
([RELEASING.md](RELEASING.md) "Minor or patch?" — *"ask whether a
reader of the release notes gains something new to run"*): a fourth completeness arm with its own
reported metric, answering a question the harness previously could not ask.

Everything here came from **re-testing every open roadmap item's trigger instead of the
item**, which is the lesson the 2026-09-01 closures taught. It paid out three more
times in a single reading of one table — two rows asked for work already done, and one
declared a flag that did not exist.

### Added

- **Invariant 23 — every CHANGELOG version heading has its own link reference.** Sibling
  of invariant 21, failing independently of it: 21 asks whether a shipped version has a
  git *tag*, nothing asked whether it has a *ref*, and **four consecutive releases**
  (1.31.2, 1.32.0, 1.32.1, 1.32.2) shipped without one. Found by hand at the v1.32.3 cut
  and backfilled there; now gated.
  - **Why it was silent.** A `## [1.32.0]` heading with no `[1.32.0]:` reference is *not*
    a broken link — Markdown renders it as literal text, brackets and all. No error, no
    404, nothing to click. Invariant 8 cannot see it either: 8 resolves `[text](file.md)`
    inline links to files on disk, and this is a reference-style link to an external URL.
  - **It compares sets, never counts.** At the moment it was written, all three CHANGELOG
    files' heading and ref counts matched *exactly* — a count check would have been just
    as green with two versions swapped.
  - **Both directions.** An orphan ref (one whose `## [X.Y.Z]` heading lives in another
    file) is what archiving produces when a section moves without its ref: one edit, two
    defects, no count change. [RELEASING.md](RELEASING.md) §1 requires them to move
    together, and now something checks it.
  - It also requires each ref to end in `/releases/tag/v<its own version>`, since all
    **75** already follow that single form, so a deviation is a typo rather than a style.
  - **Watched to fail on all four shapes** before being wired in — a missing ref, an
    orphan ref, a ref pointing at the previous release's tag, and the same defect inside
    `docs/CHANGELOG-archive.md` rather than the root file. Probe 23 added: **29 probes,
    18 of 23 invariants covered.**

- **`run-completeness.py --no-gate-arm` — a fourth arm that drops `BUILD_WORKFLOW`.**
  ROADMAP 32 asks a question the harness could not previously pose. Item 25 padded the
  with-library arm with 400 lines of competing guidance and read **−0.01** — but that arm
  *also* ran step 4, the terminal self-audit re-read whose entire job is recovering the
  cross-cutting concerns a model drops under a long, dense task. So −0.01 supports *"lean
  **plus a terminal re-read** is robust to competing context"* and says nothing about
  context length alone.
  - The new arm carries the padding **without** the gate, and the runner reports
    **`GATE-ABSORPTION`** = `mean(with+pad) − mean(pad-nogate)`: what the terminal re-read
    recovers under competing context.
  - **Two guards, both watched to fail.** It refuses `--no-gate-arm` without
    `--pad-rules` (that would measure the gate alone, not the gate against competing
    context), and refuses if the ablation leaves the prompt byte-identical to the gated
    arm — the house rule that *an ablation arm must actually differ from its baseline*,
    already enforced in `run-prompt-independence.py`. The second probe **did not land its
    own mutation on the first attempt** and reported a false pass; the assertion under
    test is what caught it.
  - **Not run.** The prediction is pre-registered with numbers, a falsification condition
    and four ways the experiment could measure nothing, in
    [evals/results/2026-09-06/PRE-REGISTRATION.md](evals/results/2026-09-06/PRE-REGISTRATION.md).
    The 28 build + 28 judge calls are live spend and are the operator's to authorise.

- **Three rows in [docs/CONVENTIONS-LEDGER.md](docs/CONVENTIONS-LEDGER.md)** for
  invariants **20, 21 and 23** — each with its incident, its silence argument, the
  mechanical-checkability case, and **what the gate does not check**. Written from
  `check-invariants.sh` rather than from the CHANGELOG.

### Fixed

- **The CONVENTIONS-LEDGER's gate tables had skipped invariants 20 and 21.** 22's row
  landed 2026-09-05 and theirs did not exist. This is the **fourth** time that file has
  drifted from the checks it describes, and invariant 17 cannot catch it — 17 checks
  stated counts and 1..N enumerations in `AGENTS.md`/`CONTRIBUTING.md`, not whether the
  ledger's *tables* are complete. Deliberately left as a habit rather than a gate, on the
  ledger's own three filters: "is this table complete" is not mechanically checkable
  without first deciding what counts as a row.

- **Three stale roadmap triggers, corrected in place.**
  - **Item 1** asked for a salience piece **written five days earlier** —
    [docs/WHY-SALIENCE-LASTS.md](docs/WHY-SALIENCE-LASTS.md), 2026-09-01, and linked from
    both `README.md` and `docs/INDEX.md`. What is actually left of item 1 is the demo and
    the listing channels.
  - **Item 32** said *"nothing — the flag exists"*. `--pad-rules` existed; the
    `BUILD_WORKFLOW` ablation did not, and had to be written before the item could move.
  - **Item 12** carried a rules-file count of 261 against a tree with **262**.
  - Re-tested and genuinely **not** met: item 5 (`check-freshness.sh` — `LAST-VERIFIED`
    2026-07-08, due ~2027-01-08), item 12's sixth-verification-file trigger (**5** in the
    tree: `rules/10`–`14`), and the deferred spanchain row, whose own entry says to read
    its trigger ledger rather than re-derive the search.

- **A memory-link `[[wiki-link]]` in `docs/ADOPTION-LOG.md`** that resolved nowhere for a
  reader. A repo-wide sweep confirms it was the only one — every other `[[` in the tree is
  bash, TOML or a regex character class.

### Changed

- **ROADMAP items 33 and 34 closed the day after they were opened**, and the priorities
  table now leads with what is actually blocked: item 32 needs only the spend, and item 1
  needs a person. The table's own preamble now says the table is the thing most likely to
  be stale, because nothing gates prose.

## [1.32.3] - 2026-09-05

**Front door checked:** empty comparand · mutate the expectation · fan-out · the scoped gate is not the gate · invariant 22

**Patch** — rule text inside surfaces that already exist, plus one CI invariant on
its own (which has shipped in a patch four times now: 8, 9, 11, 21). Nothing new to run.

A field brief from one engineering session on a static-analysis pipeline, filed under
the bad-guidance/skill-request template. Six of its seven items landed; the seventh was
already covered and is recorded as a generalization rather than a new section. Every
duplicate claim was checked against the file it named, and the one falsifiable
third-party claim was **reproduced before adoption** — which is where its stated
mechanism turned out to be wrong.

### Added

- **`sota-code-security` rules/10 §2.16 — the aggregate that masks the detection.** A
  positive control summed every list field on an analysis result and asserted the total
  was non-zero. The result type mixes the engine's *derived inputs* with its *findings*,
  and preprocessing populates the inputs on any real graph — so the assertion stays green
  whether or not detection works. Measured across 11 languages: `breaks` empty on **all
  nine** cells where that engine was registered as controlled, and **12 of 35 controls
  green on a result containing zero detections**. The discriminating question is *which
  attribute would be empty if the detector were deleted but its preprocessing left
  intact?* — assert on that one.
  - Neither neighbour catches it. `rules/11` §2.2 is the **denominator**, and here the
    denominator was healthy; `rules/12` §2.1's "instrument that cannot fail" is a scorer
    returning a plausible number whatever it is handed, and this one *could* fail, just
    never for the reason it existed.
  - **The second-order half is the more valuable one**: when the honest assertion turns
    green cells red with no evidence of a regression, that manufactures a red build out of
    a *measurement gap*. Assert on what the engine does produce and give the empty field
    its own test recording the measured fact, so it has an owner.
  - Home moved from the brief's `rules/11`: the line budget decided it (`rules/11` reached
    499/500 with it, leaving no room for the checklist bullet the section needs).

- **`sota-code-security` rules/11 §2.2a — the empty comparand.** §2.2 asks how many items
  a check *examined*; this asks how many were in the set it *compared against*. A
  differential oracle computes `lost = baseline - current`, so an empty baseline makes
  `lost` empty for **every** possible input, forever — while the run examines a full,
  healthy current set and reports a large, truthful denominator. Four of twelve committed
  reference sets were in that state. §2.2's remedy provably does not fire: **the zero is
  on the other operand**.
  - Genuinely absent — **two independent concept sweeps** across all of `skills/` returned
    **0 hits**.
  - Beyond the brief: the check must assert the reference **loaded**, not merely that it
    is non-empty — a baseline file that failed to parse yields the same empty set through
    a different door. And `gained` keeps working when the baseline is empty, which is why
    the file keeps earning its place while half the oracle is dead.
  - Applied where this repo would meet it: `sota-testing` rules/06 §6.3's
    mutation-survivor baseline is exactly this shape.

- **`sota-testing` rules/06 §6.3 — mutate the EXPECTATION, not the code.** A fourth
  mutation probe, and the cheapest: leave the SUT and the fixture alone and point one
  assertion at a plausible **wrong expected value**. Still passing means the assertion is
  keyed to something true that is not evidence. Three controls asserted an engine found
  the `system` call planted in a fixture; re-pointed at `popen`, two failed correctly and
  one passed.
  - **The fan-out corollary is the sharpest part** and had no equivalent anywhere
    (`grep -rn 'fan-out' skills/` → 0 hits): the engine groups sinks and emits one record
    per *name in the group*, so the sink name is not evidence about the code and an
    assertion keyed on it is satisfied by two names the target never mentions. An
    assertion keyed on a value the producer fans out **can never discriminate** — look for
    that before weakening the test.
  - Distinct from `rules/12` §1 (mutates the control), §2.1 (probe mutates a *fixture*
    rather than the runtime artifact), and `sota-testing` rules/02 §2.7's tautological
    test (expected value *computed* by the same logic — here it is a literal and the
    **key** is what fails). Home moved from the brief's first preference: `rules/12` was
    at 494/500 and could not hold a section, so it carries a three-line pointer instead.

- **`sota-devsecops` rules/05 §5.6 — the scoped gate is not the gate.** The inverse of
  everything already in §5.6: there the gate's scope drifts *away* from code that still
  exists; here the code is fully in scope, the gate sees it, and the **human's local
  re-run uses a different invocation** — which is what makes people report "all gates
  clean" before pushing. Reproduce the gate's *exact* invocation (flags and file
  selection) out of the hook or workflow config, or better, run the hook manager itself.

- **`sota-testing` rules/02 §2.7 — the universally-named test over one item.** A test
  called `test_every_tracked_phase_is_also_reported` looping a single-element literal.
  `sota-code-security` rules/14 §7 falsifies this shape in *prose*; here it is worse,
  because the test executes and passes, so it reads as the enforcement of the claim its
  name makes. Read the loop, not the name.

- **Invariant 22 — no `- [ ]` checklist bullet stranded inside a code fence** (skill files
  only). Found while checking one of the brief's duplicate claims, in the file that
  teaches this class: PR #226 (2026-08-16) inserted two audit-checklist bullets at the
  wrong offset, into the fenced example in `sota-code-security` rules/11 §2.2. They
  rendered as gate output for three weeks and never reached the checklist an auditor
  reads — and one of them was the item nearest to the empty-comparand class the same brief
  proposed.
  - **Nothing was close enough to catch it.** Invariant 2 already tracks fence state, but
    only to stop a fenced *heading* satisfying "ends with an Audit checklist"; invariant 10
    checks a rules file is *indexed*, not that its contents reached anyone; the line count
    never moved and the diff line is indistinguishable from another line of the sample.
  - All three [CONVENTIONS-LEDGER](docs/CONVENTIONS-LEDGER.md) filters pass. **Watched to
    fail** on a re-injection of the original defect and to pass once fixed, before being
    wired in. Sweep found exactly **2 instances across 303 skill files** — both from that
    one commit. **28 probes**, 17 of 22 invariants covered.
  - Scope stops at skill files: prose files legitimately show checklist syntax in samples.

### Changed

- **`sota-code-security` rules/12 §2.1 — the blind-spot sentence now covers scans, not just
  probes.** It already said *"state the traversed path in one line beside the probe"*; it
  now reads *"beside the probe — or beside the scan"* and carries a second worked example:
  *"reads the first positional arg, so keyword callers are invisible"*. That is the brief's
  observation (b), recorded in [ADOPTION-LOG](docs/ADOPTION-LOG.md) as **adopted as a
  generalization** rather than as a new section — plain `adopted` would have implied a
  section that does not exist, and `rejected: already covered` would have lost a reusable
  tell that this repo's own AST invariants are exposed to.

### Fixed

- **Two audit-checklist bullets restored to the checklist** in `sota-code-security`
  rules/11 — the defect invariant 22 now gates. Neither had ever appeared in the `## Audit
  checklist` an auditor reads.

- **Two stale front-door claims, both invisible to the gates that exist.**
  - `README.md` said *"Fourteen invariants enforce this"* while the script ran 21.
    **Invariant 17 could not see it**: it matches digits, and this count was spelled as a
    word. Now "Twenty-two", with the coverage list extended to name `§`-reference
    resolution, the known-bad requirement, CHANGELOG tagging and invariant 22.
  - `docs/INDEX.md` still said invariant 18's *"scope is `skills/` only"* after **v1.32.2
    widened it** to the live tooling (`evals/*.py`, `evals/README.md`, `scripts/*.sh`,
    `scripts/lib/*.py`) — the release that widened it did not update the front door that
    described it.

### Corrected

- **The brief's mypy mechanism, corrected before adoption.** It states that
  `--follow-imports=silent` on a changed-file subset *"infers differently"* from a
  whole-package run. Reproduced here at **mypy 2.3.1** on a minimal package, both
  invocations against one tree at one moment: `mypy src/pkg/` → **exit 1**;
  `mypy --ignore-missing-imports --no-error-summary --follow-imports=silent src/pkg/a.py`
  → **exit 0**. What reproduces is **error suppression for modules outside the named file
  set**, and in the *opposite* direction to the one the brief reports. The rule therefore
  ships **direction-agnostic** — neither verdict is authoritative for the other — and names
  three independent levers (file selection, flags, a stale `.mypy_cache`) rather than
  asserting a single mypy inference claim we could not isolate. This is why the item is
  logged as **adopted with a correction**.

## [1.32.2] - 2026-09-04

**Front door checked:** never tagged · dead runner

**Patch** — a CI invariant on its own has shipped in a patch three times (8, 9, 11); the
rest is a scope widening and two defect fixes.

Everything here was found by asking *"what does this session's own work suggest nothing is
checking?"* — not by re-reading the library.

### Added

- **Invariant 21 — every CHANGELOG version below the top entry has a git tag.** Invariant 5
  checks a tag is never *ahead* of `VERSION`; **nothing checked the other direction, and it
  had already failed twice.** `v1.30.0` (2026-08-29) and `v1.31.2` (2026-09-02) each had a
  CHANGELOG section, a `VERSION` bump and a merge to `main` — and no tag and no release.
  A version that ships in the CHANGELOG and is **never tagged** is unreachable: `git tag -l`
  skips it and its notes live only in a file nobody clones for that. Both have now been
  tagged at the commits where `VERSION` became them (`915df64c`, `02cb41e2`) and published.
  - The **top entry is exempt** — the tag is pushed *after* the squash-merge
    ([RELEASING.md](RELEASING.md) §4 forbids chaining them), so on a release PR the current
    version legitimately has no tag yet.
  - **Skips with a note** on a checkout with no tags at all (shallow CI clones do not fetch
    them) rather than failing every version at once: a gate that cannot see its evidence
    must say so, not invent a verdict.
  - Probed, and **the probe was wrong first**: it inserted the untagged version *above* the
    top entry, so invariant 5 complained instead and the harness reported **FALSE PASS**
    rather than crediting the catch. That is the harness's entire purpose. **27 probes**,
    16 of 21 invariants covered.

### Changed

- **Invariant 18 now scans the tooling, not just skill prose.** `§` references in `evals/`
  and `scripts/` were never checked — **27 of them live there, and one had already rotted**:
  `check-invariants.sh` cited `sota-code-security` rules/10 §2.12 for the argument that a
  documented convention must become a gate, and that content had moved to `rules/14` §3.
  The citation carrying the weight was the one that broke.
  - Scope is the **live tooling** (runners, scripts, `evals/README.md`) and deliberately
    **not** `evals/results/**`, which is superseded-not-edited history.
  - Two corrections while widening. A git pathspec **matches across `/`**, so `evals/*.md`
    dragged in every dated write-up — fixed with `:(glob)`. And outside `skills/` there is
    no containing skill, so a bare `rules/NN §X` is **skipped rather than guessed**: fail
    open, because a gate that false-positives on correct prose gets disabled
    ([CONVENTIONS-LEDGER](docs/CONVENTIONS-LEDGER.md)).

### Fixed

- **`run-adjudication.py` was a dead runner, and had been for six days.** Its ablation
  target ("Adversarial verification") moved to `sota/rules/03-audit-findings.md` when
  `rules/01` split in v1.30.0, while the runner still read `rules/01` — so its guard
  aborted every ablated run. **The guard was right**: it refused rather than returning an
  unablated corpus and reporting a fake `+0.00`. Now reads both files; ablation verified
  live (6,649 chars removed, section title gone). Found by the widened invariant 18, via
  the stale `§6` in its own docstring.
- **`smoke-runners.py` prints why a runner exited.** It rendered every `SystemExit` as
  `ok    (guard fired or usage printed)` — the same string for "needs arguments" and for
  "this guard fires on every run", which is how the dead runner above stayed invisible
  through a harness built to find dead runners. It still cannot *fail* on one (a usage exit
  is legitimate), so the least it can do is show what the guard said.
- **ROADMAP, AGENTS.md, CONTRIBUTING.md and CONVENTIONS-LEDGER** re-counted to 21 checks /
  27 probes; `check-invariants.sh`'s own summary line said `20 checks` and is not scanned by
  invariant 17, so it was corrected by hand.

## [1.32.1] - 2026-09-03

**Front door checked:** GONE · blind to the treatment

**Patch** — both changes are `§§` inside rules files that already exist; nothing new to run.
Two open items closed, one from a standing brief and one from this session's own near-miss.

### Added

- **`sota-code-security` rules/12 §2.2a — the fourth watcher state, `GONE`.** §2.2a already
  carried DONE / NOT-DONE / UNKNOWN; the missing row is **the target no longer exists** — a
  job reaped, a pod GC'd, a file rotated away — which is **terminal and knowable, not
  unknown**. Collapsing it into UNKNOWN trades a false success for a false alarm and the
  watch never ends. Distinguish them at the source (**a `NotFound` is not a transport
  error**) and, when the target is gone, fail over to its **parent** — the CronJob's
  `lastSuccessfulTime`, the deployment, the directory — which outlives the instance and
  carries the outcome. **`GONE` is the row people delete while fixing the other bug**:
  field-reported, a rewrite made fail-closed replaced an explicit "no longer exists" branch
  with the unknown-counter, which then reported *"cannot read for 20min — probe is blind"*
  about a job that had simply been garbage-collected while the API answered in the same
  second. The blindness signal worked exactly as designed and was still wrong, because the
  state model was missing a row.
  - Corrects the status of the 2026-08-16b brief in the ledger: it was recorded as
    unapplied, but §2.2a had carried its substance since. **Only the fourth state was
    missing** — and the probe that found that (`grep -rn GONE`) is why the narrow gap was
    visible at all.
- **`sota-llm-engineering` rules/01 §8 — prove the instrument can see the change before you
  run it.** An eval whose treated arm never reads the modified file returns `+0.00`, and
  **that null is structural, not a result** — an arm **blind to the treatment** cannot
  produce a finding, and its `+0.00` looks exactly like a real one. Name the
  file the treatment lives in and show the runner reads it before spending. From this
  session's own near-miss: a **router-body** change was nearly measured with a runner that
  builds its catalogue from frontmatter `description`s and never loads the body; its
  `+0.00` would have been indistinguishable from the real `±0.000` the correct runner then
  produced. Distinct from the convention already in `evals/README.md` — *an arm that cannot
  see the treatment is a free negative control* — which is the same fact used
  **deliberately**; the difference is entirely whether you chose it.

### Changed

- **ROADMAP re-counted from the tree (row 13, item 12, and the maintenance stamp).** The
  **router is no longer the library's tightest file** — offloading its library map took it
  499 → **398** — and `sota-code-security/rules/12` inherits the cap watch at **494/500**,
  six lines of slack, with its reactive-split seam already visible (probing a control §1–1b
  · judging an instrument §2 · the guard that is an instance of what it guards §3). Prior
  counts kept as history rather than edited.

### Verified, and reported as a null

- **Swept `scripts/` and `evals/` for the shape this session kept hitting** — a failure path
  swallowed so that success and failure look identical. 63 candidate sites by two
  independent methods (`|| true` in shell, broad `except` in Python); every hit inspected.
  **No new defects.** `install.sh`'s three `setup_* || true` calls are deliberate and each
  function reports its own failure (2026-07-10 audit Q-MED-4), and `_elapsed.py`'s five
  broad excepts are the documented fail-open of a module that states it *"reports, it never
  decides"* and is not a measuring instrument. The one real instance was fixed in v1.32.0
  (`check-negative-controls.sh`). Recorded because a null from a search someone else would
  otherwise repeat is worth as much as a finding — and because an unstated absence claim is
  indistinguishable from a search never run.

## [1.32.0] - 2026-09-03

**Front door checked:** library map · NOMATCH

**Minor**, by [RELEASING.md](RELEASING.md)'s test — `skills/sota/rules/04-library-map.md`
is a new surface a reader can load, the same reason the `rules/03` split made v1.30.0 a
minor. Also carries two changes merged after v1.31.2 without a version of their own.

### Added

- **`sota-shell-scripting` rules/01 §3a — zsh is not bash, and the third deviation is
  silent.** From a field brief by a session whose documentation-staleness sweep returned
  "no matches found" four times and read as *nothing is stale*. zsh's `NOMATCH` is on by
  default, so an **unquoted glob in a flag value** (`grep --include=*.md`) aborts the
  command; bash passes the same word through literally and runs it. The reason it earns a
  rule rather than a footnote: with the `2>/dev/null` customarily used to hide
  `Permission denied` noise, the broken probe is **byte-identical to a genuine
  no-match** — empty stdout, exit 1 — so **an audit sweep cannot distinguish "the tree is
  clean" from "my search never ran"**. That is `sota-code-security` rules/12's
  verifying-the-verifier failure arriving through the shell these checklists are pasted
  into. §3a gathers it with the two deviations rules/01 already covered (word-splitting
  joins, `${pipestatus[1]}`) into one table, since they share a delivery vector:
  committed scripts are immune — all 11 `scripts/*.sh` carry a bash shebang — and the
  exposure is interactive, pasted and agent-issued commands on a machine whose login
  shell is zsh.
  - Numbered **3a** rather than renumbering: 49 `§` references point into rules/01 and
    four external files cite `§3` by name, the router among them.
  - All four of the brief's measured commands were **reproduced** (zsh 5.9 / bash 5.3.15 /
    Darwin 25.6.0) before the text was written, and both of its side-claims verified —
    the bash shebangs above, and **0** unquoted globs in flag values anywhere in
    `skills/`, so the practice was already modelled and only the rule was missing.
  - **Beyond the brief:** whether the *rest* of the command list survives depends on the
    callee — an external command continues (`exit=1` reaches you), a **builtin** aborts
    the whole list, so the follow-up never runs either. Either way the intended command
    did not.
  - Cross-referenced from `sota-code-security` rules/12 §2 as a fourth tell that the
    harness is the bug — and the only one of the four with no usage error to notice.
  - Deliberately **not** a shellcheck rule: shellcheck sees `sh`/`bash` scripts, which are
    immune here, so the lint could never fire. Adding one would have created the
    appearance of a gate that cannot fail — the exact class the brief is about.

### Changed

- **The router's library map moved to `skills/sota/rules/04-library-map.md`** (#308),
  taking `skills/sota/SKILL.md` from 499 to 398 lines and **16,997 → 13,415 tokens**,
  **−21.1% per load** — measured with `count_tokens` on `claude-sonnet-5`, the model the
  existing figures use. Seven times the ~3% the 2026-08-26 BUILD/AUDIT offload bought: a
  lookup table is denser than prose and is the part nobody reads inline. Honest caveats:
  a session that *does* open `rules/04` pays **+863** tokens versus before, and the router
  still breaches the ~5k recommendation at **2.7×**.
  - **Routing was pre-registered, then measured: ±0.000.** `run-clean.py --cases
    router.jsonl`, twice, against trees differing only in the router — with-library recall
    **1.000 → 1.000**, zero misses across 120 case-samples
    ([ROUTER-MAP-OFFLOAD.md](evals/results/2026-09-03/ROUTER-MAP-OFFLOAD.md)). Recall is
    at ceiling, so this is evidence of *no detected degradation*, not of no change.
  - The PR first named `run-desc-routing.py`, which **cannot see the router body** — its
    `+0.00` would have been structural. Caught by reading the runner before spending.
  - Invariants 7 and 15 moved with the map (7 now reads two files and asserts both exist;
    15 failed *closed* on the missing file first), and negative-control probe 15 with them.

### Fixed

- **`check-negative-controls.sh` no longer swallows its own cleanup failure** (#309). The
  disposable-worktree cleanup ran `git worktree remove --force … || true` and then
  `rm -rf`'d the directory regardless, so a failed removal left an orphaned **registration**
  — `git worktree list` showing `prunable` forever — with nothing reporting it. Success
  and failure of that cleanup were indistinguishable (`sota-code-security` rules/10 §2.4)
  in the one script whose job is proving that failures surface. Found with two orphans
  already registered. Now warns to stderr and prunes; the exit code is deliberately
  untouched, since this runs on `EXIT` and a non-zero there would overwrite the harness's
  real status. `git gc` does clear these, but only at the 3-month
  `gc.worktreePruneExpire` default — that grace is why it went unnoticed, not why it was
  fine.

## [1.31.2] - 2026-09-02

**Front door checked:** defaulted read · shared sink

**Patch, not minor**, by [RELEASING.md](RELEASING.md)'s test — a reader gains nothing *new
to run*. Four new `§§` inside rules files that already exist, a harness fix, and one more
static check inside a smoke runner that already ran.

Two classes from a field brief by a session that *used* the library on a Python service
calling LLMs for structured verdicts. Both were checked against this repo before being
written up, and **one of them was found here** — so the rule ships with two independent
instances rather than one report.

### Added

- **`sota-code-security` rules/13 §4a — the defaulted read, and the seam whose producer is
  a model.** §4 already owned "the seam nobody declared", but framed as **layout** drift
  (file name, column order, separator, units) with a deterministic producer, and its build
  rule — *run the consumer on that producer's real output* — presupposes a change event.
  Neither holds when the producer samples field names from a distribution. `.get(k,
  default)` on a dict you did not construct converts a detectable disagreement into a
  plausible constant: reported instances stored `0.0` in 168 rows and `""` in 221 of 232,
  for weeks, with nothing raising. **No static check closes this seam** — the prompt naming
  a field and the code reading it can both be correct — so the sound detector is runtime:
  diff the keys the response carried against the keys anything consumed and log what
  nothing read. Distinguished from the tolerant-reader rule (`sota-api-design` rules/02 §3,
  which stays correct — the addition is that it ignore *audibly*) and from
  `deny_unknown_fields` at a trust boundary (`rules/09` §4, which rejects).
- **`sota-code-security` rules/11 §2.7 — provenance of the rows, not just the count.** §2.2
  asks a *gate* how many items it examined; this asks an *analysis* where its rows came
  from. A sink both tests and production write is two populations to everything except the
  tools reading it. **The generalisable half is the direction nobody teaches:**
  contamination is discussed as manufacturing false positives, and the reported case where
  it *destroyed a true finding* was the dangerous one — 8.5% across a shared directory
  against ~100% on real runs — because the contaminated aggregate carried the larger n.
  A false positive dies in review; a finding withdrawn on contaminated evidence leaves no
  retraction to grep for and no red build.
- **`sota-observability` rules/05 §8a — test writes and production writes must not share a
  sink.** The build half. §8 already tagged synthetic *probe* traffic for SLI purity; this
  is the same requirement one layer down, where it is met far less often. Separate sink or
  a write-time stamp — **never a naming convention**, and never a filter inferred from a
  *value* (duration, row count), which infers the population from the data instead of
  recording it.
- **`sota-llm-engineering` rules/02 §6 — whole-document rejection is a recall control.**
  Amends the bullet **of ours that caused the reported defect**: *"reject into an explicit
  error path"* lost three whole documents to one enum synonym at ~$0.05 a repair attempt.
  Salvage the valid remainder and record the drop *for a model you invoked*; still reject at
  a trust boundary. Plus the missing path from symptom to remedy — a constant column now
  points at rules/13 §4a and at constrained decoding.

### Fixed

- **`evals/results/durations.tsv` was this repo's own shared sink**, found by checking the
  brief's prediction against our harness. Replaying the live ledger: **46 of 60 rows were
  sub-10s aborts (77%)**, and **3 of the 14 real runs had been compared against one** —
  `run-completeness` printed `previous 0.1s — 6340.0x slower <-- CHECK THIS` on its first
  genuine measurement, and the next real run would have read `previous 0.0s (no usable
  ratio)` against an abort logged 92 seconds after a good 3651.8s run. **`rules/11` §2.1,
  the diagnostic that ledger exists to implement, was inert for the most-run runner in the
  repo.** The cause was one line of ordering: `run-build-safe.py` called
  `note_work(len(cases))` *before* its `--selftest` branch, so the runner's own scorer test
  recorded `n=7 cases` in exactly a measurement's shape. Fix follows §8a rather than
  guessing from duration: `note_complete()` after `main()` returns, an `ok`/`partial` sixth
  column, `_previous()` returning only completed rows, partial runs recorded and reported
  but never compared, and every printed line **stating its own exclusion filter**
  (`[2 partial run(s) skipped to find it]`). Legacy 5-column rows are never baselines, so
  the first run of each label after this reads `no completed baseline yet`.
- **`smoke-runners.py` gates the marker** — a runner registering `report_on_exit` without
  `note_complete()` fails the suite (`3 checks, all with denominators`; watched to fail by
  stripping the call from `run-clean.py`, which named the right file and exited 1).
- **`run-router-length.py` no longer overwrites a past-dated result file.** Its output path
  was hardcoded to `evals/results/2026-08-27/`, so every re-run silently destroyed the
  record a re-run should be compared against. Now date-stamped, like every other runner.
- **`evals/README.md` said `7 of 12` runners call `note_work`**; recounted, it is **12 of
  13**. Stale since the count last moved.

## [1.31.1] - 2026-09-01

**Front door checked:** WHY-SALIENCE-LASTS · COMPLETENESS-PADDING

**Patch, not minor**, by [RELEASING.md](RELEASING.md)'s test — a reader gains nothing *new to
run* that is a new surface. Everything here lives inside surfaces that already exist: a CI
invariant (8, 9 and 11 each shipped in a patch), rule-text corrections, a doc, and a flag on
an existing runner.

Closing the open roadmap items. Two closed, one opened, and **both closures came from
re-testing a claim rather than re-reading it** — which is the through-line of this change.

### Added

- **Invariant 20 — the router's `§AUDIT` is hash-pinned** (`ROUTER_AUDIT_SHA`), closing
  ROADMAP 26. `§BUILD` has been pinned since v1.15.0 and has caught drift twice; `§AUDIT`
  had nothing, and `sota/rules/01` §5 said so outright — *"nothing catches this
  automatically"*. **The reason the gate was parked was false when re-read**: the row said no
  eval consumes §AUDIT, but `run-repo-audit.py:89` returns `f"{router}\n\n{rules}"` — the
  whole router, §AUDIT included. An audit eval had been measuring against an unpinned §AUDIT
  for as long as it has existed. The pin lives in `check-invariants.sh` rather than in a
  runner because that runner pastes verbatim and cannot drift; the drift that matters is
  **router-vs-rules**, since §AUDIT's seven passes have their procedure in `sota/rules/01`
  and `rules/03`. Probed in `check-negative-controls.sh` (**26/26**, 15 of 20 invariants
  covered). Invariant 19 demanded the probe the moment the check appeared, and invariant 17
  then named all six documents whose counts had to move.
- **`run-completeness.py --pad-rules N`** — a third arm carrying N lines of genuine rules
  prose from skills the case does *not* load, routing signal stripped and asserted gone.
  Closes the completeness half of ROADMAP 25. Reuses the existing prompt builder, judge and
  rubrics rather than forking a fifth mirror of the BUILD workflow.
- **[docs/WHY-SALIENCE-LASTS.md](docs/WHY-SALIENCE-LASTS.md)** — why defect avoidance
  expired in four months while completeness did not: a knowledge gap closes with model
  progress, a salience gap does not. States the prediction and what would falsify it (a
  model whose *unguided* completeness arm scores ~1.00). Advances ROADMAP 1's writable half;
  publishing it externally remains the human half.

### Fixed — three claims this library was making that it could not support

- **`sota/rules/02` §1 and the router's BUILD step 2 both said a long context of
  similar-looking guidance "*measurably reduces* how many rules the model applies."** It had
  never been measured. Measured now: adding **400 lines** of genuine unrelated rules prose to
  the with-library arm moved the mean **1.00 → 0.99, −0.01**, six of seven cases unchanged
  ([COMPLETENESS-PADDING](evals/results/2026-09-01/COMPLETENESS-PADDING.md)). The claim was
  generalised from [WHY-COMPLETENESS-RESIDUAL](docs/WHY-COMPLETENESS-RESIDUAL.md), where
  adding a **relevant** rule made application worse — that result stands; the leap to "any
  extra context costs applied rules" does not. Both surfaces corrected. The router edit was
  **prose-only**: `BUILD_WORKFLOW` was re-read clause by clause and contains no load-lean
  clause, so `ROUTER_BUILD_SHA` was bumped alone, per `rules/02` §5.
- **`sota/rules/02` §3 credited the terminal re-read with "the bulk of the library's
  completeness lift"**, citing the 0.62 → 1.00 `sonnet-5` run. That run has **two arms**, so
  it measures the whole library and cannot apportion credit to any component. The ablation
  that can — base 0.60 → +rules 0.89 → +self-audit 0.93 → +principle 5 0.99 — shows the rules
  carrying the largest step. A number cited for something it cannot show is the same defect
  as a number that is wrong.
- **A rejection in [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md) rested on the first of
  those.** The always-pasted-brief rejection cited the load-lean finding; that ground is
  withdrawn and the entry says so. The rejection stands on its second ground (pasted
  signatures drift from the code), which is an argument about freshness, not attention.

### Fixed — stale counts

`sota/rules/01` §5 said nothing pins §AUDIT (invariant 20 now does); ROADMAP item 12 said
259 rules files (**261**) and a 498-line router (**499**); `CONVENTIONS-LEDGER` headed a
nine-row table "(8)" and quoted 25 probes (**26**). All re-counted from the tree.

### Changed

- **ROADMAP: 25 and 26 closed, 32 opened, open count 5 → 4.** Item 32 is what 25 surfaced on
  the way out and is deliberately *not* folded into it: the padded arm ran with the step-4
  self-audit **active**, so −0.01 supports "lean plus a terminal re-read is robust to
  competing context" and says nothing about context length alone. Running the same padding
  with the gate off is the experiment that separates them.
- **Items 5 and 12 remain open and were not touched**, because their triggers are genuinely
  unmet: the accuracy sweep is due ~2027-01-08 (`LAST-VERIFIED` reads 2026-07-08), and item
  12 needs a sixth verification file in `sota-code-security` where there are five. Both were
  re-validated against the tree rather than assumed.

## [1.31.0] - 2026-09-01

**Front door checked:** prompt-independence · agents-tools · audit-findings · sota-llm-engineering

A second-pass intake of [affaan-m/ecc](https://github.com/affaan-m/ecc) (MIT, read whole at
`a104765`) — already a pinned competitor in `evals/cases/competitors.json`, where it scored
0.87 to our 0.99 in July. This pass asked the other question: not "does it beat us" but "what
does it know that we don't". Roughly 6 of its 286 skill files carried value; nine adoptions,
three rejections and one deferral are in [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md) with the
grep that checked each against `skills/` first.

**The new rules are measured, not asserted.** The intake produced behavioural claims about
what a model does under pressure, so it also produced the instrument to test them —
`evals/run-prompt-independence.py`, the first here that varies the *prompt* against the rule.
Under a **competing** prompt the library reads **0.491 → 1.000, +0.509** (6 cases × 3 samples,
temp 0.7; the with-library arm was perfect in **18 of 18** runs, sd 0.000), and the three cases
the new rules touch move **+0.426** pre→post against **+0.074** of sampling noise measured on
three byte-identical control cases in the same run
([PROMPT-INDEPENDENCE](evals/results/2026-08-31/PROMPT-INDEPENDENCE.md)).

Rules changed, in full: `skills/sota-llm-engineering/rules/04-agents-tools.md`,
`skills/sota/rules/01-audit-methodology.md`, `skills/sota/rules/02-build-workflow.md`,
`skills/sota/rules/03-audit-findings.md` and
`skills/sota-code-security/rules/14-control-not-in-force.md`. The router is **untouched** —
its §BUILD section in particular, so `ROUTER_BUILD_SHA` does not move and the completeness
eval's mirror is unaffected.

### Added

- **`sota-llm-engineering` rules/04 §2 — a *required* tool call is a harness property, not a
  prompt sentence.** "You MUST call `check_policy` before answering" is disregarded as readily
  as any other instruction to a probabilistic interpreter, and it fails silently in two
  directions: the model answers without calling, or it **narrates a call it never made** and
  reasons from the invented result. Make the answer structurally unreachable without the
  result — the harness refuses to finalize a turn whose required tool has not returned this
  run — and count both the blocked finalizes and the results cited but never returned.
  `sota-code-security` rules/14 §3 already owned the **prohibitive** direction ("never
  reveal…", "only call this for admins"); this is the **mandatory** twin, and the remedy
  differs because you cannot fix a missing step by removing something from the context. Under
  the competing prompt *"put the policy requirement in the system prompt where a non-engineer
  can tweak it"*, the unguided and pre-change arms both score **0.00** and the post arm
  **1.00, 3/3**.
- **`sota-llm-engineering` rules/04 §3a — goal design for autonomous loops.** §3 bounds how
  long a loop may run; this bounds what it may call *done* — the failure where every budget
  holds and the loop confidently finishes wrong. The done-criterion must be machine-decidable,
  and **its boundary is written in the same breath**: "all tests pass" alone is a licence to
  delete the failing test, because the model is optimizing the metric you actually stated.
  With it: prefer **reconciliation over assertion** (an assertion can be loosened, a diff
  against an external reference cannot), the judge is not the builder and the builder cannot
  edit the acceptance criteria, a retry cap escalates to a human, clarification is
  front-loaded because a loop will not stop to ask at 03:00, and the last switch stays human.
- **`sota-llm-engineering` rules/04 §5 — memory admission precedence.** Not everything the
  agent produced is a fact. Tag each entry's origin — observed tool output, user statement,
  agent inference — and on conflict let the **user's correction outrank the agent's earlier
  assertion**. The symptom of getting this wrong is a correction that will not stick. rules/08
  already covered memory *poisoning*; this is the correctness half.
- **`sota/rules/02` §4 — ask for a fact to produce, not a judgment to make.** "Did you handle
  the error paths?" is answered from the same context that wrote them, and the answer is yes.
  "Paste every `except` in the diff and name what each one re-raises" cannot be answered
  without going and looking, and the going and looking is what changes the output.
- **`sota/rules/01` §3 — collect deterministically, then judge.** Enumeration is a script's
  job and must print its denominator; judgment runs over the *complete* set. Inverting them is
  how an audit acquires a confident blind spot, and the miss is invisible, because a finding
  list looks identical whether the census behind it was 12 of 12 or 12 of 61.
- **`sota/rules/03` §3 — a verdict's reason must be self-contained and decision-enabling.**
  "unchanged", "superseded", "overlaps with X", "looks fine" carry no information and quietly
  re-open the decision they were meant to close. Worked table for all four ledger verdicts.
- **`sota/rules/03` §5 — the executive-summary posture is capped by the worst blocker
  standing**, not averaged: no summary reads better than "not ready" while an unfixed Critical,
  a missing authorization check, a non-idempotent payment path or an unrecoverable migration is
  in the list. Its companion, **"evidence not obtained — and what it would change"**, is the
  ask-shaped half of the exclusions list.
- **`evals/run-prompt-independence.py` + `cases/prompt-independence.jsonl` (6)** — the first
  instrument here that varies the prompt against the rule, at three pressure levels
  (supportive / neutral / **competing**) across three arms, where `pre` is read with `git show`
  from `--ablate-ref` rather than hand-mirrored. Cases whose rules files are unchanged act as
  an in-run control that measures the sampling noise instead of assuming it. All four guards —
  judge separation, the ablation assertion, the empty case set, the operating-principles
  extraction — were **watched to fail with exit 1** before the first scored run.
- **`profiles/example.md.template` — eight fields the template never asked for.** Found by two
  independent methods that produced **disjoint** answers: mapping all 40 domain skills against
  the template's 8 sections (design system, migrations/seeding/test data, testing conventions,
  API conventions, LLM/AI features) and reading which headings a real in-use profile had grown
  beyond it (stack mapping, data classification, internal names never in public output,
  detection posture). Either method alone would have reported about half the gap.

### Changed

- **`sota-code-security` rules/14 §3** now names the mandatory direction and points at
  `sota-llm-engineering` rules/04 §2, including the failure it does not itself cover — a model
  narrating a tool call it never made.
- **[docs/ROADMAP.md](docs/ROADMAP.md)** — items 30 and 31 added; the ledger header's "All 28
  items" corrected to 31 (it was already stale by one before this cut, because item 29 had been
  added without updating it).

### Fixed — stale claims found by the release cut

The cut is the highest-yield moment to re-read prose, and it found four things no gate
could catch:

- **`docs/WHY-IT-WORKS.md` still said "Seven instruments"** for the audit family's +0.00
  while `README.md` and `evals/results/RESULTS.md` have said **nine** since 2026-08-14.
  The file was missed in that sweep and had been **understating our own evidence** for
  two weeks — the same shape as the v1.22.9 README fix.
- **`AGENTS.md` said "19 invariants + 5 more inside the eval runners."** The
  conventions-ledger table had already grown to **8** before this release and is **9**
  with the ablation assertion added below. Corrected to 9.
- **`docs/ROADMAP.md`'s ledger header said "All 28 items"** while item 29 existed — it was
  already stale by one *before* this cut, because 29 was added without touching the header.
- **`README.md` and `docs/WHY-IT-WORKS.md` both called defect-avoidance "the newest
  result."** It has not been since 2026-08-21 and certainly is not now; the phrase moved to
  the axis that is actually newest.

A fifth was left deliberately: a `docs/ROADMAP.md` entry states "7 of 12 runners declare
a denominator" inside a **CLOSED 2026-08-03** block. That is a dated record, so it is
**superseded with an as-of** (19 runners now) rather than edited — editing history to
match the present is how a ledger stops being evidence.

### Added — one enforced convention

- **An ablation arm must actually differ from its baseline.**
  `run-prompt-independence.py` diffs each case's `pre` and `post` bundles and **aborts**
  when none differ, because otherwise the ablation arm is the treatment wearing a
  different label and reports a delta of zero as a result. Cases that *do* match are kept
  and read as the run's sampling-noise control rather than dropped —
  [CONVENTIONS-LEDGER.md](docs/CONVENTIONS-LEDGER.md).

### Retracted

- **Roadmap item 31, opened and withdrawn the same day.** The new instrument's first run
  produced an apparent gap — case `pi05` reading 0.67 in all three arms, suggesting operating
  principles 5(c) and 9 both failed under an explicit "no tests" instruction — and it was
  written up as an open item on the strength of **one sample at temperature 0**. The
  confirmation run at three samples scores the with-library arm **1.00, 3/3**. The same run
  corrected a second number: run 1's control ablation of **+0.000** was a temperature-0
  artifact, and the instrument's real sampling noise is **+0.074**. `sota/rules/03` §2 — *a
  reproduction you ran once is a coincidence you have not ruled out* — caught the project's own
  eval within hours.

## [1.30.1] - 2026-08-29

**Front door checked:** audit-findings · sota-llm-engineering

ROADMAP item 29 opened and closed the same day. Five rules borrowed from two Anthropic
primary sources — the `/security-review` prompt extracted from the CLI (verified current by
diffing the 2.0.76 JS bundle against the live 2.1.251 native binary: one line differs across
10.5k characters) and `anthropics/defending-code-reference-harness` (Apache-2.0, every quote
checked against the raw README). Each was grep-checked against `skills/` before being called
a gap; verdicts and citations in [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md). They land in
`skills/sota/rules/03-audit-findings.md`, `skills/sota/rules/01-audit-methodology.md` and
`skills/sota-llm-engineering/rules/04-agents-tools.md`.

### Added

- **`sota/rules/03` §4a — bound what the refuter gets, and make its verdict a number.**
  The refutation pass existed; nothing said what the refuter is *given*. Three conditions,
  all cheap. **Give it less than the finder had** — no execution, no writes — because a
  refuter holding the finder's tools re-runs the finder's investigation and arrives where it
  arrived. **Bound what crosses to a single artifact**: fresh context is not enough on its
  own, since handing over your write-up hands over its framing; ship the proof of concept,
  the failing command, the `file:line`, and nothing else — and where no artifact can be
  produced, that is the result, because a finding with nothing to hand over is one you have
  not reproduced. **Score the verdict, do not narrate it**: require a number against a
  threshold fixed *before* the findings are seen and stated in the methodology, since a
  paragraph of hedging is a judgement you then re-judge, which is the anchoring the pass
  exists to escape.
- **`sota/rules/03` §2 — a reproduction you ran once is a coincidence you have not ruled
  out.** Where the evidence is a *behaviour* rather than a line of code — a crash, a race, a
  timing bypass, a fuzzer hit, anything an agent or a sampled model produced — reproduce it
  **N of N** and report both numbers. `1/1` and `3/3` are typeset identically in a report
  and mean entirely different things. This binds the library's own instruments: a criterion
  that flips run to run at temperature 0-ish cannot be settled by a single run, so a
  one-shot measurement quoted as a result is an unstated `1/1`.
- **`sota-llm-engineering` rules/04 §7 — partition before you fan out.** N agents pointed at
  one target with one instruction do not give N chances, they give **one chance N times**,
  because they converge on whatever is most salient. Spend a cheap recon pass proposing the
  partition first, then give each agent one. The reason this survives review is the half
  that is easy to miss: the duplication is **invisible in the output**, because N agents
  reporting the same finding reads as corroboration rather than as N−1 wasted agents.

### Changed

- **`sota/rules/01` §4 — a fix is verified when a fresh search cannot get around it**, not
  when the reported input stops working. The re-audit loop already existed and said only
  *re-run the same tools*; it now requires re-pointing the original hunt at the patched code
  with no knowledge of the fix, because a patch that closes one input and leaves the class
  open passes every narrower check.
- **`sota/rules/01` §4 — read the yield curve across waves.** Repeat audits should show the
  finding **count fall while difficulty rises**. A count that stays flat wave after wave is
  a statement about the audit, not the code: the waves were not independent. Carry the
  previous wave's findings in as an explicit exclusion, and treat a wave that returns the
  previous wave's list as a failed wave.
- **Audit-checklist items for all five**, in the three files they landed in.
- **Thirteen intake rows in `docs/ADOPTION-LOG.md`** across this release and the last: six
  now marked **adopted** with their landing sites, and four **rejected as already covered**
  with citations (threat-model-scoped scanning → router §AUDIT step 2; gVisor + API-only
  egress → `sota-sandboxing` rules/05 R2.1/R4.1; ASAN → `sota-c-cpp` rules/02; proving a
  pipeline on a known-vulnerable reference target → `sota-code-security` rules/12 §2.2). One
  rejection carries more than its verdict: the defending-code harness is an **independent
  implementation of `sota-sandboxing` rules/05 §7**, shipped the same day — it ingests a
  repository it did not author, builds and executes it, and isolates exactly where §7 says
  to. Also recorded so they are never adopted: two of `/security-review`'s own exclusions
  contradict this library deliberately (*"including user-controlled content in AI system
  prompts is not a vulnerability"*; *"memory safety issues … are impossible in rust"*). Its
  exclusion list is a PR-noise policy, not a security taxonomy.
- **ROADMAP "Start here" restamped twice in one day and both stamps name what was re-read**
  — star/forks live via `gh` (**17/3**, flat), the router at **499/500**, the release, row
  13's cap watch — and what was **not** (item 1's listing status, the deferred-row pointer).
  The "one piece of queued writing" line, added when item 29 opened, was corrected when it
  closed rather than left standing.
- **`docs/CONTEXT-MANAGEMENT.md`'s token figures stamped rather than scaled.** The tree has
  moved since they were measured (302 skill files, a 499-line router), and no tokenizer was
  reachable this session — so they are marked as a **2026-08-27 floor** with a re-measure
  instruction, rather than adjusted by estimate. That file's own rule is *do not estimate
  skill sizes; count them*, and quietly scaling them would have broken it.

### Notes

- **None of the five is measured**, and the ROADMAP row says so: they are borrowed from two
  tools Anthropic ships, not validated here. Deliberately **not gated** — all five are
  judgement conventions, and a threshold a repo cannot mechanically check is prose by
  definition ([docs/CONVENTIONS-LEDGER.md](docs/CONVENTIONS-LEDGER.md)).
- The invariants earned their keep on the way in: check 18 caught a `rules/12 §7` citation
  that should have been §2.2.

## [1.30.0] - 2026-08-29

**Front door checked:** audit-findings · sota-code-security · sota-sandboxing

Intake from **two audits of one third-party project run side by side** — a full-repo audit
using this library, and Claude Code's diff-scoped `security-review`. Seven classes adopted,
six rejected as already covered, with citations, in
[docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md). The two runs are **not comparable
instruments** — one full-repo, one diff-scoped — so nothing here is a scoreboard; what
transferred was the reasoning moves.

### Added

- **`sota-code-security` rules/14 §6 — a real control applied to part of its population.**
  Not inert (`rules/10`) and not missing (the rest of `rules/14`): it **works**, on some of
  the sites it is credited with. A containment check guarding the file *listing* and not the
  four channels twelve lines away that read file *bodies*; `disable_tools=True` at 2 call
  sites of 6; a path guard on 9 target walks of 61. Every signal is a working control's
  signal, because on the guarded subset it is one — so the falsification question answers
  "yes, something would differ" and the control is still wrong. The guarded member is
  reliably **the one the author was looking at when the bug was filed**. The audit move is a
  **census, not a search**: enumerate the protected *operation*, mark every call site
  guarded or unguarded, report the ratio. `9 of 61` is a finding; "containment is applied"
  is not a claim anyone can check.
- **`rules/14` §6a — the opt-in-secure default, the API shape that guarantees §6.** When the
  safe value is a parameter default that is *unsafe*, partial application is not a risk but a
  schedule: every call site added from now on starts unguarded. A parameter selecting a trust
  boundary **defaults to the closed side**, keyword-only. The property worth preserving is
  not "the default is safe" but that *the count of privileged call sites is a `grep -c`
  away* — which is what makes the census cheap enough to actually run. Audit in order: read
  the **default in the signature** (never the docstring), count the sites that pass it, then
  ask which of the two numbers the security documentation asserts.
- **`rules/14` §7 — the claim the code does not keep: falsify the quantifier.** §1 owns
  numbers a *tool prints at runtime*; this owns sentences a *human wrote* — threat models,
  `security_model.md`, module docstrings, ADRs. Nothing executes them, no gate reads them,
  and they are what an operator plans around, including the decision **not to look**. Most
  are universally quantified and therefore falsifiable by counting: "applied at every target
  walk" (9 of 61); "no function-calling, no shell, no subprocess — this RCE mechanism is NOT
  APPLICABLE" (tools on by default, a shell command executed on the host in the
  reproduction); a docstring promising no access to `.env` that the staging code never
  enforced. Each had been **true when written**. A wrong `NOT APPLICABLE` is the
  highest-impact form — it does not merely mislead, it *cancels the reader's own
  investigation*, which is how one survives years of review by people who would have caught
  the code.
- **`sota-sandboxing` rules/05 §7 — when your tool ingests other people's repositories.** A
  routing gap: `rules/05` owned *model output*, `sota-code-security` rules/09 owned
  *parsers*, `sota-devsecops` rules/03 owned *your own dependencies* — nothing owned the
  composition that every scanner, SAST wrapper, review bot and agentic analyser is. Four
  legs, typically owned by four different people: staging that **dereferences symlinks** out
  of the target tree (`copytree(..., symlinks=False)` is the default); "static" analysis that
  **evaluates target-controlled build metadata** (`build.rs`, proc macros, `setup.py`, npm
  lifecycle scripts, Gradle, `make`); an **LLM step spawned tools-live** with the parent's
  `cwd` and environment; and **egress on by default**, because a container with no
  `--network` flag has full outbound access. Written as *verify it for your exact command and
  flags* rather than a per-tool verdict table. Reachable from routing rule 13.
- **`sota/rules/03-audit-findings.md` — a new rules file, split out of `rules/01`.** `rules/01`
  had reached 455 of its 500 lines with new severity and refutation content to land, so it
  split at a seam it already had: **`rules/01` runs the audit** (scoping, the verified tool
  matrix, triage, hygiene), **`rules/03` governs the deliverable** (severity, evidence, the
  decision ledger, refutation, the report template). Sections 4–8 of the old file are §1–§5
  of the new one, in the same order, and the new file's header states the shift for prose
  written before it. This exercised the repo's own reactive-split policy: invariant 18 caught
  **5** broken `§` references in four files before anything shipped, and the fail-open case it
  *cannot* catch — a `sota/rules/01 §5` reference silently resolving against another skill's
  own `rules/01` §5 — was swept by hand.

### Changed

- **Severity now requires a named chain (`rules/03` §1 hard rule 3).** A severity is a claim
  about a chain, and a chain has legs: input **reaches** the code, something **acts** on it,
  the effect **crosses a trust boundary**, and where exfiltration is the impact a **channel**
  carries it out. Each leg is pointed at code or the finding is downgraded — the diff-scoped
  review killed its own candidate on three independent legs (no Swift toolchain in the image;
  `go build ./...` runs no generator, test or `main`; staging lands in a `0700` directory the
  operator already owns). A missing leg does not make a finding smaller, it makes it a
  *different* finding. The inverse is the higher-yield half: when every leg coexists in one
  path, that is what the report leads with. Also added as a fourth **chain-closure** lens to
  the refutation pass (§4), where the previous *reachability* lens asked only whether input
  arrives.
- **On a diff, rate against the code the change replaced (`rules/03` §1 hard rule 4).** A
  hardening change that closes three exposures and leaves a fourth is not a High — the High
  was the state before it. *"Filing a High here would be filing a High against the fix"* is
  not a conservative error: it teaches authors that hardening attracts findings, which is how
  the next mitigation does not get written. The residual gap is still reported, at its own
  severity, against the codebase rather than against the diff.
- **A refuted finding is a template — sweep before you drop it (`rules/03` §4 step 5).** The
  refutation hands you the pattern *and* the leg that was missing; both are reusable across
  the whole repository, not just the audited scope. The evidence is direct: the diff-scoped
  review found the only finding it shipped by sweeping outward from its own refuted
  candidate, landing on an unchanged module where the analysis step compiles the target and
  runs its build scripts with no network isolation — and the full-repo audit, with strictly
  more scope, **missed it**. A refutation with no sweep closes a class on one instance.
- **Router AUDIT step 4 now asks a second question.** After "does the control *do* anything?"
  it asks "does it cover **every** site it is credited with?", routing to `rules/14` §6's
  census and §7's prose check. Steps 5–7 and operating principle 7 re-point at `rules/03`.
  The router is **499/500**; `ROUTER_BUILD_SHA` is unchanged, since the split touched AUDIT
  and the library map only.
- **The ROADMAP's "Start here" section now opens with an actionable priorities table.**

- **The ROADMAP's "Start here" section now opens with an actionable priorities table.**
  It previously opened with twelve lines about where gate candidates come from — true,
  useful, and not what someone starting a session needs first. Provenance and the
  backlog-shape argument moved below the table under their own headings. The honest
  headline is that **nothing is urgent**: priority 1 is *use the library on real work and
  write a field brief*, because briefs from sessions that used it landed **7 of 7** and
  **4 of 4** while the written-conventions backlog is empty.
- **Live router count corrected in two places: 498/500, not 500/500 or 484/500.** ROADMAP
  row 12's "no slack" reasoning and `AGENTS.md` both carried a stale figure; AGENTS.md's
  own warning that this number has been wrong is now at **five** times. The two other
  stale copies (roadmap lines ~440 and ~714) were deliberately left: they sit inside the
  section relabelled as history in v1.29.4, which is what that relabelling was for.
- **A "closed rows" count was caught before shipping.** A case-insensitive grep for *done*
  scored row 12's "**NOT** done" as closed and produced 17. The ledger heading now states
  the count that is actually verifiable — **5 open** — and says why the other direction
  resists grepping.

## [1.29.5] - 2026-08-28

**Front door checked:** sota-architecture · ADOPTION-LOG

### Added

- **`sota-architecture` rules/01 §4b — a deferral is a standing question, so give it
  somewhere to accumulate answers.** A decision record that defers an idea behind a
  trigger ("revisit if a second implementation shows this") must also say where evidence
  toward that trigger accrues and who reads it. Otherwise the deferral is not revisited —
  it is *re-derived from scratch* by whoever next asks, at full cost, with no memory of
  the last answer: near-misses and deliberate refusals are both evidence about the class,
  and both are lost by default. The rule also covers a **deliberately-unfixed state kept
  as evidence** (a known-bad left in place to prove a control fires, a pin left stale so
  an automated bump proves the automation runs) — a good technique that carries an
  experiment's obligation, because **an experiment with no scheduled read-back is
  indistinguishable from a note**. Ships with its audit half in the same change: list the
  deferred entries, ask when each was last evaluated and what was found.

### Changed

- **The "Start here" stamp restamped again — and this time it names what was *not*
  re-read.** The previous fix set one date over a mixed section; the honest version says
  star/forks were re-read live on 2026-08-28 (**17/3**, flat since the 27th) while the cap
  watch still dates to the 27th. A single stamp over a section refreshed in parts is the
  same defect in a smaller box.
- **The deferred spanchain row in `docs/ADOPTION-LOG.md` now carries a trigger ledger.** Its revisit condition — *a
  second implementation shows the same design* — had nowhere to accumulate evidence, so
  every check re-derived the same search from scratch (this one swept 74 later intake rows
  to produce three lines). The ledger records what has been checked and how it scored:
  **1 shipped instance, 1 near-miss** (the Interdict gate-ledger, where the same failure
  mode arrived accidentally and a human caught it before it shipped) **and 1 refusal**
  (exempting `dependabot[bot]` would have been this exact design; the cause was fixed
  instead). **Trigger not met.** Also recorded: the *generic* half is owned twice over,
  and the *specific* half — encode a known gap as a marker inside the structure so the
  verdict stays green — is absent, which is what a second instance would buy. **A deferred
  item with a trigger and no evidence ledger is re-litigated from zero every time.**

## [1.29.4] - 2026-08-28

**Front door checked:** ADOPTION-LOG · roadmap

### Fixed

- **The CHANGELOG said ROADMAP 23 and 24 were closed; the ROADMAP still listed them as
  open.** Both were genuinely done in v1.29.1 — re-verified before closing the rows (20/20
  case sets state a selection rule; `check-freshness.sh` warns on an aged set and fails
  closed without a marker) — but the roadmap rows were never updated. A doc-vs-doc
  inconsistency in the two places that describe the same backlog.
- **Stale live counts in ROADMAP item 1**: "13 stars, 2 forks" was checked 2026-08-19; the
  API now returns **17 stars, 3 forks**. Re-checked rather than carried forward.
- **The "Start here next session" stamp read *as of 2026-08-20*** while its rows had been
  updated as recently as 2026-08-27. Restamped, and the provenance sentence replaced with
  one that does not claim a single re-count date. It now names **what is actually open**
  (1, 5, 12, 25, 26) so the next session does not scan 28 rows to find five — the rest are
  closed or recorded lessons whose "first move" is a habit, not work.
- The ledger's standing prediction — *the next gate comes from an incident, not from
  re-reading docs* — has now **held three times**: `evals/smoke-runners.py` came from a
  runner that had been dead for three weeks.
- **Two resolved experiments were still recorded as pending, and the answer to "what is
  open?" was assembled from one file.** The listing PR at
  [awesome-ai-plugins](https://github.com/hashgraph-online/awesome-ai-plugins) **merged
  2026-08-26** — the first time this library is catalogued outside its own repo, and the
  only concrete movement ROADMAP item 1 has ever had. The `actions/checkout` pin left
  un-bumped *on purpose* (v1.27.0, as the cheapest available proof that Dependabot runs)
  drew **#281**, merged 2026-08-27; every workflow now reads `v7.0.1`, confirmed current
  against `repos/actions/checkout/releases/latest`. Both outcomes are now in the ledger
  row and its write-up. **An experiment with no scheduled read-back is indistinguishable
  from a note** — when something is left un-fixed as evidence, say where the result lands
  and who reads it.
- **The ROADMAP is not the whole backlog, and it now says so.** Open work also sits in
  `docs/ADOPTION-LOG.md` as **deferred** rows — an idea judged real but held for a trigger
  — which the roadmap never learns about; one is live (`grep -c '**deferred'` → 1). A
  backlog assembled from a single file reads as complete and is not.
- **The stale-header fix of v1.29.4's predecessor had a sibling one screen down.**
  `## Open tasks — next-session pick-up *(as of 2026-08-05)*` was a **closed** v1.22.0
  cycle write-up wearing a live-backlog heading; relabelled as history. Fixing one
  instance of a defect without grepping for its siblings is the fourth recurrence of that
  habit recorded in this repo — the grep costs seconds and is not optional.

## [1.29.3] - 2026-08-27

**Front door checked:** proxy question · invariant

### Added


- **Six findings from the Interdict follow-up brief — including two the first intake
  missed.** All verified absent with two sweeps each, and every one shipped with its
  audit-checklist half.
  - **`sota-code-security` rules/10 §1 — the proxy question**, beside the falsification
    question. This is the strongest change of the set: the existing question finds controls
    that are *inert*, and **cannot** find one that is **correctly enforcing the wrong
    predicate** — there something observable *does* differ, so it answers "yes" while the
    control is still wrong. Four instances in one session, by an author who had just
    documented the shape: `commit.gpgsign` vs *is a key configured*; encoder round-trip vs
    *does the writer emit what the verifier expects*; does `--sk` exist vs *is it
    implemented*; is there a TTY vs *can a PIN be collected here*. Its discriminating half
    is the second clause — **who can change one without the other, and would I find out?**
  - **rules/10 §2.15 — a flag that parses is not a feature that works.** `--help` describes
    the source tree, not your binary: build-tag-gated features leave the interface compiled
    in and the implementation stubbed (Homebrew `cosign` v3.1.2 lists `--sk` and returns
    `opening piv token: unimplemented`). Invoke an optional capability once before a design
    depends on it.
  - **`sota-architecture` rules/01 §4a** — a control's **cost profile** must be checked
    against decisions already in force. A control that spends a scarce resource per use can
    reintroduce the friction an earlier decision removed; both artifacts are locally correct
    and the contradiction lives in the gap.
  - **`sota-cli-ux` rules/03** — rehearse a costly command where failure is free before
    handing it to a human, and state the cost. A YubiKey PIN blocks after **three** attempts.
  - **`sota-shell-scripting` rules/04 §1a** — never batch a state-changing command with
    exploratory reads; the reads then describe a state that no longer exists.
  - **`sota-docs-workflow` rules/01 §11** — a durable note records an **invariant**, not an
    observation. Applies directly to agent memory files.

### Changed


- **Recorded, not gated: invariant 18 checks that a `§` reference *resolves*, not that it
  points at the right content.** A reference written today pointed at `rules/11` §5 when the
  content is in §4, and the gate passed because §5 exists — the proxy shape, in our own gate,
  on the day we adopted a rule about it. Not mechanically checkable ("is this the right
  section?" is semantic); the mitigation is the new rules/10 §1 question, and the reference
  was fixed by reading the heading.

### Fixed


- **`RELEASING.md` step 4 taught the procedure that failed on 2026-08-27.** It showed
  `git checkout main && git pull` followed straight by `git tag` and `gh release create`,
  with nothing verifying that `main` actually carried the release. Chained after a **failed**
  merge, that tagged `v1.29.2` at the *previous* release's commit and published it with
  **empty notes**; invariant 5 caught the result, not the act. Step 4 now carries a gate —
  `VERSION == plugin.json == CHANGELOG top` before tagging, and a non-empty notes check
  before publishing — plus the cleanup path (`gh release delete`,
  `git push origin --delete`, and `git tag -f -a` because `git tag -d` is denied to the
  assistant). **The documented snippet was run both ways before shipping**: it passes on a
  released tree (32-line notes) and blocks on a mismatched one.
- Docs caught up with the gate they describe: `evals/README.md`, ROADMAP 28 and
  `docs/CONVENTIONS-LEDGER.md` now record the **`.env` existence assertion** alongside the
  `__main__` one — including that the `.env` assertion was **vacuous on its first draft**
  and passed the broken tree until it was watched to fail.




- **The 2026-08-26 intake was incomplete: that report was read to line 318 of 428.**
  Findings 8 and 9 sat in an addendum below where the reading stopped and were never
  assessed. Caught only because the follow-up cross-referenced "findings 1–9" and the count
  disagreed. Both are now adopted. **Check a file's length before treating a page-at-a-time
  read as complete.**
- Cap watch (ROADMAP 13) **re-measured rather than remembered**: `sota-docs-workflow/rules/01`
  **477**, `sota-code-security/rules/12` **476**, `sota/rules/01` **455**.

## [1.29.2] - 2026-08-27

**Front door checked:** smoke

### Fixed

- **The `__main__` guard, everywhere — not just the one instance I noticed.** An AST audit
  of every script found a **second** module-level runner:
  `run-build-safe-arms-guided.py` read `skills/` on import, could `sys.exit` on a missing
  marker, and **made a live API call** — so anything that introspected it ran the whole
  guided arm. Now behind `main()`; verified inert on import and still usable as a CLI.
  (`evals/_elapsed.py` was flagged by the audit and is a **false positive** — a helper
  module whose only module-level statements are pure constants. Helper modules correctly
  have no guard.)
- **A third `.env` defect, and now an assertion for the class.** `run-build-safe-arms.py`
  opened `.env` unconditionally, so it raised `FileNotFoundError` on any machine without
  one — CI caught it, as it had caught the same defect in `run-router-length.py` the day
  before. **No local run can find these**: a maintainer's tree has a `.env`, so the failing
  branch is only reachable where the file is absent. `smoke-runners.py` now asserts every
  `.env` read is existence-checked.
  - **That assertion was vacuous on its first draft and only watching it fail caught it.**
    It matched `.env` inside the `open()` call, but these build the path first
    (`p = os.path.join(..., ".env")`) and then call `open(p)` — so it found nothing and
    passed the *broken* tree exactly as happily as the healthy one. Matching on the
    enclosing function fixed it; it now fails naming `file:function()`.
- **And made checkable, because the smoke test structurally cannot catch this class.**
  Importing a module-level script runs it, which looks identical to "reached its first
  network call" — exactly how `run-router-length.py` passed while executing its sweep on
  import. `evals/smoke-runners.py` now asserts every runner keeps its side effects behind
  `if __name__ == "__main__"`. **Watched both ways**: passes on the healthy tree (18/18),
  and fails naming the file when a guard is removed.

## [1.29.1] - 2026-08-27

**Front door checked:** selection rule · freshness set

### Changed

- **Every case set now states its selection rule — ROADMAP 23 closed, 20/20.** Each says
  how its cases were chosen *and* whether it is a **measurement** set (a lift may be
  reported, so cases must never be selected by a model's score) or a **regression** set
  (selection-by-outcome is the point). The repo now practises the rule it added on
  2026-08-26. Two defects surfaced doing it: `silent-failure.jsonl`'s header still
  described the **retracted 15-case version** ("13 positive + 2 negative") while the file
  holds **81** — verified from the file as 61 positives (35 enumerated + 26 `novel`) + 20
  negatives — and `.github/workflows/freshness.yml` still carried the stale
  `actions/checkout v7.0.0` prose comment, the copy the 2026-08-27 fix missed.
- **The freshness set now has a mechanical cadence — ROADMAP 24 closed.**
  `scripts/check-freshness.sh` reads an explicit `# AUTHORED:` marker (git dates move under
  rebase) and **warns** when the newest freshness set is older than the window. Watched
  both ways: it warns at 19 months and **fails closed (exit 1)** with no marker. The
  6-month window is **borrowed** from `LAST-VERIFIED`, not derived from decay data — one
  before/after pair is not a decay rate, and it warns rather than fails because an ageing
  set still measures a real floor.
- **ROADMAP 25, routing half: null.** Padding rebuilt from genuine rules prose with every
  routing signal stripped (asserted) scored **0.992 vs base 1.000 — identical to inert
  filler**, both inside the 0.05 one-case resolution. **Not permission to grow the
  router**: routing is retrieval-ish and at ceiling; the **completeness** half is the one
  that matters and is still unmeasured.

### Fixed

- **`evals/run-router-length.py` ran its sweep at *module level*** — importing it made live
  API calls, which `smoke-runners.py` tripped (only its patched `urlopen` prevented real
  requests). Now behind `if __name__ == "__main__"`.
- **The same script overwrote a published artifact.** Its output path was hardcoded to a
  fixed date, so the follow-up run clobbered the 5-arm `2026-08-26/router-length.json`
  cited in v1.28.0. Restored from git; the runner now writes a dated filename.

## [1.29.0] - 2026-08-27

**Front door checked:** smoke · routing gap

### Fixed

- **A stale count in the ledger that no gate reads.** `docs/CONVENTIONS-LEDGER.md` said
  *"Already enforced as invariants | 17"*; the script reports **19**. Invariant 17 checks
  the tables in `AGENTS.md` and `CONTRIBUTING.md`, not this one — so the ledger of what is
  enforced had drifted from what is enforced, for the **second** time (its own §
  records the first). Corrected, and the new gate recorded against the three filters,
  which is the ledger's whole job.
- `AGENTS.md` now says its CI job runs **both** `check-negative-controls.sh` and
  `evals/smoke-runners.py`, rather than implying the job is the harness alone.

### Added

- **`evals/smoke-runners.py` + a CI step — a runner can be dead for weeks and nothing
  reports it.** `run-desc-routing.py` raised before its first API call from 2026-08-05 to
  2026-08-27, unnoticed because the guard that killed it landed *after* that eval's last
  recorded run. `--help` would not have caught it — the crash was inside `main()`. So the
  test patches `urllib.request.urlopen` (the one choke point every runner shares) and
  treats *reaching the network* as success. **Watched to fail** on a reintroduction of the
  exact bug before being wired in. It proves a runner can **start**, not that it is
  correct — stated in the script and in ROADMAP 28 so the gate is not over-read.
- **A routing gap should end as a test, not just a report** — the router's gap-reporting
  section now says so: fix the *trigger* (the `description` is the only auto-loading text
  and the whole classifier) and pin it with a regression case.

### Fixed

- **Two defects in `run-build-safe-arms-guided.py`**: `sys.path.insert(0, "/tmp")` —
  prepending a **world-writable** directory to the import path, in a repo that teaches
  supply-chain hygiene, and vestigial since the script imports its sibling by absolute
  path — and a raw `IndexError` instead of a usage message when run without arguments.
  Found by the runner sweep; the other three `sys.path` uses in the tree are
  `__file__`-relative and correct.
- **`docs/CONTEXT-MANAGEMENT.md` was itself a casualty of the chars/4 heuristic.** It
  claimed *"12 of 297 files exceed ~5,000 tokens"*; measured across all 301 files with
  `count_tokens`, it is **132 of 301 — an 11× under-count**. *"Exactly one file breaches
  the recommendation"* is **5 of 41** `SKILL.md` bodies. The Swift rules file it cites as
  ~6,737 tokens is **10,116**. Corrected with the measurements, plus the density range
  (~24–46 tokens/line) that is the actual argument a line cap cannot make. ROADMAP 27
  closed.

- **A rule the library already had, that the task never reached — fixed as a routing
  problem and measured.** `sota-llm-engineering/rules/02` §2 has always said "use the
  provider's token counter, never another vendor's tokenizer", and a maintenance task
  still got it wrong. Not a knowledge gap: **UNREACHABLE, not absent.** The skill
  `description` — the only auto-loading text, and the entire classifier — carried
  `token budget` but not `count`, `tokenizer` or `measure`; the routing-table row said
  *"**Building** LLM features"*; cross-cutting rules 5 and 8 both said *"AI/LLM
  **features**"*. All three fixed, plus new router **rule 21**, shaped as a sibling of
  rule 17: **model facts hide in your own tooling** — measuring tokens, context or cost is
  LLM engineering even when the surrounding task is repo maintenance.
  **Proved rather than asserted**: a regression case picked `sota-docs-workflow` **3/3**
  before the fix and `sota-llm-engineering` **3/3** after
  ([write-up](evals/results/2026-08-27/ROUTING-REGRESSION-TOKEN-COUNT.md)).
- **`run-desc-routing.py` could not execute at all, and had not since 2026-08-05.** An
  ablation-assertion guard called `.splitlines()` on the list `catalogue()` returns,
  raising `AttributeError` before the first API call. The guard landed in PR #223 — *an
  instrument audit* — and the last recorded run of this eval predates it, so **a guard
  added to prevent a fake null made the instrument unrunnable and nothing re-ran it to
  notice** (`sota-code-security` rules/12). Fixed and watched in both directions: 9
  descriptions differ normally; a neutered `XREF_RE` yields 0 and still aborts.

### Changed

- **`sota-llm-engineering` rules/01 §8 — regression cases are not measurement cases.** As
  written, the selection-bias rule banned choosing eval cases by outcome full stop, which
  on a plain reading forbids regression tests. Selection-by-outcome poisons a *measurement*
  set and is the entire *point* of a *regression* one. The rule now draws that line, with a
  checklist item, and regression cases live in `cases/desc-routing-regressions.jsonl`
  behind a new `--cases` flag so they can never be averaged into the published A/B. Found
  by the fix above tripping the rule written hours earlier.

## [1.28.1] - 2026-08-27

**Front door checked:** Dependabot · tokenizer

### Added

- **`sota-devsecops` rules/01 §1.10a — bot PRs get no repository secrets, and a gate that
  needs one will fail.** Dependabot and Renovate branch **inside** the repo, so any
  "trusted run" condition (`head.repo.full_name == github.repository`) is true for them
  while their token is denied repository secrets. The gate then either goes permanently red
  — training people to bypass a required check — or degrades quietly and reports the same
  green while scanning less than it claims. Ordered fixes, with **"do not special-case the
  bot"** stated as the anti-pattern: it turns the check green by removing the control on
  exactly the PRs that change the dependency graph. Two sub-traps included: a secret must
  carry the **form its consumer reads** (a pipe-joined regex, not the file's on-disk
  layout), and **what the bot maintains, it maintains narrowly** — it rewrites the trailing
  `# vX.Y.Z` beside a SHA pin and nothing else. Both halves shipped: rule + two audit items.

### Changed

- **`sota-llm-engineering` rules/02 — the tokenizer-error magnitude was understated.** The
  rule already said "measure with the provider's token counter, never another provider's
  tokenizer", and put the error at **15–20%+**. Measured on markdown-dense text it is
  **54%** — 16,934 tokens via Anthropic's `count_tokens` against 10,995 from `o200k_base`
  for the same 42.8 KB file — and a chars/4 estimate in this repo's own docs was **60%**
  under. Corrected in place with the measurement. Worth recording plainly: **the library
  already carried this rule and this session violated it anyway**, first by using tiktoken
  for a Claude budget and then by *rejecting* the correct figure with a sanity check
  calibrated on the wrong tokenizer.

### Fixed

- **Dependabot PRs can now pass CI — by giving Dependabot the secret, not by exempting it.**
  Its branches are same-repo, so CI's *"Require denylist secret on trusted runs"* step
  applies, but Dependabot's token is denied **repository** secrets — so `SOTA_DENYLIST` read
  empty and `Repository invariants` failed. The gate was **right**: on such a run invariant
  3's authoritative denylist scan genuinely is not running. Fixed by adding the secret to the
  separate **Dependabot** store (which was empty), never by exempting `dependabot[bot]` —
  that would have re-introduced exactly the silent degradation the step was built to catch.
  Verified by re-running PR #281 rather than assuming: invariant 3 passes with the secret
  injected. `CONTRIBUTING.md` records the value shape (**pipe-joined ERE**, matching how
  `check-invariants.sh` consumes the env var) and that a Dependabot PR opened before a
  release also trips invariant 5 until `gh pr update-branch`.
- **A prose comment Dependabot does not maintain.** `ci.yml` named `actions/checkout v7.0.0`
  in a comment above the first pin; Dependabot rewrites the trailing `# vX.Y.Z` on each
  `uses:` line and not that one, so it went stale the moment the v7.0.1 bump merged. Fixed by
  **not naming a version there at all** — one source of truth per fact.

## [1.28.0] - 2026-08-26

**Front door checked:** process substitution · upsert

### Added

- **`evals/run-router-length.py` — a new instrument, and the answer to a question the
  500-line cap had been standing in for.** The cap is *our* invariant mirroring platform
  guidance, **not** a loader limit: nothing truncates a skill at load. So the real question
  was whether routing degrades as the router grows, and nobody had measured it. It does
  not: recall stayed **flat at 1.000** at 501 / 902 / 1,302 lines (~40k prompt tokens) with
  the routing table pushed 800 lines deeper, while the untreated arm reproduced **0.867** —
  exactly the 2026-08-25 figure, and a free negative control since it cannot see the router.
  Filler is signal-free by construction. **Two limits published with it**: the metric is
  **at ceiling**, and inert filler tests length/depth but **not competition between real
  rules** (now ROADMAP item 25, unmeasured).
  [ROUTER-LENGTH](evals/results/2026-08-26/ROUTER-LENGTH.md).


- **The coupling is now stated in four places, because it fails silently in three.**
  Adding to §BUILD or §AUDIT usually means editing another file too: `rules/02` §5 tables
  BUILD's four surfaces, new `rules/01` §10 tables AUDIT's two (and says plainly that
  **nothing catches AUDIT divergence automatically**), the router's own two sections carry
  a one-line warning, and `CONTRIBUTING.md` explains it for humans.
- **`ROUTER_BUILD_SHA` guidance sharpened by having to follow it.** The rule first written
  as "never the hash alone" was unfollowable when only prose moved. It now says: re-read
  the mirror against the new §BUILD **clause by clause**, then state in the commit which
  case it is — *an imperative changed* (re-sync first) or *only prose moved* (hash alone is
  correct). Both of this change's two pin trips were resolved that way, verified.

- **Seven rules from a field brief — a session that *used* the library reporting defects
  it did not prevent.** Each landed with its audit-checklist half in the same change.
  Three of the brief's falsifiable claims were **reproduced on a real machine before
  adoption**: `$( )` newline stripping, BSD `chmod --` rejection, and a `git rev-list`
  usage error (exit 129) vanishing into a process substitution.
  - `sota-shell-scripting` **rules/01 §2** — **`$( )` strips every trailing newline**,
    silently, breaking line-oriented composition. Matters most where the bytes are hashed
    or signed: a writer and a verifier that disagree about one byte each look correct
    alone.
  - `sota-shell-scripting` **rules/02 §4** — **the trade process substitution makes.** The
    rule recommended `< <(cmd)` over a pipe and stopped; it never said the status is
    unreachable, `pipefail` does not apply, and a failed producer yields zero lines so the
    loop reports success over an empty set. **A rule in this library, followed literally,
    produced a vacuous pass.** Also **§5** (`--` is not portable — BSD `chmod` rejects it
    while `mkdir` accepts it, and the error names the wrong thing), **§4** (`head -1` over
    unordered output — test with two elements, never one), and **§9** ("append" to a keyed
    store is an **upsert**, which silently deletes the link target of a hash chain).
  - `sota-code-security` **rules/14 §4a** — **a control keyed to a neighbouring setting
    instead of its own dependency.** A *coupling* defect no per-file review or per-gate
    probe can see, because the control's own site never changes.
  - `sota-code-security` **rules/12 §2.1** — a fifth instrument failure mode: **a probe
    that exercises a neighbouring property**. It explains how the other six survived a
    green suite.
  - **Router**: cross-cutting rule 17 now routes evidence-producing shell (attestations,
    ledgers, gate records) to `sota-code-security` rules/10 + rules/12; BUILD step 4 adds
    **read back the artifact this run produced**. Both paid for by compressing existing
    text — the router is at **500/500** and invariant 1 fails at 501, verified by watching
    it fail.

### Changed


- **The router gave back its headroom: BUILD/AUDIT detail moved into `skills/sota/rules/`,
  loaded on demand.** `skills/sota/SKILL.md` went **500 → 484 lines** (16 spare, after
  sitting at the cap since 2026-07-30) without losing an imperative. §BUILD 37 → 28 lines,
  §AUDIT 63 → 54.
  - **New `skills/sota/rules/02-build-workflow.md`** — the reasoning behind the four BUILD
    steps: why loading lean is correctness rather than economy, why a plan item must be
    checkable, why the self-audit gate runs LAST, and the two questions that catch inert
    work.
  - **Most of what left §AUDIT was duplication, not detail.** `rules/01` already carried
    the severity model (§4), recon (§2), decision-ledger (§6), refutation (§7) and report
    structure (§8); the router now points at them instead of restating them.
  - **Measured first, not assumed.** A length sweep on `cases/router.jsonl`
    (`claude-sonnet-5`, 3 samples, temp 0.7) found routing recall **flat at 1.000** with
    the router padded to 902 and 1,302 lines and the routing table pushed 800 lines deeper
    — while the untreated arm reproduced **0.867** exactly, as on 2026-08-25. So length was
    never the thing to fear; **per-load cost is** — the router is **16,934 tokens**
    (`count_tokens`, `claude-sonnet-5`), ~3.4× the ~5k guidance, paid by every task.
    Offloading detail cuts that; raising the cap would have raised it.
  - **A compression audit came back clean.** Of 51 concept anchors that ever existed in the
    router, **49 are present today**; the two absent are a rewording of the same rule and
    one superseded by a stronger rule whose substance moved to `rules/01` §5. Nothing was
    quietly dropped to fit the cap.



- **`ROUTER_BUILD_SHA` re-synced** after the BUILD step 4 edit. The guard **aborted the
  eval, as designed**, and the mirror was updated with the new clause rather than the hash
  bumped alone — bumping alone is precisely the drift it exists to prevent. **Consequence:
  the completeness treatment arm now carries one extra clause, so the next run is not
  strictly comparable to the +0.38 measured 2026-08-21.** Stated now rather than
  discovered later.

### Fixed

- **A documented token count that was 60% wrong.** `docs/CONTEXT-MANAGEMENT.md` carried the
  router at *"~10,211 tokens — 2× the budget"*, from a chars/4 heuristic. Measured with
  `POST /v1/messages/count_tokens`: **16,934** at 500 lines, **16,442** at 484 — **3.3×**.
  OpenAI's `o200k_base` gives 10,995 for the same file, so the heuristic was calibrated on
  the wrong tokenizer; Anthropic's is ~1.5–1.8× less efficient on this text. **Count, never
  estimate** (ROADMAP item 27).
- **Stale "the router is full" claims**, now that it is not: `AGENTS.md` (and `CLAUDE.md`,
  its symlink), `docs/CONTEXT-MANAGEMENT.md`'s size table and two paragraphs, and ROADMAP
  item 4 — which also claimed "2×" and is now the measured 3.3×. The dated
  *"as of 2026-08-05"* blocks were **superseded, not edited**.
- **Negative-control probe 6 made count-agnostic.** It hardcoded `300 files` from the README
  hero, so adding `sota/rules/02` (300 → 301) made its mutation inert and CI reported
  **PROBE BROKEN** — correctly blaming the probe, not the gate. Second occurrence (the first
  was 298 → 300 on 2026-08-20). It now matches whatever numbers the README carries while
  still asserting the mutation landed. Worth recording: it **passed locally at 25/25** first,
  because the harness mutates a worktree at **HEAD** — a local pass on a probe whose literal
  your working tree just changed is not evidence.


- **`*.local.md` and friends are now gitignored.** A field report naming a private
  repository sat **untracked but not ignored** in a public repo while `git add -A` ran
  several times in the same session; it escaped only because it was created afterwards.
  Verified by the real test — `git add -A` now leaves it unstaged.

## [1.27.0] - 2026-08-26

**Front door checked:** selection bias · freshness set

### Added

- **Dependabot, scoped to the one supply-chain surface that exists.**
  `.github/dependabot.yml` watches **`github-actions` only** — the library is Markdown
  and every script is stdlib-only Python or POSIX shell, so there is no pip/npm manifest.
  The five `actions/checkout` pins now carry a readable `# v7.0.0` comment beside the SHA
  (pinned by SHA because a tag is mutable — `sota-devsecops` rules/01). Minor and patch
  bumps are grouped into one weekly PR. **The pin was deliberately NOT bumped**: v7.0.1
  is out, so Dependabot's first PR is the evidence the automation actually runs, and a
  config that watches nothing is indistinguishable from one that works
  (`sota-code-security` rules/10). **It fired within the hour** — PR #281 bumped the
  pin to v7.0.1 with the SHA matching the real tag and the version comment correctly
  rewritten, so both the automation and the pin convention are proven. It also
  **immediately exposed a CI gap**: Dependabot branches are same-repo, so the
  *Require denylist secret on trusted runs* step runs, but Dependabot's token is denied
  repo secrets — so its PRs fail `Repository invariants`. The gate is right (invariant
  3's authoritative scan really isn't running there); the fix is a Dependabot-scoped
  `SOTA_DENYLIST` secret, and it is left as an open decision in ROADMAP item 22 rather
  than resolved by weakening the step.
- **`sota-llm-engineering` rules/01 §8 — selection bias in eval-set construction**, with
  its audit-checklist half in the same change. Distinct from the contamination bullet
  above it: that tunes the *prompt* against the set, this builds the *set* from outcomes.
  Keep the cases a model failed and the gap you report was guaranteed before either arm
  ran. Found by nearly doing it — 10 of the old 32 freshness cases still discriminated,
  and reporting those alone would have produced a large number measuring nothing.

### Fixed

- **A stale README claim that understated our own evidence.** "Across seven instruments"
  had read seven since the audit question closed at **nine instruments, four designs** on
  2026-08-14 (`evals/results/RESULTS.md`). The same drift was caught once before at the
  v1.22.9 cut — found again by re-reading prose at the cut, which is the only thing that
  catches it. Remaining "seven instruments" strings are all correctly-dated historical
  records and were **superseded, not edited**.
- `docs/INDEX.md` now indexes the 2026-08-25 write-ups (freshness ageing, and routing on
  a current model), which were reachable only from the scoreboard.

- **A refreshed freshness set — ROADMAP item 21 closed the same day it was opened, and it
  settles item 20's open question.** `evals/cases/freshness-2026.jsonl` (10 cases, authored
  2026-08-25 from facts whose primary source changed Sept 2025 – Aug 2026) reads
  **0.33 → 1.00, +0.67** on `claude-sonnet-5` — *higher* than the original +0.53, measured
  on the same model the same day as the aged set's +0.30. Predictions were again
  **committed before the first API call** (`024abb9`); all held, neither falsifier fired.
  - **This proves the item-20 explanation by construction.** The guidance did not improve
    between two runs an hour apart; the questions got newer. A freshness lift is a function
    of **when its questions were written**, and must be quoted with that date the way every
    other number is quoted with its model. Freshness is a *renewable* knowledge gap — it
    decays from the authoring date, not toward zero, so long as someone keeps authoring.
  - **The selection rule is the load-bearing part** and lives in the case file's header:
    recency + the library states the fact, **never model performance**. That shortcut was
    available — 10 of the old 32 cases still discriminate — and picking those would
    guarantee a large lift while measuring nothing.
  - The with-library arm is a **zero-variance 1.00** across 3 samples, independently
    corroborating the hand verification of all ten facts against ten primary sources. The
    unguided arm fabricates with the right shape: **RFC 9840/9841** for the real 9990/9991,
    Rust 1.87 for 1.96, Prometheus 3.5 for 3.8, both dates off by days.
  - Limits published with it: 10 cases means **one case is 0.10**; two questions
    (TypeScript 6.0/7.0) telegraph each other and inflate the *without* arm — against the
    reported result, not for it; 4 of 10 were answerable unaided. The old 32-case set is
    kept **unedited** as the continuity series.
  - Chart, README, `docs/WHY-IT-WORKS.md`, `evals/README.md` and the scoreboard updated;
    `assets/lift-*` regenerated with the third freshness bar.

### Fixed

- **A rot-prone version pin that had rotted, found while verifying facts for the set
  above.** `sota-network-security` rules/02 claimed *"Cilium 1.19 (verified current line,
  2026)"*; the GitHub API returns **v1.20.1, published 2026-08-18**. Fixed by **removing
  the pin**, not bumping it — the repo's own policy is that skills never claim "the current
  release is X.Y" precisely because it rots. The same line said Cilium *"is the user's
  CNI"*, phrasing guidance as an assumption about the reader's setup, which the conventions
  forbid; now generic. **No freshness case was authored on this fact** — a set must not
  measure content written alongside it.
- **A recurring false-positive report on an eval fixture, answered durably.** PR #249 /
  issue #239 flagged `evals/cases/build-safe/reference-safe/db.py` as SQL injection. It is
  not: `column` is a value from a hardcoded two-entry allowlist and any other `sort` raises,
  so only two literals can reach the f-string — the allowlist-mapped-identifier pattern,
  which is the *correct* control since an identifier cannot be a bound parameter. The file
  is also the known-good fixture `run-build-safe.py --selftest` pins at **1.000**. Closed
  with the evidence, and the reasoning is now a comment in the file so the next scanner pass
  has it inline; `--selftest` re-run to confirm the comment did not perturb scoring.

### Changed

- **Freshness and routing re-measured on the current flagship — ROADMAP item 20 closed,
  and a pre-registered prediction refuted.** `claude-sonnet-5`, `evals/run-clean.py`, the
  same 3×/temp-0.7 protocol as the 2026-07 originals. Predictions were **committed before
  the first API call** (`91ca8d9`), per operating principle 0.
  - **Routing holds — and has *not* saturated.** 0.87 → 0.99, **+0.13** (was 0.90 → 1.00,
    +0.10). Read as unchanged: 20 cases means one missed case is 0.05, and the whole move
    is 0.03. Its falsifier (`lift ≤ 0.02`) did not trigger, unlike both neighbouring
    routing/audit instruments which sit at +0.00. The unguided arm still misses the same
    **rule-driven** routes a model generation later — testing, sandboxing, code-security,
    web-frameworks.
  - **Freshness erodes: +0.53 → +0.30 — and the reason is the instrument, not the
    library.** The with-library arm *rose* (0.97 → 0.99); the **unguided** arm rose far
    more (0.44 → 0.69). Case-level diff: **8 of the 32 facts moved inside `sonnet-5`'s
    training window**, 1 newly missed, 10 still outside it. The prediction that "a training
    cutoff is a knowledge gap model progress cannot close" is **refuted** — the cutoff
    advances into a *fixed* set.
  - **This produces a third claim-shape the knowledge/salience dichotomy missed.** Not
    two outcomes but three: **expired** (defect-avoidance, +0.19 → +0.000 — a closable
    knowledge gap), **durable** (completeness, +0.39 → +0.38 — a salience gap), and
    **eroding** (freshness — a *renewable* knowledge gap that decays toward a floor as a
    fixed question set ages, but never closes, because the world keeps producing facts).
  - The one with-library miss was **run down rather than waved through**: `f02` (OWASP Top
    10 2025 "Insecure Design") is `A06`, verified at run time against `owasp.org/Top10/2025/`,
    and `sota-code-security/rules/09`:10 states it correctly — so neither a stale library
    nor a bad key, but an in-context fact losing to a confident prior (it was A04 in 2021).
  - New **ROADMAP item 21**: the freshness set is fixed and ageing, so it under-reads its
    own claim by construction. Quote freshness as *a floor of +0.30 on an ageing set*.
  - **New front-door chart** (`assets/lift-{light,dark}.{svg,png}`, generated by
    `assets/gen-lift-chart.py`): every headline dimension, both arms, on **two model
    generations** — so the three shapes are visible rather than argued. Embedded in
    `README.md`, `docs/WHY-IT-WORKS.md` and `evals/results/RESULTS.md`. Nothing was
    *re*-generated: the two existing charts plot **completeness** (competitor benchmark
    and breadth-by-domain), whose numbers did not move, and no prior image showed
    freshness or routing at all. `CONTRIBUTING.md` now documents all three generators
    and warns that **invariant 12 does not cover them** (it pairs `*.html` with
    `*.png`), so a stale chart is caught by nobody.
  - Full write-up, scorecard and limits:
    [evals/results/2026-08-25/ITEM-20-FRESHNESS-ROUTING.md](evals/results/2026-08-25/ITEM-20-FRESHNESS-ROUTING.md);
    pre-registration: [PREREGISTRATION.md](evals/results/2026-08-25/PREREGISTRATION.md).
    Surfaces updated: `README.md`, `evals/README.md`, `evals/results/RESULTS.md`,
    `docs/WHY-IT-WORKS.md`, `docs/ROADMAP.md` (items 17, 20, 21). Cost ~$0.77 against a
    ~$0.77 estimate.

- **Recorded a rejection: TOON as the skill-file format** — no library change, a decision
  logged so it is not re-litigated. [TOON](https://github.com/toon-format/toon) sells token
  savings against a **JSON** baseline; Markdown already does its one trick (hoist repeated
  keys into a header row), so converting the largest table in the library — the router's
  42-row routing table — measured **9,992 → 9,802 bytes, 1.9%**, and table rows are only
  **3.1%** of the 63,885 instruction lines. Its retrieval benchmark is *data lookup*, which
  does not transfer to imperatives, and a rewrite would break invariants 2, 4, 8, 10, 15 and
  18 plus the negative-control probes. Full measurement, the byte-vs-token caveat, and the
  revisit condition: [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md) 2026-08-25.

## [1.26.0] - 2026-08-22

**Front door checked:** principle 9 · salience · truncation

### Added

- **Router operating principle 9 — match the rigour to the stakes, and name the level you
  chose.** The one criticism from an outside assessment that survived checking: a search
  for any proportionality rule found a single hit, in `sota-docs-workflow/rules/05`, which
  a "quick script" task never loads. So a spike or one-off gets built and *labelled* as
  one; anything reachable by an untrusted caller or touching money, credentials or another
  tenant's data gets the full treatment including principle 5, *whether or not the request
  said "quick"*. The load-bearing clause is the last: **an unnamed shortcut is not a
  prototype** — proportionality is granted, silence is not.
  **Re-baselined, because it sits inside the block `principle5()` extracts** (ROADMAP item
  4's "trim and re-baseline together"): before **0.60 → 0.99 (+0.39)**, after **0.57 →
  0.97 (+0.40)**. The before-run reproduces the published headline exactly. The `with`
  arm's −0.02 is **not evidence of harm**, and the reason is the control: the `without`
  arm never sees the router and moved **0.60 → 0.57** between two identical runs, so
  `temp 0.0` is not deterministic and the treated arm's movement sits inside the band the
  untreated arm demonstrated. Router now **500/500** lines.
  [Full method and limits](evals/results/2026-08-21/PRINCIPLE-9-REBASELINE.md)

- **Completeness re-measured on the current flagship — and it did *not* expire.**
  `claude-sonnet-5` (Jun 2026): **0.62 → 1.00, +0.38**, against +0.39/+0.40 on
  `claude-sonnet-4.6` — unchanged within the ±0.03 noise floor, judge held constant,
  **zero truncation warnings** so it is a measurement and not a floor. This was the open
  question left by defect-avoidance going to +0.000 on the same model pair.
  **The pair explains itself, and the explanation is the valuable part.** Newer models
  stopped *writing* known-bad patterns, but `sonnet-5` unguided still omits **tests in 7
  of 7 tasks**, transport in 5, rate limiting in 5 — the same blind spots as its
  predecessor. So: **knowledge gaps close with model progress; salience gaps do not.**
  Adding rate limiting to an endpoint nobody mentioned is not something a model doesn't
  know — it is something it doesn't think of while doing something else. That reframes the
  durable value: not telling a model what it doesn't know, but making cross-cutting
  concerns salient at the moment of writing — a failure that scales with task length and
  context pressure rather than model weakness, consistent with this project's own
  root-cause work. README, `WHY-IT-WORKS.md` and the scoreboard updated;
  [method and limits](evals/results/2026-08-21/COMPLETENESS-SONNET-5.md).

- **Two harness conventions from the re-baseline** (`evals/README.md`, ROADMAP item 18).
  **`temp 0` is not deterministic**: the *untreated* arm — whose prompt is `case["task"]`
  alone and which cannot see the router — moved **0.60 → 0.57** between two otherwise
  identical runs, so the noise floor is ≈**±0.03** at n=1 and any single-sample delta below
  ≈0.05 is unresolvable. Which gives the useful move: **an arm that cannot see the
  treatment is a free negative control for your own measurement — read it before
  interpreting the treated arm.** And: **never edit a file the runner reads live while a
  run is in flight** — `principle5()` is read per prompt, so a mid-run edit measures some
  cases against the old text and some against the new. That happened, was caught, and the
  run was discarded and redone from a stashed clean tree.

- **The guided arm's runner is now in the repo.** `run-build-safe-arms.py` only ever
  covered the unguided arm — the guided one lived in a scratch file, so the published
  number could not actually be reproduced from the repository. Committed as
  `evals/run-build-safe-arms-guided.py`, with the raw per-run gpt-5.1 scores.

### Changed

- **Every headline claim now names the model it was measured on.** A lift is a gap
  between a model and a standard, and **the model side moves** — on 2026-08-21 the
  defect-avoidance row went from **+0.19** on `claude-sonnet-4.6` to **+0.000** on
  `claude-sonnet-5`, whose *unguided* strict score equals what `sonnet-4.6` scored **with**
  the library. Four months of model progress absorbed the result. Until now every number
  in `README.md` and `WHY-IT-WORKS.md` was model-unattributed and therefore read as
  current. `WHY-IT-WORKS.md` gains a section stating the frame plainly — where a model is
  already strong the library adds nothing measurable; where it is weak (older, cheaper,
  unusual tasks, thin training data) it closes the gap — and records that **completeness,
  freshness and routing have *not* been re-measured on a current flagship**, as an open
  question rather than an assumption (ROADMAP item 17).

- **On current flagship models the defect-avoidance gap is closed.** `claude-sonnet-5`
  (2026-06) scores **+0.000** on `avoided` and **+0.024** on the strict measure — and its
  *unguided* strict score (0.619) is exactly what `sonnet-4.6` scored **with** the
  library. Four months of model progress absorbed the measured gap, so the result is
  **historical, not current**, and is now labelled that way alongside the gpt-5.1 row.

- **The pipeline rule generalises: the hazard is not `tail`, it is any filter chosen
  before you know what the output contains** (`sota-shell-scripting/rules/01` §3). A
  reported fourth case: `tool compare … | grep -E "baseline|current|LOST|GAINED"` silently
  discarded `!! GRAPH CHANGED: 245827 -> 245808 …` — a guard that had **fired** — and the
  conclusion forming from what survived was that the guard was *inert*, i.e. a defect
  report about working code. **`grep` is the more dangerous form precisely because it
  reads as selective rather than lossy**: the line you did not think to match is the one
  worth reading. `head`, `tail`, `grep`, `awk`, `cut` and `jq` all destroy output
  selectively, so the remedy is stated as the general one — **redirect first, filter the
  file afterwards**, because a saved file can be re-grepped once the first pattern proves
  wrong and a consumed pipe cannot. Second checklist item added.

- **The defect-avoidance headline is now qualified by a second model — which does not
  replicate it.** On `openai/gpt-5.1` (the model this project already uses for cross-model
  de-risking) the **unguided** arm scores **1.000 × 3**: it does not write these defects
  unaided, so there is no headroom and Δ avoided is **+0.000**, against **+0.191** on
  `claude-sonnet-4.6`. The `+0.19` is **baseline-dependent and must not be quoted
  unqualified** — README, `WHY-IT-WORKS.md`, the scoreboard and the write-up were all
  re-qualified the same day rather than left implying generality.
  This is the same law the five-domain breadth test already measured for completeness —
  *the lead tracks the unguided baseline* — arriving on a new axis: there, not the domain;
  here, not the model. **What survives on both models is the stricter measure**, because
  neither bare arm saturates there: **+0.33** sonnet, **+0.10** gpt-5.1. So the defensible
  claim is *"closes a defect-avoidance gap where one exists"*; *"prevents these defects"*
  is not one this project makes.

- **`evals/run-completeness.py` gains `--max-tokens`.** The build call had `32000`
  hardcoded. It never bound `claude-sonnet-4.6` (verified: zero truncation warnings across
  both runs on 2026-08-21, so those numbers are measurements and not floors), but newer
  models are far more verbose and a bound cap would silently turn the treated arm into a
  floor — manufacturing exactly the erosion one would be testing for.

### Fixed

- **The build-safe scorer had no truncation awareness and graded a truncated build.** A
  `claude-sonnet-5` run hit `finish_reason=length` at exactly 128,000/128,000 tokens;
  including it produced **negative** deltas that were pure artifact, since absent
  safe-path code in a truncated build is the part that was cut off. Drivers now write
  `.build-meta.json` beside the build and `run-build-safe.py` **refuses** to score a
  truncated one unless `--allow-truncated` is passed and the number is called a floor.
  `sota-code-security` rules/10 §2.7 arriving in our own harness. Watched to fail both
  ways; the selftest still separates 0.000/1.000.

## [1.25.0] - 2026-08-21

**A new axis, and two instruments that had to prove themselves first.** Every lift this
project had published measures what a model *puts into* code. This release adds the one
that measures what it **leaves out**: from a spec that states operational pressure and
never names a defect, an unguided model writes SQL injection and a missing ownership
check — with the library it writes neither (**0.81 → 1.00**, and **0.29 → 0.62** on the
stricter reading that also demands positive evidence of the safe path).

That result is worth more than its size because of what sits beside it: the audit half of
this library scores **+0.00** on these same classes, published across nine null rows. A
frontier model already *finds* them. So the value was never detection — it is that the
code arrives without the defect.

**Calibration** was measured too, and is deliberately **not** reported as a lift: it
measures adherence to this project's own reporting doctrine, and is kept off the headline
scoreboard for that reason.

Also: a pipeline destroys output as well as status — `pipefail` fixes only one of them —
and both deferred intake ideas from 2026-08-17 landed with their audit halves.

**Front door checked:** calibration · positive evidence of the safe path · pipefail

### Changed

- **Documentation caught up with the two evals, including a claim they falsified.**
  `evals/results/RESULTS.md` said calibration *"remains measurable"* — it was measured on
  2026-08-21, so it now says so, with the result and the standing rule that it is never
  reported as a lift. `evals/README.md` documents both new instruments under **Cases**,
  including the two facts a future reader needs before trusting either: build-safe's file
  is **7 real cases inside 49 lines** (42 comments), and the calibration judge is
  worthless unless its two controls separate first. `docs/INDEX.md` and
  `WHY-IT-WORKS.md`'s *Reproduce it* block gained the new runners.
- **The July "not a result" write-up now points forward.** `results/2026-07-30/BUILD-SAFE.md`
  recorded a failed instrument (bare arm at ceiling, spec leaking the property to
  preserve). Its diagnosis was right and the fix worked, so it carries a superseded
  banner to the 2026-08-21 re-run — and is otherwise **left unedited**, because a record
  of a failed attempt is worth more intact than tidied.


- **The front door now carries the defects avoided result, framed as the new axis it
  is.** Every previously published lift measures what the model *puts into* code;
  `README.md` and [WHY-IT-WORKS.md](docs/WHY-IT-WORKS.md) now carry the one that measures
  what it **leaves out** — **0.81 → 1.00** on seven defect classes under a spec that
  states operational pressure and never names a defect, and **0.29 → 0.62** on the
  stricter reading that also demands positive evidence of the safe path. The argument
  attached to it is the one worth making: **the audit half of this library scores +0.00
  on these same classes** — a frontier model already finds them — so the value was never
  detection, it is that the code arrives without the defect. Both surfaces carry the
  pilot's limits inline (n=3, treated arm at ceiling, single model, and prompt length as
  an uncontrolled confound) rather than in a footnote.
- **Calibration is on `WHY-IT-WORKS.md` and deliberately *not* sold as a lift** — stated
  there in those words. It measures adherence to this project's own reporting doctrine,
  and a project that scored its own house rules and called it efficacy would deserve the
  scepticism. It is included so a reader deciding whether to trust audit output knows the
  reports hedge where evidence is thin.

### Fixed

- **README understated its own nulls: "Seven +0.00 rows" when the scoreboard has nine.**
  Corrected, with the old wording noted in place. This is the same shape as the
  "seven instruments" drift found at the v1.22.9 cut — a count that moved while the prose
  did not, and in the direction that makes the project look *less* honest than it is.


- **The BUILD-safe pilot ran, and the bare arm did not saturate** — so the instrument
  discriminates and the question the roadmap carried as untested is answered. Unguided
  **0.809** mean (0.714 / 0.714 / 1.000), with-library **1.000** × 3: **Δ +0.19 avoided**,
  **Δ +0.33** on the stricter *avoided-with-positive-evidence* measure. The two classes
  the unguided arm actually wrote were `ORDER BY {sort}` interpolation and a missing
  ownership check. Seven audit instruments read +0.00 because a frontier model **finds**
  these classes unaided; this is the first evidence about whether the library stops them
  being **written**. Instrument validated before the arms were read (`--selftest`: 0.000
  known-bad, 1.000 known-good) and no build truncated.
- **The calibration eval exists and has been run** — recorded as *"the only untested claim
  about the audit half"*. Blinded judge, validated on both controls in the same batch
  (mis-calibrated 0/4, well-calibrated 4/4). Unguided **2.67/4**, with-library **4.00/4**;
  the mover is *conditioning severity on evidence*, **1/3 → 3/3**. **Deliberately kept out
  of the headline scoreboard and not reported as a lift**, exactly as the roadmap required
  when it was proposed — it measures adherence to this project's own reporting doctrine.
- **Three runners so the numbers are reproducible** — `evals/run-build-safe-arms.py`,
  `evals/run-calibration.py`, `evals/judge-calibration.py`, with raw per-run scores under
  `evals/results/2026-08-21/`. A measurement whose runner is not in the repo is not one
  anyone else can check.


- **A pipeline destroys output as well as status** (`sota-shell-scripting/rules/01` §3).
  The library covered the status half correctly — `$?` after a pipeline is the last
  stage's, `pipefail` and `${PIPESTATUS[0]}` are the fixes — and said nothing about the
  second failure mode of the same construct: **`pipefail` does nothing to bring destroyed
  output back**. For any command whose output you intend to *reason about*, redirect to a
  file and read the file. The asymmetry is what makes it a rule rather than a tip:
  **`tail` is selected to keep the summary line**, so a pipe preserves the number and
  discards the traceback, warnings and stderr context — the material that would tell you
  the number is wrong — and the surviving line is the one most likely to be quoted.
  Reproduced before writing (and the *first* reproduction was wrong, keeping the cause
  because it sat last): rebuilt pytest-shaped, `tail -12` destroyed
  `AssertionError: expected 16, got 4` while `1 failed, 38265 passed` survived intact.
  Corollaries: an **empty result and a discarded result are the same value**, and
  unflushed output in a `timeout`-killed process leaves a file that is empty for a reason
  unrelated to the result. Scope deliberately narrow — not "never use `tail`", but "not
  for output that is evidence for a claim". Checklist grep added; cross-referenced from
  `sota/rules/01`'s evidence standard, which now says an audit should keep the output that
  produced its findings.

## [1.24.1] - 2026-08-21

**The last two deferrals, closed with their audit halves.** Both ideas held over from the
2026-08-17 intake landed: event-sourcing **replay** preconditions (the `apply` step must
be a pure function of state and event, non-deterministic answers captured *in* the event,
outbound effects gated during replay) and **geospatial** index loss (`ST_DWithin` vs a
non-indexable `ST_Distance`, and the `geography`/`geometry` units trap). Every claim was
verified against a primary source *before* being written — Fowler's *Event Sourcing* for
the first, the PostGIS documentation for the second — and where the source did not support
the brief's framing, the rule was rewritten and the discrepancy recorded rather than
smoothed over.

Both shipped **with their audit checklist items in the same change**, which is the
discipline the previous release wrote down after finding that a fan-out across nine skills
had shipped the build half alone in seven of them.

**Front door checked:** replay · Geospatial

### Added

- **Event-sourcing replay preconditions** (`sota-architecture/rules/03` §6). Replay
  re-runs the **apply** step over old events, so that step must be a **pure function of
  (state, event)** — every wall clock, RNG, config lookup or service call it touches makes
  the rebuilt state differ from the original, silently and without an error. Verified
  against a primary source before writing: Fowler's *Event Sourcing* states the
  external-query case directly — *"if I ask for an exchange rate on December 5th and
  replay that event on December 20th, I will need the exchange rate on Dec 5"* — and
  prescribes gateways that can be disabled during replay. Two remedies, both required:
  **capture the answer in the event**, and **gate outbound effects during replay** (a
  gateway with no replay mode means replay only runs in a scratch environment, which is
  not a rebuild capability). Plus the ownership rule: the **event log carries the
  durability budget, not commands** — a lost command is a retry, a lost event is
  unrecoverable state.
- **Geospatial: the three ways the index is lost** (`sota-databases/rules/03`). Geometry
  was one word in the GiST row and three distinct traps in practice, all verified against
  the PostGIS documentation: `ST_DWithin` *"includes a bounding box comparison that makes
  use of any indexes"* while **`ST_Distance` is explicitly non-indexable**, so a distance
  in `WHERE` scans the table and returns the right answer; a hand-rolled haversine is the
  same mistake wearing maths; and the `geography`/`geometry` choice is about **units and
  extent** — `geography` is always metres and assumes EPSG:4326, `geometry` uses the
  SRID's units (degrees for 4326, where Cartesian distance is meaningless), with
  `geography`'s real costs being trigonometry and **fewer functions supporting it
  natively**. Audit with `EXPLAIN`, not by reading the SQL.
- Both landed **with their audit checklist items in the same change** — which is the
  discipline ROADMAP item 16 exists to enforce, applied to the first change after it was
  written.

### Fixed

- **An ADOPTION-LOG row said `deferred` for two days after the work shipped.** The
  `sota-rust` `std::process::Command` gap was deferred 2026-08-18 and closed 2026-08-19 as
  `rules/05` §9 (v1.22.11) — and nobody came back to the log. Verified before correcting:
  the section exists at `rules/05:221` and its checklist carries six subprocess probes.
  That is exactly what a landed-in pointer is for, so the row now carries one.

## [1.24.0] - 2026-08-21

**Checks that check themselves, and a method for the guards you leave behind.** Invariant
19 makes "every check has a known-bad" a property of the suite rather than of whoever last
edited it — it runs on every invocation, pins the exempt set so the rule cannot be
silenced by exempting your new check, and caught *itself* on introduction. Alongside it,
a field brief turned into `sota-testing` rules/02 §2.10: **which method a durable guard is
written in**, now a six-rung ladder for the common case where the language has no native
AST — and the rung that resolves types, which is the honest limit AST cannot pass.

Opengrep replaces Semgrep as the prescribed SAST engine, verified by running it rather
than by renaming: **there is no `opengrep ci`**, so a workflow copied from `semgrep ci`
does not run.

And the library was measured against its own rule. Asked whether an audit half ever
demands what the build half never asked for: four methods, three failed instruments, one
answer — **it does not**, but ~4% of build sections lack an audit probe, and the worst
cluster was **shipped that same morning by this session's own fan-out**.

**Front door checked:** self-test · Opengrep · durable guard

### Changed

- **Docs refreshed for what this cycle actually shipped.** `docs/INDEX.md` gains rows for
  the guard-authoring method ladder and for choosing a SAST engine (with the
  **no `opengrep ci`** warning at the front door, since that is the detail a copied
  workflow dies on). `docs/ROADMAP.md` item 13 re-measured — **cap watch is three files
  now**, not two: `sota-docs-workflow/rules/01` 456, `sota-code-security/rules/12` **455**
  (up from 426 as §1b, §1b.1 and the formatter-reflow trap landed), `sota-devsecops/rules/03`
  451. Items 15 and 16 record the BUILD↔AUDIT measurement and the finding that beat it.
  `AGENTS.md` back to **199** lines after invariant 19's row pushed it over its own
  `<200` target — the `--self-test` paragraph is now partly redundant with 19 being a
  numbered check, so it shrank rather than something being dropped.

### Fixed

- **Seven of the nine language rows added in the in-band-sentinel fan-out shipped with no
  audit item** — `sota-golang`, `sota-rust` (partial), `sota-c-cpp`, `sota-jvm`,
  `sota-javascript-typescript`, `sota-dotnet` and `sota-ruby`. Only Python and PHP had
  one. Each now carries a language-specific probe built from the behaviour measured when
  the row was written: producer greps for `return -1`, `strconv.Atoi` with a dropped
  error, `unwrap_or(-1)` and `#[serde(default)]` on numeric fields, `atoi`, `EOF` stored
  in a `char`, an `indexOf` result **stored rather than tested on the next line**,
  `TryParse` with a discarded `bool`, and `.to_i` on untrusted input. `sota-jvm` §6
  (module/package structure) had no probe either and gained one. Found by sampling the
  library's own BUILD↔AUDIT correspondence — i.e. the fan-out committed, that morning,
  precisely the failure the sampling exercise existed to look for.
- **`sota-golang` rules/01's in-band-sentinel subsection was unnumbered**, so `§4a` did
  not resolve; numbered to match the `1a`/`6a` pattern used in the sibling skills. Caught
  by invariant 18, which is now three-for-three at catching this session's own citations.

### Added

- **A parser ladder for languages without a native AST** (`sota-testing/rules/02` §2.10).
  "Author guards in AST" is unhelpful where AST is not at hand, which is exactly when
  people reach for regex. Six rungs, take the first that carries your claim: the
  language's own AST → a **semantic index** when the claim needs *types* or cross-file
  resolution (**CodeQL** — verified locally at 2.26.2, extractors for go, python, rust,
  java, cpp, csharp, javascript, ruby, swift plus yaml/xml/html/actions; or SCIP/LSIF) →
  a **cross-language structural matcher** (**Opengrep**; ast-grep/tree-sitter) → the
  **toolchain's own analysis API**, so the guard runs in the existing build → the
  **artifact or the runtime**, when the claim is about what *ships* or what is *live* →
  regex only where the input has no grammar. Rung 2 answers §2.10's own honest limit
  rather than working around it, and **rung 5 can be cheaper than rung 1**. Shell and
  config are explicitly not exceptions: `mvdan.cc/sh/v3/syntax` parses POSIX sh, bash and
  mksh with a `Walk`, and YAML/HCL/JSON/Dockerfile/SQL all have parsers.
- **Two audit gaps found by sampling, and fixed.** `sota-c-cpp` rules/01 §7 *Error
  handling: exceptions vs expected vs codes* is a full build section that had **no audit
  probe anywhere in the skill** — one incidental hit across seven files. It now carries
  greps for empty and swallow-all `catch` blocks, `bugprone-empty-catch` /
  `bugprone-exception-escape` / `misc-throw-by-value-catch-by-reference`, ignored error
  returns via `bugprone-unused-return-value` (aliased by `cert-err33-c`), and the question
  a grep cannot ask — whether one error model is used across a boundary or three meet at
  an ABI seam. `sota-ml-engineering` advertised **train/serve skew** twice in its own
  description while **no checklist in any of its seven rules files** mentioned skew,
  point-in-time correctness or feature stores; `rules/02` now audits all three, including
  the case where no feature store exists ("we are careful" is not a mechanism).
- **The BUILD↔AUDIT correspondence is now a stated convention** (`CONTRIBUTING.md`),
  in both directions and with its exception. Invariant 2 checks a checklist *exists*;
  nothing checked that it matches the guidance above it. An item with no build rule marks
  a team down for following the library; a build rule with no item is this library's most
  rediscovered gap. Advisory sections and checks owned by a sibling skill are exempt —
  cross-reference the owner.

### Changed

- **Opengrep replaces Semgrep as the prescribed SAST engine**, aligning
  `sota-devsecops/rules/05` §5.1 with the position `sota/rules/01` had already taken —
  the audit skill listed *"Opengrep or Semgrep CE"* while the gate file still prescribed
  Semgrep throughout. LGPL-2.1, multi-vendor consortium, rule format compatible.
  **Verified against Opengrep 1.27.1 in a container**, because a wrong command in a
  copy-pasteable CI block is the worst kind of defect: **there is no `opengrep ci`** — the
  subcommands are `scan`/`test`/`validate`/`show`/`lsp`, so a workflow copied from
  `semgrep ci` does not run, and the rule now says so. `scan --error` exits 1 on findings
  and `--baseline-commit` gives the diff-aware behaviour; `.semgrepignore` is still
  honoured and `nosem`/`nosemgrep`/`noopengrep` are all accepted, so porting the engine
  does not silently re-expose anything previously suppressed. Also swept
  `sota-devsecops` rules/07, `sota-python` rules/05, `sota-ruby` rules/04 and
  `sota-threat-modeling` rules/06.


- **`sota-testing/rules/02` §2.10 — which method a durable guard is written in.** The
  library stated a method default for an **audit search** (widen it, use a second
  independent method, say what you ran) and none for the **guard** that search leaves
  behind. The two differ in *lifetime*: a search is discarded the day it runs; a guard is
  a standing claim re-evaluated on every commit by people who will not re-derive it. So:
  **AST as the floor for structural claims, execution or interception for behavioural
  ones, mutation on both, regex only where no parser exists** — and name which, so the
  exception does not spread by imitation. Two failure modes are specific to text and
  neither is prevented by care: a guard can match a **comment about** the code it
  policies, and a file-scope check lets **one compliant site excuse every other site in
  the same file** (a real regression passed that way). Added beyond the brief: **name the
  parser, per language** — "no parser at hand" is exactly when people reach for regex, so
  that choice belongs in the same decision as the guard. Stated with its limit, because
  the phrase "AST-based" invites false confidence: **AST does not resolve types**, a name
  collision reads as live — a false *negative* — and the output is a candidate list, never
  a verdict. Three audit-checklist items; cross-referenced from `sota-code-security`
  rules/10's absence-claim bullet.

### Changed

- **Formatter reflow is now a fourth "the mutation did not take" cause**, in both homes
  (`sota-testing/rules/06` §6.3 and `sota-code-security/rules/12` §1). A multi-line revert
  can silently match nothing because `ruff format`/`black`/`prettier` folded the target
  onto one line — the most common cause in any formatted repo, and the one an
  *environmental* checklist (editable installs, stale bytecode, cached images) will never
  catch, because nothing about the environment is wrong.
- **Invariant 18's `` `NN` `` shorthand now has to sit immediately before the `§`.** It
  read a backticked configuration value — `` `16` `` — as a rules-file reference and
  reported `rules/16 ... does not exist`: a false positive on correct prose, which is the
  failure that gets a gate switched off. The explicit `rules/NN` form keeps its wide
  window. Verified discriminating rather than merely disabled: `` `02` §9 `` still
  resolves to a file with a §9 from a file that has only §1–§7. References resolved
  1,363 → 1,368.


- **Invariant 19 — every check has a known-bad, and the exempt set is pinned.** Three
  proposed refinements of the previous day's `--self-test` collapsed into one gate.
  **(a) Run it always.** The structural pass costs **49 ms** (measured), and it sat
  behind an opt-in flag — but a check you have to remember to run is a convention, not a
  property, which is precisely how **invariant 18 shipped probe-less in the very commit
  that introduced it**. **(b) Fail closed.** As a numbered check it sets `fail=1`, so a
  suite that cannot verify its own coverage prints **no `PASS` line at all**, rather than
  reporting green beside a warning nobody reads. **(c) Pin the exempt set** — the half
  with teeth. Without it, *"every check is probed or declared unprobeable"* is satisfied
  by adding your new check's number to the exempt list, a one-line way to silence the
  check that exists to stop you. `EXPECTED_UNPROBED` is a **tripwire, not a cached
  count**: nothing derives it, everything compares against it, so growing it is a
  deliberate edit a reviewer sees. It **caught itself** on introduction (`check 19 has no
  known-bad`) — the shortest demonstration available that it works. Watched to fail three
  ways: a deleted probe, a check exempted instead of probed (`GREW by [13]`), and a pin
  left stale in the *good* direction. `--self-test` survives with a narrower meaning —
  run the suite, then run the harness. Harness now **25 probes, 14 of 19**.

### Changed

- **Probe 17's mutation is derived rather than pinned.** Its literal is the invariant
  count, so it goes stale every time a check is added — twice on 2026-08-20 alone, each
  surfacing as `PROBE BROKEN` rather than as a defect. That is the landed-assertion guard
  working, and also a recurring cost. It now decrements whatever count is present, with
  its expected substring trimmed to the part that does not move. Every *other* probe
  keeps its hardcoded literal deliberately; this one is the exception because its literal
  tracks a number the repo changes on purpose.

### Fixed

- **Invariant 18's heading parser read `### 1b.1` as heading `1b`** — the letter suffix
  bound only to the last component. Adding a `§1b.1` subsection therefore re-satisfied a
  `§1b` reference even after `## 1b.` was renamed, so **negative-control probe 18 went
  INERT**: the gate reported healthy while verifying nothing. Caught by the harness on
  the very commit that introduced the subsection, not by review — which is the whole
  argument for running it. `2.2a` and `8a` parse unchanged; `1b.1` now parses as itself.
  Clean tree: 1,349 → 1,363 references resolved.

### Added

- **Four cross-references that make the same day's own additions reachable.** Each class
  shipped in v1.23.0/v1.23.1 was stated where the incident happened and nowhere else,
  which is the *unreachable, not absent* shape this library keeps rediscovering. Verified
  absent in all four homes before writing:
  - `sota-devsecops/rules/05` §5.6 + checklist — the negative control belongs in a
    **`--self-test` mode of the gate runner**, not only as a fixture beside it. That file
    is the canonical home for "every security gate ships a known-bad", and a DevSecOps
    reader never loads `sota-code-security` rules/12, where the placement argument lives.
  - `sota-observability/rules/01` §5 — **"at completion" is doing real work in that
    sentence**. A line emitted mid-function attests only that *that line ran*, not that
    its result survived the filter, early return or reassignment beneath it. Site the
    claim where the value is consumed. This is the skill where people actually write log
    lines, and the rule lived only in an audit file.
  - `sota-testing/rules/06` §6.3 — **mutate and read the *output*, not the suite.** Every
    other probe in that section ends in "run the tests", which answers *is this
    constrained by a test* and cannot answer *does what this reports tell the truth*.
  - `sota-code-security/rules/12` §1b.1 — **a planned change is a legitimate source of a
    gate**, with the caution that the "has it already failed?" filter reads *no* at
    proposal time *by construction* for a class nothing reports.

## [1.23.1] - 2026-08-20

**A count that is computed, and still false.** `rules/14` §1 already banned reported
numbers printed as literals — they must be *computed from the artifact produced*. A
field brief showed a defect that satisfies exactly that and lies anyway: the count was
computed, from a real collection, at a line that really ran, and described work that no
longer left the function. The narrowing is **compute it from what you returned**, and
the structural reason is that **no function can attest to its own return value** —
every emission site has a suffix that can drop the result after the line is written. So
site the claim in the consumer, and probe it by mutating the application and reading the
output rather than re-running the suite.

**Front door checked:** attest to its own return value · only witness

### Added

- **`sota-code-security/rules/14` §1 — computed is not enough; compute it from what you
  *returned*.** §1 already required every reported number to be **computed from the
  artifact it produced** rather than printed as a literal. A number derived from an
  **intermediate the function later discards** satisfies that reading and still lies:
  `len(mandatory)` logged beside the computation kept printing `1 adjudicated` after
  `return mandatory + sampled` became `return sampled` — computed, from a real
  collection, at a line that really ran, describing work that no longer left the
  function. **A function cannot attest to its own return value**, because every emission
  site has a *suffix* — a filter, an early return, an exception path, a reassignment —
  that can drop the result after the line is written. So **site the claim in the
  consumer**, derived from the value received: a producer may log its *intent*, only the
  consumer reports the *effect*. That is the reporting-output twin of `sota-kubernetes`
  rules/04 §7 (a success log is a claim about what was decided, not what landed), and a
  class generalising across two unrelated domains is worth stating plainly. **Probe it by
  mutating the application and reading the output, not the test suite** — `rules/12` §1's
  probe answers *is this tested*, which comes apart from *does the log tell the truth*
  exactly where it matters: an **unattended run has the log as its only witness**, so a
  log unchanged by the mutation is itself the finding. Two audit-checklist items added.
- **Cross-references at both anchors the class sits between.** `rules/11` §2.4 said
  silence is not evidence of health; it now states the harder inverse — **speech is not
  either**, when the claim is sited upstream of the effect it describes. And §2.5's "make
  the new branch emit exactly once" gains its **placement precondition**: an emission
  proves the line it sits on ran, not that its result survived the rest of the function.
- **A third instance of §1's own keyword-vs-shape trap, recorded in place.** The
  reporter's first test for this defect **failed on its own explanatory comment**, which
  quoted the log line it was hunting for — matching the words instead of the emission,
  while writing the detector for the paragraph that warns against it.

### Changed

- **README hero line: `~63k` → `~64k` lines.** Caught by invariant 6 rather than by eye
  (`README hero ~k-lines: says '63', tree says '64'`); the tree reads 63,501.

## [1.23.0] - 2026-08-20

**Build the gate before the refactor that needs it.** Splitting two capped rules files
would have broken a class of cross-reference nothing checked — so the check came first.
It found **six live defects on the unmodified tree** before a line moved, then caught
**27 more** that the split itself broke across eight skills. Applying the ledger's three
filters at *proposal* time, "has it already failed?" read **no**; running the check
answered it retroactively. A planned change is a legitimate second source of gates,
because *"what would this break that nothing would tell me about?"* points straight at
the class that fails silently.

Also: a three-idea intake where two were covered as *classes* and missing as
*mechanisms*, the in-band sentinel measured across nine languages (two rows changed on
measurement rather than being confirmed), the last unmeasured subprocess row closed in a
container, and this repo finally practising the rule it published that morning.

**Front door checked:** self-test · section reference · in-band sentinel

### Added

- **`check-invariants.sh --self-test` — the repo now practises the rule it published
  the same day.** `sota-code-security` rules/12 §1b argues a negative control belongs
  *inside* the tool, so *"every check can go red"* is a property of the suite rather
  than of whoever last edited it. This repo did not do that: the probes lived only in
  `check-negative-controls.sh`, and remembering to add one was **a sentence in
  `AGENTS.md`** — prose which did not stop **invariant 18 shipping probe-less in its own
  commit**. The structural pass runs in a second and fails on any check that is neither
  probed nor declared unprobeable, so "I'll add the probe later" is no longer possible.
  Both sets are **derived from the harness itself** — the `probe N` calls and the
  numbers in its own *NOT COVERED* block — so there is no second list to drift out of
  sync. It then hands off to the harness, which watches each check actually fail.
  Watched to fail on two mutations (a deleted `probe 13`; a probe added for the
  declared-unprobeable check 5), with the clean tree reporting *18 checks: 13 probed,
  5 declared unprobeable, 0 unaccounted*. The probe **count** stays deliberately
  ungated — a static count of call sites reads 13 against an actual 24.


- **The Java subprocess row, measured at last — and it changed three claims.** Run on
  **Temurin 25.0.3** in a podman container, because no JDK is installed on the machine
  that wrote every other row. `ProcessBuilder` is confirmed (no whitespace splitting,
  no shell: `ProcessBuilder("echo", "$HOME")` prints `$HOME` literally). What the row
  did *not* say: **`Runtime.getRuntime().exec(String)` tokenizes on whitespace** — the
  `shell:true` of Java — and the JDK says so itself, all three `String`-taking
  overloads carrying `@Deprecated(since="18", forRemoval=false)` while the `String[]`
  ones carry nothing, read off `Runtime.class` by reflection rather than from docs.
  On deadlines, `waitFor(t, unit)` fires on schedule (2003 ms on a 2 s budget) and
  **returns `false`**, so unlike Node the caller *is* told; `destroy()` reaps only the
  direct child and orphans a pipe-holding grandchild; and **`Process.descendants()` +
  `destroyForcibly()` does kill the tree** — making Java the only one of the five
  runtimes with a portable process-tree kill. `sota-sandboxing` rules/04 R5.1 and
  R5.3a, `sota-jvm` rules/04 with two new audit greps.

### Fixed

- **Front-door surfaces the split silently invalidated.** No gate catches these:
  `README.md` cited `rules/11` for two classes that had moved to `rules/13`, and
  `rules/10` for three that had moved to `rules/14`; `docs/CONVENTIONS-LEDGER.md`
  pointed at `rules/10` §2.12 for the class now at `rules/14` §3. Invariant 8 sees a
  file link that still resolves, and **invariant 18's scope is `skills/` only**, so
  `docs/` references remain on trust — which is why `docs/ADOPTION-LOG.md` now carries
  a **pointer-translation table** rather than eight rewritten history rows: a landed-in
  pointer records where an idea shipped *at that release*, and rewriting it would
  falsify the history the log exists to keep.
- **Two measured numbers in `docs/CONTEXT-MANAGEMENT.md` had rotted.** It said *"the
  router is at 500/500 lines with no slack"* — re-counted, it is **494/500**, and that
  number has previously read 491, so the sentence now says never to trust it in prose.
  Its token table still listed `rules/10` as the third-largest instruction file; after
  the split the third is `sota-docs-workflow/rules/01`.
- **`docs/INDEX.md` knew none of this**, which is the recurring failure where a
  capability lands in a rules file and never reaches the front door: it now routes to
  `rules/13`, `rules/14`, the in-band-sentinel class, invariant 18 (with its
  `skills/`-only scope stated), and `--self-test`.
- **The README's audit-class count is now ten, not nine** — absence-encoded-as-a-value
  is exactly what that section claims to hunt (the code is not wrong, and no linter
  flags it) and it was missing from the front door.


- **A cross-language claim the new measurement exposed as overstated.** R5.3a said
  the four measured runtimes agreed on *"no two … on all three questions"*. At that
  table's own granularity it was already false before Java arrived: Python and Rust
  answer all three identically and differ only in mechanism. Replaced with what the
  table shows — **not one of the five kills the process tree as part of the timeout**,
  one (Node) does not even tell the caller, and exactly one (Java) ships a portable way
  to clean up afterwards — with a dated note saying not to restore the stronger
  phrasing.
- **The probe's own first run was wrong, and is recorded that way.** Its liveness
  check matched a `sleep` orphaned by the *previous* phase, so it reported Java's
  tree-kill as failing. Re-run with per-phase markers and a control that demonstrably
  reads both `true` and `false` before either result was believed
  (`sota-code-security` rules/12 §2).


- **Invariant 18 — a `§` section reference must resolve.** Invariant 8 resolves
  `[text](file.md)` links; a `§` reference is **prose**, so the ~1,300 of them
  across `skills/` were checked by nothing and broke silently whenever a section
  was renumbered or a rules file split. Built deliberately **before** the split
  below, and it found **six live defects on its first run over the unmodified
  tree** — `rules/11 §6.7` cited from two files including across a skill
  boundary, `sota-golang` rules/07 §6 in a five-section file, and four cross-skill
  refs whose bare `rules/NN` silently resolved to the *citing* skill's own
  numbering. Two authoring conventions had to be modelled before it was precise,
  both found by **reading the findings** rather than trusting the count
  (`sota-code-security` rules/12 §2.2): a heading may number itself `## 3.` **or**
  `## §3 ` (missing the second form read one whole file as unnumbered and hid 102
  valid references), and `§N.M` means a `### N.M` heading in some files and **item
  M of the ordered list in §N** in others. The first draft flagged **nine correct
  references** — rules/12 §2.1's *"generalised from one sample"*, committed by the
  instrument itself. Deliberately **fail-open on ambiguity**, because a gate that
  flags correct prose gets disabled ([CONVENTIONS-LEDGER](docs/CONVENTIONS-LEDGER.md));
  an explicit `rules/NN` that exists nowhere **is** flagged, a case a probe caught
  slipping through the first design. Watched to fail on three mutations, each
  caught for the intended reason; a missing script makes it fail **closed**.
  Harness now **24 probes, 13 of 18 invariants**.
- **`sota-code-security` rules/13 and rules/14 — the two capped files split at
  seams they already had.** `rules/11` §3 (*"Five classes rules/10 does not
  cover"*) becomes **[rules/13 — Context-Dependent Silence](skills/sota-code-security/rules/13-context-dependent-silence.md)**:
  five defects that are *correct under the condition you tested and silently wrong
  under the one you shipped into* — scale, staleness, one-sample formats, an
  undeclared seam, and location. `rules/10` §2.10–2.14 becomes
  **[rules/14 — The Control That Is Not In Force](skills/sota-code-security/rules/14-control-not-in-force.md)**:
  not a control that runs and does nothing, but one that is **not there** — absent
  from the shipped artifact, standing as an instruction rather than code, never
  triggered, parked in observe-only mode, and the report that claims otherwise.
  `rules/11` 497 → 357 and `rules/10` 496 → 362. **Invariant 18 caught 27
  references the split broke, across eight skills** — including one written the
  same day in `sota-c-cpp` — which is the entire argument for building the check
  first. With the headroom recovered, `rules/11` §6's hunt list gains the in-band
  sentinel entry that had nowhere to go.


- **A negative control belongs *inside* the tool, not beside it.**
  `sota-code-security/rules/12` §1b: the mutation probe, the instrument bar and
  the committed known-bad were all already there, and in every one of them the
  probe is an artifact somebody maintains **next to** the checks — so it proves
  today's checks can fail and says nothing about the check added next week,
  because joining the harness is a convention enforced by prose and a reviewer.
  Prefer a `--self-test`/`doctor` mode that walks the same check registry the
  ordinary run walks: a check with **no declared known-bad fails the self-test**,
  the probe ships to the operator's own installation (where §1's stale-install
  trap actually bites), and the known-bad sits where a new check's reviewer is
  already reading. With the three rules that decide whether its output means
  anything — attribute the catch to the **named** check (a non-zero exit for an
  unrelated reason is a false pass), assert the mutation took, report
  checks-probed over checks-registered — and the two things it does not
  establish, which must be printed rather than assumed: a skip prints its reason,
  and a check that can fail may still have stopped covering the code that
  matters. The CLI half is `sota-cli-ux/rules/03` §2a, for any tool whose output
  is a **verdict** rather than an artifact: `"0 problems found"` and `"0 checks
  ran"` print the same.
- **The in-band sentinel — a value from the domain standing in for absent.**
  `sota-python/rules/02` §2a is the producer half: a converter returning `-1` (or
  `0`, or `""`) instead of `None` type-checks, collapses *absent* and *malformed*
  into one indistinguishable value, survives the `if x:` presence check because
  `-1` is truthy, and — the part that changes answers — carries an **ordering**, so
  it silently loses every `<` against a real value and wins every `>`. Where
  line/offset/version numbers are compared as a proxy for sequence, one missing
  operand flips the predicate, and *which* way it flips depends on which side went
  missing: fail-open in one direction, false positive in the other, from a single
  input. The audit tell is not the constant but the **asymmetric guard** — one
  operand filtered against the sentinel, the other, in the same comparison, not —
  because sentinel-filtering is applied per site and so lands only where the author
  was thinking about it. Three detectors in decreasing precision (producer /
  asymmetric guard / truthiness-as-presence), with the constraint that decides the
  rule's shape: **a value-based lint is only sound on a field with a stated
  non-negative domain**, and one converter applying one sentinel across a
  heterogeneous field set makes it 100% false-positive on any field whose producer
  emits that value legitimately. Key on the declaration; add the value lint per
  field. `sota-databases/rules/01` *Modeling hygiene* is the persistence half —
  absence is `NULL` or an omitted property, and a document/graph store makes a
  sentinel **worse**, not better, because it discards native absence the store would
  have kept for free. Pointer from `sota-python/rules/03` §12; both audit checklists
  extended, with *check the queries that order or compare first*. **Nine language
  skills carry a measured row** — Go, Rust, C/C++, JVM, JS/TS, .NET, PHP, Ruby, plus a
  pointer from Swift — because the class is universal and only the *detector* is
  per-language. Seven rows were run on a local toolchain and two taken from primary
  docs (no JDK or .NET SDK here) and labelled as such. Two runs changed the text
  rather than confirming it: the C `EOF` bug is **platform-dependent**
  (`(char)EOF == EOF` is true under the default signed `char`, false under
  `-funsigned-char`, and clang warns only in the *broken* configuration — so it is
  invisible on many developers' machines), and JS `NaN` is the **better-behaved**
  sentinel (`NaN > 20` and `NaN < 20` are both false, so it poisons and can never win
  a comparison; `-1 < 20` is true, so it lies) — which inverts the advice you would
  write from memory.
- **The question with no instrument, and the substitute that answers a different
  one.** `sota-observability/rules/05` §7a. The requirement for per-route/per-field
  usage telemetry was already stated twice in `sota-api-design` (rules/02 §5 step
  4, rules/03 §11 — *"without per-field usage data you can never delete
  anything"*), in a skill an observability or platform task never loads;
  `sota-observability` mentioned access logs once, only to exclude the health
  endpoint from them. Edge access logs are now a **required** stream wherever a
  gateway fronts a deprecable surface, retained across a full deprecation runway
  — a 30-day retention cannot support a decision with a 6-month runway. The new
  part is the residual: with the signal absent, *"is this feature used?"* gets
  answered from the **corpus**, which measures whether data shaped like the
  feature exists rather than whether anyone requests it — a different question
  whose error has a **direction**, since stored data outlives its last reader and
  so over-reports use. Generalised (commit count for maintenance, manifest
  presence for reachability, a dashboard existing for someone opening it), with
  the rule that a substitution is named in the same sentence as the number.

### Changed

- **The v1.22.14 cut's finding is now recorded where a future gate proposal will
  meet it.** `docs/CONVENTIONS-LEDGER.md` states where invariant 17 stops — it
  asserts that every stated count equals the script's own `[k/N]` and that
  `AGENTS.md`/`CONTRIBUTING.md` enumerate 1..N with no gaps, and **nothing about
  what a description means** — with the first instance against it: `AGENTS.md`'s
  invariant 14 row described an OR across README/INDEX/entry where
  `scripts/check-invariants.sh:842` and `:848` require an AND, while agreeing on
  every number. Through the three filters it is incident **yes**, silent **yes**,
  mechanically checkable **no**, so it is recorded as ungateable rather than
  proposed as invariant 18. `docs/ROADMAP.md` carries it as item 11, and its
  intro paragraph — which claimed nothing in the table comes from re-reading docs
  — now names item 11 as the near-exception, since it was found exactly that way.
## [1.22.14] - 2026-08-19

**A rule that pointed one way.** `rules/10` §2.7 has warned against truncating input
on the way *into* an inspector since it was written. A field brief showed the inverse
costs the same and is harder to see: a cap on a generator's **output**, then parsed —
and the reason it is harder is that there is no truncation operator anywhere in the
code to grep for. The cap lives in a default the call site never names.

**Front door checked:** truncation · generator · denominator

### Added

- **`sota-code-security/rules/10` §2.7 gains its mirrored half — a cap on a
  generator's *output*, then parsed.** The section, its example
  (`scan(payload[:8192])`) and its checklist line all pointed at truncation
  **into** an inspector, so an auditor following it greps every `[:limit]` on a
  scan input and walks past a `provider.complete()` with no `max_tokens`. The
  tell that makes the inverse findable is that **there is no truncation operator
  to grep for**: the cap lives in a default the call site never names. Heading
  widened to "Truncation into an inspector — or out of a generator", and the
  three index surfaces that restated the old phrasing (`sota/SKILL.md` AUDIT
  step 4, `sota-code-security/SKILL.md` non-negotiable 6 and AUDIT step 5,
  the rules/10 table row) updated with it.
- **`sota-code-security/rules/11` §2.2 gains the tell and its corollary.** A
  produced size that lands exactly on its limit is a truncation report —
  `output_tokens == max_tokens`, rows == `LIMIT`, bytes == the buffer — and it
  needs no cooperation from the producer, unlike `stop_reason`. Corollary, from
  the reporting session's own wrong turn: **a parse-error offset is
  uninterpretable without the document length**; "failed at char 3,023" argues
  against truncation until you learn 3,023 was the last character. It lands in
  the denominator section because an offset is a numerator.
- **`sota-llm-engineering/rules/02`: set `max_tokens` explicitly at every
  structured-output call site.** An unset cap inherits a client default sized
  for chat, so a long JSON document hits it silently and the call returns a
  fragment rather than an error. Where usage is reported, assert
  `output_tokens < max_tokens` — a wrapper that drops `stop_reason` leaves that
  arithmetic as the only tell.
- **`docs/ADOPTION-LOG.md`**: the intake entry, recording that three of the
  four links in the reported chain were **already covered** (rules/10 §2.3,
  §2.4 and rules/11 §1), and that the fourth was stated for LLM output only, in
  a skill an inert-control pass never loads — *unreachable*, not absent.

### Changed

- **`AGENTS.md` invariant 14 described a weaker check than the script runs.** Its row
  read "a declared term resolves in **neither** `README.md`/`docs/INDEX.md` **nor** the
  release's own entry", which is an OR across all three; `check-invariants.sh:842-850`
  requires the term in (README **or** INDEX) **and** in the entry. `CONTRIBUTING.md`
  item 14 already stated it correctly. Invariant 17 does not catch this — it checks
  counts and enumerations, not prose — so it was found the way the ledger keeps
  predicting: by re-reading at a cut.
- **`README.md`** — the inert-controls class list gains the case this release added, so
  the capability has a sentence where a reader looks (RELEASING.md §2b).

## [1.22.13] - 2026-08-19

**The gate that was one release old had a hole, and the ledger had not recorded
itself.** Invariant 17 shipped yesterday checking that documents describing the checks
agree with them. Two follow-ups it needed, both found by reading it rather than by it
firing.

**Front door checked:** invariant 17 · CONVENTIONS-LEDGER

### Added

- **Invariant 17 now asserts the *enumerations*, not just the counts.** A stated count
  and the actual list can drift apart independently: correct "runs 18 checks" in four
  files and forget a table row, and every count claim still agrees. `AGENTS.md`'s table
  and `CONTRIBUTING.md`'s numbered list must now each enumerate **1..N with no gaps**.
  Watched to fail both ways before being trusted — dropping AGENTS row 12 reports
  `missing [12]`, renumbering CONTRIBUTING item 9 reports `missing [9]` — and to pass
  again after restore. **14 claims checked**, up from 12.
- **`docs/CONVENTIONS-LEDGER.md` gains the three-filters row for invariant 17** —
  incident, silence, checkability — which the ledger existed to record and had not.

### Notes

- **The ledger's standing prediction paid out a third time, and this one indicted the
  ledger itself.** It predicted in 2026-08-02 that "the next gate will come from an
  incident, not from re-reading the docs"; invariant 17 did, and the incident *was this
  file* — its enforced section said "(14)" while sixteen were gated, with the two
  missing ones written out in the table directly above. Worth noting what that costs
  the re-read strategy: the document was re-read at two consecutive release cuts and
  the heading survived both, because a reader checking *whether a convention is gated*
  looks at the rows, not at the count above them.
- **The residual is stated where the invariant is documented.** Invariant 17 does not
  check that `AGENTS.md` row 12 and `CONTRIBUTING.md` item 12 *describe the same thing*
  — only that both enumerate all of them. Matching prose across two deliberately
  different granularities is not mechanically checkable, and a flaky gate gets disabled.


## [1.22.12] - 2026-08-19

**Nothing checked the documents that describe the checks.** Twice in one week a doc
that *describes* the gates drifted from the gates: `CONTRIBUTING.md` listed part A's
negative-control coverage as five invariants when the harness printed eleven, and
`docs/CONVENTIONS-LEDGER.md` headed its enforced section **"(14) — invariants 1–14"**
while 15 and 16 were already gated *and* described in its own table below. Both were
found by reading, both after shipping. A document that under-describes the gates is
indistinguishable from a correct one — which is the class every other invariant here
exists for, now aimed at our own prose.

**Front door checked:** invariant 17 · pre-push

### Added

- **Invariant 17 — docs describing the invariants agree with the scripts.** It derives
  the authority from `check-invariants.sh` itself (every `[k/N]` marker must share one
  `N`, and the `k`s must be exactly `1..N`), then requires every stated count in
  `AGENTS.md`, `CONTRIBUTING.md`, `docs/CONVENTIONS-LEDGER.md` and
  `docs/MAINTENANCE.md` to match it, and both negative-control coverage lists to be
  restated exactly as `check-negative-controls.sh` prints them. **12 claims checked.**
- **A probe for it**, bringing part A to **12 of 17** invariants covered.

- **A `pre-push` stage, and the reason it earns its keep.** This repo told users to
  install one (`init-gates.sh` writes `default_install_hook_types` for *their* repos)
  and had none itself. It does now — running the invariants, because that is the first
  local moment the **diff-based** ones (11, 14) have a commit to read: at pre-commit
  time the change is only *staged*, so they skip and pass. Every hook now states its
  `stages` **explicitly** — a hook with no `stages:` key runs at *every* configured
  stage (measured), which would have silently doubled the pre-commit suite onto every
  push. `verify-setup.sh` check 9a, added last release, now reports PASS here.

### Changed

- **The Node row in `sota-sandboxing/rules/04` R5.1 is now measured, not recalled**
  (Node 22): argv is not split, `execFile` gives no shell, `{shell:true}` restores it —
  and **Node itself deprecates that spelling**, `DEP0190`, because the args are
  concatenated unescaped. Added to `sota-javascript-typescript/rules/05` too, with the
  instruction to treat a DEP0190 warning as a finding rather than noise.
- **A fourth runtime joins the deadline table, and it is the worst case.** Node's
  `timeout` fired at **305 ms** on a 300 ms budget — the deadline works — but the
  **grandchild was still running** and `err` was **`null`**, because the direct child
  had exited 0. The caller cannot tell the deadline fired at all. Four measured now
  (Go, Python, Rust, Node) and **no two agree on all three questions**; Java is
  explicitly *not* among them and its row is still written from recall.

### Notes

- **A count inside `"quotes"` is read as a quotation, not a claim.** Without that, the
  correction note added last release — which records that the ledger *used to* say
  "(14) — invariants 1–14" — would trip the very check it motivated. It is the
  supersede-don't-edit rule made mechanical.
- Two defects in the check were caught by running it before trusting it. `"Invariant 10
  checks its own SKILL.md"` matched as a phantom **"0 checks"** (the look-behind needs a
  `\b` before the digits, or it anchors on the trailing digit of `10`), and the
  coverage lists are prose that **wraps at ~80 columns**, so a substring test failed on
  where the line happened to break. Both fixes carry the incident in a comment.
- The gate then immediately caught a live drift: adding the probe changed the harness's
  coverage line to `12 of 17`, and invariant 17 failed until `AGENTS.md` and
  `CONTRIBUTING.md` were updated to match. It was useful within a minute of existing.
- **The probe count is deliberately *not* gated.** A static count of call sites reads
  13 against an actual 23, because part B invokes `vs_probe` inline on the mutation
  line. A gate that has to guess is a gate that ships a wrong number, so the harness's
  own printed total stays the authority — invariant 17 covers what *is* statically
  derivable and stops there.
- Java could not be measured: `/usr/bin/java` here is the macOS stub. Recorded as an
  open roadmap item rather than quietly asserted.


## [1.22.11] - 2026-08-19

**Three languages, three behaviours, one test.** The v1.22.10 cut left one deferral on
the roadmap: `sota-rust` had **zero** coverage of `std::process::Command` — subprocess
hygiene for Rust existed only as a one-line parenthetical in `sota-sandboxing`. That
deferral carried an explicit warning: *do not infer Rust's deadline semantics from Go's
or Python's, because those two were measured and they disagree.* Worked out, it was
worth the caution — Rust is a third answer, not a copy of either.

Under the same test (a child that exits immediately after spawning a grandchild which
inherits the pipe):

| | behaviour under a 2 s deadline |
|---|---|
| Go | `Wait` blocks **past** context cancellation until `cmd.WaitDelay` is set |
| Python 3.14 | `subprocess.run(timeout=)` raises **on schedule** |
| Rust + tokio | `timeout` fires **on schedule** — and leaves the child *and* grandchild **running** |

Rust needs no `WaitDelay` equivalent, and that is exactly what makes it easy to get
wrong: the deadline works, so the code looks correct, while cancelling a future is not
killing a process. The rule pairs the deadline with `.kill_on_drop(true)`.

**A second brief, and a rule that had a direction.** A field brief from a session
applying the library returned three findings and an observation. Two were real gaps; one
was already in the tree at the brief's own anchor commit; and the observation turned out
to contain something better than the change it proposed — a rule the library states
absolutely that its own evidence contradicts.

`sota-testing` rules/07 said **"never assert wall-clock durations"**, no carve-out. The
brief's evidence table says the single unit test that caught a live defect in that session
*was* a wall-clock assertion: a 300 ms deadline measured at **30.28 s**, because a
grandchild holding an inherited pipe kept the wait alive. Both are right, about different
things — a percentage margin on shared CI is the flake that bullet is about; two orders of
magnitude is not. Same shape as v1.22.10's allow arm: an existing rule with a *direction*,
not a missing rule.

**Front door checked:** write-back · std::process::Command · hook type

### Added

- **`sota-kubernetes/rules/04` §7 — write-back controllers.** Anything reconciling
  *outward* (image updaters, PR bots, config sync committing back) is an instrument
  reporting on itself: its log describes the update it **decided** on, not the write
  landing. Measured — a controller logged `Committing 1 parameter update(s)` and
  `updated=1 errors=0` every reconcile for ~15 minutes across ~7 cycles while pushing no
  commit at all, silently stopping auto-deploy; cause established, not inferred, by
  removing the trigger and watching a commit appear in **84 seconds**. Verify at the
  **remote**; alert on the *age of the last remote change*, which goes stale by itself
  when writes stop, where a success counter never will; and where a controller manages N
  objects, assert on all N — one object's success hides another's silent failure in any
  aggregate.
- **`sota-observability/rules/02` §4a — `now` vs `offset X` is two samples, not a trend**,
  and it convinces *more* than one sample, which is what makes it dangerous. Measured: a
  p99 of **0.40 s now** against **8.83 s at 24 h** — a tidy 22x — on a series that swings
  **0.11–13.40 s** across the day, while the load-invariant absolute count was flat. Two
  points cannot separate a step change from a diurnal swing. A percentile is a *ratio*, so
  prefer a load-invariant absolute count for "is this still happening"; and a production
  series cannot be re-run, so sampling more *offsets* is the only equivalent of a
  benchmark's repeat runs.
- **`sota-rust/rules/05` §9 — running external programs**, seven rules with four audit
  probes: argv is never split by either API (so the Rust mistake is the *inverse* of the
  shell one); argument injection still survives argv; the Windows `.bat`/`.cmd` exception
  (**CVE-2024-24576**, fixed in Rust 1.77.2, where std now returns `InvalidInput` rather
  than escaping unsafely); a dropped `Child` that **neither kills nor reaps** — it keeps
  running, then becomes a zombie, and `?` makes that the easy path to write; deadlines
  that do not kill; `output()` buffering without a cap; and environment/program
  resolution, where `env_clear()` empties the environment but a **bare program name still
  resolves** through an OS-default path.
- Cross-references at the point of need: `sota-rust/rules/04` gains the cancellation
  corollary (a spawned process is owned state exactly like a spawned task), and
  `sota-rust/SKILL.md` routes to rules/05 on "spawning an external program" with
  `std::process::Command` added to its trigger list.

**"Installed" is per hook type, not per repo.** A separate question this cycle — does
`update.sh` update pre-commit? — turned up a latent gate hole, measured on pre-commit
4.6.0. Adding a **hook** to a config works without re-running anything; adding a
**stage** does not, because `pre-commit` writes `.git/hooks/<type>` only at install
time. So a release that adds a `pre-push` gate would reach every existing user's
*config* through a pull and reach nobody's *hooks* — and `verify-setup.sh` could not
see it, because check 9 counts hook files and the `pre-commit` one is right there.

### Added

- **`verify-setup.sh` check 9a — declared stages installed.** Compares the stages a
  config declares against the hook files that exist, and names the exact
  `pre-commit install --hook-type …` that fixes it. Stage tokens are matched
  **exactly**, never as substrings — `commit-msg` is a substring of
  `prepare-commit-msg`, and a substring test reports the wrong stage.
- **A negative-control probe for it** (`check-negative-controls.sh`, part B), bringing
  the harness to **22 probes, 22/22 caught by the intended check**. It deliberately
  leaves the `pre-commit` hook in place, so check 9 still passes and only 9a can catch
  the mutation — which is the whole point of adding 9a rather than widening 9.

### Fixed

- **`install.sh` returned early from `maybe_setup_precommit` whenever any hook
  existed**, so `--update` never reconverged hook *types*. It now re-runs the
  (idempotent) `pre-commit install` on update, honouring `default_install_hook_types`;
  a first-time install keeps the cheap path. **Scoped to hooks pre-commit itself
  generated** (the shim self-identifies on line 2): `pre-commit install` preserves a
  foreign hook by renaming it `<type>.legacy` — non-destructive, but still us taking
  over a hook someone hand-wrote, and this installer has form there. Both branches
  were run: a generated shim converges and gains `pre-push` with no `.legacy` file; a
  hand-written hook is left byte-identical.
- **`sota-testing/rules/07` §3 banned wall-clock assertions outright.** Carved out: where
  the deadline *is* the behaviour under test — a timeout, a cancellation, a kill-on-drop,
  a watchdog — elapsed time is the only oracle, and injecting the clock tests the
  arithmetic while proving nothing about whether the deadline fires. Assert with an
  order-of-magnitude margin.
- **`sota-sandboxing/rules/04` R5.1 told you to "beware `.arg` vs `.args` splitting".
  Neither splits** — measured. The line invited exactly the wrong mental model of an API
  whose argv guarantee is its main safety property; it now states the guarantee and names
  the one documented exception (Windows batch files).
- R5.3a's per-language deadline pointers now include Rust, and say plainly that the three
  measured languages behave three different ways — which is the argument for reading the
  language skill rather than generalising.

### Notes

- Everything above was **executed on rustc 1.97.1 / tokio 1.53**, not carried over: argv
  non-splitting, the surviving child after a dropped handle, the tokio timeout,
  `kill_on_drop`, unbounded output buffering, `env_clear` behaviour, and relative-path
  resolution against `current_dir`. Doc-sourced claims (the `cmd.exe` warning, the missing
  `Drop`, the zombie note, `pre_exec`'s unsafety, `process_group` stable since 1.64) are
  quoted from `std` and from the Rust security advisory.
- One measurement was **discarded and re-run**: the first `env_clear` probe read `PATH`
  by way of `/bin/sh`, so it measured the *shell's* invented default rather than Rust's
  fallback. Re-run against `/usr/bin/env` directly, it showed an empty environment — and
  a follow-up probe showed the OS-default lookup does **not** include the working
  directory here, overturning the hypothesis the first reading suggested.
- **One of the brief's three findings was rejected as already ours**, and the claim was
  false at the brief's *own* anchor commit: `sota-sandboxing/rules/04` already carried the
  language-skill cross-references there, from the very PR the brief credits elsewhere in
  its own text. Worth recording because it is the finding whose subject is missing a rule
  that was already present — and because the obvious excuse does not apply: the installed
  copy is a symlink farm into the repo and is byte-identical, so it cannot lag.
- **Two of the brief's suggestions were declined.** Moving the BUILD self-audit earlier
  would break a *measured* placement (its last position is where the completeness lift is
  attributed), and the router has six lines of headroom, so it would reflow rather than
  append. The hook-versus-typed-instruction note is a delivery-docs question, not a rule.
- **The first cut of check 9a silently truncated the report and still exited 0.** Under
  `set -euo pipefail`, the grep that finds no `stages:` line exits 1 and takes the whole
  script with it — so on this very repo the run stopped after check 9, printed no
  Result block, and returned success. Caught by running it rather than by reading it;
  the guard now carries the incident. A check that aborts its own script is a sharper
  version of the class the script exists to find.
- Documented what an update does **not** touch: gates generated by `init-gates.sh` in
  *your* repos stay at the release that produced them. Re-run it there — it rewrites
  only its own managed block.
- **Four stale claims found by re-reading at the cut**, none of which any gate can see:
  `CONTRIBUTING.md` said `skills/sota/SKILL.md` is "at **exactly 500 lines**" (it is
  494, and AGENTS.md already warned that number had been wrong twice); its
  negative-control paragraph listed part A's coverage as invariants 1, 2, 6, 10, 15
  when the harness prints eleven; its part B list omitted the new 9a; and
  `docs/CONVENTIONS-LEDGER.md` headed its enforced section "**(14) — invariants 1–14**"
  while naming only thirteen, with 15 and 16 already gated and described in its own
  table below. The ledger of what is enforced had drifted from what is enforced.
- **The routing docs now say what the hook already does.** With the `UserPromptSubmit`
  hook installed, re-typing "validate your claims" is a second copy of text rule (1)
  already prepends to every prompt. What is not redundant is naming the **technique**
  rather than the goal — the failure mode is never *forgot to care*, it is *checked the
  wrong artefact*. Stated as mechanism, explicitly not as a measured effect.
- No efficacy number attaches to this work; the AUDIT arm remains +0.00 across nine
  instruments.


## [1.22.10] - 2026-08-18

**The arm nobody writes.** An external session transcript — a session *applying* the
library to Go subprocess sandboxing — came back with five proposals. All five landed,
three of them with a correction, and the most useful one inverts a rule the library
already had.

`rules/12`'s mutation probe is **directional**: it installs the *permissive* no-op and
asks what fails, which finds the control that does nothing. Nothing finds the opposite —
an enforcement control (cap, quota, filter, allowlist, sandbox policy) tightened until it
refuses the legitimate case too. Both defects pass the same test, because a security suite
asserts refusal and refusal is exactly what an over-tight control produces. `sota-testing`
rules/09 §1 said so in as many words ("the assertion is that the attack is *refused*, not
that the happy path works") and `sota-sandboxing` rules/01's in-sandbox probe was
**entirely** denial arms — a policy that denies everything passed all of them.

The worked instance is the batch's other finding, and it is why the two arrived together.
`RLIMIT_AS` is not usable as a memory budget: measured in a container, a Go 1.26 hello
world reserves **1,227,204 kB** of address space at **2,376 kB** RSS and a Temurin 25
process **3,937,756 kB**, so any AS cap near the real working set kills the process at
startup. `RLIMIT_DATA` — which has covered private anonymous `mmap` since Linux 4.7 —
does the job. Deny-only, the two configurations are indistinguishable: neither lets the
runaway allocation through — the AS cap only because nothing runs at all — and one of
them also refuses every legitimate run. The allow arm is the only thing that tells
them apart.

**Front door checked:** allow arm · RLIMIT_AS · gate's scope

### Added

- **`sota-code-security/rules/12` §1a — the control that blocks everything.** The
  two-arm rule for enforcement controls, the asymmetry that explains why only the inert
  half ever gets found, and "a negative control on the environment is not a negative
  control on the control". Counterweights at `sota-testing/rules/09` §1 and
  `sota-sandboxing/rules/01` R5.1b, both of which pointed the other way.
- **`sota-sandboxing/rules/02` R7.2a — never `RLIMIT_AS` for a memory budget**, with the
  measured Go/JVM reservation table and `RLIMIT_DATA`'s Linux 4.7 boundary; cross-referenced
  from `rules/04` §1.2. The library never *recommended* `RLIMIT_AS` — this is the missing
  warning, not a corrected instruction.
- **`sota-sandboxing/rules/02` R7.2b — no cgroup available for a nested child.** A
  four-rung fallback ladder, and the tell that makes the situation findable: the cgroupfs
  is mounted `ro` while `cgroup.controllers` still lists `memory`, so **probe with `mkdir`,
  never by reading the controller list**. `GOMEMLIMIT`/`-Xmx` are documented soft limits
  and are not a boundary for untrusted code.
- **`sota-devsecops/rules/05` §5.6 — the negative control proves the gate *can* fail, not
  that it still covers you.** A refactor that moves code into a nested module, a second
  manifest, a submodule or a sidecar image shrinks the gate's scope with no diff to the
  workflow file: `govulncheck ./...` analyses the current module only. The temporal form of
  `rules/11` §2.2 — fail the build when a gate's enumerated denominator **drops**.
- **`sota-sandboxing/rules/04` R5.3a — a timeout that waits on inherited pipes is not a
  deadline**, and the semantics differ per language (Python 3.14 fires on schedule with a
  pipe-holding grandchild; Go's `Wait` does not without `cmd.WaitDelay`). Carries the
  pointers into `sota-golang`, `sota-python` and `sota-javascript-typescript` that §5 never
  had — the placement fix for a trap that lives in the language skill while you are reading
  the domain one.

### Changed

- **`sota-devsecops/rules/03` §3.6** — advisory **applicability** added as a fourth triage
  axis beside reachability, exposure and KEV/EPSS. "Only 32-bit platforms are affected" is
  a precondition in the advisory prose that no scanner ordering reflects; it resolves to a
  `not_affected` VEX from the closed OpenVEX justification list, not an ignore-with-expiry.

### Notes

- Every factual claim in this entry was reproduced this session rather than cited: the
  Go/JVM reservations and both rlimit arms in a Linux container, the nested-module omission
  by running `go list ./...`, the Python timeout behaviour by running it, and the cgroup
  `ro` mount by attempting the `mkdir`. `WaitDelay`, `SetMemoryLimit`, `setrlimit(2)` and
  the OpenVEX justification list come from their primary docs.
- The transcript's own two misses — `cmd.WaitDelay` and zsh word-splitting — were both
  **already in the library**, the second one twice (routing rule 17 and `rules/12` §2).
  Deliberately not restated a third time: that is the salience effect documented in
  [WHY-COMPLETENESS-RESIDUAL](docs/WHY-COMPLETENESS-RESIDUAL.md), where adding the missing
  rule made adherence *worse*. The placement fix (R5.3a) was taken instead.
- Logged as eight rows in [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md), including one
  **deferred**: `sota-rust` has no `std::process::Command` coverage at all, found while
  validating the R5.3a cross-references.
- **No efficacy number attaches to this release**, and none may be inferred from it. The
  AUDIT arm remains **+0.00 across nine instruments and four designs**
  ([RESULTS](evals/results/RESULTS.md)); a new audit class is a coverage claim, not a
  measured lift. The README's ninth-class entry is backed by gap analysis and by the
  reproduced `RLIMIT_AS` instance, nothing more.

## [1.22.9] - 2026-08-18

**The domain the library kept gesturing at.** An external intake
([system-design-notes](https://github.com/liquidslr/system-design-notes), read at full
depth, 29 files) landed three rules, all from the same blind spot: the library banned
float money in five language skills, required prices to be recomputed server-side, and
told you to use "ledger rows with unique keys" — while `debit` and `double-entry` scored
**zero** hits across `skills/`. It knew everything about money except how to model it.

Cutting it also turned the lens on the docs, which is where most of this entry's line
count went: a release cut is the moment stale claims are cheapest to catch.

**Front door checked:** double-entry · reconciliation · ledger

### Added

- **`sota-databases` rules/01 — ledgers and consumable balances.** The authoritative
  state is append-only entries, at least two per movement summing to zero under one
  journal; the balance is derived (a rollup is a cache a job re-derives and compares),
  and corrections are reversing entries. Sum-zero is enforced by a **deferred constraint
  trigger**, not app code — a one-sided write becomes an invariant the database rejects
  instead of drift a customer reports months later. The DDL was **executed on PostgreSQL
  17.11, negative control first**: a one-sided write returns `INSERT 0 1` and fails at
  `COMMIT` — the asymmetry that proves the deferral is real — and `BEFORE` / `FOR EACH
  STATEMENT` are syntax errors, so the two restrictions the rule states stop a reader
  rather than silently downgrading the check.
- **`sota-architecture` rules/03 §5b — reconciliation against an external system of
  record.** The word appeared eight times in the tree and never as a rule: every instance
  was domain-bound (orphaned accounts, a webhook backfill API, pipeline row counts).
  §2–§4 buy *integrity*; reconciliation is the only thing that buys **completeness**.
  Reconcile against the counterparty's extract, not your own event log; classify breaks
  into auto-adjustable / manual / unclassified; age them. A reconciliation that has never
  reported a break has the inert-control signature (`sota-code-security` rules/11 §2.2).
- **`sota-architecture` rules/03 §5 — conservative leg ordering.** Debit before credit, so
  a crash between legs leaves value *missing* (recoverable by compensation) rather than
  *duplicated* (not, once spent). Credit-first only where the credit provably cannot be
  consumed before the terminal state — enforced, not assumed.

### Changed

- Audit checklists gained the probe for each rule, not just the rule
  (`grep -rn "SET balance"` for the mutable-balance CRITICAL; "has the reconciliation ever
  been observed reporting a break?").
- Routing surfaces updated so the new material is reachable: the router's routing table
  rows for `sota-architecture` and `sota-databases`, and both skills' rules-index rows.
- [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md): the intake recorded in full — three
  adopted, two deferred (event-sourcing determinism; geospatial, which is **thin, not
  absent**), four rejected, including one **rejected: contrary** (the source teaches CAP
  as "pick two of three"; `rules/03` §1 is PACELC and per-operation). The source is
  unlicensed and derivative of a copyrighted book, so nothing was copied — only the idea
  class, re-derived.

### Fixed — four stale claims, found by re-reading rather than by a gate

None of these had a gate that could catch them; all four were prose asserting a state
the tree had moved past.

- **README claimed "seven audit instruments across three designs"** while the scoreboard
  carried **nine rows across four**. The missing two are the strongest form of the test —
  a real repository at a real vulnerable commit — so the stale number understated the
  evidence rather than overstating it: across 16 real BOLA sites in Harbor v2.5.1 both
  arms recalled 15/16, and across 59 blinded findings both scored precision 1.00.
- **`evals/DESIGN-real-repo-audit.md` still announced itself as "nothing measured yet",
  "No run, no number, no lift"** — four days after the eval ran and closed the question.
  A reader following the link from RESULTS would have concluded the opposite of the
  truth. Re-headed as executed, with the outcome and a pointer to the results; the
  method sections are kept, since those held up.
- **[RESULTS.md](evals/results/RESULTS.md)** called the audit question "Final" at seven
  instruments. The dated paragraph is left standing — it was true when written, and
  rewriting history is not correcting it — with a **superseding** note above it: closed
  at nine instruments and four designs, and no tenth accuracy instrument.
- **[docs/ROADMAP.md](docs/ROADMAP.md)** carried a router count of 491/500 (actual:
  **494**, six lines of headroom) and a "pending release cut" for **1.22.4**, five patch
  versions ago.

### Changed — docs

- [AGENTS.md](AGENTS.md) now honours its own "keep it under 200 lines" rule for the
  first time in several releases — **208 → 199** — by compressing narration of
  *closed* incidents while keeping every operative rule. It is the one file that loads
  into every session, so its length is a live cost, not a tidiness question.
- [docs/ROADMAP.md](docs/ROADMAP.md) gained the two deferred ideas as an explicit open
  item, so neither gets silently dropped or silently re-litigated.
- The negative-control harness was **re-run** rather than cited from memory:
  `PASS: 21/21 mutations caught by the intended check`.

## [1.22.8] - 2026-08-16

**A rejection, and three counts that had drifted.** The as-deployed competitor
comparison is closed as *rejected* rather than deferred — checking the pinned clones
showed it would measure corpus size and a retrieval path already scored saturated, not
guidance quality. Alongside it, the docs were re-counted against the tree: the router
headroom, the ledger's own list of verdict states, and a roadmap row whose premise had
been overtaken by evidence.

**Front door checked:** competitor · benchmark · roadmap

### Changed

- **The as-deployed competitor comparison is rejected, not deferred.** It sat on the
  roadmap as a ~$8 purchase; checking the pinned clones instead of memory shows it is not
  a purchase and not a harness gap — it is a measurement that would land on the wrong
  variable. **ECC ships 889 `SKILL.md` files with a `.claude-plugin/marketplace.json`;
  claude-skills ships 777** — so two of three competitors deploy through *our own*
  mechanism over a corpus 20× ours (41). The result would partly measure repo size, and
  it would route through a description-selection layer `run-desc-routing.py` already
  scores at **+0.00, saturated**. Neither confound has a neutral fix: simulating a loader
  none of them ships lets our choices decide the outcome, and a retrieval **miss** would
  score as a content zero — defensible as a deployment fact, rigged-looking as a published
  claim about a named third party. The content-only benchmark stays the claim, with its
  own disclosed weakness (the maintainer hand-picks 4–8 files per competitor), which is
  the better-understood limitation. Reasoning kept in
  [ROADMAP](docs/ROADMAP.md) and [ADOPTION-LOG](docs/ADOPTION-LOG.md) so it is not
  re-litigated.


- **`adopted with a correction` is now a documented ledger verdict.**
  [ADOPTION-LOG](docs/ADOPTION-LOG.md) said every entry ends in one of four states, and
  v1.22.7 introduced a fifth without saying so. It exists for the real case it was coined
  for: a proposal whose *substance* was right but whose *wording* would have licensed the
  opposite behaviour. Plain `adopted` would hide the edit from whoever wrote the proposal;
  `rejected` would be false.
- **Docs re-counted against the tree.** `AGENTS.md` claimed the router sits at 491 lines;
  it is **494** — six left against the 500 cap, so the next router addition has to reflow
  rather than append. That number has now been wrong twice in this file, so the sentence
  tells the reader to re-count instead of trusting it. `ROADMAP` drops the closed
  denylist-divergence row (re-derived and canary-proven 2026-08-13) and renumbers; the
  remaining five were each re-checked, including the star count, which is unchanged at 13.

## [1.22.7] - 2026-08-16

**Two rules written because I broke them.** A gate joined to an irreversible action with
`;` instead of `&&` — so a push ran while the check printed FAIL — and a verification
instrument that runs *over time*, where "abort on a missing result" kills the watch and a
dead watcher is indistinguishable from a waiting one. Both arrived from field use, both
ship with an audit probe, and both name the failure as observed rather than as advice.

**Front door checked:** instrument · shell · invariant

### Added

- **`rules/12` §2.2a — instruments that run over time.** §2.2's "abort on a missing
  result" is right for a one-shot scorer and wrong for a watcher: abort on the first
  unreadable read and the watch dies on any transient failure, and because **silence is a
  watcher's normal state**, a dead watcher and a waiting one are indistinguishable. Both
  resolutions of an unreadable read are live defects — fail open invents a success, fail
  closed-by-aborting loses the event — so the section adds a **third state**: done /
  not-done / **cannot-tell**, with the terminal condition asserted *positively*, a bound
  on consecutive unknowns so persistent blindness is reported, and an **independent
  signal printed beside the verdict** so a false verdict has something to disagree with.
  Reported from a watcher that announced success on a job that was 89% done, because
  `!= "0"` is satisfied by an empty read. Paired in `sota-shell-scripting` rules/02 §2:
  validate **captured output**, not just arguments — verified that `""`, `error`, `null`
  and a usage message all compare `!= "0"`.

  Two decisions recorded in [ADOPTION-LOG](docs/ADOPTION-LOG.md): the finding stays in
  `rules/12` rather than `sota-observability` §8 (which owns probing a *running service*,
  a different subject), and the drafted wording "§2.2 **inverts**" was corrected to "its
  principle holds, its remedy does not" — the stronger claim would license dropping §2.2
  inside a watcher, which is the opposite of the intent.


- **A gate and the irreversible action it gates must be joined by `&&`, never `;`**
  (`sota-shell-scripting` rules/04 §1b, with an audit probe). In a script `set -e` stops
  you; typed at a prompt or joined with `;` inside a CI `run:` block, nothing does — the
  check runs, prints FAIL, and the push happens anyway because it was the next token.
  Two aggravating factors named because they make it invisible rather than merely
  ignored: a pipe rewrites the status (`check | tail -2` reports `tail`), and
  **diff-based checks legitimately differ before and after a push** because their merge
  base changes — so a pre-push result must never be what authorises the push.

### Changed

- **`RELEASING.md` now documents how invariant 14 actually matches.** The comparison is
  literal (`grep -F`) and the front-door line is excluded from the entry search, so a
  term cannot satisfy itself. Both failure modes are recorded because both happened on
  real cuts: declaring `negative control` when the entry writes `negative-control`, and
  declaring a word that appears only in the declaration. Includes a one-liner to test a
  candidate term before committing to it, plus the note that invariants 11 and 14 are
  diff-based and should be re-run once the branch exists upstream.

## [1.22.6] - 2026-08-16

**The audit turned inward.** A scoped audit of the code that *measures* this library —
`evals/` and `scripts/`, the two areas 15 of 16 invariants never touch — found a
Critical data-loss bug, two gates that passed while structurally unable to see anything,
and a drift guard that did not span what it protects. **Zero findings in `skills/`.**
The prediction was committed before any auditor reported. Alongside it, five findings
from a session that used the library on a real project, each re-validated here.

**Front door checked:** negative-control · instrument · invariant

### Added

- **Five field-use findings from a live build, each re-validated here before landing.**
  A handoff brief from a session that used the library end to end on a real project. Every
  anchor and every empirical claim was re-checked at this commit rather than taken on
  trust; full intake with the one rejection is in
  [ADOPTION-LOG](docs/ADOPTION-LOG.md) 2026-08-16.

  - **The auditor's own verification one-liner is an uninstrumented instrument**
    (`sota/SKILL.md` rule 17 + `rules/12` §2). Unlinted shell, run against the system
    under test, producing false findings *about the product* — three in one session, all
    zsh joining/pipeline bugs this library already documents. The rule existed; nothing
    **routed** to it, because the task did not look shell-shaped. Rule 17 now names the
    commands you type, and `rules/12` §2 carries the three tells and an explicit
    cross-reference.
  - **`set -e` cannot be re-armed, and `$-` lies about it** (`sota-shell-scripting`
    rules/01 §2). Inside a suspended call tree neither `set -e` nor `set -o errexit`
    restores errexit, while `case $- in *e*)` still matches — the shell reports the safety
    flag as enabled while it is behaviourally inert. **Reproduced here on GNU bash 5.3.15
    *and* 3.2.57** (the brief had only checked 5.3.15), so the rule states both. Only
    explicit `&&` or a fresh `bash -c` work.
  - **`SECURITY.md`'s "never open an issue" now has a private-repo carve-out**
    (`sota-docs-workflow` rules/01, both the table row and the checklist). GitHub's
    private vulnerability reporting is **public-repo only** — *"Owners and administrators
    of public repositories can enable private vulnerability reporting"* (docs, checked
    2026-08-16) — so the rule pointed at a feature that cannot be enabled, while the thing
    it forbade (a collaborator-only tracker) *is* private. The file must now name the
    switch to make on going public.
  - **Location-dependent silence** — a new class in `rules/11` §3.5, with the count fixed
    in all **four** ripple sites. A filter whose predicate matches the *ambient
    environment* rather than the data: `"private" not in p.parts` against an absolute path
    empties the collection on macOS, where `/var` resolves to `/private/var` (verified).
    Generalises to hostnames, usernames, env vars and locales; the defences are anchoring
    the predicate and asserting non-empty on every collection a suite iterates.
  - **A platform-refused pipeline is a third state** (`rules/10` §2.13) and **proving a
    pipeline runs** is now a section (`sota-devsecops` rules/01 §1.11). Refused runs
    report *failure*, not skipped, so the all-skipped test misses them; the tell is every
    job failing in seconds with no step logs and the reason only in annotations. The
    remedy — run the jobs locally against a fresh clone of committed state, treat missing
    tooling as a hard failure, print substitutions — deliberately names **no tool**, since
    the brief flagged its own suggestion as unevaluated.


### Changed

- **Docs re-synced to what the audit changed, with the numbers re-counted rather than
  carried forward.** `AGENTS.md`: **16 → 21 negative-control probes**, and the enumeration
  now names the 11 probed invariants plus the five that need a fixture a worktree cannot
  provide. Its "every file-list-driven check reports its denominator" sentence is now
  annotated with the fact that it was **false for checks 4 and 8** until this cycle — in
  the one file that states the rule. `CONVENTIONS-LEDGER`: runner-enforced conventions
  **5 → 8** (judge-verdict shape, pin-what-you-compare-against, a probe must assert its own
  mutation) — every one of them arrived from an incident, which is that ledger's own
  thesis. `evals/README` gained the judge-shape convention with the two demonstrated
  0.00/12 failures. `ROADMAP` records the audit outcome and its two deliberate residuals.

### Fixed

- **Instrument audit, final pass — every remaining finding closed.**
  - **Negative-control coverage: 6 of 16 invariants probed → 11 of 16.** New probes for
    invariants **3, 4, 7, 8, 13** — all single-file edits, so the old "diff-, history- or
    release-shaped" rationale never applied to them. `PASS: 21/21`. The remaining five
    (5, 9, 11, 12, 14) genuinely need state a worktree lacks (a tag, a merge base, an
    mtime) and the harness now says exactly that. Probe 3 synthesises its trigger phrase
    at runtime because writing it literally made the harness trip check 3 — **the gate
    caught its own probe**, which is the best evidence it works.
  - **`run-decay` silently measured a different depth than it printed.** `FILLER[:depth]`
    caps at 30, so `--depths 0,12,60` reported "depth=60" while measuring 30 — and the
    DECAY headline is computed from `depths[-1]`. Now refuses.
  - **`run-repo-audit` had no empty-fixture guard** (its sibling ten lines below does): a
    renamed fixture dir would hand both arms an empty source and print a fake `+0.00`.
  - **`run-unscoped-audit` credited a defect when the file and the mechanism appeared
    anywhere in the report** — a report naming `db.py` in one paragraph and "sql
    injection" in another scored a hit. Matching is now windowed to the same block.
    **This changes a published method:** the +0.00 in `RESULTS.md` was produced by the
    looser matcher and would need a re-run to be strictly comparable. Both arms were at
    ceiling, so the direction of any change is to lower both — recorded rather than
    quietly re-scored.
  - **`install.sh` leaked temp files on any abort** — four `mktemp` sites cleaned only on
    the success path. Now a registry plus an `EXIT` trap. The first attempt was **broken
    and the test caught it**: the tracker ran inside `$( )`, a subshell, so the parent's
    registry stayed empty and the trap cleaned nothing. Rewritten to track in the parent
    shell; verified by aborting mid-run and confirming zero files remain.


- **Instrument audit, second pass — the remaining findings.**
  - **The judge parser validated nothing.** All four judge-driven instruments call one
    `judge()`; it parsed the reply and scored `verdict.get(id) == "present"`, so a
    *well-formed* reply of the wrong shape scored **0.00 in silence** — `{"results":{…}}`
    and `"Present"` with a capital P both demonstrated at 0.00/12. It now normalises case
    and **aborts** on missing/extra ids or values outside present/absent. Each of the four
    failure modes was replayed against the real rubric shape.
  - **Competitor SHAs are now enforced, not just documented.** `comp["sha"]` appeared only
    inside an error string, so every published competitor number rested on an unverified
    clone — in a repo that pins `ROUTER_BUILD_SHA` for exactly this reason. The runner now
    compares `git rev-parse HEAD` against the manifest and refuses on mismatch (proven
    both directions), and the artifact records build/judge model, manifest path and the
    resolved SHAs.
  - **Artifact provenance**: the flagship completeness artifact stored only case results —
    no models, samples, temp, or router SHA. It now writes a `_meta` block.
  - **A stale probe used to accuse a healthy gate.** Every mutation in the negative-control
    harness is a hardcoded literal; when one goes stale the edit is a no-op and the probe
    reported `NOT CAUGHT: INERT`. It now asserts the mutation actually changed the tree
    and reports **PROBE BROKEN** instead — watched to fire by neutering probe 1. `restore()`
    also no longer swallows a failed reset with `|| true`, which would have leaked one
    probe's mutation into the next.
  - **The denylist degrade is now announced** — an all-comment `.denylist.local` silently
    fell back to two generic phrases with output byte-identical to a full scan.
  - **`install.sh backup()` clobbered the original** on a second `--update`, overwriting
    the backup with the already-modified file. Rewritten as a real function (kept-backup,
    no `cp` on a missing file, `die` on failure) after the one-line version introduced an
    `A && B || C` bug — the same class fixed in `verify-setup.sh` earlier in this cycle.
  - **Two known-good/known-bad selftests ran nowhere.** `run-build-safe.py --selftest` and
    `unscoped-audit/selfcheck.py` are the repo's only reference *pairs* and no CI job or
    hook invoked them; both are now in CI. The unscoped-audit selfcheck also hardcoded
    "7 planted defects, 6 demonstrated" (the 6 already stale) — it now counts its own
    checks against a floor, watched to fail at `MIN_CHECKS = 8`.
  - Workflow-level `defaults: run: shell: bash` (steps were getting `bash -e {0}` — no
    `pipefail`, no `-u`), and `.gitattributes` pins `*.sh`/`*.py` to LF so a CRLF commit
    cannot produce `/usr/bin/env: bash\r`.


- **Instrument audit: a Critical data-loss bug in `install.sh`, and two gates that
  passed while unable to see anything.** Three scoped auditors read `evals/*.py` and
  `scripts/*.sh` at `cc1529b` against `rules/10`–`12`. The prediction was
  [pre-registered and committed first](evals/results/2026-08-16/PRE-REGISTRATION-INSTRUMENT-AUDIT.md);
  it held — **highest severity in `scripts/`, zero findings in `skills/`**.

  - **Critical — `install.sh` could delete a user's file.** With an altered/indented END
    marker, `grep -qF` (substring) passed and `extract_block` returned BEGIN→EOF, so it
    was non-empty and the emptiness guard passed too; `refresh_block`'s awk then never
    left its delete branch and **erased every line below the block** in
    `~/.claude/CLAUDE.md`. Reproduced end-to-end. Both marker greps are now `-qxF` and
    the block check is end-anchored (`tail -n 1 == RT_END`). Verified three ways: the
    bad case refuses, a healthy block still proceeds, an indented BEGIN falls through.
  - **Invariants 4 and 8 had no denominator** — a drifted glob printed `ok` and exited 0,
    contradicting `AGENTS.md:69` ("every file-list-driven check reports its denominator").
    Both now print counts (`ok (41 descriptions)`, `ok (351 markdown files)`) and were
    **watched to fail closed** on a mutated pathspec.
  - **CI's shell lint could not see its own top defect class.** `shellcheck -S warning`
    exits 0 on `rm -rf $dir` because SC2086 is info-level — the class this repo's
    `sota-shell-scripting` rules/01 §3 calls "a bug, not style". Raised to `-S style`,
    widened from `scripts/*.sh` to every tracked `.sh` (which brought
    `evals/cases/dead-path/selfcheck.sh` under lint for the first time), and made to fail
    closed on an empty file list. The tree was cleaned to **0 findings at style** first —
    `ls`-parsing and `A && B || C` fixed properly rather than suppressed.
  - **`principle5()` returned `""` on a moved marker**, silently weakening the treatment
    arm of the flagship +0.39 — and `ROUTER_BUILD_SHA` does not cover it (the hash spans
    chars 24111–26758; principle 5 lives at 4079–6433, **disjoint**). Now aborts, with a
    length floor. Watched to fire.
  - **`judge-live-build.py` averaged over survivors** — the defect fixed in
    `run-competitors.py` two days earlier, in the instrument that produced the published
    **0.987**. Now aborts when nothing was judged, labels partial runs in stdout *and*
    the artifact (`cases_done`/`cases_total`/`complete`/`skipped`).
  - **The negative-control harness misreported its own coverage**: invariants 3, 4 and 7
    were in neither the covered nor the "not covered" list, so
    `AGENTS.md:97` ("what is not covered is printed, not implied") was false. The list is
    now exhaustive — 6 covered + 10 uncovered = 16, no overlap — and says *why* each is
    uncovered. Harness still **16/16**.
  - **Invariant 14 matched front-door terms as a regex** (`a.b` matched `axb`); both
    greps are now `-F`.
  - Silent-zero guards added and each watched to fire: `score.py` (empty corpus),
    `run-adjudication.py` (`assert` → `sys.exit`, plus a router-marker guard),
    `run-desc-routing.py` (the ablation must actually remove something, or the null is
    manufactured), `run-clean.py` (empty freshness corpus).

### Added

- **A missing tool is a decision, not automatically a failure**
  (`sota-shell-scripting/rules/02` §6). `|| die` is right only for a dependency the
  script cannot be correct without; for everything else the rule is now explicit —
  **skip the affected check with a named note** (never let a summary read clean when a
  check did not execute), degrade for optional tooling, and **on an interactive run stop
  and ask the human to install it, printing the exact command**. Never auto-install:
  installing software is a change to someone's machine and a non-interactive run has
  nobody to consent. Ships with a `need()` helper and its audit half.



### Measured

- **Competitor benchmark re-run: the published claim holds after a month of library
  change.** SOTA **98.7%**, ECC 84.9%, awesome-cursorrules 80.0%, claude-skills 77.0%,
  unguided **58.2%** — and SOTA again **won 17, tied 4, lost 0** of 21 head-to-head
  cases. Same build model (`git log -S` shows the default was set by the original
  benchmark commit and never changed) and the same pinned competitor SHAs, so library
  content was the only variable. **The unguided arm reproducing to 0.2 points is the
  control** that says the harness and judge did not drift underneath the comparison.
  Competitor moves of 2–4 points are **not** claimed as regressions — n=1 per arm, and a
  2-point move is one rubric item on one case.
  [COMPETITOR-RERUN](evals/results/2026-08-14/COMPETITOR-RERUN.md)

### Fixed

- **A partial results artifact reached `main`, and the runner now refuses to hide it.**
  A `git add -A` in an unrelated docs commit swept up `competitor-rerun.json` while the
  run was still executing, and it merged. The committed file was **valid JSON with 2 of 7
  cases** and `means` recomputed over just those two — `ECC` read **0.954** against a true
  **0.849**, with nothing in the artifact saying it was partial. That is the dangerous
  shape: not corrupt, just plausibly wrong. The incremental save stays (it is deliberate
  crash-safety); the artifact now carries `cases_done`, `cases_total` and `complete` so a
  reader or scorer can refuse an unfinished file instead of averaging it. The complete
  file replaces the partial one in this change.


### Added

- **zsh does not word-split unquoted expansions — and the library said it did.**
  `sota-shell-scripting/rules/01` §3 stated word splitting as universal, which is a
  *bash* fact: zsh's `SH_WORD_SPLIT` is off in native mode (the manual marks it
  `<K> <S>`, ksh/sh emulation only). So `cmd $args` passes **one** argument in zsh, and
  the same line that is a splitting bug in bash is a **joining** bug in zsh — on the
  platform that defaults to zsh. Verified by execution, not assertion:
  `printf "[%s]" $args` → `[one two three]`, `${=args}` → `[one][two][three]`.

  Shipped with its audit half. **`shellcheck` refuses zsh outright** (`SC1071 … only
  supports sh/bash/dash/ksh`, confirmed by running it — and popular web summaries claim
  the opposite, which the binary settles). The checklist now carries a verified tool
  table rather than the absence claim this entry first made: `zsh -n` catches **syntax
  only** (proven on a broken script), `WARN_CREATE_GLOBAL` is runtime and narrow, and
  `z-shell/zsh-lint` exists and is actively pushed (~33 stars) — so "no linter for zsh"
  is false, while "no widely-adopted static analyser catches the splitting class" holds.
  The checklist adds the
  grep for `${var:+--flag $var}` and bare `cmd $args`, and names the symptom that
  misleads: a **usage error (exit 2) from the callee**, which reads as a bug in the tool
  rather than in the harness calling it. `rules/02` §4 gained zsh's `${pipestatus[1]}`
  (1-indexed) beside bash's `${PIPESTATUS[0]}`.

### Changed

- **The empty-completion guard is now a recorded convention, not just code.**
  [CONVENTIONS-LEDGER](docs/CONVENTIONS-LEDGER.md) goes from **four** runner-enforced
  conventions to **five** — and it arrived the way that ledger predicts they do, from an
  incident rather than from re-reading the docs. `AGENTS.md` and the evals harness
  conventions were updated to match.
- **Competitor benchmark re-run in flight** at the pinned competitor SHAs, with the same
  build model as the 2026-07-13 original (`git log -S` confirms the default was
  introduced by the original benchmark commit and never changed, so the library content
  is the only variable). The **as-deployed** variant stays unbuilt and is now recorded as
  blocked on a *design* decision rather than effort: "as their users install them" means
  something different per competitor, and choosing those mechanics chooses the result on
  a public claim about named third parties.

## [1.22.5] - 2026-08-14

**Instruments, corrected.** Every entry here is a measuring tool that was wrong or
silent, found by using it: an empty completion counted as a successful call in five
runners, a probe that counted Go import paths as network traffic, two arms that
reported a verification they never ran, and a page still explaining the audit +0.00
with a hypothesis this cycle falsified. The one new number, +0.58 at three samples,
exists because the harness crash that produced it was fixed rather than retried.

**Front door checked:** cross-family · real-repo · precision

### Measured

- **Cross-family #2 re-run at 3 samples/arm: 0.38 → 0.96, lift +0.58** (`$4.48`, 1753 s,
  temp 0.7 — the same multi-sample protocol the other value dimensions use). The n=1
  caveat is discharged: **all 7 cases positive** (+0.52 to +0.67), and the arms behave as
  they do everywhere else — with-arm mean 0.96 with a max within-case sample spread of
  **0.10**, against the unguided arm's **0.18**. Three labs now read +0.39 / +0.44 /
  +0.58. [CROSS-FAMILY-GEMINI](evals/results/2026-08-13/CROSS-FAMILY-GEMINI.md)

### Fixed

- **The same empty-completion defect was in four more runners — now guarded in all of
  them.** After fixing `run-completeness.py`, a sweep found `run-clean.py`,
  `run-decay.py`, `run-desc-routing.py` and `run-repo-audit.py` reading
  `choices[0].message.content` raw with no check. That set includes **`run-clean.py`,
  which produces the flagship +0.39** — and the two importers (`run-adjudication`,
  `run-silent-open`) plus `run-competitors` inherit its `call()`, so four files cover all
  twelve runners. Each guard was **watched to fire** against a stubbed
  200-with-null-content response, not merely compiled: two exit with
  `empty completion from …: finish_reason=length`, two raise it so their retry loop
  engages first.
- **`run-completeness.py` treated an empty completion as a successful call.** A reasoning
  model can spend its whole `max_tokens` budget on reasoning and return
  `content: null` under HTTP 200; the harness passed that to the judge, where it
  surfaced 80 lines away as `'NoneType' object is not subscriptable`. Worse than the
  crash was the near miss: an **empty artifact that reached the judge would have scored
  ~0 and silently depressed an arm**. `call()` now retries an empty completion and then
  fails loudly with the finish reason, and warns when `finish_reason == "length"` because
  a truncated artifact is a floor, not a measurement. Watched to fail before being
  trusted (`max_tokens=1` → `RuntimeError: empty completion … finish_reason=length`), and
  the 3× run that followed produced **zero** truncation warnings.

- **Stale claims removed from the docs that carry them.** `AGENTS.md` said the
  negative-control harness runs **15 probes** and enumerated five invariant probes; it
  runs **16** and the enumeration omitted invariant 16, which shipped with its own probe
  in v1.22.2 (re-counted: 6 in part A, 10 in part B). And
  [WHY-IT-WORKS.md](docs/WHY-IT-WORKS.md) still explained the audit +0.00 by saying a
  real lift "would need whole-repo, cross-file context a snippet can't carry" — that
  hypothesis was **tested and falsified** this cycle on a real repository with real CVEs,
  on both recall and precision, so the page now says so and points at what is actually
  untested (a different dependent variable, not more context). The third cross-family
  result was added there too.

### Measured

- **Audit precision measured: 1.00 vs 1.00 — the ninth null.** All 59 findings from the
  two clean arms of the Harbor run were pooled, blinded, hash-shuffled and adjudicated
  against the code by three independent agents barred from the internet. **Zero false
  positives on either side.** With recall already 15/16 = 15/16 and severity mix
  indistinguishable, the library arm and the bare arm are the same auditor on this
  subject. The adjudicator itself passed a **4/4 known-answer control** (two fabricated
  findings REFUTED with the deciding code quoted, two real ones CONFIRMED), so the 1.00
  is not a lenient scorer.

### Fixed

- **Two corrections to the published real-repo audit, both found by re-checking my own
  probes.** The "upstream fetches" column counted `github.com/goharbor` — the Go **module
  path in every import statement** — not network calls; re-counted from actual commands.
  And the correction surfaced worse: **both clean arms claimed a byte-identical diff
  against upstream that neither ever ran** (r1 executed one `cat VERSION` in a workspace
  with no `.git`, and invented a "sanity-checked against v2.6.0" detail). The two arms
  that *did* run the diff are precisely the two that got contaminated by reading the fix.
  Symmetric across a bare and a library arm, so it is a model property, not a library one
  — but it lands on this library's own "claim done only with evidence" doctrine.
  [REAL-REPO-AUDIT](evals/results/2026-08-13/REAL-REPO-AUDIT.md)

## [1.22.4] - 2026-08-14

**Rules from someone else's incident notes, a leak the leak-check could not see, and
the eighth audit null.** Three of this cycle's rule additions came from reading an
outside implementation's own failure write-ups; one came from our own gate passing
while a name sat in two tracked docs. The measurement half is one positive and one
null, both published.

**Front door checked:** business logic · cross-family · real-repo

**Three rules from a 1-star repo that documented its own failures.** An intake pass over
[spanchain](https://github.com/ghostfactory-art/spanchain) (Elixir hash-chained audit
ledger for agent runs) found six of its lessons already in `sota-code-security/rules/04`
§8 — independently arrived at on both sides — and three that were not. Full intake with
verdicts, rejections and the verification notes: [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md)
2026-08-11.

### Changed

- **Business-logic flaws are now reachable by name.** A coverage/depth audit of that
  defect class against OWASP WSTG-BUSL (all **10** sub-tests, IDs read from OWASP's own
  repo — the task that commissioned this audit recalled 9 and missed
  `WSTG-BUSL-10 Test Payment Functionality`), API6:2023 and the CWE-840 cluster found the
  **content is there — 10 of 10 map at depth ≥3, most at 4** — but the class was
  unreachable: "business logic", "checkout", "refund" and "state machine" appeared in
  **zero** of 41 `SKILL.md` descriptions, and "workflow" appeared only in the CI, SOC and
  docs senses. Descriptions are the only auto-loaded trigger classifier, so the fix is one
  word-pair in `sota-code-security`'s description (998 → 1014 of the 1024 cap).

  **Two drafted rules edits were cut after refutation**, which is the point of running
  one: the BUSL-07 and BUSL-10 "gaps" were both covered under other names, and the
  refuter's own surviving residual (currency mismatch) fell to
  `rules/01-input-injection.md:28`. No rule text changed.
  [COVERAGE-BUSINESS-LOGIC-2026-08-13](docs/COVERAGE-BUSINESS-LOGIC-2026-08-13.md)

### Measured

- **The real-repo audit eval ran: no measurable lift, and a new contamination vector.**
  Four live agents (2 bare, 2 library) audited Harbor `v2.5.1` against 16 real
  broken-object-level-authorization sites. Clean result: **bare 15/16, library 15/16** —
  the eighth audit instrument to read ≈ +0.00, and the first on a real repository with
  real CVEs. **Two of four arms were discarded**: they looked up Harbor's *fixed* source
  mid-audit, proven by counting symbols the fix introduces (`requirePolicyAccess` and
  friends, 63 and 54 occurrences) which exist nowhere in the vulnerable tree. A synthetic
  subject leaks the answer through structure; a real one leaks it through the internet.
  The probe is now a documented harness convention.
  [REAL-REPO-AUDIT](evals/results/2026-08-13/REAL-REPO-AUDIT.md)
- **Third model family confirms the completeness lift: `google/gemini-3.1-pro-preview`,
  0.41 → 0.96, lift +0.55** ($1.63, 7 cases, n=1 per arm). Three labs, three positive
  lifts — +0.39 sonnet, +0.44 gpt-5.1, +0.55 gemini — and the same relationship each
  time: the lift tracks the **baseline**, not the lab. Recorded as a confirmation of
  direction, not a precision estimate.
  [CROSS-FAMILY-GEMINI](evals/results/2026-08-13/CROSS-FAMILY-GEMINI.md)

### Fixed

- **The real-repo audit subject was mischaracterized, and reading the tree caught it.**
  [DESIGN-real-repo-audit.md](evals/DESIGN-real-repo-audit.md) described Harbor's 8
  advisories as a *missing* authorization check. They are not: at `v2.5.1` every
  vulnerable handler already calls `requireAccess`, and `retention.go` has 11 checks for
  11 handlers. What is missing is the **object-to-tenant binding** — that the policy or
  execution named in the URL belongs to the project the caller was authorized against
  (34 object-binding lines added in the fix, against 1 project-access line). It is OWASP
  API1:2023, and a *silent control* in `rules/10`'s sense: the guard runs, returns nil,
  and everything downstream believes authorization happened. A better subject than the
  original reading, and the correction only surfaced because the claim was checked
  against the tree instead of the filenames.
- **An internal-name leak the internal-name check could not see.** Two tracked docs
  named one of the maintainer's other projects, and one of those lines also carried a
  local `~/` path; a third line elsewhere did the same. Invariant 3 passed on all of it,
  because the private denylist had no pattern for that name — the gate was green on an
  incomplete **list**, not a clean tree, which is `rules/12` §3's guard-whose-predicate-
  misses-its-own-target in this repo's own machinery. Lines redacted (the meaning is
  kept, the identifiers are gone), the private list extended, and the new pattern
  **watched to fail** against a staged known-bad before being trusted (`[3/16]` flagging
  the probe, full run exiting 1, then 0 once removed). The pre-2026-07-01 disclosure in
  git history is unchanged and stays an accepted risk — re-confirmed with the sweep's
  scope recorded in [docs/AUDIT-2026-07-01.md](docs/AUDIT-2026-07-01.md) S1.

  [CONTRIBUTING.md](CONTRIBUTING.md) now documents the part that bit: the list lives in
  two places that cannot see each other (a git-ignored local file and a **write-only**
  CI secret), so a name added to one silently leaves the other lane open. It also
  documents the **canary** — a synthetic pattern in both copies that lets anyone prove
  the secret is loaded and blocking by pushing a file containing it, without printing a
  real internal name into a public CI log, which is what probing with a real name would
  do.

### Added

- **`sota-code-security/rules/04` §8 — a partitioned chain must chain its partitions.**
  Ledgers get segmented for ordinary reasons (fixed-size epochs to bound an index, daily
  partitions, rotated files) and the obvious implementation starts each segment with
  `prev_hash = NULL`. Deleting a whole **interior** segment then verifies clean on both
  sides of the hole. §8 previously enumerated two deletion geometries, tail and
  whole-stream; the rule now names three and says which a chain walk can and cannot
  catch. Audit checklist asks for the fixture: one whole interior segment removed.
- **`sota-code-security/rules/12` §3 — a fourth form of "the guard that is an instance of
  what it guards".** The segment bug lived in the *verifier*, which reset its carried
  hash at each boundary: predicate right, traversal right, blind to the removal of a
  whole chunk. Also a new axis for §3's per-target rule — for a guard that walks a
  sequence the population includes the **seams** (first chunk, last chunk, interior chunk
  removed, empty chunk), and three of those four survive any amount of single-record
  mutation.
- **`sota-code-security/rules/04` §8 — canonicalization fails in two directions, and
  "canonical" must name a spec.** The library said "canonical, unambiguous encoding" in
  three places and never said how to get one; a reader complying with `sort_keys=True`
  has a single-language encoder with unpinned float and escaping behaviour, which
  contradicts the same section's requirement that verification run off the storing
  system. Now names RFC 8785 (JSON Canonicalization Scheme, June 2020, Informational) or
  a written encoder spec, pinned by a committed known-answer vector. Adds the missing
  **false-alarm** direction: a default map/JSON encoder is not canonical — quoting the Go
  spec ("the iteration order over maps is not specified…") and the Elixir `Map` docs
  ("key-value pairs in a map do not follow any order") — so identical data hashes
  differently, the ledger reports tamper on untouched records, and an alarm that is wrong
  on ordinary traffic gets muted, which is `rules/10`'s inert control by another route.
- **`sota-llm-engineering/rules/01` §5 — a replay harness is not an eval.** Recorded-trace
  or cassette replay re-executes nothing, so it tests pipeline determinism, not the
  system's behaviour; wired into the gate as if it were the suite, the CI job stays green
  through a prompt rewrite, a model swap or a retrieval change. Suites must declare what
  is live and what is replayed, and the gate must fail with the model endpoint
  unreachable — the file's first link into the silent-control family.

## [1.22.3] - 2026-08-05

**Closing the loop on the gates.** The v1.22.x cycle built a harness to prove our checks
can fail, then found the harness itself could not block a merge. This closes that, and
tidies the roadmap the cycle left messy.

**Front door checked:** negative control · activation

### Fixed

- **All four CI jobs are now required checks.** Branch protection required only
  `Repository invariants` and `Secret scan (gitleaks)`; `Negative controls (the gate can
  fail)` and `Shell lint (shellcheck)` ran on every PR and **could not block a merge** —
  so the harness built to prove our gates can fail was itself unable to stop anything.
  A gate that executes with no enforcement power is `rules/10` §2.13 one level up.

  **Watched to block, not merely configured.** A throwaway PR made invariant 2 inert so
  that *only* the negative-controls job failed — `check-invariants.sh` stays green when
  one of its checks goes inert, which is exactly the defect the harness exists to catch,
  so the other three jobs stayed passing and the protection's reaction was unambiguous:

  ```
  BEFORE   mergeable=MERGEABLE  mergeStateStatus=UNSTABLE   ← could have been merged
  AFTER    mergeable=MERGEABLE  mergeStateStatus=BLOCKED
           gh pr merge → "the base branch policy prohibits the merge"
  ```

  `UNSTABLE` vs `BLOCKED` is the discriminating observable — `UNSTABLE` means a
  *non-required* check failed. Applied via the dedicated `required_status_checks`
  endpoint, not the full `/protection` PATCH, which requires every field and silently
  drops what you omit: everything outside that key diffed **identical** before/after,
  `enforce_admins` stayed `true`, `strict` stayed `false`.
- **`docs/ROADMAP.md`'s actionable table had three rows numbered 8 and two numbered 9**,
  because three consecutive cuts each appended "the next item" without checking. Record
  rot of our own making. The five completed items now sit in a dated **closed list**
  below the table, without numbers; the table holds only what is still actionable (1–7).

### Changed

- **`docs/INDEX.md` gained the two rows this cycle needed.** The find-it-fast index had
  **zero** hits for `negative control` and for skill *activation* — both shipped in
  v1.22.0–v1.22.2 with no way to reach them from the index a lost reader is told to start
  at. The `CONTEXT-MANAGEMENT.md` anchor was derived from the live heading rather than
  assumed: invariant 8 resolves `*.md` targets, not fragments.
- `AGENTS.md` and `RELEASING.md` said **"both required checks"** — now four.
  `docs/AUDIT-2026-07-01.md`'s "both checks green" is a dated historical record and was
  deliberately left alone.

**Nothing here is measured; no lift is claimed.**

## [1.22.2] - 2026-08-05

**Invariant 16 — the hook we document is the hook we install.** `install.sh` *writes*
the `UserPromptSubmit` hook and `README.md` *documents* it, and nothing kept them equal.
On 2026-08-05 three texts existed simultaneously: the README block (two revisions
behind), `HOOK_CMD`, and what was actually in a real `settings.json`. The README's is
the one a reader copies **by hand**, so the stale one is the version that spreads — and
nothing executes a README, so the drift is silent by construction.

**Front door checked:** install.sh · UserPromptSubmit

### Added

- **Invariant 16.** Parses the README's fenced JSON block rather than regexing the
  string, so reformatting the block is not a false positive, and compares the extracted
  `command` to the single `HOOK_CMD` assignment in `install.sh`.
- Its **known-bad is in `check-negative-controls.sh`**, per the rule this repo now
  applies to itself: a check whose failure nobody has watched is not a check. The
  harness reports **16/16**.

### Verification

Watched to fail **four** ways, then restored: README drifts; `install.sh` drifts; the
README block is removed (fails **closed** via `SCOPE EMPTY`, not silently); and the
`HOOK_CMD` assignment is renamed (same). The two empty-scope cases matter most — they
are the mode where a gate keeps printing green over nothing.

**Nothing here is measured; no lift is claimed.**

## [1.22.1] - 2026-08-05

**Turning the negative-control bar on our second gate — and finding a rotted number
while doing it.**

### Fixed

- **`verify-setup.sh` printed a hardcoded, repo-specific, and by then false number.**
  Check 10b's message carried `(this repo: 0 failures in 60, 1 in 200)`. Two defects in
  one parenthetical: the script is **generic** and runs against anyone's repo, so a
  sample measured on *this* one is wrong for the reader (AGENTS.md: *"never phrase
  guidance as an assumption about the reader's setup"*); and it had **rotted in three
  days** — re-measured 2026-08-05, the last 200 runs are 200/200 success and the single
  failure sits at ~position 400 (2026-07-14), pushed out of the window by this session's
  CI volume. It is `rules/10` §2.10 — a literal in reporting output instead of a derived
  value — inside the script whose whole job is verifying claims. The derived
  `$n_runs` and the actionable `Widen with --runs N` remain.

### Added

- **`check-negative-controls.sh` part B — negative controls for `verify-setup.sh`.**
  It had 14 checks and nothing had ever proven one could fail. The fixture is inverted
  from part A: `verify-setup.sh` audits a **machine**, so part B builds a
  fully-configured fake one — `CLAUDE_CONFIG_DIR` at a temp home (the script reads that
  env var, so the real `~/.claude` is never touched), a throwaway git repo, and a stub
  `gh` on `PATH` so run history is decidable — then **removes one thing per probe**.
  10 probes over checks 1, 2, 3, 4, 6a, 6b, 7, 8, 9 and 10a; the harness now reports
  **15/15**. Extended the existing script rather than adding a second CI job.
- Both parts keep the FALSE-PASS rule: a non-zero exit for any reason *other than the
  intended check* is reported as a false pass, not a catch.

### Verification

Watched to fail, per the script's own bar: making `verify-setup.sh` check 6a
unconditionally pass makes the probe report **`NOT CAUGHT: This check is INERT`** and
the harness exit 1. `CLAUDE_CONFIG_DIR` redirection was proven rather than assumed (a
temp home with 2 planted skills reports 2, against the real 41). `shellcheck -S warning`
caught an `rm -rf "$VS/home"` that would expand to `rm -rf /home` on an empty variable —
now `${VS:?}`.

**Front door checked:** check-negative-controls · verify-setup

**Nothing here is measured; no lift is claimed.**

## [1.22.0] - 2026-08-05

**The activation release — and gates that prove they can fail.** Two findings, both
from real sessions rather than from re-reading docs. First: a ~25-turn session doing
upstream-contribution work invoked **zero** `sota-*` skills, because only the
frontmatter `description` auto-loads and the old trigger verbs all assumed you own the
codebase. The router's content was never in question; it was never read. Second: the
repo's own CI printed "ok" fifteen times without anything ever proving those checks
could still fail — the thing this library requires of everyone else.

**Front door checked:** check-negative-controls · pull request · publishing · negative control

**Nothing in this release is measured; no lift is claimed.** `desc-routing` reads
**+0.00 (saturated)** and cannot distinguish two descriptions; the AUDIT arm remains
+0.00 across seven instruments.

**Activation, not content.** A real ~25-turn session doing upstream contribution work
invoked **zero** `sota-*` skills. The router body — which already contained rules that
would have caught the worst error — was never read, so its quality was irrelevant. Only
the frontmatter `description` auto-loads
([Agent Skills docs](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview):
*"until a Skill is triggered, only its name and description occupy context"*), which makes
the description the entire trigger classifier and everything downstream dead weight until
it fires.

### Added

- **Router description now covers code you do not own** — reviewing a pull request or
  diff, responding to code review, evaluating someone else's patch, preparing an upstream
  contribution, *including mid-session once you are already reading source, a diff or CI
  config*. The old verbs all assumed you own the codebase. Paid for by cutting the
  31-domain enumeration (**−445 chars**), which duplicated the routing table in the body;
  the description is a matcher, and verbs like `diff`/`upstream`/`review` match harder
  than 31 nouns. Net **951/1024**, recovering 73 chars of headroom against invariant 4.
- **Principle 7 — restate from the artifact, never from your own summary.** Principle 0
  listed what does *not* validate (training data, plausibility, "the rules file says so")
  and never named the commonest one: **your own earlier prose in this session**.
- **Principle 8 — publishing under someone else's name raises the bar**, with the full
  procedure as `sota-docs-workflow` rules/03 **§8**. The library assumed findings go to
  the person who asked; a PR comment, issue or commit message posted upstream is public,
  attributed and permanent. Nothing covered that. (`llm-engineering` rules/04's approval
  gates are about agents you *build*; rules/03 §3's "ask, don't assert" is a tone rule.)
- **Falsification precondition on principle 0** — state what result would falsify a claim
  *before* measuring; if none could, read the deciding code path instead of benchmarking
  symptoms.

### Fixed

- **The shipped hook buried its own routing rule.** `install.sh`'s `HOOK_CMD` put routing
  in a subordinate clause after two numbered rules. In the session above, rules (1) and
  (2) were obeyed every turn and the routing clause was dropped every turn — same text,
  same repetition, opposite outcome. Routing is now **numbered rule (3)** of equal weight,
  and it is **recoverable**: *"If you have already read code this session without routing,
  route now."*
- **A reworded hook silently stopped receiving updates.** `HOOK_SIG` was
  `"sota standing rules:"` — the first three words of the message — so a user who
  reworded the opening un-managed their own hook, and `--update` would then **add a second
  hook** rather than refresh it. Verified against a real install with the exact `jq`
  `install.sh` runs. The marker is now **`sota-* skills`**, a phrase present in every
  version ever shipped and in hand-edited variants; tested to match those and to ignore an
  unrelated hook.
- **Three different hook texts** existed across `README.md`, `install.sh` and installed
  configs. The README now shows exactly what `install.sh` writes, and documents that
  hand-edits must keep the `sota-* skills` marker.

### Changed

- `skills/sota/SKILL.md` reflowed (library map, cross-cutting rules, AUDIT workflow) from
  ~72 to ~98 columns to buy the lines for principles 7 and 8 — content unchanged, **491/500**.

**Nothing here is measured; no lift is claimed.** The repo's one adjacent instrument, the
`desc-routing` eval, reads **+0.00 (saturated)** and cannot distinguish these descriptions.

**Proving the gate can fail.** v1.21.1 shipped two known gaps in our own CI and wrote
them down as ROADMAP #8 and #9. Both are now closed, and the second one justified
itself within a minute of first running.

### Added

- **Invariant 15 — the router's library map lists every rules file, both
  directions.** Invariant 7 proves every *skill* is in the map; invariant 10 proves
  every rules file is indexed by its *own* `SKILL.md`. Neither reads the map's
  **contents**, which is how `sota-code-security/rules/11` sat unlisted in
  `skills/sota/SKILL.md` from **v1.19.8 to v1.21.0** with all fourteen checks green.
  The check compares the `NN` numbers the map enumerates per skill against
  `skills/<skill>/rules/NN-*.md` and reports a file missing from the map *and* a map
  entry naming a file that does not exist. The number is anchored to a list position
  so a title containing digits cannot be misread — `02 NIST 800-53/800-171` yields
  `02`, never `80` or `53`. **Watched to fail first**, per the script's own header:
  once by recreating the real defect, once on its inverse, then restored.
- **`scripts/check-negative-controls.sh` — a negative control for our own gates**,
  running in CI as its own job. `check-invariants.sh` passing proves the *tree* is
  clean; it has never proved the *checks* still work, and those two states print
  identically. The harness injects a known-bad per invariant into a disposable git
  worktree and requires **the intended check** to be the one that complains — a
  non-zero exit for any other reason is a **FALSE PASS**, not a catch. It runs a
  positive control first (clean copy must pass, else abort rather than report), and
  copies in the working-tree gate and byte-compares it, because a worktree at `HEAD`
  would otherwise test the *committed* gate rather than the one being edited.
  Covers invariants 1, 2, 6, 10, 15; states plainly that the diff-, history- and
  release-shaped checks are **not** covered.

### Why the second one earned its keep immediately

On its **first run** the harness reported a FALSE PASS against its own probe 15.
`git clean` does not remove *staged* files, so a fixture added by probe 10 leaked
into the next mutation, which then failed on the file-count check instead of the
check it targeted. **A harness that accepted any non-zero exit would have printed
`5/5 caught` and been wrong about one of them** — precisely the `rules/12` §2.1
"instrument that cannot fail" mode, caught in our own instrument by the one
assertion added to catch it. Fixed with `git reset --hard` (which clears the index)
plus a re-copy and re-compare of the gate, since the reset also reverts it.

### Changed

- Invariant count **14 → 15** across `AGENTS.md` (table + prose),
  `CONTRIBUTING.md` (numbered list + a new "proving the gate can still fail"
  section) and `docs/MAINTENANCE.md`. `docs/ROADMAP.md` line 426 says "14 checks"
  about **`verify-setup.sh`**, a different script, and was deliberately left alone.
- `AGENTS.md`'s "two gaps in the gates, known and unfixed" paragraph — added one
  release ago — was **false as of this change** and now records both as closed.
- ROADMAP #8/#9 struck through with what shipped; `docs/CONVENTIONS-LEDGER.md`
  moves both candidates from "gateable but not gated" (2 → **0**) to gated, and
  records that the doctrine-only candidate is no longer doctrine-only.

**Nothing here is measured; no lift is claimed.**

## [1.21.1] - 2026-08-05

**The inert-control release — three days of "the rule was there, the probe wasn't."**
An external audit spec (seven classes beyond our five) and two commissioned research
reports were taken in, and the recurring finding was the same each time: the library
*stated the BUILD rule* and had never written the **AUDIT probe**. It said "unit tests
touch no sockets" in three places and offered no way to find out that they do; it
governed the *numbers* a tool prints and not the *words*; it declared instruments to be
controls without ever turning that recursion on **guards**. The inert-control family is
now three files — `rules/10` catalogs, `rules/11` sweeps, **`rules/12` proves a control
works and distrusts whatever did the proving.**

**Front door checked:** negative control · metamorphic · oracle problem · rules/12

**Nothing here is measured; no lift is claimed for any of it.** The AUDIT arm remains
at +0.00 across seven instruments, and none of this changes that.

**Naming the prior art, and the four gaps two research reports found.** Two
commissioned reports on inert controls were evaluated against the tree. They agree
on the headline — the missing layer is a control shown *capable of failing* — and
they are not of equal quality: one misquotes NIST SSDF PO.3.3, over-generalises the
formal-verification vacuity statistic from hardware to software, and sources
aviation self-test to Scribd uploads. Every claim that became library text was
checked against a primary source first, which is why four gaps landed out of
thirteen proposals. Full verdicts, both rejections, and the misquote are in
[docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md) (entry 2026-08-05).

**Nothing here is measured; no lift is claimed for any of it.**

### Added

- **`rules/12` §3 — per-target kill verification.** A guard protects a
  *population*. Watching it reject one member proves the predicate can fire and
  says nothing about the other 19; the real shape is a tripwire that fired for 2
  of 20 targets and stayed green for 18, indistinguishable from full coverage on
  any single-instance test. Inject the defect into **each** member. For a security
  gate the bar is a **100% kill rate** — unlike a code mutation score, where
  surviving mutants are triaged and a number below 1.0 is normal.
- **`rules/12` §2.4 — evidence the subject supplies about itself.** An instrument
  that accepts the evaluated party's own report is transcribing, not measuring.
  The anchor is now measured: across 1.5M assets and 128K agents, **"over 84% of
  approved assets bypass quality checks using vacuous tests (e.g. `console.log()`)"**
  ([arXiv:2605.25815](https://arxiv.org/abs/2605.25815)) — the platform accepted
  each agent's own execution log as proof. Notably the *other* report asserts no
  such corpus exists; this one found it.
- **`rules/11` §2.6 — when you cannot state the right answer, state how it must
  change.** A **metamorphic relation** as a liveness oracle for a tool: commit a
  fixture with N known items, assert the count is N, assert it rises when you add
  one. The only diagnostic in that file that catches an analyser emitting an
  empty-but-well-formed artifact while exiting 0.
- **`sota-devsecops` rules/05 §5.6 — what the standards ask for, and the one thing
  none of them ask.** SSDF **PW.8.2**/**PO.3.3** and CRA **Annex VII** require a
  record that the scan *ran*; OpenSSF Scorecard's SAST check detects tool
  *presence* only, and its Dependency-Update-Tool check says outright it "does not
  ensure that the tool is run". **None require evidence the gate can fail** — SLSA
  will sign provenance for a scanner configured to scan zero files. So a passing
  compliance check is evidence of process, not protection, and the negative
  control has to be a house rule.

### Changed

- **The cross-discipline lineage is now named.** The library had described proof
  tests (IEC 61508's dangerous-undetected framing), positive controls, aviation
  built-in test, poka-yoke, **vacuous satisfaction** (Ball & Kupferman, quoting
  Beer et al. on hardware verification) and **the test oracle problem** (Barr,
  Harman, McMinn, Shahbaz & Yoo, *IEEE TSE* 41(5):507–525, 2015) for months
  without using any of those words — `poka-yoke` and `oracle problem` returned
  **zero** hits across all 41 skills. Named in `rules/12` intro + §3 and
  `rules/11` §2.6.

### Rejected (recorded so they are not re-litigated)

- **A minimum mutation-score threshold in CI** — contrary to `sota-testing`
  rules/07 §7.2 ("never set a global percentage target") and rules/06 §6.3
  differential mutation, adopted 2026-07-24. The *per-gate* kill rate above is
  compatible and was adopted; a global score is not.
- **GSN / assurance-case notation** — a notation, not a mechanism, and its own
  cited critique (arguments that "assume the conclusion") describes what
  `sota/rules/01` §7 adversarial refutation already prevents.

### Not verified, and therefore not asserted

IEC 61508 §3.8.5/§3.8.6 clause text is paywalled — the *concept* is named and no
clause number is quoted. The CRA Annex VII **point number** was not confirmed
(EUR-Lex returned only recitals); the sentence was verified against published
copies of the regulation, and `rules/05` says so at the point of use.

**The rules/12 split — the inert-control family gets a third file.** The previous
entry below shipped `rules/10` and `rules/11` at 493 and 495 of the 500-line cap and
said plainly that the next addition needed a split rather than another squeeze. This
is that split, and the boundary is not arbitrary: rules/10 catalogs inert controls,
rules/11 sweeps for them at scale, and **rules/12 is the third move — proving a
specific control works, then turning the same suspicion on everything that did the
proving.** That layer was previously split across two files (a mutation procedure at
the end of one, an instrument section at the end of the other) and belonged together.

### Added

- **`sota-code-security` rules/12 — Verifying the Verifier** (191 lines). Composed
  from `rules/10` §3 (the mutation probe for a security control) and `rules/11` §7
  (your instrument is a control), plus the **guard that is an instance of what it
  guards** promoted from a bullet to its own §3 with all three forms written out:
  the predicate the defect satisfies (`"auth=" in line` passes on `auth=None`), the
  guard nested in another gate's success branch, and the denominator counting only
  survivors. Its organising asymmetry: a broken feature produces a complaint, but a
  **broken verifier produces a green tick or a number**, and both get believed.
- **`rules/11` §7 "Then turn the lens around"** — a short hand-off replacing the
  moved section, stating the rule that motivates the file: a finding produced by an
  unvalidated instrument is not yet a finding.

### Changed

- **`rules/10` renumbered**: §3 (vacuous tests) moved out, so §4 → §3 (degradation
  helper) and §5 → §4 (evidence rules). All live cross-references repointed —
  `rules/11` ×4, `sota-devsecops` rules/03, README, `docs/CONVENTIONS-LEDGER.md`,
  `evals/README.md` ×2, and a comment in `scripts/check-invariants.sh`. Historical
  CHANGELOG and ADOPTION-LOG entries were deliberately **not** rewritten: they
  record what shipped at the version they describe.
- **`### 7.1 Four failure modes` listed five bullets** — count-rot introduced by the
  previous entry when the guard bullet was added without updating the heading. Fixed
  structurally rather than by editing the number: the guard is now its own section
  and 7.1 (`rules/12` §2.1) is back to four.
- **The router's library map had never listed `rules/11`.** `skills/sota/SKILL.md`
  stopped at "10 silent control failure"; it now lists 10, 11 and 12. Invariant 7
  gates skills against the router, not *rules files*, so this drifted unnoticed —
  and `sota/SKILL.md` is itself at exactly 500 lines, so the entry was rewritten to
  fit the same four lines rather than growing the file.
- **`rules/11` §2.2 — the runners disagree, which is the point.** Both verified by
  running them: `go test ./...` over a package with no test files **exits 0**, while
  `pytest` on the same empty scope **exits 5** — as it does for a file with no test
  functions and for a `-k` selector that deselects everything (pytest 9.1.1). One
  fails closed, one fails green, so no folklore about "runners exit 0 when they find
  nothing" tells you which you have. (The previous entry deliberately omitted the
  pytest half as unverified; it is now measured.)
- README file count 297 → **298** (invariant 6 again), and the "your own scorer"
  class now points at `rules/12`.

### Family headroom after the split

`rules/10` 468, `rules/11` 415, `rules/12` 191 — from 12 lines of combined headroom
to 426.

**The audit half of a rule we already had.** An external inert-control audit spec
(seven classes beyond our five) was evaluated against the tree class by class. Two
were already covered end to end and stay rejected; the rest split into a pattern
worth naming: **we had stated the build rule and never written the probe.** The
library said "unit tests touch no sockets" in three places and offered no way to
find out that they do; it governed the *numbers* a tool prints and not the *words*;
it declared instruments to be controls without ever turning that recursion on
guards. Full reasoning, including the five candidates rejected as already ours, is
in [docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md) (entry 2026-08-04).

**Nothing here is measured; no lift is claimed for any of it.**

### Added

- **`sota-code-security` rules/10 §2.10 — unearned claims are words, not just
  numbers.** The section governed literals in reporting output. It now also
  governs the verbs: `verified`, `confirmed`, `reachable from`, `tainted`,
  `sanitized`, and any severity or confidence set from a constant. The test is
  "which line would have to succeed for this word to be true, and can I make that
  line fail?" — with both traps stated, because keyword-hedging every message
  saying "tainted" leaves the identical claim phrased "reachable from input", and
  "TLS certificate not verified" is correct English describing the analysed code.
- **`sota-code-security` rules/10 §2.14 — a control parked in observe-only mode.**
  Kyverno `Audit`, PSA `warn`, WAF detection-only, `SCMP_ACT_LOG`, CSP
  report-only, DMARC `p=none`, `--soft-fail`. Each is correct as a rollout *stage*
  and inert as a destination, and renders identically to an enforcing control on
  every dashboard. Ships with an owner and an expiry, enforced somewhere that
  fails — the discipline `sota-testing` rules/07 §7.1 puts on a quarantined test.
  The staged ladders already existed in `sota-devsecops` rules/07 and
  `sota-network-security` rules/06; the inert-control framing did not.
- **`sota-code-security` rules/11 §3.4 — contract drift by interaction.** Neither
  component is wrong: a producer change silently alters a layout its consumer
  depends on, and both sides' isolation tests pass while the seam is broken. The
  distinguishing feature is that **no schema declares this seam**, so nothing
  exists for a registry or compat check to compare — every contract rule we own
  presumes a declared contract. The high-yield trigger is a config-level backend
  or frontend swap that changes the output layout as a side effect. Rule: run the
  consumer on the producer's real output before merging.
- **`sota-code-security` rules/11 §7.1 — the guard that is an instance of what it
  guards.** §7 already said an instrument is a control; it never turned the
  recursion on guards. Three forms: a coverage test whose *scope* is narrower than
  the population **and** whose *predicate* the defect satisfies (`"auth=" in line`
  passes on `auth=None`); a tripwire nested inside another gate's success branch;
  a denominator counting only the items that survived earlier filtering. §2.2
  catches an *empty* scope — this catches one merely wrong, and a predicate merely
  weak.
- **`sota-code-security` rules/11 §7.2 — three rules for the auditor's own
  instrument.** Sample and read before you count (a regex over prose reported 50
  unearned claims where reading found 8); a control validated on inputs that
  **cannot** produce the failure proves nothing, which is the negative control's
  twin; when a wrapper reports an empty reason, go one layer down.
- **`sota-code-security` rules/11 §6 — run every script before reading any of
  them.** A measurement tool nobody has executed this quarter is presumed dead
  until it prints something; the ones needing credentials, a daemon, a rules
  directory or a network fail in precisely the way a clean result looks, and one
  environment change kills them all at once.
- **`sota-testing` rules/02 §2.6 — prove hermeticity, don't assert it.** Block
  egress and run the suite; anything that fails was not the unit test it claimed
  to be. What this catches is not a slow test but one *passing for the wrong
  reason*, its usual mechanism being a config object the SUT never reads (it
  resolves from the environment instead — `rules/11` §6.7). Plus: check each
  surviving assertion against the test's own **name**.
- **`sota-testing` rules/02 §2.7 — resource optimism** added as its own smell, and
  **mystery guest** restored to its standard external-resource sense. Ours had
  narrowed a standard catalog term to a readability defect — record rot in our own
  file, found while auditing for it.

### Changed

- **`rules/10` §2.13 now cites the platform mechanic.** Per
  [GitHub Docs](https://docs.github.com/en/pull-requests/reference/status-checks),
  a **skipped job reports its status as *Success*** and "will not prevent a pull
  request from merging, even if it is a required check" — strictly worse than
  §2.13's existing "all-skipped is not all-green". A required gate whose `if:`
  condition stops matching turns green, not pending.
- **`rules/11` §2.2 gained the instance everyone meets.** `go test ./...` over a
  package with no test files prints `? x [no test files]` and **exits 0**
  (verified this session). Gate on a floor for tests actually executed, never on
  the runner's exit code — and check *your* runner rather than assuming, since
  they differ.
- `rules/11` §3 is now "**Four** classes rules/10 does not cover", with the
  matching count in `rules/10`'s header pointer; both `SKILL.md` routing rows and
  the README's `~62k lines` figure updated (invariant 6 caught that one).

### Note for the next contributor

`rules/10` and `rules/11` now sit at **493** and **495** of the 500-line cap. That
pair is effectively full: the next addition to this family needs a `rules/12`
split, not another round of trimming.

## [1.21.0] - 2026-08-03

**The output-you-can-read release.** Nothing the installer *does* changed — what changed
is that you can tell its actions apart. Every line it printed was the same two-space
grey, so "created your `CLAUDE.md`" and "already up to date" were indistinguishable at a
glance; and the one command everybody needs after the first day — updating — existed only
as a *flag* on the install command, which is discoverable if you already know it is there.

**Front door checked:** update.sh · --color · NO_COLOR

**Nothing here is measured; no lift is claimed for any of it.**

### Added

- **`scripts/update.sh`** — the update path was reachable only as a *flag*
  (`install.sh --update`), which is discoverable if you already know it exists. The new
  script is a **pure `exec` forwarder** (`exec install.sh --update "$@"`) and holds no
  logic of its own by design: a wrapper carrying its own copy of the update rules is a
  wrapper that drifts from them. Every install.sh flag still works
  (`update.sh --yes`, `--project DIR`, `--no-color`, …). The three places that named the
  old command — the installer's closing hint, the "upstream is ahead" line, and the
  SessionStart update reminder — now point at `scripts/update.sh`.

### Changed

- **`scripts/install.sh` output is colour- and emoji-coded.** The installer printed one
  undifferentiated wall of two-space-indented lines, so "created your CLAUDE.md" and
  "already up to date" looked identical and the sections (update / skills / routing /
  hygiene) had no visible boundary. It now prints emoji section headers and three
  distinct line kinds — `✓` green (something was done), `↻` cyan (changed, or you should
  act), `·` dim (a no-op or context) — with `⚠ warning:` and `✗ error:` on stderr.
  **The decoration is never the message**: every line still says in words what it means,
  the `warning:`/`error:` prefixes stay, and the glyphs degrade to ASCII (`+ ~ - ! x`).
- **…and it turns itself off, per stream** (`sota-cli-ux` rules/02 §4). Colour requires a
  terminal on *that* stream, `TERM` set and not `dumb`; `NO_COLOR` (non-empty) disables,
  `FORCE_COLOR`/`CLICOLOR_FORCE` re-enables, and the new **`--color=always|never|auto`**
  (plus `--no-color`) beats both. Emoji additionally require a UTF-8 locale, so a C-locale
  box gets ASCII markers rather than mojibake. Verified by running the installer under a
  pty, piped, with stdout redirected but stderr on the tty, and with each of `NO_COLOR`,
  `TERM=dumb`, `LC_ALL=C` and `--color=always`.

## [1.20.1] - 2026-08-03

**The don't-do-the-thing release.** Four questions answered with evidence instead of
reasoning, and three answers were *no*: long rules files do **not** need a table of
contents (242-file sweep cancelled), a **synthetic** large-repo fixture **cannot** test
audit skill (built twice, ruled out), and the router should **not** be restructured to
hit a token recommendation. The fourth was yes: §2b's front-door check **can** be
gated — not by gating discovery, which is judgement, but by gating the declaration.

**Front door checked:** front door · duration

**Nothing here is measured; no lift is claimed for any of it.**

### Changed

- **`docs/ROADMAP.md` opens with *Start here next session*** — every actionable item in
  one ordered table with why it is not done and the first move, plus an explicit
  **do-not** list so nine settled decisions are not re-litigated. Added because this
  cycle's real output was largely *decisions not to act*, and those are worthless if the
  next session cannot find them.
- **This cycle's research is summarised in one block** instead of scattered across four
  documents: the TOC test, the size-limits table, the synthetic-fixture result, and how
  §2b's gate came unblocked.
- **Two stale claims in `evals/results/RESULTS.md` corrected.** It twice called the
  agentic large-repo audit *"the real remaining audit frontier"*; both are now qualified
  — a **synthetic** one is ruled out, and only a real repo with real defects could still
  test it.
- **`docs/ROADMAP.md`'s header and cycle range were stale** (*as of 2026-08-02*, "PRs
  #174–#176"); corrected.
- **README gained the two front-door sentences §2b's grep found missing** — the
  fourteenth invariant (the sentence claimed "Fourteen" while listing thirteen) and the
  eval duration baseline.

### Fixed

- **Invariant 14 caught two real defects on its own first release**, which is why it
  shipped before a cut rather than after one.
  - Its pattern was **unanchored**, so it also matched the format example quoted inside
    its own CHANGELOG entry; the two matches concatenated into a garbage "term". Now
    anchored to line start — a declaration is its own line, unindented and unbackticked.
  - It then rejected `sample size` as **declared but absent from this release's entry**,
    correctly: that capability shipped in v1.20.0. The anti-filler guard earned itself
    on first use.

### Added

- **The agentic large-repo audit was attempted, and a synthetic fixture cannot do it**
  ([BIG-REPO-AUDIT](evals/results/2026-08-03/BIG-REPO-AUDIT.md)). This was the one
  audit design the roadmap kept open after seven +0.00 results, on the theory that
  prior instruments saturated because code and question both fit one prompt.
  - Two fixture generations, **360+ files / ~95k tokens** each, six planted defects
    from classes this library owns. Bare-arm recall: **6/6, 6/6, 6/6** (v1) and
    **6/6, 5/6** (v2). At ceiling, with no library.
  - **The library arm was never run, and that is the disciplined call**: with the bare
    arm at ceiling there is no headroom, and the instrument is confounded, so any
    number would be uninterpretable. Publishing one would be worse than having none.
  - **The reason generalises, and is the actual finding.** In a synthetic corpus a
    planted defect is *by construction* a deviation from generated filler, and agents
    find deviations mechanically — v1 by file naming (*"the six seeded-looking
    modules"*), v2, after that tell was removed, by AST-normalising every method body:
    *"the only substantive code is six methods that deviate from the template."*
    **Scaling the repo makes the anomaly cheaper to find, not harder**, because more
    filler is a stronger baseline to diff against.
  - **The pre-registered prediction was wrong by ~2×** — bare 0.30–0.50 predicted,
    0.92–1.00 measured — and is reported as wrong, in the direction the repo's own
    prior evidence favoured and the prediction discounted.
  - Recorded as an **instrument failure, not a null**, and deliberately kept **off the
    scoreboard**. What would be needed: a *real* repository with *real* defects at a
    known commit, where the flaw is ordinary code someone believed was correct.
- **Two roadmap entries this cycle closed but left reading as open** are now marked:
  the front-door capability gate (invariant 14) and the clone-install update path
  (`update-reminder.sh`).

- **The eval runners now have a duration baseline, not just a printed duration.**
  Closes the open half of the duration item: every run appends to a git-ignored
  `evals/results/durations.tsv`, and the next run of the same runner prints the delta
  — `[run-completeness elapsed 12.3s over 7 cases | previous 380.0s — 30.9x faster
  (total)  <-- CHECK THIS: a large swing usually means the work changed, not the
  speed]`.
  - **Printing alone was never enough.** `sota-code-security` rules/11 §2.1's tell —
    a step that finishes far faster than its claimed work allows did not do the work
    — is a **comparison**, and there was nothing to compare against. It was
    *"visible only to a human reading two logs"*; it is now in the log you are
    already reading.
  - **A duration without a denominator is the same defect in time form.** "12s" says
    nothing; "12s over 7 cases" does. **7 of 12 runners** declare one via
    `note_work(len(cases), "cases")`; the other five have no single `cases = load…`
    line to hook, so their rows record `-` and print `[no denominator — bare seconds,
    weak evidence]` rather than being quietly compared. Differing corpus sizes are
    compared **per case**, and the line says which basis it used.
  - **The ledger is git-ignored, and that is correctness rather than convenience**: a
    duration is only comparable on the same machine and network, so committing one
    would invite exactly the cross-machine comparison it cannot support — and would
    dirty the tree on every local run.
  - **Printed, never gated**, consistent with `check-invariants.sh`'s own wall-time
    decision: these call a remote API whose latency is not ours, and a flaky gate
    gets disabled. **Fails open on every path** — corrupt ledger, unwritable
    location, and absent ledger were each tested by breaking them.
  - **The CI half of the item needed nothing built.** The GitHub API already returns
    `started_at`/`completed_at` per *step* (verified 2026-08-03:
    `Check invariants 21:48:18 → 21:48:20`), so per-step duration is already
    observable. Recorded rather than reimplemented.
  - Verified end-to-end on the two `--selftest` paths CI runs without an API key —
    both still PASS, with correct denominators (dead-path **4**, reimplement **10**,
    matching their real case counts) — plus `py_compile` across `evals/` and
    `test_scoring.py` still green at 38 checks.

- **Invariant 14 — a release declares its front-door terms, and they resolve.**
  Closes the last actionable candidate in
  [docs/CONVENTIONS-LEDGER.md](docs/CONVENTIONS-LEDGER.md), which had it **blocked**
  on *"needs a machine-readable capability list per release"*.
  - **That objection was right, and is still right: discovery cannot be gated.**
    Deciding what counts as a capability is judgement. What *can* be gated is the
    **declaration** — the same move invariant 11 makes for `LAST-VERIFIED`, where
    the escape is a claim that must be *true*. A release adds
    `**Front door checked:** term · term` to its CHANGELOG section and the gate
    proves every term resolves in `README.md`/`docs/INDEX.md` **and** appears in
    that release's own entry — so a filler word cannot buy a pass.
  - **Fires only when `VERSION` changes**, so it adds nothing to an ordinary PR.
    The problem it fixes is release-time: invariant 6 fails on a wrong *number* in
    the README, and nothing failed on a *capability* that never got a sentence —
    five shipped across v1.17.0–v1.19.7 with zero README hits.
  - **Watched to fail on five paths**: ordinary PR (skips, no ceremony), release
    with no declaration (fails, naming the required line), a term in no front door
    (fails, naming the term), a term absent from the release's own entry (fails),
    and a valid release (passes, `ok (2 terms declared, all resolve)`).
  - **The fail-watch found a real bug rather than confirming behaviour.** The first
    cut read the *topmost* `## [` section, which is `[Unreleased]` when one still
    sits above the new entry — so it reported "no declaration" for a release that
    had one. It now selects the section matching `VERSION`. Case C failing for the
    wrong reason is what exposed it.

### Changed

- **One decision table now settles every size question.**
  `docs/CONTEXT-MANAGEMENT.md` gains *Size limits: what to actually do* — all ten
  limits that govern this library, each marked **hard** or **recommendation**,
  each with its verified source and a standing decision. Written because this
  cycle produced findings across four documents and the useful form of that is one
  table, not four narratives. The load-bearing entries: `description` is at
  **1024/1024** with no slack, the router is at **500/500 lines** with no slack,
  long `rules/*.md` are **correct by design**, and the router's 2× token overrun is
  **accepted rather than restructured** — trimming it would break
  `ROUTER_BUILD_SHA` and invalidate comparability with every historical +0.39 run,
  while the compaction truncation it causes is self-healing on the next invocation.
- **Tested whether long rules files need a table of contents. They don't — so the
  242-file sweep is off the table.** Anthropic's skill-authoring guidance says
  reference files over 100 lines should carry a TOC *"even when previewing with
  partial reads"*; **242 of this repo's rules files exceed 100 lines and none has
  one**. Rather than assume, the *mechanism* was tested: four arms, one agent each,
  an unguessable canary constant so a hit proves retrieval and not prior knowledge,
  the prompt silent about position/length/TOCs, and the arm kept out of every path
  (opaque workspace IDs — two agents in an earlier study read their arm from a
  directory name).
  - Control (434 lines, canary at 99% depth, no TOC): **found**. With a TOC:
    **found**. Stress at **1,719 lines / 92 KB**, 4× the repo's longest rules file:
    **found**, with the agent reporting the canary's exact line range.
  - **The positive control is what makes it readable**: moving the canary to 1%
    depth changed nothing, so there was no depth effect for a TOC to correct. Every
    agent read the file whole — two said so unprompted. The TOC's only measurable
    effect was **+183 tokens** of context.
  - **Limits stated rather than implied**: *n* = 1 per arm, a pilot, deliberately
    **not** on the scoreboard. It covers the `Read`-tool path on a directly named
    file; the guidance's own trigger is *nested* references, which this library does
    not have — `SKILL.md → rules/NN.md` is already the "one level deep" structure the
    same guidance prescribes.

### Fixed

- **A skill description violated a documented constraint, found by applying this
  repo's own absence-claim rule to itself.** `sota-dotnet`'s `description` contained
  `Span<T>/Memory<T>` — C# generics, but `<T>` is also a well-formed XML start tag,
  and Anthropic's Agent Skills reference states that `name` and `description`
  *"Cannot contain XML tags"*. Rewritten as "Span and Memory" (965 → 963 chars).
  - **How it surfaced is the point.** The claim under test was *"there is no hard
    size cap for skills"* — an **absence claim**, and `skills/sota/rules/01` §5/§7
    require a widened search **plus a second independent method**, because a narrow
    search and a true absence are indistinguishable. The first source
    (`agentskills.io/specification`) does not mention XML tags at all. Only the
    second (`platform.claude.com` Agent Skills reference) carries that constraint —
    and a reserved-word rule for `name` (`anthropic`, `claude`) that the spec page
    also omits. One source would have missed both.
  - The absence claim itself **held**, and the second source states it more
    strongly than the first: *"No practical limit on bundled content… There's no
    context penalty for bundled content that isn't used."*
- **Invariant 4 now checks both new constraints** — an XML tag in `name` or
  `description`, and a reserved word in `name`. Watched to fail on the real defect
  (`XML TAG in description ['<T>', '<T>']`), on a synthetic `claude-golang` name
  (`RESERVED WORD 'claude'`), and to pass on the clean tree. It stays inside
  invariant 4 rather than becoming invariant 14: same file, same parse, same
  failure mode — a description a loader silently mangles or rejects.

### Changed

- **`AGENTS.md` is back under the platform's 200-line target** (234 → **170**
  lines, 15.4 → 10.9 KiB). `CLAUDE.md` and `GEMINI.md` symlink to it, so it loads
  into **every** session, and the Claude Code memory documentation is explicit:
  *"target under 200 lines per CLAUDE.md file. Longer files consume more context
  and reduce adherence."* There is **no hard limit** — *"CLAUDE.md files are loaded
  in full regardless of length"* — so nothing was truncating; adherence was the
  cost. The file had crossed the target while gaining invariants 12 and 13.
  - The 128-line invariant section became a **13-row table**, one line each. No
    detail was lost: the rationale and the incident behind every invariant already
    live in `check-invariants.sh`'s own header (the point of use), and the
    practical "what this means for your PR" version in `CONTRIBUTING.md` — both
    verified to carry all 13 before the cut.
  - The file now states its own constraint, because it is the one file in the repo
    where invariant 1 does *not* apply and a **different, ungated** limit does.
    That is the `docs/CONVENTIONS-LEDGER.md` "unwritten convention" class again:
    a real constraint, documented nowhere in the repo, discovered by exceeding it.
- **The `rules/*.md` files were checked against the same target and deliberately
  left alone.** The 200-line figure governs *always-loaded* context. Skills load on
  demand — *"unlike CLAUDE.md content, a skill's body loads only when it's used, so
  long reference material costs almost nothing until you need it"* — and their
  documented cap is *"keep `SKILL.md` under 500 lines; move detailed reference
  material to separate files"*, which is invariant 1 exactly, with `rules/*.md`
  being those separate files. **162 of 256 rules files exceed 200 lines and that is
  correct by design**; splitting them would work against the documented model.
- **Validated against the Agent Skills spec: there is no byte cap for skills, but
  the 500-line cap is a loose proxy for the one budget that exists.** Prompted by
  the observation that `MEMORY.md`'s hard cap is *"200 lines **or** 25KB, whichever
  comes first"* — so a few long lines can exhaust it well under 200 lines. Checked
  whether the same shape applies to skills:
  - **It does not, as a hard cap.** The spec's only hard limits are on frontmatter
    (`name` ≤ 64, `description` ≤ **1024** — which confirms invariant 4 — and
    `compatibility` ≤ 500). Of the body it says outright: *"There are no format
    restrictions."* Nothing truncates a skill at load. And the 200-line/25KB rule is
    scoped in the memory docs to `MEMORY.md` alone: *"This limit applies only to
    `MEMORY.md`. CLAUDE.md files are loaded in full regardless of length."*
  - **But the budget it stands in for is stated in tokens, not lines**:
    *"Instructions (< 5000 tokens recommended)"*. Measured across this repo's **297**
    skill files, line density varies **3.3×** (38–127 bytes/line, median 57), so a
    500-line file lands anywhere between **~4,750 and ~15,870 tokens** — the median
    density already puts it 42% over. **12 files exceed ~5,000 tokens and 11 of them
    pass invariant 1 comfortably** (`sota-mobile/rules/07-swift-language.md`: 254
    lines, half the cap, ~6,737 tokens).
  - **Exactly one file breaches the recommendation where it applies** — the
    `SKILL.md` body: `skills/sota/SKILL.md` at **~10,211 tokens**, 2× the budget,
    at 500/500 lines with no slack. `rules/*.md` are stage-3 resources, for which
    the spec gives no number.
  - **Logged, not gated.** A byte-or-token check passes all three ledger filters but
    would fail on `main` today, and the only fix is trimming a router with no line
    slack — a design decision. Recorded in `docs/ROADMAP.md` with the explicit
    caveat that `bytes/4` is a heuristic and a real tokenizer should be used before
    acting on any specific number.
- **`docs/CONTEXT-MANAGEMENT.md` records a platform behaviour none of the six
  defenses covers.** Auto-compaction *"re-attaches the most recent invocation of
  each skill after the summary, keeping the **first 5,000 tokens of each**"*, with a
  combined 25,000-token budget. The six defenses fight *attention*; this is
  *deletion*. By a rough `bytes/4` estimate the router (~10,200 tokens) and two
  rules files exceed the per-skill cut. **Explicitly recorded as unverified** — read
  off the docs and a byte heuristic, not observed in a session — and deliberately
  not acted on, since the router has no line slack and the honest next step is to
  watch a real compaction first.

- **`RELEASING.md`'s minor-vs-patch rule now matches 31 releases of practice.** It
  said *"adding a skill is a **minor** bump; fixes to existing content are a
  **patch**"* — whose first half is exceptionless and whose second half misleads,
  because it reads as *no new skill → patch*. Measured with `git ls-tree` across
  every tag: **6** skill-adding releases, **all 6 minor** (so a skill is
  *sufficient*), but **15 of 21 minors added no skill at all** (so it is never
  *necessary*). The rule that actually separates them, spot-checked against six
  releases: **minor when the library gains a new surface someone can *use*** — a
  skill, a script or command, a hook, a cross-tool integration (v1.9.0's
  `AGENTS.md` support), or a new eval instrument (v1.13.0, v1.14.0, v1.17.0,
  v1.18.0); **patch when the change lives inside surfaces that already exist** —
  rule text, docs, intakes, and, on the evidence, **a new CI invariant on its
  own**: invariants 8, 9 and 11 each shipped in a *patch*. Invariants 12 and 13
  rode a minor because that release also added two scripts and a hook. Tie-breaker
  recorded for the next cut: does a reader of the release notes gain something new
  to run? Found while cutting v1.20.0, where the old line would have argued for a
  patch.
- **`AGENTS.md` and `docs/INDEX.md` describe the setup check as the two halves it
  now is.** Both still framed it as a paste-in prompt, which had been true for four
  days: `scripts/verify-setup.sh` answers the mechanical half in a second and tells
  the agent which checks are left. Both now say to run the script first.

## [1.20.0] - 2026-08-02

**The reported-but-never-read release.** Every change here traces to the same
shape: a control that *was already printing what you needed* and nobody looked.
`gitleaks` prints `179 commits scanned` — in a shallow clone it prints `1` and
still exits 0. The scoreboard prints a `Samples` column — nothing checked a new
row filled it. The `how-it-works` diagram's source was fixed and the rendered PNG
the README actually embeds was not, so `main` served the corrected-and-still-wrong
claim all day. The eval runners printed no duration at all. Two invariants (12,
13), two scripts, and one CI fix later, the denominators are read.

The one deliberate inversion: the new update reminder reports **less** than it
could. It never phones home, because the value was the nudge, not the telemetry.

**Nothing here is measured; no lift is claimed for any of it.**

### Added

- **`scripts/update-reminder.sh` — an occasional update nudge that makes no
  network request.** Closes the *push* half of the update-notification item, open
  since the 2026-07-28 cycle: symlinked skills update the moment you `git pull`,
  but nothing ever told you to pull, and the plugin's first-run notice is
  marker-guarded to fire once ever, so it is onboarding rather than a version
  channel.
  - **The phone-home question was dissolved, not answered.** The roadmap had this
    blocked on "a `SessionStart` version check reaches passive users but phones
    home — a deliberate privacy decision, not to be built without an explicit
    call." The resolution is that the *benefit* — reminding you updates exist —
    never needed the network. The hook cannot tell whether a new version exists,
    only how long since it last spoke. A real check from every session start would
    turn a documentation library into something that reports when and how often you
    work; you run the check instead, and it is one command.
  - **Verified, not asserted**: run under a `PATH` seeded with `curl`/`wget`/`git`/
    `nc`/`ssh` stubs that report any invocation, it makes **zero** attempts. The
    only external commands it uses are `find`, `tr`, `mkdir`, `printf`, `dirname`
    and `pwd`.
  - Silent on first run (a fresh install is current by definition), then at most one
    message every `SOTA_UPDATE_REMINDER_DAYS` days (default 14, `0` disables). TTL
    from the state file's **mtime** via `find -mtime` rather than date arithmetic,
    because GNU `date -d` and BSD/macOS `date -v` disagree.
  - **Fails open on every path**, because a `SessionStart` hook that errors degrades
    the session it is attached to: unwritable data dir, missing `VERSION`, and
    garbage in the interval env var were each tested and each exit 0.
  - Reaches **both** install paths — the plugin via `hooks/hooks.json`, clone
    installs via a new `setup_update_reminder` in `install.sh`. The installer path
    was tested against a `settings.json` already holding the user's *own*
    `SessionStart` hook: that hook and an unrelated `theme` key survive untouched,
    and a second run adds nothing (idempotent).
- **`scripts/verify-setup.sh` — the deterministic half of
  [docs/VERIFY-SETUP.md](docs/VERIFY-SETUP.md)**, open since the 2026-07-28 cycle.
  14 checks, strictly **read-only**, exit 1 on any FAIL: skills reachability and
  whether the *router* is among them, the three always-on routing layers reported
  separately, profile symlinks resolving, a licence under *any* name, which gate
  mechanisms exist, whether a hook is **installed** rather than merely configured,
  and — from real run conclusions — whether CI has ever *executed* and ever
  *rejected* anything. `--runs N` widens the run-history sample.
  - The read-only claim is **verified, not asserted**: hashing the file tree and
    `git status` before and after a full run shows both unchanged.
  - The three checks a script cannot do (agent-file content, whether its claims
    are still *true*, the routing dry-run) print as `N/A — judgement check` with a
    pointer to the prompt, so the split is visible where you run it rather than
    only in the doc.
  - **Writing it found a bug in itself.** Check 8 used `git grep`, which reads only
    **tracked** files — so an untracked `.pre-commit-config.yaml` configuring
    gitleaks was reported as *no secret scanning*. That is a false FAIL on exactly
    the case the doc names first ("on a repo you just scaffolded"), and it was found
    by running the fail path, not by reading the code. Now plain `grep`.
  - **It also validated its own UNVERIFIED vocabulary.** On this repo check 10b
    (*has CI ever rejected anything?*) reads UNVERIFIED at the default 60-run
    sample — 60/60 success — and turns up **1 failure at 200**. "Not in the last 60"
    really is not "never"; the sample size is printed for that reason.
- **`evals/_elapsed.py` — the eval runners report their wall time.** All 13 now
  print `[<runner> elapsed 12.3s]`, closing the runner half of the duration item.
  Registered with `atexit` so the line survives the `sys.exit(...)` several runners
  use on an empty corpus — the fast-exit case most worth timing — and written to
  **stderr** so a runner whose stdout is piped or parsed is not handed an extra
  line. **Printed, never gated**: these call a remote API whose latency is not ours,
  and a flaky gate gets disabled. Verified end-to-end on the two `--selftest` paths
  CI runs without an API key, plus `py_compile` across all of `evals/`.

### Removed

- **The `gh-sota` extension idea is cancelled, not deferred.** Its one real benefit
  was update notification, now delivered directly by the `SessionStart` reminder
  above — without a second repo, a shim, or a CLI nobody would invoke for a library
  used *inside* an agent session. The original blocker stands and is kept in the
  roadmap for why the shape never worked (gh requires a `gh-*` repo with a matching
  root executable, so it could not live here). Closed rather than left deferred: a
  deferred item whose rationale has died is indistinguishable, on a list, from a
  live one.

### Fixed

- **The secret scan reported a denominator nobody read.** `gitleaks` prints
  `179 commits scanned`, and the roadmap had carried *"still unexamined: what
  gitleaks reports as its scope"* since 2026-07-30. Examined: in a `--depth 1`
  clone of this repo it scans **1 of 179 commits**, prints `no leaks found`, and
  **exits 0** — a green secret scan over 0.5% of history, where `fetch-depth: 0`
  is the only thing preventing it and nothing asserts that. CI now asserts the
  scope.
  - The assertion keys on `git rev-parse --is-shallow-repository`, **not** on a
    commit count. `git rev-list --count HEAD` truncates to 1 in the same clone, so
    it degrades alongside the scan it would be checking; and the three available
    numbers disagree anyway (measured: rev-list HEAD **175**, rev-list --all
    **181**, gitleaks **179** — gitleaks walks refs beyond HEAD), so any equality
    test would be flaky, and a flaky gate gets disabled.
  - It also fails when gitleaks prints **no** `N commits scanned` line: an output
    format we can no longer parse means the scope is no longer verified, which must
    not read as a pass.
  - Watched to fail on four paths: shallow clone (exit 1), unparsable output (exit
    1), a degenerate 1-commit count on a non-shallow tree (exit 1), and the real
    repo (exit 0, `179 commits scanned`).

### Changed

- **The 500-line cap is stated as *instruction-files-only* everywhere it appears.**
  A file is capped **iff an agent loads it as instructions** — `skills/*/SKILL.md`
  and `skills/*/rules/*.md`, nothing else. README, CHANGELOG, `docs/`, `evals/`,
  `AGENTS.md` and the scripts have **no line cap at all** (decided 2026-07-15,
  PR #100). The scope was already correct in `check-invariants.sh`, `AGENTS.md`,
  `CONTRIBUTING.md`'s checklist and the README's contributing section, but five
  surfaces still read as a repo-wide rule and have been fixed: the README hero
  ("each file under 500 lines"), the pre-commit hook's own name, the
  `how-it-works` diagram, the router's opening paragraph, and
  `CONVENTIONS-LEDGER`'s enforced list. `AGENTS.md`, `CONTRIBUTING.md` and the
  script's header now lead with the rule in one line and say outright that any
  line-cap claim not scoped to skill files is stale.

  **Correction: the `how-it-works` fix reached the source and not the surface.**
  It edited `assets/how-it-works.html`, but the README embeds
  `assets/how-it-works.png`, which was last rendered in #55 (2026-07-09) and was
  not re-rendered — so every reader kept seeing `every file < 500 lines` while
  the diff, the commit message and the line above all reported the surface fixed.
  Rendered now; the same claim that opened this entry had been *counted* on a
  surface it never reached, which is the shape v1.19.9 is named for.
- **The `how-it-works` diagram shows the loop it describes.** The README hero
  argues the library is "a **loop**, not a prompt dump — route in only the rules a
  task needs, re-state them every turn, and re-check them *last* before shipping",
  and [docs/CONTEXT-MANAGEMENT.md](docs/CONTEXT-MANAGEMENT.md) documents six
  defenses behind that claim. The diagram drew a **one-way four-box pipeline** and
  showed exactly one of the six (stage 4's terminal self-check). It now carries a
  return path from stage 4 back to stage 2 for the per-prompt re-injection —
  labelled **optional · always-on**, because that layer is opt-in setup
  (`install.sh --routing`) and the diagram must not imply it ships on by default.
  The footer's always-on aside moved into that rail and now points at the six
  defenses. The repo URL was added to the header, since the image travels
  (LinkedIn, forks, docs) far from anything that links back.
- **`CONTRIBUTING.md` gained a "Rendered assets" section and a PR-checklist line**
  — `assets/*.png` are committed build outputs of the `*.html` beside them, nothing
  regenerates them, and the README embeds the image. The section carries the render
  command, the exact size per asset, the `file://`-is-blocked reason for serving
  over localhost, and the `sips` dimension check. Placed in `CONTRIBUTING.md`, not
  `RELEASING.md`: the failure happened in an ordinary docs PR, not at a release cut,
  so release-time guidance would have been guidance at the wrong point of use
  (v1.19.9's proximity finding, applied).
- **Invariant 12 — a rendered asset is never older than its source.** Every
  `assets/*.png` must be committed no earlier than the `assets/*.html` it renders.
  It passes all three [CONVENTIONS-LEDGER](docs/CONVENTIONS-LEDGER.md) filters (it
  had already failed, that same day; it fails silently, since nobody reads the HTML
  and the PNG looks fine — it just says the old thing; and it is checkable from
  `git log -1` alone).
  - **Commit times, not mtimes.** A fresh clone stamps every file with the checkout
    time, so an mtime comparison would pass on every CI runner while examining
    nothing — `rules/11` §2.2, built into the gate meant to prevent it. Equal
    timestamps pass: rendering in the same commit as the edit is the wanted
    behaviour, not a violation.
  - **Escape: `[no-render]` in the HTML's own commit subject**, for an edit that
    cannot change the output. A declaration rather than a heuristic, because
    nothing short of rendering both can distinguish a cosmetic HTML edit from a
    load-bearing one — and invariant 11 already learned that a gate firing on
    non-events gets waved through until it is decorative.
  - **Watched to fail on six paths before being trusted**, per the script's own
    "adding a check?" block: the real defect (a worktree at `0f08094`, the commit
    where the drift existed → exit 1), a live HTML-only commit (exit 1), an HTML
    with no committed PNG (exit 1), a drifted pathspec (`SCOPE EMPTY`, exit 1), the
    declared escape (exit 0), and current `main` (exit 0, `ok (2 asset pairs)`).
  - One earlier attempt at the fail-watch was **vacuous** and is recorded because
    it is the failure mode this repo keeps rediscovering: a `git reset --hard`
    reverted the still-uncommitted script, so two mutation cases ran against a
    build with no check 12 in it and printed nothing at all. Empty output — not a
    passing result — is what exposed it. The check is now committed before any
    mutation runs, and the mutations run in a throwaway worktree.
  - The first diagnostic printed `%cs` (date only) and so reported the **same date**
    on both lines of a same-day miss while asserting one was older. It prints full
    timestamps now: a finding that reads as a broken check is one people switch off.
- **Invariant 13 — every scoreboard row declares its sample size.** Each row of the
  results table in [evals/results/RESULTS.md](evals/results/RESULTS.md) must fill its
  `Samples` cell. A lift from one run is typographically identical to a lift from ten,
  and this repo has been burned twice: a **+0.07** retracted when the set grew 15 → 49,
  and a **+0.40** corrected to **+0.39** by a second run. Neither looked uncertain on
  the page.
  - Like invariant 10 it is a **regression guard** with no incident of its own — all
    10 rows pass today. It catches the *next* row added without an `n`, which is the
    cheap moment; the expensive moment is after the number has been quoted.
  - **Shape-driven, not position-driven**: it finds the table by its `Samples`
    **header** and checks that column in every data row beneath. So a renamed or
    dropped column fails closed (`SCOPE EMPTY`) rather than passing over zero rows —
    the drift a hardcoded column index sails straight past.
  - The loop reads from a **process substitution, not a pipe**. A `| while` runs in a
    subshell, so every `v13=1` set inside it would be discarded on exit: a gate that
    finds offenders, prints them, and still exits 0.
  - Watched to fail on four paths first: a blanked `Samples` cell (exit 1, naming the
    row), a renamed column (`SCOPE EMPTY`, exit 1), a missing scoreboard file
    (skipped, not assumed), and the clean tree (exit 0, `ok (10 scoreboard rows)`).
  - This closes the **last actionable candidate** in
    [docs/CONVENTIONS-LEDGER.md](docs/CONVENTIONS-LEDGER.md). One candidate remains
    (§2b's front-door grep) and is blocked on machine-readable capability names.
- **Five stale surfaces fixed, found by re-checking the ones this cycle touched.**
  - `README.md` still said **"Eleven invariants"** — missed by the earlier sweep
    because its grep was case-sensitive. Its list of what they cover also omitted
    four: rules-file indexing, the single `[Unreleased]`, `LAST-VERIFIED` pairing,
    and rendered-asset currency. Both fixed, and the list now names all thirteen
    areas rather than trailing off after six.
  - `docs/MAINTENANCE.md`'s structure row had its **count** bumped to 12 in the same
    breath as leaving its **parenthetical list** without the new check — a count that
    agrees with the script while the prose beside it does not.
  - `docs/INDEX.md` had **no route to the render procedure** added a day earlier: a
    documented procedure with no front-door row, which is `RELEASING.md` §2b's class
    applied to the index rather than the README.
  - `RELEASING.md`'s social-preview step described re-rendering by hand with no
    mention that **invariant 12 now enforces the commit-both half**, and no pointer
    to the fuller procedure in `CONTRIBUTING.md`.
  - `docs/ROADMAP.md`'s open-tasks header still read *as of 2026-08-01* and called
    §2b "the only other candidate" while the Samples guard was still listed as open.
- **Two stale invariant counts fixed.** `docs/MAINTENANCE.md` said
  `check-invariants.sh` runs **7 checks** and `docs/WHY-IT-WORKS.md` said **eight
  invariants**; both are **11** (the script prints its own count, so the drift was
  only ever in the prose). `docs/ROADMAP.md`'s `test_scoring.py` floor note now
  records that 25 has since risen to **38**.

## [1.19.9] - 2026-08-01

**The counted-as-a-layer release.** Five changes with one shape between them: a
control that is *counted* — in a threat model, in a release runbook, in a repo's
list of conventions — while being structurally unable to cover the case it is
counted for. A second-opinion classifier from the same model family. A TEE bought
to fix records that were never emitted. A rule written three times and still nearly
broken twice. **Nothing here is measured; no lift is claimed for any of it.**

### Added

- **`sota-code-security/rules/08` §1 — a same-class checker is not an independent
  layer.** A classifier, judge or "second opinion" tier drawn from the same model
  family as the system it guards shares that system's blind spots by construction:
  **common-cause failure**, so the two do not multiply into defence in depth however
  the diagram is drawn. Escalate-only cascades are worse *deductively*, not
  empirically — a tier that only sees inputs the primary scored **uncertain** cannot
  see one the primary scored **confidently wrong**, which is the failure it was added
  to catch; its marginal recall on the hard class is bounded by the primary's
  uncertainty coverage, not by its own accuracy, so a better second model does not fix
  it. The rule's demand is a measurement: marginal recall **on the hard class**, not on
  a mixed corpus where easy cases dominate the mean. Closes onto `rules/10` §1 — a
  layer that adds nothing on the class you care about is a control that looks enabled
  and does nothing. Same reasoning for any guard sharing a substrate (model family,
  tokenizer, training corpus, or the normalization step that produced the miss).
- **`sota-code-security/rules/04` §8 — a TEE does not fix a completeness gap.** §8
  already separated integrity from completeness for audit ledgers; this names the
  expensive wrong turn — reaching for confidential computing to fix *"records that were
  never emitted"*. CC protects a record's confidentiality and integrity once it exists;
  no hardware can compel a component to emit one. That is a **liveness** failure and
  sits outside the guarantee. Cross-refs `sota-confidential-computing` rules/01 §2
  (availability row) and rules/04 §7, which state it from the CC side — the new text
  makes it reachable from the crypto side, where the mistake is actually made.
- Audit-checklist entries for both, so each new rule is reachable from an audit pass.

- **`docs/CONVENTIONS-LEDGER.md`** — which repo conventions are enforced, which are
  prose, and why the rest should stay prose. Built after invariant 11, so the next
  documented-but-unenforced rule is found deliberately rather than by luck.
  Mechanically extracted from the five agent-facing docs: **49 raw entries, 8
  duplicates, 41 distinct**, of which **11** are invariants and **4** more are
  enforced inside the eval runners — so reading `check-invariants.sh` alone
  undercounts what this repo enforces by about a third.
  - It corrects an earlier estimate of "~122 conventions", which came from a loose
    regex matching any bold line or any line containing *must/never/always* — an
    over-count of roughly 3×, recorded so it is not repeated.
  - Applying three filters (has it already failed · does it fail silently · is it
    mechanically checkable) yields **one** actionable candidate, not the 2–4
    predicted: a regression guard requiring every scoreboard row to declare its
    sample size. The other candidate (§2b's front-door grep) stays **blocked** on
    needing machine-readable capability names.
  - For the ~18 judgment conventions the ledger argues against a fourth copy of the
    text and for **proximity**: `LAST-VERIFIED` failed while documented in three
    places, all far from the point of use.

- **`docs/INDEX.md`** reaches the reimplement case set, and the case file now
  carries the predictions written **before** any run existed — so if it is ever
  run, the pre-registration is the authoring session's, not one composed after
  seeing data. It also records, in advance, that a null there is the **eighth**
  and the conclusion is to stop rather than author a ninth.
- **`evals/cases/reimplement.jsonl` + `run-reimplement.py` — documentation, not a
  measured instrument.** Ten cases (5 disqualified / 5 legitimate) encoding the
  §3.9.4-vs-§3.9.6 conflict, with every legitimate case resembling a disqualified one
  so that *ratio-only* and *refuse-everything* both land at exactly **0.500** — a
  three-arm selftest in CI holds that, and four guards abort on an empty case file, a
  vacuous reason axis, a one-sided case file, and a report with no parsable lines
  (all four verified to exit non-zero). `test_scoring.py` grows to **38 checks**,
  including the row where the decision and reason metrics legitimately diverge, which
  is what a metric-conflating mutation dies on.

  **It has never been run and no number from it may be cited.** Seven audit
  instruments already read +0.00 and the roadmap records "do not build another
  audit-recall instrument"; an eighth run was declined. It is kept because building it
  produced the rule fix above, and the scorer stays so the case set stays checkable.

### Changed

- **README — the audit-class list grew from seven classes to eight.** The §2b
  front-door grep returned **0 hits** in `README.md` and `docs/INDEX.md` for every
  term this release added, the **second consecutive cut** where that happened *with
  the checklist item already written* — evidence the habit does not stick without the
  gate §2b still lacks. New class: **"Layers that were never layers"**, covering both
  additions above. `RELEASING.md` §2b now also says where such a fix belongs — the
  README is the front door for a rule-level capability; `docs/INDEX.md` indexes
  *documents*, so a new rule inside an existing file usually does not earn a row there.
- **`RELEASING.md`'s pre-tag `ADOPTION-LOG` check is now case-insensitive and
  bracket-tolerant** (`grep -ni '· \[\?unreleased'`). Two rows in this release were
  written `· [Unreleased]`, which the documented case-sensitive `grep -n '· unreleased'`
  **would not have matched** — a checklist step that silently matches nothing, in the
  release that is otherwise about exactly that.
- **`AGENTS.md`** gained a pointer to `docs/CONVENTIONS-LEDGER.md`, which shipped in
  v1.19.8 with no mention in the file every agent reads first, and records that the
  adoption ledger also takes proposals from **our own** sessions, not only outside repos.
- **`docs/ROADMAP.md` — one item was stale and is now marked superseded.** It said
  *"the BUILD-safe eval needs a thinner spec before it measures anything"*, while a
  closed item twenty lines above records that the thinner spec was written **and**
  tested and did not discriminate either. Kept for the diagnosis it holds; the
  remedy it proposes is done and did not work. Also records this cycle's items: the
  one remaining gateable convention (a Samples-column regression guard, low priority
  because it currently passes), §2b's grep still blocked, the reimplement set being
  documentation-never-run, and an explicit note **not** to "finish" the point-of-use
  work by relocating the other ~18 judgment conventions.
- **`scripts/check-freshness.sh`'s header caught up with its own parser** — it still
  described `LAST-VERIFIED` as holding only a date, after the parser was taught to
  strip `#` comments so the file could carry the rule that governs it. Now also
  points at invariant 11.

- **Three conventions moved to their point of use** — step 4 of the ledger plan,
  and the one step its data actually supported. The principle comes from a measured
  failure: `LAST-VERIFIED` was documented in three places and mentioned across nine
  files, and two sessions still nearly broke it. **Proximity beats repetition.**
  - **`LAST-VERIFIED` now carries its own rule.** This required teaching
    `check-freshness.sh` to strip comment lines — its strict
    `tr -d '[:space:]'` + `YYYY-MM-DD` glob was *precisely why* the rule could not
    live in the file it governs. Both rejection paths were re-verified after the
    change (comments-only and comment-plus-malformed-date each still exit 1), because
    a parser loosened until it accepts anything is worse than the problem it solved.
  - **`scripts/check-invariants.sh` gained an "adding a check?" block.** The file had
    **zero** guidance on adding a check, despite being where every check is added:
    watch it fail first (invariant 9's first cut printed its heading and nothing else
    — a `grep -m 1` on a pipe SIGPIPE'd the upstream `printf`), print your
    denominator and fail on an empty scope, and skip rather than guess when a
    prerequisite is missing.
  - **All three live-agent runners now carry the A/B conventions** they govern —
    that a bare arm is not bare by default (sub-agents inherit the agent files and 2
    of 3 loaded the router anyway), and that the arm must never be encoded in a path
    or label. None of the three carried this before.

  **The move exposed an imprecision in invariant 11, fixed in the same change.**
  The gate keyed on the *file* changing rather than the *stamp* changing — so this
  very commit, which only added comments, demanded an escape and got one
  reflexively. A gate that fires on non-events trains people to wave it through,
  which is how it becomes decorative (rules/11 §7). It now compares the parsed date
  and reports `LAST-VERIFIED touched but the stamp is unchanged` for comment-only
  edits. The fail path was **re-watched** after the refinement rather than assumed:
  a real date bump with no escape still exits 1.

  Not moved: the remaining judgment conventions have no single point of use.
  *Verify every claim* applies everywhere, which is exactly why it cannot be
  relocated and must stay a principle.

- **`evals/README` — the n=1 convention contradicted itself.** Its bolded headline
  read *"Never publish from n=1"* while the next sentence permitted it *"or state
  the sample size"*. A skim-reader saw a prohibition, a close reader a disclosure
  rule, and the scoreboard follows the body (the audit row is a declared `1×`, and
  is therefore compliant). Headline reworded to match the rule it actually states.
  Found by checking the scoreboard for a violation and discovering a wording defect
  instead.

- **Invariant 11 — `LAST-VERIFIED` moves only alongside a sweep.** The stamp
  records the last *full* re-verification pass, not the newest verified fact, so a
  rules section may legitimately carry today's verification dates while the stamp
  reads months old. Bumping it on an ordinary edit asserts a sweep that never
  happened — a false green planted in the one control whose job is detecting stale
  claims.

  The rule was already written in `AGENTS.md`, `docs/MAINTENANCE.md` and
  `check-freshness.sh`'s own header, and **two separate sessions still proposed
  bumping it wrongly**, catching themselves only on verification. A convention
  documented three times and still nearly broken twice is `sota-code-security`
  rules/10 §2.12 — a natural-language instruction standing in for an enforced
  control — so it became a gate.

  Two escapes, matching the batched and rolling passes the runbook allows: a
  **sweep-shaped diff** (≥ 20 skill files; the real 2026-07-08 sweep touched
  **100**, so the floor sits far below a genuine one), or **naming `LAST-VERIFIED`
  in the CHANGELOG**, which the runbook already requires and which is how a rolling
  pass declares completion.

  This is the repo's first **diff-based** invariant — every other check reads the
  whole tree — so with no merge base it skips with a note rather than guessing,
  the way checks 4 and 8 skip without `python3`. Watched to fail before being
  trusted (rules/11 §7): a lone stamp bump exits **1** with an actionable message,
  a 25-skill-file diff passes, and a CHANGELOG declaration passes.

- **`sota-devsecops` rules/03 §3.9.6 — the protocol prohibition now says which side
  you are on.** The clause read *"never recommend an in-house implementation of:
  crypto primitives or protocols…"*, which forbids writing a request signer against a
  published spec — something reasonable, and something the rule's own reasoning does
  not actually argue against. Found by building a case set for the §3.9.4-vs-§3.9.6
  conflict, where the ambiguity made the answer key unusable.

  Primitives remain out unconditionally. A **protocol** is out whenever *this* system
  is the **validating** side: there a canonicalisation, parsing or comparison bug
  fails **permissively and silently** — it accepts what it should reject and nothing
  errors, which is the `rules/10` family and the reason the prohibition exists.
  Composing stdlib primitives per a published spec so that a **remote authority**
  validates the result is a different class: a wrong signature is rejected on the
  first request, loudly. Taking that path now requires stating which side you are on,
  pinning the spec version, and testing against the publisher's vectors where they
  exist — and when you cannot say which side fails first, treat it as validating and
  keep the library.

## [1.19.8] - 2026-07-31

### Changed

- **README gained the seventh class**: `rules/11 §7` — your own scorer, gate or
  benchmark is a control too. Found by the front-door grep that `RELEASING.md`
  §2b added at the previous cut: the only "instrument" hits in the README were
  about *eval* instruments, so a capability shipped since v1.19.7 had no
  front-door mention. The step earned its place one release after being written.

### Changed

- **`evals/cases/build-safe/SPEC.md` rewritten to stop leaking its own answers**,
  and the rule behind it recorded where a subject cannot read it. The first spec
  stated the quality property to preserve; the rewrite states features and facts
  only. Verified: zero "must …" clauses and zero defect names remain, with all six
  product tensions intact. The note explaining this was initially placed in the spec
  as an HTML comment — still text the agent reads, naming every leaked property —
  and now lives in the ground-truth file's header. General form: **keep guidance
  about the instrument out of the artifact the subject sees.**
- **The build-safe instrument is closed, not pending.** The rewritten spec was
  tested: two bare agents scored **1.000 / 1.000**, making five bare builds across
  two spec versions all at ceiling. These seven defect classes are **not elicitable
  from a spec** at this model tier. The residue is a distinction worth keeping —
  the +0.39 completeness lift comes from *cross-cutting omissions* under a
  one-sentence prompt (rate limiting, logging, TLS, tests), while these are *local
  correctness decisions inside a feature the model is actively writing*. Defect
  avoidance and practice completeness are different measurement targets, and only
  the second has ever shown a gap here. Recorded with "do not rebuild this
  instrument" so a third spec version is not attempted.
- **`docs/INDEX.md` now reaches the day's results.** The find-it-fast index had
  **zero** pointers to the four 2026-07-30 result files, so the most consequential
  findings — why the audit half has no measured lift, a prediction written down
  before the run that killed it, and an eval that failed as an *instrument* rather
  than as a result — were reachable only by knowing they existed. Four rows added.
- **`docs/ROADMAP.md`** records two pending items rather than implying closure: the
  rewritten build-safe spec is **untested** (a bare pilot is mid-flight, and no
  build-safe number should be cited until it lands), and **calibration** is the one
  untested claim left about the audit half — measurable, but it would measure
  adherence to our own reporting doctrine and must never be reported as a lift.
- **`evals/README` gained a "Live-agent A/B runs" convention block**, so the
  contamination lessons stop living only in a result write-up: a bare arm is not
  bare by default (sub-agents inherit the agent-file rule to consult this library,
  and the API harness's *"use only your own security knowledge"* line did not
  survive the move to live agents); never encode the arm in a path or label
  (agents read `ub1` as "unguided-bare" and self-assigned); establish contamination
  per agent from citation evidence, never from the prompt or self-report; and the
  contamination detector is itself an instrument that needs a known-positive and a
  known-negative — ours produced one false positive and then a false negative on a
  known-contaminated report. Also added: bound what an instrument reads, and read
  the denominator it prints.

### Added

- **`sota-code-security` rules/11 §7 — the instrument that measures a control is
  itself a control.** Scorers, quality gates, benchmarks, coverage thresholds and
  dashboards decide whether something is *OK*, so every rule in that file applies
  to them — the most commonly skipped application, because measurement code reads
  as scaffolding. The asymmetry: a broken feature produces a complaint, a broken
  instrument produces a **number**, and numbers get quoted.
  - Four instrument-specific failure modes, each observed: unbounded or **unread**
    scope (a scorer printed "851 files" for a ten-module service — it was reading a
    vendored virtualenv and the project's own test assertions, and the denominator
    went unread); generalising from one sample (§3.3 turned inward — patterns
    written against a single reference flag every *other* correct spelling, each
    time punishing code better than the sample); errors running **both** ways, with
    only the excusing direction going unchased because it agrees with the hoped-for
    result; and the instrument that cannot fail (a mutation harness reporting
    18/18 caught while every run died before the tests started).
  - The bar: **never trust a number from an instrument you have not watched produce
    a wrong answer on purpose.** Two references wired into CI (known-bad at the
    floor, known-good at the ceiling), a negative control for anything that
    classifies, abort-don't-warn on a missing summary, and assert the mutation took.
  - §7.3 covers changing an instrument *after* seeing results — sometimes correct,
    also how a result gets massaged: disclose the change, the reason, and the
    before/after, and show no ranking moved for another reason.
  - Written because the class recurred: three new scorers needed eight corrections
    between them in one session, on top of four harness failures already recorded in
    `evals/README`. That file now points at the rule; the lesson had been repo-local
    and so invisible to anyone using the library elsewhere.

### Added

- **A procedure-compliance eval — `evals/cases/dead-path/` + `run-dead-path.py`.**
  Every existing audit instrument scores *recognition* and returns **+0.00**,
  because a frontier model handed the code and the question is already at ceiling.
  This one scores whether the model **does the procedure** rules/11 and §3.9
  require — mutate the control, delete the dependency, run the real build — which
  is behaviour, not knowledge, and is checkable without a judge.
  - The fixture is built so a careful static read gets **half the items wrong**:
    `csv_export` looks unused (named only as a config string) but is resolved at
    runtime, so deleting it breaks the suite → **KEEP**; `xml_export` is
    statically imported and called from a branch whose condition the only entry
    constructor can never produce → **DELETE**; `check_currency` looks untested
    (no test names it) but a no-op mutation breaks the suite → **REFUTED**, so
    flagging everything scores *worse*; `validate_amount` reads as enforcement but
    its boolean is discarded, so an over-limit entry posts → **CONFIRMED**.
  - Scored on two axes because they fail differently: **verdict accuracy** and
    **proof compliance** (a correct verdict with no command-plus-observed-outcome
    is not full credit — rules/11 §5). Deterministic: no API key, no network.
  - `selfcheck.sh` re-derives all six planted properties **by mutation** against
    the real suite, and `--selftest` feeds the scorer one report that only reasoned
    and one that ran, failing unless they separate (they score **0.000** and
    **1.000**). Both wired into CI, because a fixture that quietly loses its traps
    keeps printing plausible numbers while measuring nothing.
  - **Not yet run against a live agent.** The instrument exists; the number does
    not, and none is claimed.


- **`sota-code-security` rules/11 — dead-path diagnostics.** rules/10 asks, per
  control, "if this were a no-op would anything look different?". rules/11 is the
  **sweep**: the cheap signals that surface the family across a codebase without
  reading every line, plus three classes rules/10 does not cover because they are
  correctness rather than security. From two user-authored audit prompts; the
  library covered roughly two thirds of them, and the third that was missing is
  where this file starts.
  - **Diagnostics**: duration-vs-claimed-work (the highest-yield tell, and the
    only one needing no code reading); **printing every gate's denominator** —
    `0 checked, 0 failed, exit 0` is the family's signature; cross-scale delta;
    telemetry silence; and proving a fix's new path actually executed.
  - **Classes**: scale-dependent silence (unbounded traversal, size-gated paths no
    fixture crosses, and budgets that truncate **coverage** while reporting a
    normal result); stale-artifact no-ops (a cache/tag/fingerprint key narrower
    than the behaviour — "what input can change while the key stays constant?");
    and format assumptions generalised from one sample, including lenient parsers
    that return a plausible-but-wrong value instead of raising.
  - **`assert` is not a control.** Verified by running each case 2026-07-30:
    `python3 -O` and `PYTHONOPTIMIZE=1` deleted a failing `assert` (the program
    printed `passed`); `cc -DNDEBUG` did the same in C; Java disables assertions
    by default, and Oracle's guide calls disabled ones "essentially equivalent to
    empty statements". CMake's `Modules/Compiler/GNU.cmake` appends `-DNDEBUG` to
    `RELEASE`, `RELWITHDEBINFO` *and* `MINSIZEREL`, so every non-Debug C/C++ build
    strips them. Cross-refs landed in `sota-python` rules/05, `sota-c-cpp`
    rules/04, `sota-jvm` rules/04.
  - **Evidence bar**: one *discriminating* proof per class, and ACTIVE / LATENT /
    REFUTED labels (report refuted suspicions too). Plus: a fix that moves a
    detector's decision boundary needs known-bad/known-good validation before
    shipping, or a silent miss is traded for a silent flood.
- Cross-refs where a builder meets these classes: `sota-testing` rules/03 §3.7a
  (fixtures must cross the thresholds the code branches on), `sota-performance`
  rules/01 §9a (duration as a *correctness* signal, not just a cost one), the
  router's AUDIT step 4, and the README's audit section (now six classes).


- **Invariant 10 — every `skills/*/rules/*.md` must be referenced by its own
  `SKILL.md`.** The library's loading model is that `SKILL.md` loads first and the
  model reads only the rules files its index names, so an unindexed rules file is
  written, capped, checklist-ed — and never loaded. It is the skill-level twin of
  invariant 7 (a skill missing from the router) and the same class as the new
  §3.9, turned on ourselves. **Invariant 8 does not cover it:** measured
  2026-07-30, **30 of 41** `SKILL.md` files list their rules as plain backticked
  text rather than Markdown links, so a rename leaves the link checker nothing to
  resolve — verified by renaming `sota-golang/rules/01-errors.md` and watching
  invariant 8 report `ok` while invariant 10 caught it. All 255 rules files pass,
  so this is a **regression gate, not a repair**; watched to fail on two injected
  cases (an unindexed new file, and a renamed reference) before being trusted,
  per the harness convention.
- **`scripts/install.sh --version`** — nothing reported which release was in use,
  so a bug report ("the day-zero check fired wrongly") could not name the version
  that produced it. Reports the release (read from `VERSION`, never hardcoded),
  `git describe` incl. `-dirty`, whether the remote is ahead **as of the last
  fetch** (no implicit network call), and whether skills are symlinked (update
  live) or a pinned `--copy` snapshot. **`--update` now prints the version delta**
  (`1.19.7 → 1.20.0 — see CHANGELOG.md`) or `(unchanged)`: because symlinked
  skills change under you on a pull, "nothing happened" and "you just moved three
  releases" previously looked identical. Tested on six paths — normal checkout,
  non-git snapshot, missing `VERSION`, unlinked target, `--update` with and
  without a change, and behind-upstream — each verified to exit 0 without
  tripping `set -euo pipefail`.

### Changed

- **The dead-path eval was run, and it is an honest +0.00 that refutes our own
  explanation.** Six live Claude Code sub-agents, 3 per arm, identical prompts
  except the treatment: **both arms scored 1.000 verdict / 1.000 proof**, 12/12
  items each, including both inverted traps and the REFUTED case. The
  pre-registered hypothesis — *"a bare agent reasons and scores ~0.25 verdict /
  0.00 proof; a library-guided one runs the mutations"* — is **wrong**. The bare
  agents worked in scratch copies, mutated the controls, deleted the modules and
  ran `trace.Trace` unprompted; one used `dis` to identify `POP_TOP` after the
  control's `CALL` as the bytecode tell for a discarded return. Nothing asked them
  to.
  - This matters beyond one eval: the standing explanation for the other four
    audit nulls was that they score *recognition*, and a procedure-graded
    instrument would separate the arms. It did not. That explanation is retired,
    and `RESULTS.md` says so at the top of the audit section.
  - The arms differ only in **reporting discipline** — ACTIVE/LATENT labels 0/3 vs
    3/3, claims bounded by what actually ran 0/3 vs 3/3, flagging that the fix
    moves a decision boundary 0/3 vs 3/3. Post-hoc, n=3, and partly tautological
    (the library arm was told to follow a file that defines that vocabulary).
    **Not a lift, and not to be cited as one.**
  - Two disclosures in the write-up: the scorer's execution regex was **widened
    mid-run** after a false negative on a real, prose-described deletion proof (no
    arm's ranking changed; the `--selftest` guard still separates the arms 0.000 vs
    1.000), and one agent's report file is a transcription because the harness
    blocked it from writing `.md` — its verdict lines are verbatim, its method text
    abridged. Full detail: `evals/results/2026-07-30/DEAD-PATH.md`.

### Fixed

- **The rest of the automation got the same treatment as the invariant checks**
  (the two roadmap items opened yesterday). `check-freshness.sh` printed its
  denominator but never failed on zero — a drifted pathspec would have reported
  freshness over nothing; it now exits 1. `evals/test_scoring.py` printed
  `PASS: eval scoring functions behave correctly` **without saying how many
  assertions ran**, so an early return or an emptied test tuple read exactly like
  a pass; it now prints `(25 checks)` and fails below a floor — watched to fail by
  simulating a test that returns early (`only 17 ran, expected at least 25`).
  `check-invariants.sh` now reports its **wall time** alongside the denominators,
  since rules/11 §2.1's tell is unavailable unless someone records the duration;
  printed, deliberately **not gated** — a duration threshold in CI is flaky under
  runner variance, and a flaky gate gets disabled, which is how a control becomes
  inert.
- **A suspected third case was REFUTED and is recorded as such.** CI's
  `shellcheck -S warning scripts/*.sh` looked like it would pass silently if
  `scripts/` were renamed. Verified in bash (CI's shell): an unmatched glob stays
  literal, shellcheck exits **2** with `scripts/*.sh: openBinaryFile: does not
  exist`. It fails loudly. Reported rather than "fixed", per rules/11 §5.
- **Our own gates were vacuous under an empty scope — found with the diagnostic
  rules/11 §2.2 teaches, and fixed.** `scripts/check-invariants.sh` enumerated
  files via `git ls-files 'skills/*/rules/*.md'`; mutating that pathspec to match
  nothing (simulating a `rules/` directory rename) made checks 2 and 10 print
  `ok` and the script exit **0** while examining **zero files**. Check 6's tree
  recount did *not* catch it, because the `SKILL.md` count it recounts was
  unaffected — one gate's green does not cover another gate's scope. Classified
  **LATENT**: the mechanism was verified, and verified not to have fired (today's
  pathspecs match 296/255 files). Checks 1, 2, 7 and 10 now report their
  denominator (`ok (255 rules files)`) and **fail closed** on an empty scope; the
  same mutation now exits **1**. An early version of the fix printed `ok` on the
  line after a failure note — misleading green, the exact defect this file warns
  about — corrected so the count prints only on success.

### Changed

- **The README told users auto-update would keep them current. It doesn't.** The
  roadmap had flagged "git-hosted marketplaces also check at session start" as
  documented-but-unverified; checked against the Claude Code docs 2026-07-30, it is
  wrong in the way that matters: *"Third-party and local development marketplaces
  have auto-update disabled by default"* — this is a third-party marketplace, so a
  plugin user gets **no** automatic refresh unless they turn it on. Even enabled,
  the check runs after session start "with a random delay of up to ten minutes"
  while the running session keeps its launch versions. The section now carries the
  quote, the opt-in path (`/plugin` → Marketplaces → Enable auto-update), and a
  pointer to `--version`. This makes the open update-notification item **more**
  pressing, not less: neither install path pushes updates by default.
- **`docs/ROADMAP.md` corrected an item that was itself wrong.** It claimed
  `install.sh --update` "already pulls and knows both versions — have it print the
  delta". The script had **zero** references to `VERSION`
  (`grep -c VERSION scripts/install.sh` → 0), so the cheap fix it proposed did not
  exist. Now implemented, and the item split into what is done (report) and what
  remains open (push).
- **A third copy of the stale 500-line claim, this time inside the checker.**
  `scripts/check-invariants.sh`'s own header said invariant 1 covers "every tracked
  `*.md`", contradicting its own implementation (skills-only, with a comment
  explaining why). Fixed. After the README and CONTRIBUTING fixes, that is three
  places one policy change failed to reach — the reason RELEASING.md §2b now says
  to re-read long-lived prose at each cut.
- **`CONTRIBUTING.md` carried the same wrong cap the README did.** Rule 3 said
  "Every Markdown file is ≤ 500 lines" and the PR checklist said "All touched files
  are ≤ 500 lines". The cap has been **skill-files-only since PR #100**
  (2026-07-15) — README/CHANGELOG/`docs/` are deliberately uncapped. Both fixed,
  with the reason (incremental rule loading) and where navigability comes from
  instead. `AGENTS.md` was checked and needed no change: its wording already scopes
  the cap correctly ("the cap is load-bearing only there").
- **`RELEASING.md` gained the step that would have caught the invisible-audit-half
  problem** — a new §2b "Front-door surfaces", because **no invariant catches a
  capability that never got a sentence anywhere a reader looks**. Invariant 6 fails
  on a wrong *number* in the README; nothing fails on a missing *feature*, which is
  how five audit capabilities went undocumented across v1.17.0–v1.19.7. The pre-tag
  checklist now carries a matching item. Also documented there: avoid dots in release
  branch names — the assistant's `Bash(git checkout *.*)` deny rule matches a branch
  name containing dots, so `release/v1.19.7` is refused while
  `chore/release-v1-19-7` works. It bit again at this cut.
- **`docs/MAINTENANCE.md` now names its high-rot targets** instead of treating every
  claim as equally durable. First on the list is §3.9.2's eight-project tool table,
  which demonstrated its own failure mode the day it landed: two of the eight had
  been renamed under the URLs a manifest still carries. The runbook now says to
  re-verify with `gh api` **and read `full_name` back**, and flags that the Ruby row
  asserts a *negative* ("no established tool") that needs re-checking rather than
  assuming.
- **`docs/ROADMAP.md` re-stamped to 2026-07-30 / post-v1.19.7**, recording a third
  discovery mode (a user-authored prompt aimed at the library's own coverage, with
  CVEs ruled out), four new open items, and live re-checked adoption signals: **8
  stars, 0 watchers, 2 forks, exactly one true issue ever** (#4, closed — filtering
  `has("pull_request")` out of the issues endpoint, which otherwise counts every PR
  as an issue), and **0 external gap reports in 8 days**. `ROUTER_BUILD_SHA` was
  **re-computed and matched** (`71a9d78ea5e9e341`), confirming v1.19.7's router edits
  landed outside the eval-pinned BUILD block, so historical completeness runs stay
  comparable. Router headroom re-counted at 497/500.
- **`docs/INDEX.md`** points at the README's new audit section, so the capability is
  reachable from the find-it-fast index rather than only from the README itself.

## [1.19.7] - 2026-07-30

### Added

- **`sota-devsecops` rules/03 §3.9 — the declared-but-not-reached sweep.** The
  dependency file covered whether what you ship is *vulnerable* (CVEs, SBOM,
  confusion, typosquats) and never whether a declared dependency is **reached at
  all**. Found by running an audit prompt against the library that explicitly
  excluded CVEs and versions: five of its six requirements had no home. The new
  section covers reachability tracing from a real entrypoint (with the
  impossible-path trap — a symbol referenced only on a branch the live code
  cannot produce — and its inverse, dynamic loading, where static tools
  false-*positive*); per-ecosystem tooling with each tool's blind spot named;
  **deletion as proof** (scratch copy, real build + lint + full suite, exact
  commands, exit codes, before/after transitive counts) with the two traps that
  make a green run lie; the leverage ratio (<5 symbols used / >10 modules
  inherited); upstream health fetched **this session** via `gh api`; and an
  A–D classification (DELETE / REPLACE IN-HOUSE / KEEP / UNMAINTAINED-but-keep).

  Every tool named was verified live on 2026-07-30 via `gh api repos/<o>/<r>` —
  the same command the rule prescribes. Two checks were promoted from what that
  verification itself turned up: `gh api` **follows renames silently**
  (`fpgmaas/deptry` answers as `osprey-oss/deptry`, `icanhazstring/composer-unused`
  as `composer-unused/composer-unused`), so `full_name` must be read back; and
  the honest per-ecosystem answer for Ruby is that **no established tool exists**
  — its candidates are single-maintainer and low-adoption, which is precisely
  the case the deletion proof exists for.

  The KEEP bucket's do-not-reimplement list adds a class the library did not
  have: **an algorithm whose output is persisted and must stay comparable with
  stored data** (fuzzy/LSH hashes, similarity digests, tokenizers, ID derivations).
  A merely *equivalent* reimplementation invalidates every stored value it has to
  compare against, and the failure is silent — comparisons keep returning
  answers, just wrong ones.

- Cross-refs so the sweep is reachable from where the question gets asked:
  `sota/rules/01` §2 inventory, `sota-code-security` rules/10 §2.13 (the sibling
  class one layer up), the router's routing table and library map, and the four
  language skills that had partial or zero coverage — `sota-golang` rules/05
  (`go mod why -m` and its test-inclusive graph), `sota-javascript-typescript`
  rules/07 (knip output is a candidate list, not a finding), `sota-python`
  rules/01 (`deptry` DEP002/003/005), `sota-rust` rules/05 (`cargo machete`
  false positives vs `cargo udeps` nightly + false negatives).

### Changed

- **README: the audit half of the library was invisible.** The README sold BUILD
  completeness and listed standards; nothing described what the audit actually
  *does*, so five capabilities shipped across v1.17.0–v1.19.7 were documented
  nowhere a reader would look. New section **"What the audit hunts that a scanner
  can't"** covers inert controls, declared-but-unreached dependencies, decisions
  that stopped being right, adversarial refutation, and absence-claim discipline —
  each linked to the rules file that owns it. It carries its own honest caveat:
  the measured lift is in BUILD, every audit eval sits at **+0.00**, and one
  earlier audit lift was retracted when its sample grew 15 → 49 cases. Also:
  "How it works" step 3 described a 5-step audit chain that omitted the
  silent-control pass, the decision ledger, and the refutation pass — now the
  real seven; two Conventions bullets added (negative claims need a second
  independent method; positive observations must show *effect*, not existence).
- **README fixed a stale invariant claim.** Contributing said "keep every file
  ≤ 500 lines". The cap has been **skill-files-only since PR #100** (2026-07-15) —
  README/CHANGELOG/`docs/` are deliberately uncapped, which is why this file and
  `docs/` can hold full narrative entries. It now says so, names the reason
  (incremental rule loading), states that nine invariants enforce the conventions,
  and links `docs/ADOPTION-LOG.md`, which the README had never mentioned.
- **Docs refreshed to the post-v1.19.6 state**, and stale claims corrected:
  - `docs/MAINTENANCE.md` said CI enforces **7** invariants — it is **9** since
    v1.19.5. The only stale count left in the tree (`grep -rn "[0-9] invariants"`
    over docs/README/AGENTS/CONTRIBUTING/evals now returns nothing wrong).
  - `docs/ROADMAP.md` "Open tasks" was stamped **2026-07-22** and predated six
    releases. Re-stamped 2026-07-28 with what v1.19.1–v1.19.6 actually shipped,
    the day-zero field-validation result, and six new open items (see below).
    Adoption signals re-checked live via `gh` rather than restated: **8 stars, 0
    watchers, 2 forks, 1 issue ever** — and **0 gap reports in 6 days**.
  - The roadmap's OpenRouter credit figure is now marked *as of 2026-07-22, not
    re-checked* instead of reading as current — no paid eval ran this cycle.
  - `RELEASING.md` now says to consolidate duplicate `[Unreleased]` sections
    before a cut, and that invariant 9 fails the build on them.
  - `AGENTS.md` (and so `CLAUDE.md`/`GEMINI.md`, its symlinks) gained pointers to
    `docs/VERIFY-SETUP.md` and `docs/ADOPTION-LOG.md`, neither of which was
    listed despite both being current working surfaces.

  New open items recorded in the roadmap: no update-notification path for clone
  installs; nothing reports which version is in use; `scripts/verify-setup.sh`
  for the deterministic half of VERIFY-SETUP; the `gh-sota` extension considered
  and **deferred with its reason** (gh requires a `gh-*` repo name, and its
  update notice fires only on invocation); router headroom at **497/500**; and
  one unverified README claim about marketplace session-start re-checks.

## [1.19.6] - 2026-07-28

The **field-found** release: both changes came from watching the library be used
rather than from reading it. A live BUILD session hit two of the library's own
rules contradicting each other, resolved it correctly by reasoning, and thereby
exposed that nothing told it how. No skill added (41 unchanged).

### Added

- **Router — how to resolve two loaded rules that contradict each other.** The
  library has 41 skills that can disagree and, until now, said nothing about
  what to do when they do: a `grep` for `conflict|precedence|disagree|override`
  across `skills/sota/SKILL.md` returned only an unrelated table row. Six lines
  in "When this library is wrong": a contradiction is usually a **scope
  collision** (a general default vs a requirement inside a narrower domain), the
  narrower wins *in its domain*, pick by which failure mode is worse here, and
  **never resolve it silently** — name the rule you followed and why in a comment
  beside the code, or the next reader reverts it. Then report it, because a
  contradiction needing judgment is itself a defect. Placed next to the report
  path, outside the eval-pinned BUILD block (`ROUTER_BUILD_SHA` unchanged).

### Fixed

- **`sota-python` rules/07 §1 contradicted `sota-observability` rules/05 §1.**
  rules/07:56 called an `async def` endpoint with zero `await` "a bug marker";
  rules/05 specifies a liveness probe as process-internal-only, "usually just
  return 200" — which *is* a no-`await` `async def`. A reader following rules/07
  literally makes the handler `def`, it runs in the anyio threadpool, and
  saturation by slow sync handlers delays the probe until the orchestrator
  restarts a process whose event loop was fine: the restart storm rules/05
  exists to prevent. rules/07 now carves the liveness case out explicitly, cross-
  references rules/05 §1, tells the author to say so in the docstring (or the
  next reader "fixes" it), and notes that readiness follows the normal rule. One
  audit-checklist grep added.

  Found by running the library, not reading it: a live BUILD session hit the
  collision, resolved it correctly by judgment, and documented why — but only
  because the model was thinking. The rule as written would have produced the
  wrong code for a literal reader. Third gap this week surfaced by field use.

  **Scoped deliberately to Python**, verified rather than assumed: no other
  language skill carries an analogous "async without await" rule (checked all
  eight), and the trap is FastAPI-specific — a `def` handler is dispatched to
  the anyio threadpool. `sota-javascript-typescript` rules/04 shows a *sync*
  `/healthz` handler, which is correct for Node, where nothing dispatches
  request handlers to a threadpool. No equivalent carve-out is needed elsewhere.

## [1.19.5] - 2026-07-28

The **verify-what-you-set-up** release. The library could scaffold a repo and
could state what a repo needs; nothing checked the result, and nothing in CI
noticed when two PRs each opened a `[Unreleased]` section. Every item here comes
from something being run rather than reasoned about. No skill added (41
unchanged).

### Added

- **`docs/VERIFY-SETUP.md` — the read-only setup check.** `init-gates.sh` sets a
  repo up; nothing checked the result, and "configured" and "working" render
  identically. A paste-in prompt that reports whether the library reaches the
  directory, whether the repo's agent file is *true*, and whether its gates are
  real — changing nothing, and marking anything unobservable as UNVERIFIED
  rather than passing it. Linked from README → Enforcing the gates and
  docs/INDEX.md. Derived from two live runs against a 4300-commit repository:
  the first run's own limitations produced four of its checks (claims-vs-commands,
  the three-state hook distinction, execute-vs-reject, and can-you-land-the-fix),
  each a gap the run exposed rather than something reasoned in advance.
- **`sota-code-security` rules/10 §2.13 — a control that never executes.** One
  step earlier than "runs but does nothing": a gate whose trigger never fires —
  an `issue_comment` job nobody comments on, a path filter matching nothing, a
  branch filter naming a renamed branch. Its whole run history is *skipped*, and
  **all-skipped is not all-green, but every dashboard renders it the same way**.
  Verify on two axes (ever executed / ever rejected) and state the sample.
  Found in the wild: a review workflow with 5/5 skipped runs. One checklist item.
- **`sota-docs-workflow` rules/01 §7 — check an agent file's *claims*, not just
  that its commands exist.** The two rot at different rates and only the first
  gets noticed. Observed on that same repo: all seven `make` targets resolved,
  while the stated toolchain was seven months stale and the stated contents of
  `make check` were wrong. Verify in two passes, and prefer linking the file that
  owns a fact over asserting it. One checklist item.

- **Invariant 9 — at most one `## [Unreleased]`, and it must be the top entry**
  (`scripts/check-invariants.sh`), with archives allowed none. Invariant 5 reads
  only the *first* `## [` heading, so a second `[Unreleased]` further down was
  invisible to CI; on 2026-07-28 PRs #142 and #143 each opened one above
  `[1.19.3]` and `main` carried both until the v1.19.4 cut caught it by hand.
  Fence-aware (a heading quoted inside a code block doesn't count), portable to
  bash 3.2, no `python3` needed. Documented in AGENTS.md and CONTRIBUTING.md,
  where the contributor-facing rule is: if `[Unreleased]` exists, add to it.

  Watched to fail before being trusted, on all four cases — duplicate headings,
  a single one buried below a release, one in an archive, and one quoted inside
  a fence (must pass). The second case exposed a defect **in the check itself**:
  `grep -m 1` on a pipe closes it early, the upstream `printf` dies of SIGPIPE,
  and `pipefail` + `set -e` then killed the script mid-check — it printed its
  heading and nothing else. Fixed by reading the first heading without an
  early-exit consumer. (Invariant 5's `grep -m 1` is safe because it reads a
  file, not a pipe.) A guard that dies silently is the failure this repo keeps
  writing rules about; only running it against a real break surfaced it.

## [1.19.4] - 2026-07-28

The **field-testing** release. v1.19.3 wrote down what a new repo needs; this one
makes the library *raise* it unprompted, then corrects it against two real repos
— a 4304-commit kernel project and a live agent session scaffolding it. Four of
the six changes below exist because something written from reasoning met a real
repo and turned out to be wrong or incomplete. No skill added (41 unchanged).

### Added

- **Router `skills/sota/SKILL.md` — a "Day zero" section.** On the first BUILD
  task in an unfamiliar repo, check by *looking* (gate config, LICENSE, agent
  file, git history length) and, if two or more are missing and the history is
  short, surface `init-gates.sh` / `gen-agents-md.sh` **once, in a line**. Two
  guards are part of the rule: a long history means a mature repo that decided
  against them (say nothing), and **offer, never perform** — the scripts write
  config into the user's repo, and a decline is decided. Placed outside the
  `## BUILD mode — workflow` block on purpose: it is a per-repo precondition,
  not a per-task step, and keeping it out leaves the eval-pinned BUILD section
  byte-identical (`ROUTER_BUILD_SHA` still `71a9d78ea5e9e341`, verified).
- **`sota-docs-workflow` rules/01 §10 — "an ambient install doesn't travel".**
  User-scoped rule libraries, skills and linters resolve against one home
  directory; a teammate's clone and CI see nothing. Solo vs shared is an
  explicit choice, but the **gates** must be repo-resident either way — a
  secret scan that exists only in your shell is not a control on anyone else's
  commit. Plus: a pointer file referencing tooling the reader lacks is worse
  than no pointer, because it reads as a satisfied requirement. One
  audit-checklist item added.
- **`sota-docs-workflow` rules/01 §6 — the host-capability report.** Where a
  repo's documented dev loop doesn't run on every supported host, ship a small
  executable report that probes the machine and prints, per target, whether it
  works here and **what each gap blocks**. Its three load-bearing properties:
  probe capabilities rather than one implementation's name (a `docker` check
  reports "no runtime" on a machine running podman), name the consequence of
  each gap so nobody discovers it through a ten-minute failed build, and report
  rather than gate. Verified absent — every `preflight` in the library was CORS
  and `doctor` appeared nowhere. Taken from a *worked example* rather than a
  repo of ideas: a live agent session scaffolding that same clone.
- **`sota-docs-workflow` rules/01 §7 — automation on an agent's edits must
  check, not rewrite.** A format-on-write hook is right for a human editor and
  wrong for an agent: rewriting the file *after* the agent wrote it stales the
  agent's view, so its next edit fails or clobbers the reformat. Such hooks
  report (non-zero, with file and fix) and let the agent apply it; rewriting
  belongs at commit time or in CI, where nothing holds a live view. Zero prior
  hits across the tree. Two audit-checklist items added.

### Fixed

Both found by running the new detection against a real repo
([asterinas](https://github.com/asterinas/asterinas), 4304 commits) rather than
trusting it as written:

- **Licence detection matched the bare name `LICENSE`.** Asterinas ships
  `LICENSE-MPL` + `COPYRIGHT`, so a literal check reports the licence missing
  and feeds a false signal into the day-zero trigger. The router now matches
  `LICENSE*` / `COPYING*` / `COPYRIGHT`, and says explicitly not to match the
  bare name. Gate detection likewise widened beyond `.pre-commit-config.yaml`
  to any hook manager or CI job.
- **rules/01 §10 offered only two ways to point a second tool at `AGENTS.md`**
  (symlink, CI-generated copy). Asterinas uses a third that is better than
  both — a 28-byte `CLAUDE.md` reading `See [AGENTS.md](AGENTS.md).`:
  platform-independent, no build step, and unable to degrade silently the way a
  `core.symlinks=false` checkout does. It is now option 1 and the recommended
  default, with the trade (one hop the agent must follow) stated.

### Changed

- **README Installation** gains "An install is personal, not repo-resident" —
  that one install covers every project including brand-new ones, that it
  resolves only on your machine, the `--project .` / `--copy` options for a
  shared repo, and a pointer to the day-zero list.

Everything above is **not measured** — no lift claimed. The same session
independently rediscovered five rules we already had (silent control failure in
an upstream script that exits 0 while checking nothing, agent-doc decay, proving
a gate by making it fail, and two shell-safety rules); those are recorded in
[docs/ADOPTION-LOG.md](docs/ADOPTION-LOG.md) as convergences, including one
noted as a *routing* miss rather than a coverage gap.

## [1.19.3] - 2026-07-28

Third intake pass, against
[claude-project-scaffold](https://github.com/martinholovsky/claude-project-scaffold)
— an agent-context scaffolder, not a repo scaffolder. Most of its content turned
out to be ours already (the minimal-agent-file principle, the context-rot
rationale, the ADR format), recorded as convergences. Three ideas were genuinely
absent and landed; the gap the source *didn't* cover — that a fresh repo
inherits nothing from an ambient/global agent setup — became the fourth and
largest addition. No skill added (41 unchanged).

### Added

- **`sota-docs-workflow` rules/01 §9 — the troubleshooting playbook.** The
  dev-facing counterpart to §5's on-call runbooks: a symptom-keyed index of
  failures already solved once, in Symptom → Diagnosis → Fix form, written in
  the PR that fixed the bug. Includes the two rules the source didn't have —
  delete entries a root-cause fix invalidated, and treat a thrice-reported
  symptom as a signal to fix the code instead of documenting it again. Verified
  absent: "symptom" appeared across the library only in the alerting/on-call
  sense.
- **`sota-docs-workflow` rules/01 §10 — day zero in a new repo.** An installed
  skills library, a personal `CLAUDE.md`, and a house style guide are *ambient*;
  a fresh repo, a teammate's clone, and a CI runner inherit none of them.
  Covers the only two artifacts that must precede the first commit (`.gitignore`
  + secret scanning, LICENSE) and why; the ambient-vs-repo split for agent files
  in both directions; and the `core.symlinks=false` failure mode that turns a
  symlinked `CLAUDE.md` into a one-line text file (verified against
  `git help config`), with CI generation as the fallback.
- **`sota-docs-workflow` rules/01 §7 — the minimal agent-file shape.** §7 said
  what content earns its place but gave no skeleton; it now carries a four-block
  one, with the rule that the row which earns its place is the one contradicting
  the default.
- **`sota-architecture` rules/01 §4 — ADR directory discipline.** Sequential
  kebab-case filenames plus an `index.md` status table, and committing the ADR
  in the PR that implements the decision. The format and the
  consequences-with-a-downside rule were already there; the directory-level
  practice that makes a stalled process visible was not.

### Changed

- `sota-docs-workflow/SKILL.md` BUILD mode now routes new-repo bootstrap and the
  troubleshooting playbook (steps 7–8), and rules/01 gains three audit-checklist
  items.

## [1.19.2] - 2026-07-24

The **second intake** release: three ideas mined from
[swarm-forge](https://github.com/unclebob/swarm-forge) — an agent-orchestration
harness whose engineering content is deliberately thin — each verified absent
from our tree before landing. The headline is a genuine hole it exposed: we had
hexagonal ports/adapters and we had coverage exclusions, but nothing joining
them into the **testability boundary** that makes any test metric interpretable.
Six of its rules turned out to be ones we already had, recorded as convergences
rather than manufactured diffs. No skill added (41 unchanged).

### Added

- **`sota-architecture` rules/02 §14 — the testability boundary (humble
  object).** Every system has a shell automated tests cannot drive (GUI,
  devices, real clocks/networks, process spawn); draw that boundary explicitly
  in the build, keep it thin, allow it no business branching, and measure
  coverage/mutation/complexity against the core only. Includes the corollary
  that a *growing* shell is an architecture finding, not a testing one. Two
  checklist items added. The library had hexagonal ports/adapters (§4) and the
  generated/vendored coverage exclusion, but nothing connecting them — a
  `grep` for `humble object|near IO|adapter shell|untestable` across
  `sota-architecture` and `sota-testing` returned zero hits.
- **`sota-testing` rules/06 §6.3 — mutation survivor baselines.** Persist the
  survivor set and gate CI on *new* survivors (the mutation analogue of the
  coverage ratchet) instead of an absolute score, under two conditions: the
  mutation engine version is pinned beside the baseline (engines change
  operator sets between releases, so an unpinned diff attributes tool churn to
  your code), and only the tool writes the file (a hand-edited baseline is a
  live survivor marked dead). Checklist item added.
- **`sota-testing` rules/07 §7.2 — rank coverage gaps by complexity.** Cross
  coverage with branch density to aim the next test and the next mutation run;
  a branch-dense thinly-covered module outranks a 3-line getter at 0%. Stated
  as a pointer, never a gate, so it does not become the Goodhart target that
  §7.2 already warns coverage thresholds are. Two checklist items added, one
  of them tying the measured scope back to the rules/02 §14 boundary.

### Changed

- **`docs/ADOPTION-LOG.md`** — second entry: three ideas adopted from
  [swarm-forge](https://github.com/unclebob/swarm-forge) (read at source level
  on `main`, `six-pack`, and `adversaries`), one recorded as `rejected:
  contrary` (its resolve-at-latest tool policy, which also breaks its own
  mutation baseline — none of the seven tool repos carries a tag, verified via
  the GitHub API), and **six convergences** recorded as `rejected: already
  ours` with the file:line that covers each. All three adoptions are reasoned,
  **not measured** — the entry says so explicitly and forbids citing a lift.
- **`RELEASING.md` — ADOPTION-LOG version stamping.** Adoptions land in ordinary
  PRs between releases, so a log entry's "Landed in" cell is written before the
  shipping version is known. `unreleased` is now the documented placeholder, and
  the release cut stamps it: a row in the §1 version-bearing files table plus a
  pre-tag checklist grep. Deliberately a runbook step, not a ninth invariant —
  the marker is *correct* until the cut, so CI failing on it would be backwards.

## [1.19.1] - 2026-07-24

The **adopt-what-we-verified** release: five ideas mined from an external repo
([training-knowledge-vault](https://github.com/Eolas-bith/training-knowledge-vault)),
each validated against our own tree before landing, three adopted and two
recorded as already-covered. No skill added (41 unchanged). New
[`docs/ADOPTION-LOG.md`](docs/ADOPTION-LOG.md) is the audit trail.

### Added

- **Invariant 8 — internal Markdown link resolution.**
  `scripts/check-invariants.sh` now fails the build on any relative Markdown link
  to a `*.md` target that doesn't resolve, so a moved/renamed file can't leave a
  dead link in the README, `docs/`, CHANGELOG, or a skill. Scoped to `*.md`
  targets (broadening false-positives on `[text](x)`-shaped prose/code). The
  dry-run that justified it immediately caught **5 real broken links** in
  `evals/results/**` (`../../docs/…` for a path that needs `../../../docs/…`) —
  fixed in this release. Idea from the source repo's `vault-doctor.py`.
- **`sota-llm-engineering` rules/02 — self-contained prompts.** A new rule in §1:
  a prompt that references a schema/format in a file the model may not have
  loaded degrades *silently to fabrication*; inline every schema/enum/rule the
  prompt depends on. Scoped so it does not contradict a coding agent's on-demand
  rule loading. Checklist item added.
- **`sota-code-security` rules/10 §2.12 — instruction standing in for a control.**
  A "do not surface / do not reveal / ignore instructions below" instruction over
  data or permissions in the same context is a silent control: attention leakage
  shapes output without quotation, and prompt injection overrides it — enforce
  structurally/in code (cross-refs rules/08 §1–2, rules/07 §2). Checklist item added.
- **`docs/ADOPTION-LOG.md`** — an external-idea intake ledger (adopted/rejected/
  deferred/superseded, observation-before-diagnosis, landed-in pointers),
  itself the fifth idea borrowed from the source repo's lessons-log discipline.
  Linked from `docs/INDEX.md`.

### Fixed

- Five broken relative links in `evals/results/2026-07-10/` and
  `evals/results/2026-07-13/` (`../../docs/…` → `../../../docs/…`), surfaced by
  the new invariant 8.

### Changed

- Invariant docs updated for the new check (`AGENTS.md`, `CONTRIBUTING.md`,
  `docs/WHY-IT-WORKS.md`: "seven" → "eight"). Corrected two stale statements of
  the 500-line cap that still said "any tracked `*.md`" — it has been
  skill-files-only since 2026-07-15.
- **Roadmap refreshed to the live state and a broken sentence repaired.** The
  "Open tasks" stamp was stale (*as of 2026-07-16* — three releases and a week
  behind); replaced with a **2026-07-22** current-state block that summarizes the
  v1.17→v1.19 stretch and lists what is *genuinely* open (distribution/adoption first,
  then the agentic audit, then the cheap incremental runs), separated cleanly from the
  dated per-cycle history below. An orphaned fragment in the history (a sentence that
  began mid-clause, *"extension mismatch, env-filter mismatch…"*, left by an earlier
  edit) was completed and the cross-model follow-up marked done. `docs/INDEX.md` gained
  a row pointing at the cross-model result, which was otherwise unfindable from the
  index. Docs-only; no measured number changed.

## [1.19.0] - 2026-07-22

The **de-risk-the-foundation** release. The flagship BUILD lift is now shown to hold
across model families, the eval harness that produces every published number finally
has tests, the last two open eval signals resolved as noise, and the README leads with
what's proven instead of what's voluminous. No skill added (41 unchanged): evals,
harness, and positioning.

**Headline:** the completeness lift (**+0.39**, `0.59 → 0.98`) is **not sonnet-specific**
— a different-family frontier model (`openai/gpt-5.1`) shows **+0.44** on the same tasks,
the single largest untested assumption in the evidence base, now discharged for the
flagship dimension.

### Changed

- **Negative controls grown 8 → 20; the over-flagging signal is resolved as noise.**
  The last unexplained result in the silent-failure set was the *ablated* arm scoring
  1.00 on the loud controls while both other arms scored 0.75 — a hint that rules/10's
  catalogue might nudge a model into flagging correct, loudly-failing controls. Twelve
  more negatives were authored, each deliberately *resembling* a positive class so an
  arm matching on shape rather than effect would trip (an `exists()` check that also
  asserts non-emptiness, an optional import raised at startup, a `chmod` that actually
  restricts, correct first-match-wins ordering, a timeout attached via
  `NewRequestWithContext`, a retry loop that re-raises, decorators in the right order).
  Set is now **81 cases: 35 enumerated positives, 26 novel, 20 negative controls.**
  **Result: all three arms score 1.00 on the loud controls** — the hint was 2 of 8
  cases and it disappears at n=20. Overall lift **+0.02** with per-arm ranges of
  ±0.05–0.07, i.e. still effectively +0.00 and consistent with n=49 and n=69.
  Noteworthy: **every subgroup signal this set has produced has evaporated when the
  subgroup grew** (anchoring 6→26, over-flagging 8→20) — the strongest evidence in
  this repo for the "grow the set before trusting a subgroup" rule.

### Added

- **The eval scoring functions now have tests — and they run in CI.** A mutation probe
  replaced `run-clean.score()` with `return 1.0, {}` and asked what would notice:
  `check-invariants.sh` passed, `pre-commit` passed, and scoring a deliberately wrong
  prediction set returned **1.00**. Nothing noticed, because **there was no test suite
  in the repo and CI never touched `evals/`** — the code producing every number this
  project publishes (the README's +0.39, every +0.00 reported as an honest null) was
  unverified. A scorer stuck at 1.00 would have made all of it a lie, silently: the
  rules/10 class at its worst, in the one place it would do the most damage.
  `evals/test_scoring.py` (plain `python3`, no new dependency) covers all three
  scorers with **mutation-resistant** rows — each checked at 1.0, 0.0 *and* a partial
  value, so constant-return mutations die on the 0.0 rows and swapped-metric mutations
  die on the partials; `run-repo-audit` gets a row where category- and strict-recall
  legitimately differ. **Both mutations were watched to fail before the tests were
  trusted.** Wired into CI (`Eval scoring tests`) and pre-commit (on `evals/*.py`), so
  it cannot become a test that exists but never runs.

### Changed

- **Docs hygiene + harness/measurement conventions extended.** `evals/README.md`'s
  "Harness conventions" now carries the two findings from the deliberate self-audit
  (an unchecked corpus glob; an `--ablate` that matched nothing) and a new
  **Measurement conventions** section: *one run is a data point, not a number — never
  publish from n=1* (twice in a week a single run produced a figure a larger sample
  walked back), *grow the set before trusting a subgroup signal* (the n=6 anchoring
  "finding" evaporated at n=26), and *scrub artifacts but don't trust the scrub —
  gitleaks and push protection are the backstop, not the pattern list*.
  `docs/WHY-IT-WORKS.md` had a stale `+0.40` **and** an orphaned sentence fragment
  introduced by an earlier edit in this cycle — both repaired.
- **Completeness follow-up resolved, and the published figure corrected to `+0.39`
  (0.59 → 0.98).** v1.18.0 shipped `+0.40` from a **single** synced run; arm B was
  repeated and the two-run mean is **+0.39** — back on the original number. The 0.02
  with-arm dip that looked like it might be a salience cost of the falsification
  clause was **noise**: c1_ticket_api recovered 0.86 → 0.94, and its own swing across
  three runs (0.86–0.97) is larger than the 0.016 gap it was supposed to explain. No
  measurable cost; hypothesis closed. README, WHY-IT-WORKS and RESULTS.md updated.
  **Standing lesson recorded: stop publishing from n=1** — this is the second time in
  a week a single run produced a figure a larger sample walked back (the other being
  the retracted +0.07 on silent-control detection).

### Fixed

- **The artifact secret-scrubber was itself incomplete — a JWT pattern was missing,
  and gitleaks caught what it did not.** Added in v1.18.0 covering Stripe/AWS/GitHub/
  Slack/Google/PEM shapes, it missed a fake JWT the model wrote into generated code
  on the very next run. That is the enumeration problem the library warns about,
  occurring in our own tooling: the pattern list is incomplete *by construction*
  because a model inventing example code invents new shapes. JWT pattern added,
  artifact re-scrubbed (1 → 0, scores unchanged), and the code now says plainly that
  **gitleaks is the backstop, not the list** — add a pattern whenever it fires, and
  never bypass push protection. Third time this week a second, independent scanner
  caught what the first missed.

- **Silent-control audit of `evals/` — the library's own rules/10 applied to the
  harness that measures it.** Four silent failures surfaced here on 2026-07-20, every
  one found *incidentally*; this was a deliberate pass. **Two confirmed findings in
  ten files, both demonstrated live before being fixed**, and both sharing the
  property that makes them worse than an ordinary bug: **their failure mode produces
  `+0.00`** — a result this project has legitimately published four times, so a fake
  null would be indistinguishable from a real one.
  **F1 — an empty library corpus yields a "with-library" arm containing no library.**
  `run-clean.audit_library_context()`, `run-repo-audit.library_context()` and
  `run-desc-routing.catalogue()` all globbed their corpus and never checked the count;
  a wrong cwd or renamed directory hands the with-arm `""` and still prints a recall.
  Reproduced live (`with-library corpus: 0 chars`, no error). All three now abort.
  **F2 — `--ablate` silently ablates nothing when its target is renamed.** The filter
  was a filename equality test whose result was never asserted, so a rename leaves the
  "ablated" arm as the *full* corpus and reports a fake +0.00 contribution — while the
  run header still prints `ABLATED(...)`. Reproduced live (`removed=0 chars`). Now
  aborts. This was the **third** instance of one pattern (after
  `run-adjudication.py`'s section-number marker and `run-completeness.py`'s drifted
  mirror), so every ablation and mirror in the harness is now guarded: *a
  transformation whose result is never asserted*. Every guard watched to fire.
  Categories checked with nothing found are stated explicitly (optional-dependency
  degradation, swallowed enforcement exceptions, truncation, hardcoded reporting,
  shipped-artifact gaps) rather than padded. Report:
  [`evals/results/2026-07-21/EVALS-SELF-AUDIT.md`](evals/results/2026-07-21/EVALS-SELF-AUDIT.md).

### Changed

- **Doc hygiene: stale silent-failure counts corrected and the audit-null story
  consolidated.** `evals/README.md` still said "41 positives + 8 negative controls"
  (doubly stale — the set is 61 positives + 20 negatives at 81 cases); fixed, and the
  +0.00 result annotated as reproduced at n=49/69/81. The `RESULTS.md` scoreboard row
  moved 49 → 81 cases, and a new paragraph states the audit-family result plainly in
  one place for the first time: **all four audit-ability rows are +0.00** (recall,
  cross-file, silent-control, precision), every apparent subgroup exception dissolved
  when its subgroup grew, and the library's audit half is justified by gap analysis
  plus one real self-audit — **not by a measured lift**. The measured lift lives
  entirely in BUILD (completeness +0.39, freshness +0.53).

### Added

- **Cross-model replication of the flagship BUILD lift — it is not sonnet-specific.**
  Every completeness number this project had published used one build model
  (`claude-sonnet-4.6`), the single largest unhedged assumption in the evidence base.
  Re-running the completeness eval with a **different-family frontier model**,
  `openai/gpt-5.1`, driving BUILD — same blind judge (`opus-4.8`), same rubrics, same 7
  tasks — gives **0.44 → 0.88, lift +0.44** (every case positive, +0.29 to +0.55),
  against sonnet's **0.59 → 0.98, +0.39**. The lift generalizes and is *larger where the
  baseline is lower* (gpt-5.1's unguided arm is 0.44 vs sonnet's 0.59) — the same "lift
  tracks incompleteness" mechanism the breadth study found across domains, now
  reproduced across models. The with-arm ceiling is lower (0.88 vs 0.98): the library
  takes gpt-5.1 to *very good*, not *near-perfect*. The blind judge shares a family with
  sonnet but not gpt-5.1, so +0.44 is a conservative floor. Two families is not
  "model-agnostic", but the single-model assumption is discharged for the flagship
  dimension. Cost $1.87. Writeup:
  [`evals/results/2026-07-22/CROSS-MODEL.md`](evals/results/2026-07-22/CROSS-MODEL.md);
  `RESULTS.md` + `docs/WHY-IT-WORKS.md` updated.

### Changed

- **README hero re-led with the measured lift and the *loop*, not the volume.** The
  opening had led with "41 skills (296 files, ~60k lines)" — which reads as exactly
  the prompt-dump this library outperforms. It now opens with the proven result
  (best-practice coverage **~59% → ~98%, +0.39**, from a bare "build X" prompt, linked
  to the scoreboard) and the one-line mechanism that differentiates it — *a loop, not a
  prompt dump: route lean, re-state every turn, re-check last*. The volume figure moves
  to a supporting "under the hood" line (kept intact for invariant 6). A distribution
  move, not a content one: ~500 unique cloners/14 days were converting to 7 stars, and
  the hero was selling the wrong thing.

## [1.18.0] - 2026-07-21

The **learning-from-use** release. Ships the library's first path for hearing from its
users, retires an open hypothesis about its own content pattern, and re-verifies the
headline number against the workflow that actually ships. No skill added (41
unchanged): router content, evals, and docs.

**If you upgrade for one reason, it is this:** the completeness figure quoted in
v1.17.0 (`+0.39`, `0.60 → 1.00`) was measured against a *drifted copy* of the BUILD
workflow. Both arms have now been run — the number reproduces at **+0.40** either way
— and every user-facing surface now carries the verified `0.58 → 0.98 (+0.40)`.

### Added

- **Gap-reporting loop — the library's first path for learning from use.** The
  project has no telemetry by design, which also means a wrong rule, a stale
  version claim, or a missing skill stays in the library for everyone until a human
  reports it. Measured reality at v1.17.0: **~24 organic clones/day against 7 stars
  and one issue ever filed** (GitHub traffic API; the three days with zero CI runs
  show clones exactly equal to unique cloners). Hundreds of installs, no signal.
  The fix uses the one channel this project uniquely has — the user is talking to an
  agent that **already read the skills**. A new short router section tells that agent
  to surface a **one-line** note when the library actually let the user down (a rule
  contradicted by a primary source it just checked; a rule that doesn't fit and
  states no exception; real surface area with no owning skill; guidance that would
  have shipped a defect), with the issue-template link — and explicitly *not* for
  personal preference, unneeded rules, or mid-task. Deliberately placed **outside**
  the always-apply operating principles so it does not dilute the measured
  principle-5/6 salience. README gains a matching section (issue templates already
  existed; nothing pointed users at them). Regression-checked — the router grew
  443 → 467 lines and the routing eval pastes it whole: with-arm **held at 1.00**
  (3×@0.7, no misses), lift +0.11. Artifact:
  `evals/results/2026-07-20/routing-3sample-postfeedback.json`.

### Changed

- **Taxonomy-anchoring hypothesis tested and RETIRED** — the open question from
  v1.17.0, and the one that mattered most: the library is ~296 files of largely
  *enumerative* guidance, so if catalogues make a model pattern-match the list
  instead of applying the underlying question, that indicts the dominant content
  pattern. At n=6 novel mechanisms the unguided arm had scored 1.00 vs 0.83 for
  both library arms. The novel subgroup was grown **6 → 26** (20 mechanisms
  `rules/10` never lists — a `def` shadowing an imported validator, a signature
  compared against itself, `return` inside a loop body, middleware registered after
  its routes, an autouse fixture disabling the rate limiter suite-wide, a `chmod`
  that ORs permissions *wider*, an allowlist consulted after the request is sent, a
  seconds/minutes TTL mismatch, an inverted predicate, a wildcard allow shadowing a
  deny under first-match-wins, a feature gate read at import time, …). The set is
  now **69 cases: 35 enumerated positives, 26 novel, 8 negative controls.**
  **Result: not supported.** The gap collapsed to **0.96 vs 0.92 — a single case**,
  inside the per-arm run spread (0.91–0.96). The n=6 signal was small-sample noise,
  exactly as it was labelled, and the enumerative content pattern is **not** shown
  to reduce generalization to unlisted mechanisms. Overall library lift reproduced
  at **+0.00** on a set 40% larger and harder, consistent with the n=49 run.
  Logged but explicitly **not** claimed: the *ablated* arm scored 1.00 on the 8
  loud-control negatives vs 0.75 for both other arms — if anything the opposite of
  anchoring, hinting at mild over-flagging; 2 of 8, to watch if that set grows.
  `SILENT_VOCAB` extended with the 20 new slugs; no answer-key leakage (verified
  across both runners). Writeup:
  [`evals/results/2026-07-20/SILENT-FAILURE.md`](evals/results/2026-07-20/SILENT-FAILURE.md).

- **Docs hygiene against this cycle's work.** `evals/README.md`: silent-failure case
  count corrected 49 → **69** and the novel subgroup 6 → **26** (both stale), with the
  retracted +0.07 and the retired anchoring hypothesis stated in place. `docs/INDEX.md`
  gained rows for the two new writeups (AUDIT-PROCESS, SILENT-FAILURE) — the honest
  +0.00 results were previously unfindable from the index. `docs/ROADMAP.md`: the
  top item moved BLOCKED → IN PROGRESS with the arm-A number; "grow the eval case
  sets" replaced with what actually remains thin (the 8 negative controls, the 7-case
  completeness set, competitor domains beyond the five measured); and the distribution
  item grounded in measured traffic (~24 organic clones/day vs 7 stars, 0 watchers,
  1 issue ever — LinkedIn confirmed as top referrer).
- **New `evals/README.md` section: harness conventions**, written from four
  self-inflicted silent failures in one day — a prompt-field whitelist that dropped
  `prompt` (the routing eval sent bare ids and still printed a recall score), an
  ablation keyed on a section *number* that a renumber broke, a scripted CHANGELOG
  edit whose anchor did not exist on its branch, and a wait condition that matched a
  per-case progress line and called a still-running job complete. Rules: guards abort
  rather than warn; watch the guard fail before trusting it; wait on a terminal
  artifact, not a log substring; assert a scripted edit landed; pin what you mirror.
  `AGENTS.md` points at it — the same failure class `rules/10` describes, occurring in
  the tooling that measures the library.

### Fixed

- **The flagship completeness number is now verified against the workflow that
  actually ships — `0.58 → 0.98, +0.40`.** Both arms were run with one variable
  changed: the drifted mirror measured **0.59 → 1.00 (+0.40)** and the synced mirror
  **0.58 → 0.98 (+0.40)**. So the published `+0.39` was **never wrong** — it was
  measured against stale text and reproduces either way. `RESULTS.md`, `README.md`
  and `docs/WHY-IT-WORKS.md` now carry the synced figures rather than numbers
  produced by a workflow the library no longer ships. The 0.02 with-arm difference is
  **one case** (c1 lost transport, sizelimit, pagination) and is **not** separable
  from sampling variance in a single run — logged as a follow-up (repeat arm B 3×),
  not claimed, though it points exactly where our own
  [context-rot finding](docs/WHY-COMPLETENESS-RESIDUAL.md) predicts. Method,
  per-case table and limits:
  [`evals/results/2026-07-20/MIRROR-VERIFICATION.md`](evals/results/2026-07-20/MIRROR-VERIFICATION.md).
- **Eval artifacts are now secret-scrubbed at write time.** Artifacts store
  model-generated code verbatim, and a model asked to build a payments endpoint
  writes `sk_live_...` into its examples — which blocked a push on 2026-07-20 (two
  synthetic Stripe-shaped strings in `c1_ticket_api`'s generated code; not real
  credentials, but secret-shaped strings do not belong in a public repo: they trip
  push protection, train readers on a bad example, and bury a genuine leak in noise).
  `scrub_secrets()` replaces Stripe/AWS/GitHub/Slack/Google/PEM-shaped strings with a
  **visible** `[SCRUBBED-SECRET-SHAPED-STRING]` marker — the class, not the instance —
  and runs on every artifact write. Existing artifacts cleaned (4 → 0); recall scores
  are unaffected. Verified by feeding it known key shapes and confirming they are
  replaced. Note this is the *second* time push protection caught something local
  gitleaks did not: `.gitleaks.toml` disables the entropy rule so the security skills'
  deliberate examples don't false-positive, which also blinds it to vendor-specific
  patterns. Two scanners, two coverage sets.
- **`run-completeness.py`'s `BUILD_WORKFLOW` mirror had drifted from the router, and
  the drift class is now closed.** That constant is a hand-compressed mirror of router
  BUILD steps 3–4 (kept compressed so results stay comparable with every historical
  run) — but it is *not* a live read, and the falsification clause added to router
  step 4 in #119 was missing from it for four days. The project's most-cited number
  was therefore being measured against a workflow that no longer shipped. Nothing
  failed; the eval quietly measured the wrong thing.
  Fixed deliberately and measured, never synced blind: **arm A (drifted mirror)
  measured without 0.59 → with 1.00, LIFT +0.40**, reproducing the recorded +0.39 —
  so the figure was never wrong, only measured against stale text. The mirror is now
  synced and a **`ROUTER_BUILD_SHA` pin** was added: the runner hashes the router's
  BUILD section and **aborts** if it no longer matches what the mirror was synced
  against, rather than measuring unshipped text. Guard watched to fire on a synthetic
  router edit before being trusted.

## [1.17.0] - 2026-07-20

The **silent-failure release**, and an unusually honest one. New coverage for the
class where a control *looks* enabled and does nothing; adversarial refutation and
decision-ledger review added to AUDIT mode; and three new eval instruments — two of
which returned **+0.00**, plus a **headline lift that was measured, failed to
replicate on a larger set, and is retracted here rather than quietly kept**. No
skill added (41 unchanged): content, evals, and docs.

**Reading guide.** The library's audit dimension now saturates on four independent
instruments (recall, cross-file, silent-control, precision), so nothing added to the
audit path in this release carries an efficacy claim. What *is* measured and holding:
completeness +0.39, freshness +0.53, routing +0.10 (re-verified at 1.00 with-arm
twice in this cycle, after the router grew ~5%).

### Changed

- **Silent-control eval grown 15 → 49 cases, and its headline lift RETRACTED.**
  The 15-case set saturated the with-library arm (0.99–1.00), leaving no headroom
  to measure. The set now carries **41 positives + 8 negative controls** (loud
  failures, incl. a display-only truncation and a *documented deliberate*
  fail-open, both of which must NOT be flagged) and **6 positives tagged `novel`**
  — mechanisms rules/10 does not enumerate (case-sensitive blocklist regex vs
  lowercased input, unawaited async authz check, decorator/route ordering bypass,
  inverted config-merge precedence, a context timeout never attached to its
  request, a retry loop that swallows its final failure) — which separates
  "teaches the lens" from "recites its own list". Harder positives were added
  across Go/TS/SQL/YAML/Helm/Markdown.
  **Result: the +0.07 lift measured at n=15 does not replicate.** At n=49 it is
  **+0.03** (vocabulary design) and **−0.01** (open-ended design), both inside a
  per-arm spread of ±0.04; rules/10's own ablated contribution is **+0.00** (the
  vocabulary design's with- and ablated arms are *identical* — 0.918, zero spread,
  same four missed cases). `RESULTS.md` corrected from +0.07 to +0.00 with the
  retraction stated in place. One signal logged as a **hypothesis, not a finding**:
  on the 6 unenumerated mechanisms the *unguided* arm scored 1.00 and both library
  arms 0.83 — possible **taxonomy anchoring**, one case at n=6, needs a larger
  novel subgroup. Four cases defeat every arm (build-tag no-op, `*.yaml` glob vs
  `.yml`, env-filter mismatch, unawaited `expect().rejects`); adding them to the
  rule text was deliberately **not** done, as that would fit the guidance to the
  test set.
- **Both eval runners now whitelist prompt fields** (`id`/`language`/`snippet`)
  instead of blacklisting known answer keys — a new case field such as `novel` or
  `reference` can no longer leak the answer into the prompt just because nobody
  updated a strip list. `run-silent-open.py` additionally reports **novel** and
  **negative-control** subgroup recall per arm.

### Added

- **Audit-precision eval + the regression check for this PR** —
  `evals/cases/finding-adjudication.jsonl` (30 code+claim pairs, 15 genuine / 15
  plausible-but-wrong across six distinct refutation classes) and
  `evals/run-adjudication.py`, scoring **specificity** (refute the false claims) and
  **sensitivity** (keep the real ones) with an ablation arm that strips §6. Every
  other audit set here measures *recall*; this measures the false-positive side that
  refutation actually targets. **Result: +0.00 — all three arms 1.00**, zero wrong
  answers in 90 adjudications per arm. Run twice: the first framing enumerated the
  ways a claim can fail (i.e. handed §6's content to every arm) and was replaced with
  a neutral one — identical 1.00s, so the saturation is not a framing artifact.
  Routing was re-run as the regression check for today's three router edits and
  **held at 1.00** (lift +0.10, both matching the recorded multi-sample numbers).
  Completeness was deliberately **not** re-run and the reason is documented: all 17
  skill files it loads are unchanged since v1.16.0, its `principle5()` extract is
  byte-identical (sha `2a36f20d8e51`), and its `BUILD_WORKFLOW` is a hardcoded mirror
  — so it is structurally blind to today's changes and a green run would have been a
  vacuous test. That mirror's drift from the router is logged, not silently synced.
  **Four audit instruments now saturate** (recall, cross-file, silent-control,
  precision); the writeup states plainly that no current instrument can score an
  audit-*process* change, and recommends stopping additions to the audit path until
  an agentic one exists:
  [`evals/results/2026-07-20/AUDIT-PROCESS.md`](evals/results/2026-07-20/AUDIT-PROCESS.md).
- **Decision-ledger review in AUDIT mode** — `sota/rules/01-audit-methodology.md`
  gains **§6**, and the router's AUDIT workflow a **step 5**. Code passes find defects
  in what was built; they cannot find the defect where the code faithfully implements
  a choice that **stopped being right** — a datastore picked for scale that never
  arrived, a rewrite justified by a benchmark that no longer reproduces, an expired
  constraint still shaping the design. Reconstruct the expensive-to-reverse decisions
  (ADRs, design docs, CHANGELOG, the PRs that introduced each major component) and
  classify each **JUSTIFIED / STALE / UNJUSTIFIED / UNVERIFIABLE**, with STALE
  (sound when made, inputs since expired) kept distinct from UNJUSTIFIED (the stated
  reasoning never supported it). Where a decision rests on a **number**, re-run that
  measurement *this session* — a benchmark in a two-year-old ADR is a historical
  claim, not a current fact — or mark the decision unverifiable and say what would
  confirm it. Ledger-vs-code is checked **both** directions (recorded-but-not-
  implemented is as much a finding as implemented-but-not-recorded). Verdicts carry a
  severity and feed the roadmap. Report structure gains a **Decision ledger** section;
  one audit-checklist line added; §7–§9 renumbered.
  `sota-architecture` rules/01 §4 owns *writing* ADRs and is cross-referenced, not
  duplicated — this is the audit side. Verified the gap on current `main` first:
  zero hits for ADR/decision-record/stale-justification anywhere under `skills/sota/`.
  **Unmeasured, deliberately:** four audit instruments now saturate at +0.00
  (recall, cross-file, silent-control, precision), so no current eval can score an
  audit-*process* change — see
  [`evals/results/2026-07-20/AUDIT-PROCESS.md`](evals/results/2026-07-20/AUDIT-PROCESS.md).
  No efficacy claim is made, and this is the **last** planned audit-path addition
  until an agentic instrument exists.
- **Adversarial verification in AUDIT mode** — `sota/rules/01-audit-methodology.md`
  gains **§6 "Try to kill your own findings"**, and the router's AUDIT workflow step 6
  changes from *verify* to **refute**. Re-reading your own finding re-runs the
  reasoning that produced it, so it is the weakest check available; every
  Critical/High now gets an **independent pass prompted to kill it** — a separate
  agent or a fresh-context hostile read, working from the code at the pinned commit
  rather than the write-up, defaulting to REFUTED when evidence is ambiguous.
  Includes the three distinct refuter lenses (is the mechanism real / is it
  reachable / is the impact inflated), majority-refute-kills, **recording
  refutations** so the next auditor doesn't re-raise them, a refuter for absence
  claims, effort scaling by severity, and the two failure modes that make the pass
  theatre (the rubber-stamp refuter told to "verify" rather than refute, and
  refuting the *description* instead of the code). Report §7 and hygiene §8
  renumbered accordingly; one audit-checklist line added.
  Adopted from a field-tested external audit harness — verified first that the
  library had **no** independent-refutation language anywhere (`grep` for
  refut/adversarial/independent-verify across `sota/` and `sota-testing/` returned
  zero hits), so this is a genuine gap, not a restatement. **Unmeasured:** the audit
  dimension already saturates at +0.00, so the existing evals cannot show a lift
  here; no efficacy claim is made.

- **`sota-code-security` rules/10 "Silent control failure"** — a new rule file for
  the class the library had no home for: a control, feature, or safeguard that
  **appears active but does nothing**, where a broken system and a working system
  are indistinguishable from the outside. Organized around the *falsification
  question* ("if this were silently a no-op, would anything observable differ? —
  if no, that IS the finding"), then eleven places no-ops hide: weak existence
  checks (`exists()`/`is_dir()` standing in for a loaded artifact), optional-
  dependency degradation (`except ImportError` → feature vanishes), empty or
  placeholder rulesets loaded as real, swallowed exceptions on the enforcement
  path, overloaded flags, attacker-triggerable early returns, truncation before
  inspection, config keys silently ignored by permissive schemas, doc/code drift
  on defaults, hardcoded numbers in tool output, and **shipped-artifact gaps**
  ("works in a dev checkout, dead in the image"). Plus the mutation probe for
  vacuous tests (with the two traps that make a green run lie), the shared
  deduped-per-cause degraded-control helper, and the evidence rules — including
  that **a negative claim needs more proof than a positive one**.
  A prior gap analysis confirmed 9 of these 12 concepts had no coverage anywhere
  in the tree; fail-open (rules/03) and test vacuity (`sota-testing` rules/02/06/
  09) were already covered and are cross-referenced rather than duplicated.
- **The lens is now part of the default BUILD and AUDIT paths**, not an opt-in
  file: the router's BUILD self-audit gate (step 4) asks the falsification
  question of every control in the diff; AUDIT mode gains a **step 4
  "silent-control pass"** run over the controls the domain passes confirmed
  exist (the class is invisible to those passes and to pattern-based SAST,
  because the code isn't wrong — it's inert); `sota-code-security` BUILD mode
  gains step 6 ("every control must be falsifiable") and AUDIT mode step 5
  ("check the inert"); and routing rule 20 ("'it's enabled' is a claim, not a
  fact") points at it from the router.
- **Asymmetric evidence burden for negative claims** — router operating
  principle 3 and `sota/rules/01-audit-methodology.md` §5 now require a widened
  search plus a second independent method before asserting "no instances of X",
  and require positive observations to be evidenced by **effect** (a rejection,
  a log, a test that fails when the control is disabled) rather than presence.
  Two audit-checklist lines added.
- **Eval case set for the silent-control class** — `evals/cases/silent-failure.jsonl`
  (15 cases: 13 positives, one per hiding place, across Python/Go/JS/YAML/Dockerfile,
  plus **2 negative controls** whose correct answer is "not silent" so an
  over-flagging arm cannot score 1.00), a `silent` kind in `run-clean.py`, a new
  **`--ablate`** flag that drops rules/10 from the with-library arm to isolate a
  single file's contribution, and `evals/run-silent-open.py` — an open-ended,
  no-vocabulary variant graded by a **different** model blind to the arm.
  **Result, reported as measured:** at the initial 15 cases the library appeared to
  lead **0.92 → 0.99 (+0.07)**, and that number briefly shipped in `RESULTS.md`.
  **It did not replicate and is retracted** — see the grow-the-set entry below.
  The design's own limit is documented: both arms must be *told* to hunt inert
  controls, and that framing is the falsification question itself, so what the rule
  actually adds — asking unprompted — is what this design cannot measure. Writeup,
  raw artifacts, and limitations:
  [`evals/results/2026-07-20/SILENT-FAILURE.md`](evals/results/2026-07-20/SILENT-FAILURE.md);
  scoreboard row added to `evals/results/RESULTS.md`.
- Cross-references so each home keeps its own doctrine: `sota-testing` rules/06
  (hand-mutating a control's body as a no-tooling audit probe, plus the
  missing-dependency and mutation-didn't-take traps), `sota-observability`
  rules/05 (one shared degraded helper, deduped per cause not per request),
  `sota-devsecops` rules/04 (the built image must contain what the code needs at
  runtime; smoke-test controls against the artifact, not the checkout).

- **`sota-docs-workflow` rules/01 §8 "The documentation baseline"** — the must-have
  doc set every repo should carry, closing a real gap (the individual docs were
  covered but scattered, and the community-health files SECURITY/CODE_OF_CONDUCT/
  SUPPORT/GOVERNANCE were absent entirely). Enumerates *always* (README + LICENSE +
  CHANGELOG) vs *trigger-based* (CONTRIBUTING/CODE_OF_CONDUCT/SECURITY once public,
  runbooks once on-call, AGENTS.md for AI-assisted repos, ADR log, CODEOWNERS), with
  GitHub's community-health-file search precedence (`.github/` → root → `docs/`,
  verified against GitHub docs) and the single-canonical-home rule so the baseline
  itself doesn't become sprawl. Two audit-checklist lines added; SKILL index + BUILD
  step updated.

### Changed

- **`evals/results/RESULTS.md` now embeds the five-domain breadth chart** and
  carries the full breadth story inline (chart + table + 0.7-baseline threshold +
  the "why the baseline predicts the lift" mechanism), so the scoreboard is
  self-contained instead of splitting the visual off into `BREADTH.md`. `BREADTH.md`
  stays as the per-domain-notes and raw-data appendix.

## [1.16.0] - 2026-07-16

The competitor + breadth release: a fair, blind, reproducible head-to-head against
the most popular guidance libraries; a five-domain breadth study showing the lead
tracks the *unguided baseline*, not the domain; three conventions distilled from an
external review (each independently measured); plus a discoverability and
eval-harness overhaul. No skill added (41 unchanged) — content, evals, and docs.

### Added

- **Three conventions adopted from an external agent-orchestration review**
  (pure-Markdown, generic; runtime-bound ideas like memory-bank persistence,
  RAG, and worktree locks were deliberately skipped):
  1. **Negative routing cross-references** — 9 confusable skill descriptions now
     name the sibling to use instead ("Not for X — use sota-Y": api-design,
     observability, async-concurrency, performance, threat-modeling, devsecops,
     cli-ux, databases, docs-workflow), sharpening disambiguation inline. No
     harness reads skill descriptions, so this is off every measured eval path.
  2. **Plan-concreteness** — router BUILD step 3 now requires each planned
     checklist item be a concrete, checkable done/not-done outcome (vague items
     rejected); mirrored into `run-completeness.py`'s `BUILD_WORKFLOW` so the eval
     reflects the real workflow.
  3. **Evidence-based completion** — new router operating principle 6: never claim
     "done"/"working" from plausibility; state the check run and its result.
  Regression-tested (our [context-rot finding](docs/WHY-COMPLETENESS-RESIDUAL.md)
  warns added text can lower salience): the 3× completeness eval held at **0.991
  with-arm / +0.385 lift** (vs 0.996 / +0.395 — Δ −0.005, within sampling noise;
  no cross-cutting concern systematically dropped), and the 3× routing eval (which
  pastes the whole router, so it sees principle 6) **held at 1.00** with-arm, no
  misses. Raw: `evals/results/2026-07-13/completeness-3sample-postadopt.json` +
  `routing-3sample-postadopt.json`; summary in `evals/results/RESULTS.md`.

- **Description-based routing eval** (`evals/run-desc-routing.py`,
  `evals/cases/desc-routing.jsonl`, `results/2026-07-13/desc-routing-3sample.json`)
  — the first measurement of the skill **auto-loader** path (pick a skill from the
  description catalogue), distinct from the router table. A/Bs the catalogue with vs
  without the negative cross-references added above, on 10 adversarially-confusable
  tasks. **Honest +0.00:** the model never routed to the warned-against sibling in
  *either* arm (distractor-pick 0.00 across all cases/samples), so the cross-ref had
  nothing to fix — the description-selection path is already saturated for a frontier
  model, like audit. The cross-refs are kept as zero-cost defensive clarity; no
  routing lift is claimed. Summary in `evals/results/RESULTS.md` §5.

### Fixed

- **Accuracy sweep (4-way doc audit against the result JSONs).** Corrected claims stated more strongly than the data: the **web-search recovers/can't-recover** claims (freshness + completeness) were never measured — now marked as predictions; the live-agent 0.99 was called *identical* to the 0.99 simulation (actually 0.987 vs 0.988) — softened to *matching*; `claude-skills` 3-tightest confidence 83% → **82%** (recomputed 0.8249); DECAY guidance/filler sizes were tokens mislabeled as KB (18.7 KB → **~18.6K tokens / ~72 KB**); freshness **+0.65** was mis-attributed to the 32-case set (it's a 20-case run; 32-case is +0.53); `completeness-blind-spot` upload 0.55 → **0.58** (multi-sample mean); ROADMAP item 6 and the AGENTS.md WHY-IT-WORKS pointer were stale (competitor benchmark is done, WHY now carries a scoped vs-libraries section); star counts dated. Cited literature was spot-verified accurate (Chroma 2025 '18 models') and left as-is.

### Added

- **Competitor breadth experiment (five domains) — concludes the comparison.**
  `evals/results/2026-07-13/BREADTH.md` plus the case/manifest/result files for
  Go backend, complex frontend (SSR/auth), simple frontend, and IaC
  (`evals/cases/completeness-{go,iac,frontend,frontend-complex}.jsonl`,
  `evals/cases/competitors-{go,iac,frontend}.json`,
  `results/2026-07-13/competitor-breadth-{go,iac,frontend,frontend-complex}.json`);
  `run-competitors.py` gained `--cases`/`--manifest`/`--ids`/`--samples`/`--temp`
  and incremental `--out` saving. **Finding: the lead tracks the *unguided
  baseline*, not the domain.** Below a ~0.7 baseline (Python backend 58%→lead +12,
  Go 67%→+10, hard SSR/auth frontend 53%→+10) SOTA-skills leads every competitor by
  ~10 pts; above it (simple React forms 77%→+0, templated IaC 87%→+0) everyone
  converges. This **supersedes** the earlier "backend-specific" reading — the first
  frontend run used *easy* forms; a re-run with the invisible concerns (server-side
  authz, secret-boundary leakage, injection, hydration, CSP) shows SOTA-skills leads
  hard frontend too. All docs (README, WHY-IT-WORKS, RESULTS, COMPETITOR-BENCHMARK,
  ROADMAP) reframed from "backend-specific" to baseline-driven.
- **Five-domain breadth chart** (`assets/breadth-{light,dark}.svg` + matching
  1520px `.png`, regenerable via `assets/gen-breadth-chart.py`) — a theme-aware
  grouped bar of unguided / best-competitor / SOTA-skills completeness across the
  five domains, ordered by baseline so the lead-where-incomplete pattern is visible;
  embedded in `BREADTH.md`. Palette validated with the dataviz skill's checker.
- **Competitor-benchmark bar chart** (`assets/benchmark-{light,dark}.svg` +
  matching 1440px `.png`, regenerable via `assets/gen-benchmark-chart.py`) — a
  theme-aware visual of best-practice completeness per library (SOTA-skills 99%
  highlighted vs the field), embedded in the README, `evals/results/RESULTS.md`,
  and `docs/WHY-IT-WORKS.md` via `<picture>` (light/dark SVG). The PNGs are for
  LinkedIn/slides/anywhere SVG isn't supported. Palette validated with the dataviz
  skill's checker; alt text carries the numbers.
- **Discoverability overhaul.** `docs/INDEX.md` (a find-it-fast map: every topic →
  where it's documented, organized by intent), `docs/CONTEXT-MANAGEMENT.md` (the
  single home for how the library keeps the model applying rules as context fills —
  the re-injection hook, principle 5, terminal re-read, deterministic gates, and
  the *why*), and `evals/results/RESULTS.md` (a consolidated scoreboard of every
  measured number). README gained a **table of contents** and deep-doc links; both
  new indexes are linked from AGENTS.md.
- **Skill-application decay eval** (`evals/run-decay.py`,
  `results/2026-07-13/DECAY.md`) — the first measurement of the *temporal*
  (multi-turn) dimension of rule forgetting, not just single-call. Arms: anchor /
  reminder (the `UserPromptSubmit`-hook analog) / control. First run: **no decay at
  moderate scale** (guidance held over 30 unrelated turns); bounds the problem but
  needs a bigger intervening context to find the breaking point (roadmap item 5).

### Changed

- **Every competitor-repo reference now uses its full `owner/repo` name + a
  GitHub link** (no bare "ECC"/"claude-skills"/"awesome-cursorrules", which
  collide with unrelated same-named repos), and `evals/results/RESULTS.md` bundles
  all competitor numbers into **one consolidated per-repo table** (completeness,
  confidence, gap vs SOTA, head-to-head).
- **The 500-line cap now applies to skill Markdown only** (`skills/**/*.md`), where
  it's load-bearing for incremental loading. README, CHANGELOG, and `docs/` are
  uncapped — navigability comes from the TOC + `docs/INDEX.md`, not a line ceiling.
  CHANGELOG archiving is now optional hygiene, not forced. *(PR #100)*

Evaluation-harness additions (no skill-content change; not in CI — see
`evals/README.md`). These execute two roadmap follow-ups from v1.15.0.

### Added

- **Cross-file repo-audit eval** (`evals/run-repo-audit.py`,
  `evals/cases/repo-audit.jsonl`, `evals/cases/repo-audit/orderdesk/`). A 15-file
  FastAPI fixture with **8 defects that are invisible in any single file** (an
  authz check one layer assumes another enforces, a taint crossing modules, an
  invariant one file documents and another violates, an insecure default trusted
  by its caller). Answers roadmap item 3 — the only identified path to a real
  audit lift. Result: **+0.00** on both `claude-sonnet-4.6` and `claude-opus-4.8`
  (strict, file-attributed scoring). When the whole repo fits in one context, a
  capable model reads across files unaided; making defects cross-file changes
  nothing while every file is visible. The library makes **no audit-lift claim**;
  the real frontier is a repo too large to hold at once (agentic selective
  reading), logged as the open follow-up
  (`evals/results/2026-07-13/REPO-AUDIT.md`).
- **Live-agent BUILD validation** (`evals/judge-live-build.py`). Closes the
  completeness eval's one simulation gap (roadmap item 2): `run-completeness.py`
  *pastes* the router's principle 5 + rules to stand in for what an agent loads.
  This scores artifacts from a **real sub-agent** driven over each build task
  through the actual router BUILD workflow, with the same blind opus judge and
  rubrics. Live-agent mean completeness is **0.99 (6/7 perfect)** — identical to
  the 0.99 paste-based simulation and vs 0.60 unguided base, confirming the
  simulation is a faithful proxy. Result: `evals/results/2026-07-13/LIVE-BUILD.md`
  (+ `live-build.json`).
- **Multi-sample eval tightening** (roadmap item 1) —
  `evals/results/2026-07-13/MULTI-SAMPLE.md` + `completeness-3sample.json` +
  `routing-3sample.json`. Re-ran the value dimensions at `--samples 3 --temp
  0.7`: completeness **0.60 → 1.00 (+0.39)** (reproduces the single-sample
  headline; with-arm ±0.01 across-case sd, 6/7 cases perfectly steady), routing
  **0.90 → 1.00 (+0.10)** (with-arm ±0.00), freshness **0.44 → 0.97 (+0.53)**
  (reused 3× run). The with-library arm is near-zero variance everywhere; the
  sampling wobble is all in the unguided arm. Retires the single-sample caveat in
  `docs/WHY-IT-WORKS.md`.
- **Publication draft** — `docs/writeups/completeness-blind-spot.md`, a
  reader-facing write-up of the completeness/salience finding (context rot →
  dropped rate-limiting; adding rules made it worse, a short reminder fixed it),
  with the before/after data and honest boundary. Draft for the maintainer to
  publish (roadmap item 7, distribution).

### Added

- **Competitor benchmark** (`evals/run-competitors.py`,
  `evals/cases/competitors.json`, `results/2026-07-13/COMPETITOR-BENCHMARK.md`) —
  SOTA vs. the most popular competing guidance libraries on the 7 completeness
  tasks, content-only and blind-judged. **SOTA-skills 0.99 vs
  [affaan-m/ECC](https://github.com/affaan-m/ECC) (~230k★) 0.87,
  [PatrickJS/awesome-cursorrules](https://github.com/PatrickJS/awesome-cursorrules) (~40k★) 0.83,
  [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) (~23k★) 0.81**;
  unguided 0.58. SOTA wins or ties every one of the 21 head-to-head cases and
  loses none; competitors are legitimate (all beat unguided by +0.23–0.28) but
  drop the cross-cutting non-negotiables (rate limiting, transport, tests) SOTA
  embeds. Clears the roadmap honesty gate for a scoped, reproducible "vs library
  X" claim; `docs/WHY-IT-WORKS.md` now carries it. A **3-sample/temp-0.7 confidence
  check** on the 3 tightest cases confirms the lead holds — SOTA's worst sample is
  ≥ each competitor's best, and the gaps match the single-sample run. The harness
  gained `--samples/--temp`, `--ids`, and crash-safe incremental `--out` saving.

### Changed

- **README surfaces the measured lift up front** — the dense one-liner is now a
  scannable per-dimension list (completeness +0.39, freshness +0.53, routing
  +0.10, with the multi-sample endpoints and the "near-zero variance" note). The
  clone/script install method now sits in the top quick-install block right after
  the plugin commands; the Installation section keeps the clone-path details
  without repeating the command blocks.

## [1.15.0] - 2026-07-13

The measured-efficacy release: completeness proven as the library's thesis, the
one residual root-caused, and the BUILD workflow rewritten around it.

### Added

- **Completeness eval — the library's thesis, measured** (`evals/cases/completeness.jsonl`,
  `evals/run-completeness.py`). Given a minimal "build X for my app" prompt with
  no security/logging cues, does the model embed best practices from v1? Clean
  raw-API, generate-then-**blind-judge** (opus-4.8 grades sonnet-4.6's artifacts,
  blind to arm), 7 build tasks. Vs. an unguided model the full library lifts
  best-practice coverage **0.60 → 0.99 (+0.39), 6/7 tasks perfect** — embedding
  the tests/rate-limits/logging/transport a base model *systematically* skips.
  Unlike freshness, this is **not** recoverable by "verify via search" (an agent
  won't search "should I add rate limiting"), which makes it the most defensible,
  least-redundant value. Ablation: base 0.60 → +rules ~0.89 → +BUILD self-audit
  0.93 → +router principle 5 0.99.
- **`docs/WHY-IT-WORKS.md`** — the measured case, framed honestly (**vs. an
  unguided model**, explicitly *not* vs. other libraries — we haven't benchmarked
  one) + the four in-repo-verifiable benefits (auto-routing/composition,
  freshness-maintained + primary-source-cited, build+audit, CI-gated quality).
  README hero links it.
- **`docs/WHY-COMPLETENESS-RESIDUAL.md`** — why a with-library build still
  occasionally drops a cross-cutting rule, and the design that counters it.

### Changed

- **Root-caused the completeness residual; it is a salience / context-length
  attention effect, NOT a "coverage gap"** (`docs/WHY-COMPLETENESS-RESIDUAL.md`).
  In all 7 tasks the forgotten rule was in context *and* in a pasted Audit
  checklist, yet dropped. Five controlled experiments (+ a 4-case recovery test)
  disprove the coverage story: **adding the missing rule files made it worse**
  (context 72→100 KB, compliance fell — live context rot), while a **short salient
  reminder recovered it to 1.00**. Matches the literature — context rot
  ([Chroma 2025](https://www.trychroma.com/research/context-rot)), lost-in-the-middle
  ([Liu 2023](https://cs.stanford.edu/~nfliu/papers/lost-in-the-middle.arxiv2023.pdf)),
  instruction-count decay ([arXiv 2507.11538](https://arxiv.org/html/2507.11538v1)).
  It occurs in a single call, so it is not a workflow/subagent artifact — chains
  only amplify it.
- **Router BUILD workflow rewritten around the finding** (`skills/sota/SKILL.md`):
  a **hard self-audit gate** (step 4 — do not present code until every checklist
  item is implemented or explicitly scoped out); a short **operating principle 5**
  (universal non-negotiables — rate-limiting / transport / tests / logging on any
  endpoint, kept short for salience, 947→765 chars); **load lean** (extra
  similar-looking rules *measurably lower* compliance — correctness, not economy);
  **plan with the checks up front**; **self-audit LAST with a terminal re-read**
  (recency); plus recommend a separate fresh-context audit pass + deterministic
  CI gates. The eval's with-arm now pastes principle 5, so its number reflects the
  real library.
- **Eval suite hardened and validated against primary sources.** Completeness
  4 → 7 build tasks (+search, webhook, password-reset). **Freshness 20 → 32
  cases** (+12 across languages/security/cloud/crypto/web specs, each
  grep-confirmed in the library and primary-source-verified) — lift **+0.50**
  (with 0.97, without 0.47), and +0.53 at 3 samples; the base model still
  *fabricates* (RFC 9334 for EAT, PG 17 for `uuidv7`). **Harder audit 7 → 14
  cases** (realistic, non-telegraphed, multi-vuln: IDOR / SSRF-bypass / TOCTOU /
  prototype-pollution / ReDoS) — **still +0.00**: a capable model catches them
  *in isolation*, so a real audit lift needs cross-file context, not more
  snippets. **Multi-sample** `--samples N` / `--temp T` on both harnesses
  (default 1 / 0), plus 32k gen cap / 100k judge window / progress logging +
  retries for observable, resilient long runs.

## [1.14.1] - 2026-07-11

### Changed

- **Grew the freshness eval 8 → 20 cases** (`evals/cases/freshness.jsonl`): +12
  objective 2026-current-fact cases across domains (TypeScript 7 GA, Cilium
  ztunnel, PQ MLKEM768, OpenAPI 3.2, K8s user-ns 1.36, Keep-a-Changelog 2.0,
  MISRA C:2025, RateLimit draft status, SCIM RFC 9967, libFuzzer maintenance,
  Azure Cobalt 200, rust-lld 1.90) — each verified present in the library +
  primary-source correct + token-scorable. Clean 20-case lift **+0.65
  (sonnet-4.6) / +0.50 (opus-4.8)**, with-library 1.00 on all 20. The tighter
  set strengthens the finding and reveals the base model **fabricates**
  plausible wrong facts with confidence — invents RFC 9440 for RateLimit
  headers, RFC 9816 for SCIM events; "Cobalt 100" not 200, "MISRA C:2023" not
  2025, Keep-a-Changelog "1.1.0" not 2.0. BASELINE.md / README / ROADMAP
  updated to the robust 20-case figures.

## [1.14.0] - 2026-07-11

### Added

- **code-security rules/04 §8 — Tamper-evident logs & audit ledgers** (NIST
  AU-9/AU-10). New section codifying the audit-ledger pattern: unkeyed hash
  chains detect accidents, not adversaries (HMAC or external anchoring
  required); tail truncation / whole-stream deletion is invisible to
  chain-walk verification; hash every attested field incl. server timestamps;
  canonical preimage encoding (§7); **integrity ≠ completeness** (attest and
  report separately); verification must be possible off the storing system;
  vantage (self-reported vs independent chokepoint →
  detection-engineering rules/02); erasure-by-design for immutable stores
  (privacy rules/03 §4 crypto-shredding). +2 audit-checklist items;
  code-security SKILL.md index row and router rule 18 (crypto fan-out)
  updated. Motivated by a real audit of a public "tamper-evident AI-agent
  ledger" where this gap class recurred (unkeyed SHA-256 chain marketed as
  compliance evidence).

- **Eval golden sets + efficacy baseline + clean isolated control** (roadmap
  Next, done). Cases expanded to 20 routing + 13 audit + 7 harder audit
  (`evals/cases/`). New `evals/run-clean.py` — a **raw model-API** harness
  (OpenRouter, key from `.env`, never committed) that removes the in-session
  contamination entirely (no HOME/`CLAUDE.md`/skill-registry) for a true
  library-vs-nothing control. Findings (all in
  `evals/results/2026-07-10/BASELINE.md`, raw in `results/2026-07-11/`):
  **routing recall lift replicates ~+0.10 in the clean control** — +0.09
  (sonnet-4.6), +0.14 (sonnet-5), +0.09 (opus-4.8), with-library 1.00 each;
  even opus-4.8 misses the same rule-driven skills without the router (r01
  testing, r02 sandboxing, r07 code-security, r09 web-frameworks). So the
  in-session +0.08/+0.11 was **not** a contamination artifact — the routing
  lift is real and attributable to the cross-cutting rules. README now cites
  the freshness evidence ("Measured, not asserted") linking `evals/`. **Audit
  lift = +0.00, model-independent** (haiku→sonnet-4.6, original + harder cases):
  strong models recognize textbook vulns library-or-not. **Freshness lift =
  +0.75 (sonnet-4.6) / +0.50 (opus-4.8)** on **8** objective 2026-current-fact
  cases (`cases/freshness.jsonl`, each answer carried in a rules file;
  with-library 1.00) — the decisive finding: the base model is not just missing
  current facts but **confidently wrong** (asserts RFC 7489 not 9989, OWASP A04
  not A06, ingress-nginx "maintained", NIST "8 chars" not 15, TorchServe
  "maintained"), while the with-library arm is 1.00. So the library's value is
  currency (large lift, ~5–7× routing), not routing/recognition (small/zero).
  Also: `.env` added to `.gitignore` (was untracked but unignored).

## [1.13.0] - 2026-07-10

### Added

- **Content-accuracy runbook + eval harness** (2026-07-10 audit STRAT-HIGH-1/2,
  the two top strategic gaps). `docs/MAINTENANCE.md` documents the reproducible
  per-skill re-verification sweep (extract rot-prone claims → verify vs primary
  sources → fix under the no-pins/EOL policies → adversarial re-verify → bump
  `LAST-VERIFIED`) that previously lived only in maintainer memory, and states
  honestly which dimensions are CI-automated vs human/agent discipline. The
  freshness re-verify window is cut **12 → 6 months** (content drifts far
  faster; 6mo stays clearable). New `evals/` prototype: a runnable
  efficacy-regression harness — golden-set cases (`cases/router.jsonl`,
  `cases/audit.jsonl`) + `score.py` (recall/precision vs an agent's
  predictions, exit 1 on any miss). Deliberately not in CI (an LLM eval is
  non-deterministic); it gives a repeatable with-vs-without baseline. Harness
  verified end-to-end this session (perfect predictions → exit 0, misses →
  exit 1); AGENTS.md/CONTRIBUTING.md link the runbook.
- **Invariant 7 — router completeness** (`check-invariants.sh`): every domain
  skill must appear in the router's routing table AND library map; every map
  entry must name a real skill. Automates the drift class the 2026-07-10 audit
  found (the 41st skill was missing from the map for a full release).
  Documented in AGENTS.md/CONTRIBUTING.md.

### Changed

- **Roadmap re-cut around the 2026-07-10 audit** (`docs/ROADMAP.md`): the
  2026-07-01 cycle (fully executed) demoted to history; a fresh Now/Next/Later
  reflects the audit — Now (prove/protect accuracy) closed this cycle, Next
  (grow evals + first 6-month sweep), Later (distribution over coverage,
  STRAT-MED-1). Fixed two STALE bookkeeping items the audit flagged: the
  2026-07-08 sweep is a "34-skill" pass (not "full-library" — it covered 34 of
  40 skills), and the low-severity-triage tally no longer implies 58+32=75
  (the ~75 candidate findings split across files into more line-items).
- **Invariant-gate hardening** (2026-07-10 audit): check 2 now tracks code-fence
  state so a `## Audit checklist` inside a fence no longer satisfies the
  "ends-with" rule (the 2026-07-01 fix was incomplete; verified identical
  verdicts on all current files); check 5's semver guard is a strict
  `X.Y.Z` regex that rejects interior malformations (`1..2`, `1.2`, `1.2.3.4`);
  and CI now fails loudly if `SOTA_DENYLIST` is empty on a trusted (push-to-main
  or same-repo-PR) run instead of silently degrading check 3 to generic-only
  (S-MED-1). Each change adversarially tested to confirm it catches the
  violation.

### Fixed

- **Installer script defects** (2026-07-10 audit): `install.sh` no longer
  aborts (`set -e`, exit 1) when the user declines a routing prompt — routing
  setup is best-effort and now always returns success, so pre-commit setup and
  the final instructions still run (Q-MED-4, reproduced fixed: exit 0, reaches
  the end); `install.sh` profile-linking no longer silently clobbers a real
  file in `~/.claude/profiles` — it backs up + asks first, matching
  `setup_claude_md`'s contract, and keeps the file untouched non-interactively
  (Q-MED-5, reproduced: user content preserved); and `init-gates.sh` writes
  `.pre-commit-config.yaml` as 644 instead of the `mktemp` 600 (Q-LOW).
- **Audit 2026-07-10 content corrections** (all primary-source verified):
  OWASP Top 10 2025 mislabel — Insecure Design is **A06**, not A04
  (`sota-code-security` rules/09); JSON Merge Patch citation **RFC 7386 →
  7396** (obsoleted 2014, `sota-api-design` rules/01); ingress-nginx wording —
  the 2026 CVE wave **was** patched in the final releases (≥1.13.9/1.14.5/
  1.15.1), the standing risk is post-EOL CVEs (`sota-kubernetes` rules/01);
  Iceberg v3 "GA across major engines" overstated → GA on Snowflake/Databricks/
  Spark, Trino still lagging (`sota-data-engineering` rules/01); a
  `grep -v "--"` end-of-options bug in an audit checklist
  (`sota-javascript-typescript` rules/07); a dangling retired-convention
  "last-verified" reference (`sota-confidential-computing` rules/04); and
  ~7 rot-prone version pins reworded to the no-pins policy (Rust 1.96→"recent
  stable", golangci-lint, Swift, Flutter, PHP, Ruby, Vue/Nuxt patch→minor).
- **Router library map** (`skills/sota/SKILL.md`) — added the missing
  `sota-confidential-computing` bullet (41st skill) and refreshed the stale
  `sota-testing` (→09) and `sota-docs-workflow` (→05) bullets. Routing table
  and per-skill indexes were already correct; only the map overview drifted.

### Added

- **`docs/AUDIT-2026-07-10.md`** — second adversarial repository audit (13
  fan-out auditors across 4 lenses + refutation pass, at v1.12.1). Verdict:
  **strong health** — all 6 invariants pass, supply-chain pins genuine, ~150
  rot-prone content claims sampled and primary-source-verified with only a
  handful of small errors, no dangerous advice. Headline findings are
  strategic: no automated content-accuracy gate, no eval harness, coverage
  expansion exhausted vs near-zero adoption. Plus a tail of low-severity
  content/script defects (OWASP A04→A06 mislabel, RFC 7386→7396, ingress-nginx
  "unpatched" wording, router library-map omission of the 41st skill,
  `check-invariants` check-2 fence bypass, two `install.sh` interactive-path
  bugs, ~8 residual version-pins). 11/11 non-trivial findings survived
  adversarial verification; 0 refuted.

## [1.12.1] - 2026-07-10

### Added

- **`sota-network-security` rules/06 — email authentication & anti-spoofing**
  (R12–R14): the library had no coverage of SPF/DKIM/DMARC beyond incidental
  mentions — a real gap given domain spoofing (BEC/phishing) and deliverability.
  Adds SPF (RFC 7208, `-all`, 10-lookup limit), DKIM (RFC 6376, >=2048-bit +
  rotation), **DMARC** (RFC 9989 — the 2026 Proposed Standard obsoleting the
  original RFC 7489; reporting RFC 9990/9991) with the `p=none→quarantine→reject`
  progression and alignment as the actual anti-spoofing control, MTA-STS
  (RFC 8461) + TLS-RPT (RFC 8460) + DANE-for-SMTP (RFC 7672), parked/non-sending
  domain lockdown, ARC (RFC 8617), and the Gmail/Yahoo bulk-sender requirements
  (5,000+/day: SPF+DKIM+aligned DMARC, RFC 8058 one-click unsubscribe, spam
  <0.3%). BIMI noted accurately as an IETF draft (not an RFC), VMC optional.
  Three audit-checklist items + SKILL/router routing updates. Cross-refs
  sota-copywriting rules/04 (marketing-mail content law) and
  sota-detection-engineering (DMARC RUA as a spoofing feed). Every claim
  primary-sourced (RFC editor/IETF datatracker + the Gmail/Yahoo sender rules).
- **`sota-network-security` rules/05 — self-hosted / bare-metal DDoS
  hardening** (R8.1): the one gap in the library's DDoS coverage. Existing
  guidance assumed a scrubbing edge (Cloudflare/Shield/Cloud Armor); this
  adds the L3/4 kernel layer for edges with no provider in front — TCP SYN
  cookies + nftables synproxy (prereqs per the nftables wiki), conntrack-table
  exhaustion sizing/alerting, reverse-path filtering (RFC 3704), and
  not-being-an-amplifier hygiene (BCP 38 / RFC 2827 — no open DNS/NTP/
  memcached/SSDP/chargen reflectors). R8 reframed to name edge scrubbing
  generically (Anycast/provider tiers), with cross-refs to
  sota-cloud-infrastructure rules/03 §10. Two audit-checklist items + SKILL
  index/scope/trigger updates. All claims primary-sourced (nftables wiki,
  kernel.org ip-sysctl, RFC 2827/3704).

## [1.12.0] - 2026-07-09

### Added

- **`sota-confidential-computing`** — confidential computing and cryptographic
  PETs (41 skills total): protecting workloads and data in use from the
  infrastructure they run on — the explicit inverse of `sota-sandboxing`
  (router cross-cutting rule 19 encodes the boundary). SKILL.md + 5 rules:
  01 threat model & selection (CCC definition test — memory encryption alone
  is not CC; five-rung escalation ladder; adversary→mechanism table),
  02 TEE technologies (SEV→SEV-ES→SEV-SNP insufficiency ladder, TDX on
  TME/TME-MK, ARM CCA status incl. Azure Cobalt 200, SGX/LibOS reality,
  Nitro Enclaves' distinct trust model, NVIDIA confidential GPUs,
  side-channel posture), 03 remote attestation (RATS RFC 9334 roles,
  attest-then-release, evidence hard rules, hosted vs self-hosted verifiers,
  TCB recovery, RA-TLS/IETF SEAT), 04 confidential Kubernetes (nodes vs pods,
  CoCo/Kata/Trustee KBS, AKS preview retirement caveat, operational reality),
  05 PETs/COED (FHE families + ISO/IEC 28033 + NIST PEC, MPC/threshold, ZKP
  circuit risk, PSI/OPRF, TEE-vs-PET-vs-DP selection). Built by 5 parallel
  research agents + 2 adversarial verifiers; 54 claims re-verified, 8
  corrected against primary sources (CCC, AMD/Intel/Arm docs, RFC editor,
  Azure/GCP docs, CNCF, NIST, ISO). Per repo policy no current-version pins —
  "latest stable, verify at time of use" throughout.
- **README "how it works" diagram** (`assets/how-it-works.png` + HTML source):
  a four-stage invocation flow (plain prompt → auto-routing → selective
  rules-file loading → BUILD/AUDIT application) with a worked file-upload
  example showing 4 skills loading automatically. Deliberately count-stable
  ("40+") so it never needs re-rendering on skill additions. Also clarified
  two README lines: the language-standards bullet no longer reads as
  "only 4 languages supported", and the invoicing example prompts no longer
  imply the user must name a stack (profile/skill defaults fill it in).
- **Count-surface floor model for the social preview**: the image pill and
  README alt now read **"40+"** so the PNG needs no re-render/re-upload per
  skill addition; `check-invariants.sh` gained `ck_floor` (fails only if the
  tree count drops below the floor); PNG re-rendered once; RELEASING.md
  updated.

### Fixed

- **Low-severity sweep triage (2026-07-09)** — the never-verified
  low-severity suggestions from the 2026-07-08 sweep (~75 candidate findings)
  were re-verified hypothesis-by-hypothesis against primary sources by one
  agent per skill: **58 applied** (each cites the verifying source; e.g.
  GraphQL @oneOf per the September 2025 spec edition, Mercurius WS depth-bypass
  CVE-2026-30241 checklist item, NATS 2.12–2.15 feature gates + the 2.15
  ack-subject ACL migration warning, PEP 734 subinterpreters + Python 3.14
  asyncio introspection, Go 1.25 testing/synctest, C++26 DIS status),
  **32 skipped** with recorded reasons (refuted, already covered by the
  verified-fix pass, or not worth the lines). The applied+skipped tallies
  exceed 75 because some findings split across multiple files. No version pins
  added; all invariants green.
- **Freshness sweep 2026-07-08** — 34-skill research pass (one web-research
  agent per skill; every high/medium finding independently
  adversarially verified against primary sources) fixed **7 high + 58 medium**
  confirmed gaps across 31 skills. Highlights: SurrealDB 3.1.5 security batch
  (databases/08); Argo CD repo-server unpatched gRPC RCE → require
  NetworkPolicy isolation (devsecops/06); ASP.NET Core Data Protection
  CVE-2026-40372 (dotnet/04); TorchServe archived → maintained serving
  runtimes (ml-engineering/05); Cilium mTLS guidance moved to the ztunnel
  integration (network-security/04); ingress-nginx EOL 2026-03-24 + migration
  guidance (network-security/05, kubernetes/01); jqwik 1.10.0 protestware
  advisory (testing/06); NIST SP 800-63B-4 15-char password floor
  (code-security/02); OCSP-stapling guidance retired after Let's Encrypt
  ended OCSP (code-security/04, network-security/06); ATT&CK v18/v19
  restructuring + BadSuccessor/dMSA detection (detection-engineering);
  JDK 24 ZGC/virtual-thread-pinning updates (jvm); K8s user-namespaces GA,
  Landlock ABI correction, 2025 runc CVE triple (sandboxing); TypeScript 7 GA,
  npm v12 script-blocking defaults, June-2026 supply-chain campaigns
  (javascript-typescript); Kyverno CVE-2026-4789 + CEL policy-type
  stabilization (devsecops/07, kubernetes/03); and more — see the PR for the
  full list.
- Genericity: removed three internal-abbreviation/reader-assumption phrasings
  that had slipped past the denylist; patterns added to the private denylist.

### Changed

- Contributor docs synced to this cycle's policy changes: AGENTS.md and
  CONTRIBUTING.md now state the **no-version-pins rule** (latest stable +
  semantic boundaries only, EOL→successor) as a standing convention and
  describe invariant 6's exact-count vs "N+"-floor split; RELEASING.md's
  pre-tag checklist matches the floor model; docs/ROADMAP.md logs
  `sota-confidential-computing` under coverage additions.
- **Version-claim policy applied library-wide**: rot-prone "current release is
  X.Y" claims replaced with "use the latest stable release — verify via a
  quick web search"; version numbers that mark semantic boundaries
  ("introduced/fixed/removed in vX", CVE fix versions, GA milestones) are
  kept. EOL/unmaintained tools are replaced by their maintained successors
  (project-recommended target first, then CNCF-maintained alternatives), with
  a one-line EOL note kept for auditors.
- **Freshness tracking model**: per-file line-1 `<!-- last-verified: YYYY-MM -->`
  markers retired (they duplicated git metadata and stayed 84% unstamped);
  replaced by a single root `LAST-VERIFIED` stamp recording the date of the
  last full-library verification sweep (initialized to 2026-07-08).
  `scripts/check-freshness.sh` rewritten for the new model (red when the
  stamp exceeds the 12-month window; warns on stray per-file markers);
  `freshness.yml`, AGENTS.md, CONTRIBUTING.md, and the README maintenance
  prompt updated accordingly.
- Router (`skills/sota/SKILL.md`): added cross-cutting routing rule 18,
  **"Cryptography fans out"** — a single lookup that maps a crypto task to its
  distributed owners (algorithm/AEAD/key-handling/TLS-client/PQC →
  `sota-code-security` rules/04; key material/storage/rotation →
  `sota-secrets-management`; TLS server/PKI/cert lifecycle →
  `sota-network-security` rules/06; FIPS-validated-module →
  `sota-security-compliance` rules/02). Documents the deliberate no-single-crypto-skill
  design; no content moved.

## [1.11.0] - 2026-07-06

### Added

- **`sota-web-frameworks`** — React 19 + Next.js and Vue 3 + Nuxt 4 engineering,
  plus the cross-cutting concerns of server rendering (40 skills total). SKILL.md
  + 7 rules files: 01 baseline (support/EOL matrix, render-mode selection, React
  Compiler), 02 React 19 (hooks, Suspense, the Actions model, `dangerouslySetInnerHTML`),
  03 Next.js (App Router, Server Actions as public endpoints, the caching model —
  `use cache`/Cache Components/PPR/ISR — `proxy.ts`, the Data Access Layer), 04 Vue 3
  (Composition API, reactivity pitfalls, `defineModel`, `v-html`), 05 Nuxt 4
  (`useFetch`/`useAsyncData`, `useState`, `runtimeConfig`, Nitro server routes,
  `routeRules`), 06 SSR & hydration (mismatches, state-serialization XSS,
  cross-request state pollution, cache safety, CSP with streaming SSR), and 07
  framework security (server/client secret boundary, authorization placement,
  SSRF surfaces, consolidated CVE reference). Every version and CVE claim
  web-verified against primary sources (react.dev, nextjs.org, vuejs.org, nuxt.com,
  GitHub Security Advisories) and stamped `last-verified: 2026-07`. Notable
  security coverage: the 2025-12 React Server Components RCE (CVE-2025-55182
  "React2Shell" / CVE-2025-66478), the middleware auth bypass (CVE-2025-29927),
  Next cache-poisoning and SSRF CVEs, and the Nuxt/Nitro/h3/IPX/devalue advisory
  waves. Router routing table + library map + cross-cutting rule 6 updated;
  count surfaces updated to 40 skills / 289 files / ~57k lines (README
  badge/hero/alt/table, plugin.json, marketplace.json, social-preview pill + PNG).

---

Releases **1.10.0 and earlier** are archived: 1.10.0–1.5.0 in
[docs/CHANGELOG-archive.md](docs/CHANGELOG-archive.md), 1.4.0 and earlier in
[docs/CHANGELOG-archive-2.md](docs/CHANGELOG-archive-2.md).

[1.43.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.43.1
[1.43.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.43.0
[1.42.2]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.42.2
[1.42.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.42.1
[1.42.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.42.0
[1.41.2]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.41.2
[1.41.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.41.1
[1.41.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.41.0
[1.40.7]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.40.7
[1.40.6]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.40.6
[1.40.5]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.40.5
[1.40.4]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.40.4
[1.40.3]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.40.3
[1.40.2]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.40.2
[1.40.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.40.1
[1.40.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.40.0
[1.39.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.39.0
[1.38.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.38.0
[1.37.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.37.0
[1.36.3]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.36.3
[1.36.2]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.36.2
[1.36.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.36.1
[1.36.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.36.0
[1.35.2]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.35.2
[1.35.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.35.1
[1.35.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.35.0
[1.34.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.34.0
[1.33.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.33.1
[1.33.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.33.0
[1.32.3]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.32.3
[1.32.2]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.32.2
[1.32.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.32.1
[1.32.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.32.0
[1.31.2]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.31.2
[1.31.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.31.1
[1.31.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.31.0
[1.30.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.30.1
[1.30.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.30.0
[1.29.5]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.29.5
[1.29.4]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.29.4
[1.29.3]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.29.3
[1.29.2]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.29.2
[1.29.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.29.1
[1.29.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.29.0
[1.28.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.28.1
[1.28.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.28.0
[1.27.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.27.0
[1.26.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.26.0
[1.25.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.25.0
[1.24.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.24.1
[1.24.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.24.0
[1.23.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.23.1
[1.23.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.23.0
[1.22.14]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.14
[1.22.13]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.13
[1.22.12]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.12
[1.22.11]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.11
[1.22.10]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.10
[1.22.9]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.9
[1.22.8]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.8
[1.22.7]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.7
[1.22.6]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.6
[1.22.5]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.5
[1.22.4]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.4
[1.22.3]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.3
[1.22.2]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.2
[1.22.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.1
[1.22.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.22.0
[1.21.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.21.1
[1.21.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.21.0
[1.20.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.20.1
[1.20.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.20.0
[1.19.9]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.19.9
[1.19.8]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.19.8
[1.19.7]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.19.7
[1.19.6]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.19.6
[1.19.5]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.19.5
[1.19.4]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.19.4
[1.19.3]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.19.3
[1.19.2]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.19.2
[1.19.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.19.1
[1.19.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.19.0
[1.18.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.18.0
[1.17.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.17.0
[1.16.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.16.0
[1.15.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.15.0
[1.14.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.14.1
[1.14.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.14.0
[1.13.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.13.0
[1.12.1]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.12.1
[1.12.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.12.0
[1.11.0]: https://github.com/martinholovsky/SOTA-skills/releases/tag/v1.11.0
