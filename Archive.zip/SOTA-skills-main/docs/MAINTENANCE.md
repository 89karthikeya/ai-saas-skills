# Maintenance — keeping the library accurate

The library's value is that its fast-moving claims (versions, CVEs, RFCs,
specs, GA states, tool status, standards) hold up against primary sources.
CI enforces *structure* (the 34 invariants in `scripts/check-invariants.sh` +
gitleaks + shellcheck) but **cannot** verify that a claim is *true* — that
needs web access and judgment. This file is the human/agent process that
covers the accuracy dimension CI can't, plus how efficacy is measured.

The 2026-07-10 audit ([AUDIT-2026-07-10.md](AUDIT-2026-07-10.md)) flagged the
absence of this runbook and eval scaffold as the top strategic gaps.

## 1. The freshness stamp

`LAST-VERIFIED` (repo root) holds the date of the last full-library
re-verification sweep. `scripts/check-freshness.sh` fails once that stamp is
older than the re-verify window (**6 months**; was 12 — content drifts far
faster). `.github/workflows/freshness.yml` runs it monthly (report-only, does
not block PRs). A red freshness report means: **due for a sweep** — run the
procedure below, then bump `LAST-VERIFIED`.

The window is 6 months, not shorter, on purpose: a too-short window is
perpetually red and trains everyone to ignore it (the same failure the
retired per-file-marker backlog had). 6 months catches real drift while
staying clearable.

## 2. The re-verification sweep (runbook)

Goal: re-verify every skill's rot-prone claims against primary sources and
fix what has drifted. Do it as a **rolling** pass (a few skills a month) or a
**batched** sweep before the window expires — either way, update
`LAST-VERIFIED` only after a full pass.

**Per skill:**

1. **Extract the rot-prone claims** — anything with a shelf life: version
   numbers and "latest/current" statements, CVE/advisory IDs and fix
   versions, RFC/ISO/NIST/OWASP/CIS/WCAG numbers and editions, "GA since /
   removed in / deprecated" statements, tool recommendations and their
   maintenance status.
2. **Verify each against a PRIMARY source** you fetch now — vendor release
   notes, the RFC editor, NIST/OWASP pages, GitHub Security Advisories, the
   project's own repo/docs. Not memory, not a blog restating it.
3. **Fix drift under the repo policies** (see
   [CONTRIBUTING.md](../CONTRIBUTING.md)): no rot-prone version pins ("latest
   stable, verify at source"; keep only semantic boundaries like "fixed in
   vX" / "GA since"); replace EOL/unmaintained tools with their maintained
   successor (project-recommended first, then a maintained CNCF/OSS fork),
   keeping a one-line EOL note for auditors.
4. **Adversarially re-verify** — a second pass (ideally a different agent)
   that re-fetches the source and re-reads the edit, defaulting to "wrong"
   until the evidence reproduces. This is where hallucinated citations get
   caught (e.g. the 2026-07 sweeps caught "BIMI = RFC 8910" and a stale
   DMARC RFC this way).

**Named high-rot targets** (check these even in a rolling pass):

- **`sota-devsecops` rules/16 §2 — the dependency-reachability tool table.**
  Eight third-party projects, each row asserting that tool's *documented* blind
  spot; all verified live 2026-07-30. Highest-rot item in the library by
  construction, and it demonstrated its own failure mode on the day it landed: two
  of the eight had been **renamed** under the URLs a manifest still carries
  (`fpgmaas/deptry` → `osprey-oss/deptry`, `icanhazstring/composer-unused` →
  `composer-unused/composer-unused`). Re-verify each with
  `gh api repos/<o>/<r> --jq '{full_name, archived, pushed_at}'` and **read
  `full_name` back** — `gh api` follows renames silently, so a 200 under the old
  name is not evidence the project is where the row says it is. The Ruby row
  asserts a *negative* ("no established tool"); re-check that a maintained option
  has not appeared rather than assuming it still holds.
- **Tool names generally** — the §3 tool matrix in `sota/rules/01`: renames, forks
  and license splits (Semgrep → Opengrep) are the common drift, not version bumps.

**At scale**, this is a natural multi-agent job: one research+fix agent per
skill in parallel, then an independent adversarial verify pass, then land the
fixes via PR. The 2026-07-08 sweep (65 fixes) and 2026-07-10 audit followed
exactly this shape, reproducible from the CHANGELOG entries.

**After a full pass:** set `LAST-VERIFIED` to today (`date +%F`), note the
sweep in the CHANGELOG, and open a PR. **Invariant 11 enforces that pairing** —
the stamp may only move in a diff that is sweep-shaped (≥ 20 skill files) or that
carries a CHANGELOG line naming **both** `LAST-VERIFIED` and the stamp's new date
(e.g. *"rolling accuracy pass complete; LAST-VERIFIED moved to 2026-09-14"*). A bare
mention of the token is not a declaration. A rolling pass takes the second escape. Do **not** add per-file markers — that
convention is retired.

## 3. Measuring efficacy (the eval harness)

Freshness keeps claims *true*; the eval harness (`evals/`) keeps the library
*effective* — does loading a skill actually change agent output for the
better? It is a manually-run prototype (an LLM eval can't run deterministically
in CI): golden-set cases with expected outcomes + a scoring script. See
[`evals/README.md`](../evals/README.md) for how to run it and read the score.
Run it before and after a large content change as a regression check, and
grow the golden sets as coverage warrants.

## 4. What is and isn't automated

| Dimension | Gate | Automated? |
|---|---|---|
| Structure (skill-file line cap, checklist-last and checklist-unique, description cap, counts, router completeness, link resolution, rules-file indexing, `LAST-VERIFIED` pairing, rendered-asset currency, scoreboard sample sizes, release front-door terms, router library-map completeness, documented-vs-installed hook, docs-describing-the-checks (README included, word-form counts too), `§`-reference resolution, every check has a known-bad, no checklist bullet stranded in a code fence, every CHANGELOG heading carrying its link ref, AGENTS.md under its own 200-line cap, eval runners named in `evals/README.md`, undocumented eval flags not growing, the roadmap's open set agreeing with itself, ADOPTION-LOG deferrals naming a revisit trigger, eval case sets declaring a SELECTION RULE, a release changing a skill description declaring a routing check) | `check-invariants.sh` (**34 checks**) | Yes — pre-commit + CI |
| Secrets | gitleaks (full history) | Yes — CI |
| Shell quality | shellcheck | Yes — CI |
| Claim **accuracy** | this runbook + `LAST-VERIFIED` | No — human/agent, monthly red-flag |
| **Efficacy** | `evals/` | No — manual prototype |

The bottom two are deliberately not in CI: verifying a claim against a live
primary source, or scoring an LLM's output, is non-deterministic and needs
network + judgment. Keeping them honest is a maintainer discipline, and this
file is the checklist for it.
