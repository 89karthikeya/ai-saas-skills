# Keeping the model applying the rules (context management)

**The short answer to "how do we re-inject rules so the model doesn't forget them?"**
A `UserPromptSubmit` hook in `~/.claude/settings.json` re-states the routing
directive on **every** prompt, so a rule loaded 30 turns ago is restated fresh
each turn. It's the third layer of
[README → Always-on routing](../README.md#always-on-routing-recommended), and
`scripts/install.sh --routing` sets it up. (It fires every prompt, not only when
the window is "full.") But that hook is one of **six** defenses; this page is the
whole picture in one place.

## The problem

LLMs don't apply every loaded rule equally. Two effects work against you:

- **Within a single generation** — output quality degrades as input grows *even
  below the context limit*, and semantically-similar distractors (dozens of
  look-alike rules) hurt most. Low-salience, cross-cutting items (rate limiting,
  transport, tests) fade first. Measured and root-caused in
  [WHY-COMPLETENESS-RESIDUAL.md](WHY-COMPLETENESS-RESIDUAL.md) — notably, *adding*
  more rules made it **worse**; a short salient reminder fixed it.
- **Across a long session** — the literature finds instruction adherence drops
  with turn count as a directive recedes into history (Laban et al., "LLMs Get
  Lost in Multi-Turn Conversation"). We now measure this ourselves (below).

## The six defenses (what the library actually does)

Fight the attention shape; don't out-muscle it with volume.

1. **Load lean** — open only the rules files that match the task. **Corrected
   2026-09-10:** this used to say extra look-alike guidance *measurably lowers*
   compliance, which contradicted the router's own step 2 (*"measures no worse;
   the degradation this step once claimed is not supported"*) and was the older,
   unsupported claim. What **is** measured: 400 lines of unrelated rules prose
   cost **+0.01** (nothing) with step 4 active, and **−0.05** with it removed.
   Lean is worth doing because it costs less, not because extra context degrades
   you — *unless you also drop the self-audit*. (Router BUILD step 2;
   [GATE-ABSORPTION-N3](../evals/results/2026-09-09/GATE-ABSORPTION-N3.md).)
2. **Plan with the checks named up front** — list the non-negotiables before
   coding, so they're a tracked artifact at the strong start of context. (BUILD step 3.)
3. **Self-audit LAST** — a terminal re-read of each rules file's Audit checklist
   exploits recency and re-surfaces faded mid-context items; for a big change, run
   it as a separate pass over the diff (fresh context, no rot). (BUILD step 4;
   [`skills/sota/SKILL.md`](../skills/sota/SKILL.md).)
4. **A short, salient universal reminder** — the router's *operating principle 5*
   (rate-limit + transport + tests + logging on any endpoint), kept deliberately
   short because a long reminder rots too. ([`skills/sota/SKILL.md`](../skills/sota/SKILL.md).)
5. **Per-prompt re-injection** — the `UserPromptSubmit` hook that re-states the
   routing directive every prompt (the answer up top;
   [README](../README.md#always-on-routing-recommended)). This is the defense that
   directly targets *multi-turn* decay. **Write each rule as a numbered imperative
   of equal weight** — a directive demoted to a subordinate clause is re-injected
   every turn and ignored every turn (measured in the field; see
   [the precondition section](#the-precondition-all-six-defenses-assume-measured-in-the-field-2026-08-05)).
6. **Deterministic gates for the critical few** — a lint/CI check that fails when
   an endpoint has no rate limiting or TLS moves the invariant out of "attention"
   entirely. ([README → Enforcing the gates](../README.md#enforcing-the-gates).)

## Size limits: what to actually do (settled 2026-08-02)

Every size number that governs this library, verified against three official sources
(`agentskills.io/specification`, the `platform.claude.com` Agent Skills reference and
its best-practices page, and the Claude Code memory/skills docs), with the standing
decision for each. **Nothing here is a guess; where a number is a heuristic it says so.**

| Limit | Kind | Us | Do |
|---|---|---|---|
| `name` ≤ 64 chars | **hard** | fine | nothing — gated (inv. 4) |
| `description` ≤ 1024 chars | **hard** | router at **1024/1024** | **watch it** — no slack; any new domain in the description means trimming another |
| no XML tags in `name`/`description` | **hard** | fixed 2026-08-02 | nothing — gated (inv. 4) |
| no reserved words (`anthropic`, `claude`) in `name` | **hard** | fine | nothing — gated (inv. 4) |
| `description` + `when_to_use` ≤ 1,536 in the listing | **hard** truncation | 1024, no `when_to_use` | nothing — 512 spare |
| `SKILL.md` < 500 lines | recommendation | router at **410/500** (re-counted 2026-09-10; this cell read 399 until then) | nothing — gated (inv. 1); **90 lines of slack** since BUILD/AUDIT detail *and* the library map moved to `rules/` |
| `SKILL.md` body < 5,000 tokens | recommendation | **STALE — do not quote.** Last real measurement **13,415** (**2.7×**) with `count_tokens` on 2026-09-02, when the router was 399 lines; it is **410** now, so the true figure is higher and unknown | **accept, don't restructure** — but see the correction below. Re-measure with `count_tokens` before citing: no estimate is admissible here (chars/4 under-reads Claude by ~54%) |
| `rules/*.md` length | **no budget** — stage-3 resources | 162 over 200 lines | nothing — **long is correct by design**; the spec says move detail *into* these |
| TOC for reference files > 100 lines | recommendation | 242 without one | **skip** — tested, no retrieval benefit at 4× our longest file |
| first 5,000 tokens kept on compaction re-attach | **hard** truncation | router loses ~half | **accept** — a later invocation reloads it in full |

**Why the router stays as it is.** It is the one file exceeding a documented
recommendation, and the temptation is to restructure it into the spec's "high-level
guide with references" pattern. Three reasons not to, in order of weight:

1. **It would invalidate the flagship number.** `ROUTER_BUILD_SHA` pins the BUILD
   section that `run-completeness.py` mirrors; moving those steps into a referenced
   file breaks comparability with every historical **+0.39** run.
2. **The compaction truncation is self-healing.** It applies to the copy *carried
   forward* past a summary. A subsequent invocation reads `SKILL.md` again in full —
   and defense 5, the per-prompt routing directive, is what prompts that re-invocation.
   (Inferred from the documented behaviour; not separately observed.)
3. **The overrun costs context, not correctness.** Nothing truncates at load; all
   three sources agree there is no hard size cap.

Revisit only when the router must **grow**. *(Superseded 2026-08-26: growth no longer
forces a trim — the router is at 399/500 and detail now goes to `skills/sota/rules/`.)*

## Do long rules files need a table of contents? Tested — no (pilot, 2026-08-02)

Anthropic's skill-authoring guidance says: *"For reference files longer than 100
lines, include a table of contents at the top. This ensures Claude can see the full
scope of available information **even when previewing with partial reads**."* **242 of
this repo's rules files exceed 100 lines and none carries a TOC**, so the question is
whether that costs anything.

It was tested rather than assumed, because the claim rests on a *mechanism* — partial
reads — that may simply not occur here. Four arms, one agent each, an unguessable
canary constant (`PROBE_QUARANTINE_RUNS = 17`) planted so a correct answer proves
retrieval rather than prior knowledge. The prompt never mentions position, length or
tables of contents, and **the arm is not encoded in any path** (opaque workspace IDs),
because two agents in an earlier study read their arm out of a directory name.

| Arm | File | Canary depth | TOC | Canary found | Tool calls |
|---|---|---|---|---|---|
| A control | 434 lines | 99% | no | **yes** | 1 |
| B treatment | 446 lines | 99% | **yes** | **yes** | 1 |
| C positive control | 434 lines | **1%** | no | **yes** | 1 |
| D stress | **1,719 lines / 92 KB** | 99% | no | **yes** | 2 |

**The positive control is what makes this readable.** Arm C moved the canary to the
top; it scored identically to A, so there was no depth effect for a TOC to correct.
The agents read the files whole — two said so unprompted ("read the file in full
(434/446 lines)"), and arm D's agent reported the canary's exact line range in a
1,719-line file. Arm B's only measurable effect was **+183 tokens** of context for the
TOC itself.

**Conclusion: the 242-file TOC sweep is not justified**, and would be pure added
context cost at these lengths.

**Limits, stated because they bound the claim.** *n* = 1 per arm — a pilot, not a
result, and not on the scoreboard. It exercises one path: the `Read` tool in a Claude
Code sub-agent on a **directly named** file. The guidance's own stated trigger is
different — *"Claude may partially read files when they're referenced **from other
referenced files**"* — i.e. nested references. That condition is untested here, and it
does not arise in this library anyway, because `SKILL.md → rules/NN.md` is already the
**one level deep** structure the same guidance prescribes. Finally, the canary sat
after the `## Audit checklist` heading, which two agents flagged as anomalous; that
salience may have aided detection.

## The 500-line cap is a proxy, and a loose one (measured 2026-08-02)

The Agent Skills specification states the budget in **tokens**, not lines:

> **Progressive disclosure** — 1. Metadata (~100 tokens): `name` and `description`
> loaded at startup for all skills. 2. **Instructions (< 5000 tokens recommended)**:
> the full `SKILL.md` body is loaded when the skill is activated. 3. Resources (as
> needed).
>
> Keep your main `SKILL.md` under 500 lines.

Invariant 1 enforces the *line* half because lines are trivially checkable. But
lines predict tokens only as well as line length allows, and across this repo's
**297** skill files line density varies **3.3×** — 38 to 127 bytes per line, median
57. So, by a `bytes/4` estimate:

| A 500-line file at… | ≈ tokens | vs. the 5,000 recommendation |
|---|---|---|
| the sparsest observed density | ~4,750 | within budget |
| the **median** density | ~7,118 | **42% over** |
| the densest observed density | ~15,870 | **3× over** |

**132 of 301 files exceed 5,000 tokens** — every one of them passing invariant 1, most
comfortably. `sota-mobile/rules/07-swift-language.md` is 254 lines, half the cap, and
**10,116 tokens**. A line cap cannot see that: density ranges from ~24 to **46 tokens per
line** across the tree, so two files at the same length differ ~2× in what they cost.

> **Corrected 2026-08-27 — this paragraph was itself a casualty of the heuristic.** It
> read *"12 of 297 files … and ~6,737 tokens"*, all chars/4-derived. Measured with
> `count_tokens` across all 301 files: **132**, not 12 — an **11× under-count** — and that
> Swift file is 10,116 tokens, not ~6,737. The file count was stale too (297 → 301). If a
> claim about size was not produced by a tokenizer, assume it is wrong by half.

Two things keep this from being urgent. The 5,000-token figure applies to the
`SKILL.md` **body** (stage 2); for `rules/*.md`, which are stage-3 resources, the
spec gives no number, only *"keep individual reference files focused — agents load
these on demand, so smaller files mean less use of context."* And **5 of the 41**
`SKILL.md` bodies breach the recommendation where it actually applies — led by
`skills/sota/SKILL.md`, the router, at **16,831 tokens, 3.4× the budget**, at 498/500
lines (measured 2026-08-27; it was 16,442 at 484 lines the day before, so this number
moves with every router edit — re-measure, never carry it forward).

> **Not re-measured since, and the tree has moved.** As of 2026-08-29 the library holds
> **302** skill files rather than 301 (`sota/rules/03` was split out of `rules/01` in
> v1.30.0), the router is **499** lines, and v1.30.1 added sections to three `rules/*.md`.
> Every token figure above therefore dates to **2026-08-27** and is a **floor**, not a
> current reading. They were left un-updated rather than scaled on purpose: this file's own
> rule is *do not estimate skill sizes; count them*, and no tokenizer was reachable in the
> session that moved the tree. Re-measure with `count_tokens` at the next sweep.

> **Re-measured 2026-09-02, and the router's own figure is superseded.** The 108-line
> library map moved out of the router into `sota/rules/04-library-map.md`, so the router
> is **399 lines / 13,415 tokens** — down from **500 lines / 16,997 tokens** (both counted
> this session with `POST /v1/messages/count_tokens`, `claude-sonnet-5`, the same model as
> the 2026-08-26/27 figures). That is **−3,582 tokens, −21.1%**, on *every* session that
> loads the router. Two honest caveats. The map did not vanish: `rules/04` is **4,445
> tokens**, so a session that *does* consult it pays **+863** versus before (the file
> carries a header and an audit checklist the bare map did not) — the win is that most
> sessions never open it, because `rules/02` step 2 sends them to the skill's own index
> instead. And **compare this to the previous offload before concluding it generalises**:
> the 2026-08-26 BUILD/AUDIT move saved 16,934 → 16,442, about **3%**, and was honestly
> reported as buying *headroom, not context economy*. This one is seven times that,
> because a lookup table is denser than prose and is the part nobody reads inline. The
> router still breaches the 5,000-token recommendation at **2.7×** — offloading narrowed
> the gap, it did not close it. Only the router was re-counted; the other four breaching
> `SKILL.md` bodies still date to 2026-08-27.

> **Correction, 2026-08-26.** This paragraph read *"~10,211 tokens — 2×"* until it was
> measured. That figure came from a chars/4 heuristic and **under-reported the router's
> context cost by ~60%**; `POST /v1/messages/count_tokens` returns **16,934** for the
> 500-line router and **16,442** for the 484-line one. OpenAI's `o200k_base` gives 10,995
> for the same file — the heuristic was calibrated on the wrong tokenizer, and Anthropic's
> is ~1.5–1.8× less efficient on this text. **Do not estimate skill sizes; count them.**

There is no hard cap anywhere here. The spec's only hard limits are on frontmatter
(`name` ≤ 64, `description` ≤ 1024 — invariant 4 — `compatibility` ≤ 500), and of the
body it says outright: *"There are no format restrictions."* Nothing truncates a
skill at load. What a token overrun costs is context, and — see below — survival
across compaction.

**Not gated, deliberately.** A byte-or-token check passes all three
[CONVENTIONS-LEDGER](CONVENTIONS-LEDGER.md) filters, but it would fail on `main`
today, and the only fix is trimming a router that has no line slack left. That is a
design decision, not a mechanical one; it is logged in [ROADMAP.md](ROADMAP.md).

## The precondition all six defenses assume (measured in the field, 2026-08-05)

Every defense above fights for the model's *attention* over content that is
already in context. **None of them applies if the skill never loads at all**, and
that is not a hypothetical: a real ~25-turn session doing upstream-contribution
work invoked **zero** `sota-*` skills. The router body already contained the rules
that would have caught the worst error in that session. It was never read, so its
quality was irrelevant.

The mechanism is worth stating exactly, because it decides where effort pays off.
Per the [Agent Skills docs](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview),
only Level 1 loads at startup — *"until a Skill is triggered, only its name and
description occupy context"* — and the `description` is *"what Claude matches your
request against when determining whether to trigger the Skill."* So:

```
auto-loaded  →  frontmatter description only   (~100 tokens, always present)
inert        →  SKILL.md body + rules/*.md     (loads only when triggered)
```

The description is therefore not a hint. It is the **entire trigger classifier**,
and the other ~40 KB is dead weight until it fires. Three things went wrong:

- **The trigger verbs assumed you own the code.** "build, design, implement,
  refactor, harden, optimize, review, or audit an application, service, or
  codebase" does not describe reading a maintainer's review, judging someone
  else's patch, or preparing an upstream contribution. Fixed by adding
  non-owned-code triggers (v1.22.0).
- **Matching is per-prompt; the session drifted.** The individual prompts were
  "we have got response \<url\>", "what's the link on lychee?", "post it". The
  engineering nature emerged across ~20 turns and no single prompt named a code
  task. There is no "this conversation became a code task" mechanism, so the
  description now names the mid-session case explicitly and the hook makes it
  recoverable.
- **Structure beat repetition in the hook, and this is the transferable finding.**
  The re-injected hook carried three rules. Two were numbered imperatives; routing
  was a subordinate clause after a semicolon in a run-on sentence. Rules (1) and
  (2) were followed **every turn**; the routing clause was dropped **every turn**.
  Same text, same per-prompt repetition, opposite outcome. Defense 5 works — but
  it works on *grammatical form*, not on presence. A directive demoted to a tail
  clause is re-injected and still ignored.

So treat activation as **defense 0**: the cheapest thing in this document is
making sure the description matches the situation, because everything else is
conditional on it.

**Superseded 2026-09-12 — activation is now measurable, and this paragraph used to
say it was not.** The claim above was that the repo's one adjacent instrument, the
`desc-routing` eval, reads +0.00 (saturated) and cannot distinguish two
descriptions, so changes here are reasoned rather than measured. The first half is
still true of *that* set; the conclusion is not. Two instruments do distinguish
descriptions:

- **`cases/desc-routing-regressions.jsonl`** — selected by outcome on purpose, which
  is why it discriminates where the 10-case set saturates. The `sota-devsecops`
  edit moved it **0.667 → 1.000**.
- **`run-routing-shift.py`** — its fresh arm moved **0.750 → 1.000** on the same edit.

And the effect is not small or slow: a **single token** moved an unrelated case 3/3
to the wrong skill. An intermediate phrasing of that same edit carried a second
occurrence of the word *"gate"*, which pulled an attestation-script question away
from `sota-code-security` in **both** arms; deleting two words restored it. So a
description edit is a change to the whole classifier and is measured like one —
invariant 29 requires a declared routing check on any release that changes one.
See [ROUTING-FIX-DEVSECOPS](../evals/results/2026-09-12/ROUTING-FIX-DEVSECOPS.md).

## A platform behaviour the six defenses do not cover (recorded 2026-08-02)

Auto-compaction **truncates a re-attached skill**. Per the Claude Code skills
documentation: after the conversation is summarized, Claude Code *"re-attaches the
most recent invocation of each skill after the summary, **keeping the first 5,000
tokens of each**"*, and re-attached skills *"share a combined budget of 25,000
tokens"*, filled from the most recently invoked — so older skills can be dropped
entirely after a long session.

**That 5,000 is the same 5,000 as above, and the match is not a coincidence**: a
`SKILL.md` written to the spec's recommended instruction budget survives a
compaction intact, and one written past it is silently cut in half. The budget is
sized to the format.

This interacts with the library in a way none of the six defenses addresses, because
they all fight *attention* and this is *deletion*. A rough `bytes/4` estimate of what
exceeds the per-skill 5,000-token cut:

| File | ~tokens |
|---|---|
| `skills/sota/SKILL.md` (the router) | ~10,200 |
| `sota-docs-workflow/rules/01-documentation-architecture.md` | ~7,200 |

`sota-devsecops/rules/03-dependencies.md` left this table on 2026-09-07: splitting its
§3.9 out to `rules/10` took it to ~4,850 by the same `bytes/4` method, and the new file to
~3,450 — both under the cut. Splitting for the line cap moved this number too, which is the
only reason the row is worth mentioning rather than silently deleting.

**The list is illustrative, not exhaustive, and only the `SKILL.md` row is a finding.** The
5,000-token figure is a **stage-2** budget — it applies to a `SKILL.md` *body*, which is what
compaction re-attaches. `rules/*.md` are stage-3 resources the spec gives no budget at all, so
several of them sit above 5,000 by design and are not listed: measured 2026-09-08,
`sota/rules/03` ~7,400, `sota-code-security/rules/14` ~7,100 and `rules/11` ~7,000, all
`bytes/4`. Listing them would imply a ceiling this file explicitly says does not exist. Read
the row above as *"the router is the one to watch"*, not as a census.

So after a compaction, a re-attached router keeps roughly its first half. **This is
unverified in practice** — it is read off the documentation and a byte-count
heuristic, not observed in a session, and the ordering inside each file decides what
actually survives. It is recorded rather than acted on: the router is at **399/500**
lines as of 2026-09-07 (re-count with `grep -c ''`; this sentence has read "500/500 with
no slack", then 491, 494, 500 and 484, so it has been wrong far more often than right — see
[ROADMAP.md](ROADMAP.md) item 4), and the honest next step is to
*watch* a compaction and see what is retained before reshaping anything around a
number we have not measured.

Note it does **not** change the 500-line cap's justification. Invariant 1 exists for
incremental loading, and the Agent Skills guidance it matches is explicit that long
reference material is cheap *until used*. This is about what happens to a skill
already loaded when the window is summarized.

## How we measure it

- **Single-call salience** — the completeness eval + five controlled experiments
  in [WHY-COMPLETENESS-RESIDUAL.md](WHY-COMPLETENESS-RESIDUAL.md). Result: with the
  full library (incl. principle 5) completeness is **0.60 → ~1.00**; the residual
  is a salience effect, not a coverage gap.
- **Multi-turn decay** — [`evals/run-decay.py`](../evals/run-decay.py) builds a
  session where guidance is loaded at turn 1, followed by K turns of unrelated
  filler, then a build task; a blind judge scores whether the guidance is still
  applied. Arms: *anchor* (guidance once), *reminder* (guidance + a generic
  per-prompt reminder, the hook's analog), *control* (none).

  **First run (2026-07-14, `c6_webhook`, K ∈ {0,15,30}):**

  | arm | K=0 | K=15 | K=30 |
  |---|---|---|---|
  | control (no guidance) | 0.40 | 0.40 | 0.40 |
  | anchor (guidance at turn 1) | 1.00 | 1.00 | 1.00 |
  | reminder (guidance + per-prompt reminder) | 1.00 | 1.00 | 1.00 |

  **No decay at this scale** — an ~18.6K-token (~72 KB) guidance block loaded at turn 1 was still
  fully applied after 30 unrelated turns. That *bounds* the problem (moderate
  sessions are safe here) but does **not** find the breaking point: the ~3.2K tokens of
  filler is small next to the guidance, so it can't dilute it. A real decay test
  needs much larger intervening context (or a smaller anchor); the harness takes
  `--depths` and a bigger filler to scale up — and the filler is the blocking half, since
  `--depths` past 30 is refused by a guard, not silently capped. Logged as **roadmap item
  49**, still open (it cited *item 5* until 2026-09-11, which has meant the 6-month accuracy
  sweep since the ledger was renumbered)
  ([`evals/results/2026-07-13/DECAY.md`](../evals/results/2026-07-13/DECAY.md)).

## Re-routing is per task shape, not per session (2026-09-12)

The re-injection hook carries one clause the router cannot: **route again when the work
changes shape.** A numbered imperative inside the router body cannot fix *"the router was
never re-read"* — the hook is the only surface that fires after a session has already moved
on from its opening frame.

Observed four times before it was written, across three discovery modes and never as a
trigger defect — the description matched, the rule existed, and it simply was not loaded:
a session typing zsh one-liners while auditing with three shell rules unloaded; a
documentation session that became campaign execution without re-routing; a shell-work
session that never opened `sota-devsecops` and filed a duplicate-rule proposal as a result;
and the review of that proposal, which verified the gap inside the file the report named and
never asked which skill owned the topic.

**Not yet measured.** The honest instrument is whether a long session that changes task
shape mid-run loads the second skill at all — a routing eval, on a harness that already
exists, needing live spend and its own pre-registration (ROADMAP 48).

## See also

- [README → Always-on routing](../README.md#always-on-routing-recommended) — set up all six layers
- [WHY-COMPLETENESS-RESIDUAL.md](WHY-COMPLETENESS-RESIDUAL.md) — the why, with experiments
- [docs/INDEX.md](INDEX.md) — find anything else
