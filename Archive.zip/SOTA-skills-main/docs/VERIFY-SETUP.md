# Verifying a repo's setup — the read-only check

`scripts/init-gates.sh` and `scripts/gen-agents-md.sh` **set things up**.
Nothing checks the result. This is that check, in two halves that answer
different questions — run both:

```sh
/path/to/SOTA-skills/scripts/verify-setup.sh          # deterministic half
/path/to/SOTA-skills/scripts/verify-setup.sh --runs 200   # widen the CI-history sample
/path/to/SOTA-skills/scripts/verify-setup.sh --reach-only # section A only (what install.sh runs)
/path/to/SOTA-skills/scripts/verify-setup.sh --no-color  # plain output (also: NO_COLOR=1, TERM=dumb)
```

`install.sh`/`update.sh` end every run with `--reach-only`, so the *library reach* half is
checked whether or not anyone remembers to. The repo-context, gate and CI sections are not:
they describe whichever directory you are standing in, so they stay a deliberate manual run.

**Check 1c — the report command.** `/sota-report` is how this library finds out it is wrong;
an install where the skills reach the machine but the command does not is one that keeps
working and can no longer be told anything. 1c distinguishes four states, not two: a live
symlink (**PASS**), absent or dangling (**FAIL**), a `--copy` snapshot that will not update
(**PARTIAL**), and a file that is not ours, which is left alone.

**Check 1d — the other commands.** 1c proves the one command whose absence is expensive; 1d is
check 1's *denominator* applied to `commands/`, comparing what is installed against what the
checkout ships. A `git pull` refreshes every existing symlink and creates none, so a command
added upstream stays uninstalled and silent — the same failure that made check 1 grow a
denominator after it printed "41 skills" over a tree of 42. **PARTIAL**, not FAIL: a missing
workflow command costs a workflow. It goes **INFO** when no `commands/` directory resolves,
rather than passing over an empty scope.

**Output is two-mode and the plain mode is a contract.** On a TTY the rows carry colour and a
status symbol (`✔ PASS`, `✘ FAIL`, `▲ PART`, `? UNVR`, `ℹ INFO`, `· N/A`). Anywhere else —
piped, redirected, `NO_COLOR`, `TERM=dumb`, `--no-color` — every line is the plain
`STATUS  check  evidence` it has always been, starting at column 0. That is not cosmetic:
`check-negative-controls.sh` part B asserts on lines beginning `FAIL`, and twelve probes
depend on those bytes.

**`scripts/verify-setup.sh`** does everything mechanical and does it identically
every time: are the skills reachable, is the routing hook installed, does the
profile symlink resolve, is there a licence under *any* name, which gate
mechanisms exist, is a hook actually **installed** rather than merely configured,
and — from real run conclusions — has CI ever *executed* and ever *rejected*
anything. Its section F adds one thing about the **machine** rather than the repo:
**what this box's default searcher silently skips** (check 13). Every searcher excludes
something quietly — a symlinked directory, a `.gitignore`'d path, a dot-directory — and the
failure mode is a *clean absence*, which is exactly the answer a sweep was hoping to prove.
So it runs a four-match fixture under `$TMPDIR` and names the exclusions as **INFO**;
nothing fails for them, because `rg` skipping ignored files is a feature. The one thing
that *can* fail there is the **positive control**: a searcher that cannot find the plain
file is broken, and its absences are not evidence. Set `SOTA_SEARCHERS` to choose which
commands it probes.

It is read-only with respect to your repo and configuration (section F's fixture lives in
`$TMPDIR` and is removed) and exits 1 if any check FAILs.

**The prompt below** does the half a script cannot: whether the agent file's
content is *meaningful* (check 4), whether its factual claims are still *true*
(check 5b — where agent files actually rot), and the routing dry-run (check 11).
Run the script first; it answers a dozen checks in a second and tells the agent
which ones are left.

It exists because "configured" and "working" are different states that render
identically. A `.pre-commit-config.yaml` with no installed hook is a file, not a
control. A CI workflow whose every run is *skipped* is a gate on paper. An
`AGENTS.md` whose commands all resolve can still assert a toolchain seven months
stale. Each of those passes an existence check and fails the job.

## When to run it

- On a repo you just scaffolded, before trusting the scaffolding.
- On a repo you inherited, before assuming its green CI means anything.
- Periodically on your own, because agent files decay
  ([`sota-docs-workflow` rules/01](../skills/sota-docs-workflow/rules/01-documentation-architecture.md) §7).

## The prompt

Paste this verbatim.

```text
SOTA setup verification — READ-ONLY. Do not build, scaffold, install, or fix
anything. Do not create, modify, or delete a single file. If a check fails, say
so and move on; the output is a report, not a repair.

Verify by OBSERVATION, never inference. Run the command, read the file. Any
check you cannot actually run gets reported as UNVERIFIED with the reason —
never as a pass. Probe for capabilities, not for one implementation's name: a
check for `docker` misses podman, `LICENSE` misses `LICENSE-MPL`,
`.pre-commit-config.yaml` misses husky/lefthook/a CI job.

## A. Is the library reaching this directory?

1. List the sota-* skills you can actually load right now, and count them.
   Compare against `ls -d ~/.claude/skills/sota*/ | wc -l` (or the plugin's
   skills dir). PASS = the counts agree and the `sota` router is among them.
1b. **Count the skills listed with NO description.** Look at your own skill
   listing and count entries that are a bare name with nothing after the colon.
   This is the one thing the script cannot do and you can: it measures the
   descriptions *on disk*, while only you can see what actually **arrived**.
   Claude Code reserves a per-turn character budget for the listing
   (`(contextTokens x 4) x skillListingBudgetFraction`, fraction default 0.01 —
   8,000 chars at a 200k context, shared across every installed skill) and, over
   budget, **drops whole descriptions** rather than shortening them, choosing the
   losers by *recent usage*. A skill with no description is installed, correct,
   invocable by name, and cannot be auto-selected on what it does. Report the
   count and the names. Non-zero is a finding even when check 1 says PASS —
   they answer different questions.
2. Always-on routing: does `~/.claude/CLAUDE.md` contain a sota routing
   directive, and does `~/.claude/settings.json` define a `UserPromptSubmit`
   hook whose command mentions sota? PASS = both. If only the CLAUDE.md
   directive exists, say so — routing then depends on the model reading it
   rather than on a per-prompt injection.
3. Stack profile: does `~/.claude/profiles/*.md` exist and resolve (not a
   dangling symlink)? Report the filename only, not its contents.

## B. Is this repo's own context in place?

4. Agent file: `AGENTS.md` and/or `CLAUDE.md`. PASS is not existence — it is
   CONTENT. Read it and state whether it carries (a) exact build/test/lint
   commands, (b) deviations from the language default, (c) traps. A file that
   only restates generic best practice, or that points at tooling a fresh
   contributor would not have, is a FAIL with the reason.
   If `CLAUDE.md` is a symlink, check it resolves; a one-line pointer to
   `AGENTS.md`, or a native `@AGENTS.md` import, is fine.
4a. **Did it actually LOAD?** Presence is not loading, and this is the one check
   here that answers it directly: run `/context` and list what appears under
   **Memory files**. A file in the repo that is missing from that list is a file
   Claude cannot see — the most common cause of "the agent suddenly got worse".
   Three specific ways it happens, all silent:
   - the repo carries `AGENTS.md` only, and **Claude Code does not read
     `AGENTS.md`** — it reads `CLAUDE.md`;
   - a `CLAUDE.md` symlink checked out as a plain text file containing the
     literal string `AGENTS.md` (`core.symlinks=false`, or Windows without
     Developer Mode, where creating the link needs elevation);
   - an `@…` import resolving **outside** the working directory whose approval
     was declined once — it stays disabled and never prompts again.
   Where a hook is available, log it rather than eyeballing it: the
   `InstructionsLoaded` hook records which instruction files loaded, when, and
   why. Report PASS only with the list, not with "the file is there".
5. Verify the agent file is TRUE, in two passes:
   5a. Every build/test/lint command it names exists (Makefile target, script in
       package.json, task in pyproject/justfile). Name the file:line of each.
   5b. Every factual CLAIM it makes is still accurate — pinned versions,
       toolchains, image tags, what a given target actually does. Open the file
       it describes and compare. This is where agent files rot: the command
       still exists, the claim about it went stale months ago, and nothing
       checks it.
6. Day-zero artifacts: a licence file (`LICENSE*`/`COPYING*`/`COPYRIGHT`),
   `.gitignore`, README. Report each present/absent.

## C. Are the gates real, or just configured?

7. Find every gate mechanism, not just one: `.pre-commit-config.yaml`, husky,
   lefthook, `.git/hooks/*` (non-sample), and CI workflows. For each, list what
   it actually runs.
8. Secret scanning specifically: is any gate running gitleaks/trufflehog/
   detect-secrets, at commit time or in CI? Confirm with a repo-wide search, not
   by assuming from a filename.
9. Are the gates INSTALLED, not merely configured? Check `.git/hooks/` for
   non-sample hooks and `core.hooksPath`. Distinguish three states: installed /
   configured-but-not-installed (a file, not a control) / nothing configured at
   all (N/A, not a failure). "Installed" is **per hook type, not per
   repo**: pre-commit writes `.git/hooks/<type>` only at install time, so a config
   that declares `stages: [pre-push]` installs nothing by itself and that gate
   never runs, while the present `pre-commit` hook makes the repo read "installed"
   (verified on pre-commit 4.6.0). The script's check 9a compares declared stages
   against hook files; if you are doing this by hand, list both and diff them.
10. For each gate, establish TWO things from observable history — use
    `gh run list --limit 60` (or the CI provider's equivalent) and read real
    conclusions:
    (a) Has it ever EXECUTED? A workflow whose runs are all "skipped" has a
        trigger condition that never fires — that is a control on paper only.
    (b) Has it ever REJECTED anything? A gate with only successes has never
        been observed doing its job.
    Mark each UNVERIFIED where history doesn't show it, and state your sample
    size — "not in the last 60 runs" is not "never".

## D. Routing dry-run (no code)

11. Without writing any code, state which sota-* skills and which specific
    rules files you WOULD load for: "add an authenticated file-upload endpoint
    backed by Postgres". List them, then stop. This tests that routing resolves;
    it is not permission to implement anything.

## E. Can the findings be acted on?

12. Report `git remote -v` and whether this repo is yours, a fork, or an
    upstream clone. A fix list you cannot land is a different deliverable from
    one you can.

## Output

A table: check | PASS / FAIL / PARTIAL / UNVERIFIED / INFO / N/A | evidence observed.
PARTIAL and N/A each require a one-line reason. INFO is the script's own (section F);
it is an observation about this machine, never a grade. UNVERIFIED must state what
prevented verification and your sample size where relevant.
Then a short ordered list of what to fix — described, not done — each marked
[local] or [upstream] per check 12.
Do not apply any fix. Do not offer to start building. End after the report.
```

## The one check it cannot do read-only

Proving the secret gate *rejects* something needs a real commit attempt. Run it
yourself — three lines, reversible:

```sh
printf 'aws_secret_access_key = "AKIAIOSFODNN7EXAMPLE"\n' > leak-test.txt
git add leak-test.txt && git commit -m "gate test"   # MUST be rejected
git reset -q && rm -f leak-test.txt
```

If that commit succeeds, check 8 was a false pass — you have a scanner in the
config and no control on the commit path.

## Reading the report

- **FAIL on check 5b with PASS on 5a** is the common and dangerous shape: the
  commands work, the claims lie. Fix by replacing the assertion with a link to
  the file that owns the fact.
- **All-skipped run history** is
  [`sota-code-security` rules/10](../skills/sota-code-security/rules/10-silent-control-failure.md)
  §2.13 — the trigger is the finding, not the gate's logic.
- **UNVERIFIED is not a soft PASS.** It means nobody has watched the thing work.
  Treat it as unknown, and say so when reporting upward.

## Provenance

Derived from two live runs against a real 4300-commit repository (2026-07-28).
The first run's own limitations produced checks 5b, 9's three-state
distinction, 10's execute/reject split, and 12 — each was a gap the run exposed
rather than something reasoned in advance. See
[ADOPTION-LOG.md](ADOPTION-LOG.md).
