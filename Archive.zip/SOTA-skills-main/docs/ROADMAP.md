# Roadmap

Priorities set by the **2026-07-10 audit**
([AUDIT-2026-07-10.md](AUDIT-2026-07-10.md)). Ordered; revisit after each
release. The 2026-07-01 cycle is fully executed and kept below as history.

## Start here next session *(as of 2026-09-12)*

**Read this table, then stop reading.** Everything below it is provenance and history.

### Actionable next-session priorities

Ordered by what a session can actually move. **Two items closed 2026-09-01 and both taught the
same lesson**: a claim nobody re-tests stops being true quietly. **It happened three more times on 2026-09-06**, in one
pass over this very table: two rows asked for work that was already done, and one declared a
flag that did not exist. **Re-test the trigger, not the item** — and the table itself is the
thing most likely to be stale, because nothing gates prose. Item 26 was parked on "no eval
consumes §AUDIT" — false when re-read, since `run-repo-audit.py` pastes the whole router. Item
25's completeness half **refuted a claim this library was making about itself**. Item 32 is what
25 surfaced on the way out. Nothing here is urgent.

**This table is a view, not a record.** Status lives in exactly one place — the `**OPEN` /
`**CLOSED` marker on each ledger row below — and **invariant 26** asserts that the count, the
list above and every `**Item N**` cited here agree with those markers. What the table adds is
the part a machine cannot: ordering, what a session would do first, and cost. It may cite an
item; it must never restate whether the item is open, because a restatement drifts and this
one drifted three times in a single session (items 12, 32's follow-up, and 38).

| P | Item | What a session would do first | Cost | Blocked on |
|---|---|---|---|---|
| **1** | **Use the library on real work and write a field brief** (not a roadmap row) | Build or audit something real with `sota-*` loaded, then report every defect it did *not* prevent | a session | nothing — this is the highest-yield input available |
| — | **The deferred rows in [ADOPTION-LOG.md](ADOPTION-LOG.md)** | Nothing: read their own trigger ledgers rather than re-searching | — | a second implementation |

**The ledger's actionable set is empty, and that is the finished state, not a gap to fill.**
Of 56 items, 55 are closed and the last (item 5, the accuracy sweep) is **dormant until
2027-01-08** with a monthly cron that turns red on **2027-02-01** by itself. Item 1
(distribution) was **closed permanently on 2026-09-12 by operator decision** — the work is
real but it is a person's, and a row no session can act on is a reminder, not a backlog item.
**Do not re-derive either of them**, and do not open a replacement row for distribution.

So there is nothing here to pick up. The one row above is deliberately **not** a roadmap
item: the highest-yield input this library has ever had is a session that *used* it and
reported what it failed to prevent (47 of 49 proposals adopted across eleven briefs). If you
came here looking for the next task, the answer is to go use the library on something real.

**Why priority 1 is a session, not a task.** Field briefs from sessions that *used* the
library have the highest adoption rate of any intake source in the ledger. Counted from the
release entries, **eleven briefs landed 47 of 49** — the two newest are the 2026-09-11 InterdictOps report (**7 of 8**, its eighth **retracted by its own author** the next day before anyone else caught it) and its 2026-09-12 successor (**3 of 3**, filed as a separate document precisely so the retraction would reach an implementer mid-PR, which it did). Earlier: 2026-08-26 **7 of 7**, its follow-up
**4 of 4**, v1.32.3 **6 of 7**, v1.34.0 **6 of 6**, v1.35.2 **4 of 4**, v1.36.3 **4 of 4**,
and three on **2026-09-10** — the process-table brief **1 of 1** (#342), the
self-recursive-wrapper brief **2 of 2** (#344) and the `sota-testing` brief **3 of 3**
(#345, which also had a fourth item adopted that the brief had explicitly *declined* to
propose) — and the two intakes of 2026-09-08 (v1.38.0) landed in full as well. They find defects no
amount of re-reading the library could surface, because the failure is usually a rule that is
present, correct, and never reached. **What to ask a brief for has sharpened three times**: for the
rules of *ours* that caused the defect (2026-08-26), and — since v1.35.2 — for its
*already-covered* reports too, since a rule earning its place is invisible from inside the
repo, and — since 2026-09-10 — for its **"considered and NOT proposed"** section, which is
where the author's judgement is genuinely uncertain and therefore where a reviewer adds
most: the `sota-testing` brief's declined item (a stopped runtime turning 30 tests into
skips at **0 failed**) was adopted, and the round-2 brief's most valuable contribution was a
*question* about one of our own measurements, which turned out to refute it. Read a brief's **premises** as sceptically as its findings: at v1.35.2 all four
proposals were sound and three of the sentences supporting them were not. Commissioned research and doc re-reads land far
fewer, and the written-conventions backlog is empty.

### How this list is maintained

**Last re-count 2026-09-12**, after a session that ran three pre-registered evals and split a rules file: **6 open → 4** (47, 53, 54, 55 closed; 55 opened and closed). **What re-testing a trigger bought this time, three times over:** item 49's recorded blocker (*author more filler*) priced at **~580 pairs** — a dead end — while its own unpriced alternative (a smaller anchor) took **one flag**; item 48's *"the harness already exists"* was **false**, the third row in a row to assert a capability that was not there; and item 55's seam was chosen by **citations** rather than line count, which is why a 44-reference rewrite broke nothing. **What no row predicted:** the anchor arm producing *no build at all* at K=0, reproduced twice, with a one-line reminder recovering it completely — the first large measurement of the mechanism the re-injection hook implements. Counts re-measured from the tree this pass: **42 skills / 313 files / 271 rules files**, and `AGENTS.md`'s denominator example was changed from a literal to `N` after going stale a **fourth** time (261 → 262 → 270 → 271). Previously **2026-09-11**, after a session that worked the whole READY/decision backlog: **5 open → 6** (46, 50 and 51 closed; 49, 50, 51 and 52 opened, 50 and 51 closing the same day they were opened). What that session found that no row predicted, all of it from **running** something rather than reading it: a **dead eval runner** behind the +0.509 headline, invisible to CI because the smoke gate could not see past a credential check (51); the roadmap's own *"what is open?"* command returning **0** against a real 2 after a marker convention changed under it; a decay question that had cited a **retired item number** for two months; and — from the magus intake — the first look anyone here has taken at the **aggregate** size of our description corpus (52). Two roadmap rows turned out to rest on false premises when tested: item 46's *"it touches the pinned §AUDIT"* (it does not) and DECAY.md's *"the harness is ready for it"* (the flag is; the filler is not). Previously **2026-09-10**, after three field briefs landed: **4 open → 5** (item 48 opened; nothing closed).
Items 41, 44 and 45 were the three parked on a *decision*, and taking each decision changed
the answer the row proposed — 41's per-(file, flag) fix was rejected for a per-**runner**
one, 44 became a release-time declaration rather than a CI gate, 45 became a behavioural
INFO probe rather than a presence check. Item 12's replacement trigger was **measured** and
reads negative. What the session found that no row predicted: **two undocumented runners**,
a **broken escape hatch in the new invariant** (probe 29b), **two stale unprobeable
exemptions** (11 and 14), a **vacuous fixture in the new check**, and a **wrong row in a
shipped rules file** (`sota-shell-scripting` rules/06 §2 on BSD `grep -R`). Every one of
those came from a gate or a probe being *run*, not from re-reading the roadmap.

Numbers here are re-counted at each cut, never carried forward — the stamp above goes stale
within a day, which is the case for re-reading this at every cut rather than trusting it.
Last re-count **2026-09-07, after v1.35.0**: skills 41 → **42**, files 305 → **309**, and the count claims re-read against the tree — which found the README badge's **alt text** stale at 41 while its number said 42 (invariant 6 checked the machine-readable half only; now it checks both, watched to fail) and the router's library-map pointer saying "all 40 skills" against 41. Items **38–41 opened**, **32 closed**. Previously **2026-09-06 (second pass, after v1.34.0)**: row 13's cap watch re-measured across **two splits**, and every file in it re-read from the tree. Previously the same day, this named what was re-read — **every open item's trigger, and three of them were stale**: item 1's *"write the salience piece"* (done 2026-09-01 as [WHY-SALIENCE-LASTS.md](WHY-SALIENCE-LASTS.md), linked from README and INDEX, and this row kept asking for it for five days), item 32's *"the flag exists"* (`--pad-rules` did; the `BUILD_WORKFLOW` ablation did not and had to be written), and item 12's rules-file count (261 → **262**). Re-tested and genuinely not met: item 5 (`check-freshness.sh`, due ~2027-01-08), item 12's sixth verification file (**5** in the tree), the deferred ADOPTION-LOG row (its own ledger says read it, not re-search). **Items 33 and 34 closed; 35 and 36 opened** by a post-release doc sweep that found `AGENTS.md` at **201** against its own <200 rule, its denominator example stale (261 → **262** rules files), and `--no-gate-arm` documented everywhere except `evals/README.md`. **Item 37 opened and closed the same hour**, when CI red-flagged a probe the local run passed. **35 and 36 closed the same day they were opened** (invariants 24 and 25); the invariant count is now **25**, probes **32**. Shipped as **v1.33.1**. At that cut a post-release sweep confirmed the live count claims agree with the scripts, verified `test_scoring.py`'s **38** assertions by running it standalone (pytest's "4 passed" counts *functions* — a different denominator, both true), and found `evals/README.md` said nothing about invariant 25 to the contributors it governs. Invariant count 22 → **23**, probes 28 → **29**. Previously **2026-09-05**, this named what was re-read: the **cap watch** (row 13, all eight files re-measured with `awk 'END{print NR}'`), the **invariant count** (21 → **22**), the **probe count** (27 → **28**, from a real CI run printing `PASS: 28/28`, not a static count of call sites), and the **latest release (v1.32.3)**. Two items opened (**33, 34**). **Not** re-read this pass: star/forks, item 1's listing status, item 12's counts, the deferred-row pointer. Previously **2026-09-03**, this named what was re-read: the **cap watch** (row 13,
re-measured from the tree — the router left the list at **398**, `sota-code-security/rules/12`
inherits it at **494**), item 12's router count, and the **latest release (v1.32.0)**. **Not**
re-read this pass: star/forks, item 1's listing status, the item-ledger and open counts.
Priority 1 was *exercised* rather than closed — a field brief arrived and landed in v1.32.0
(zsh `NOMATCH`), which is the standing invitation working, not a task completed. **Exercised again 2026-09-05**: a static-analysis-pipeline brief landed **6 of 7** in v1.32.3, and *evaluating* it — not applying the library — found the defect that became invariant 22.
Previously, 2026-09-01, this named what was re-read: the item ledger count (**31 → 32**), the open count (**5 → 4**: items 25 and 26 closed, 32 opened), item 12's two stale counts (259 → **261** rules files, router 498 → **499**, both re-counted from the tree), and item 26's trigger — which was **re-tested rather than trusted**, and had been met all along. **Not** re-read this pass: star/forks, item 1's listing status. Previously, 2026-08-29: star/forks live via `gh`
(**17/3**, flat since 2026-08-27), the router re-counted at **499/500**, the latest release
(**v1.30.0**), and row 13's cap watch. **Not** re-read this pass: item 1's listing status
and the deferred-row pointer, both last checked 2026-08-28. **Restamping a header is not enough when the
section was refreshed in parts — say which parts.**

**This table is not the whole backlog.** Open work also sits in
[ADOPTION-LOG.md](ADOPTION-LOG.md) as entries marked **`**DEFERRED —`** — an idea judged
real but held for a trigger, which the roadmap never learns about. **Two are live today**
(2026-08-11, an integrity verdict left routinely red for operational reasons, revisit when a
second implementation shows the same design; and the **over-firing control** from the
2026-09-11 magus intake, held until `sota-code-security` rules/10 is split or a second
instance appears, because placing it today would let the 484/500 line cap choose where it
goes). A third resolved on 2026-09-11, when the `vulnerability-triage-brocards` trigger was
executed rather than re-read — it became a confirmed gap and then **item 50**, which is where
a deferral should go when its condition is met and the work is real. Answering "what is
open?" means
counting those as well as reading this table — a list assembled from one file reads as
complete and is not.

**Count them with the gate, not by hand.** `scripts/check-invariants.sh` prints the number
in check 27 (`ok (N deferral(s), each naming a trigger)`), which is the same regex the
marker convention is enforced by, so it cannot drift from it. This paragraph used to hand
out `grep -c '\*\*deferred'` instead — **lowercase**, which stopped matching when invariant
27 fixed the marker as uppercase `**DEFERRED —` on 2026-09-09. Measured 2026-09-11: that
command returned **0** against a real **2**, so the instruction for finding the rest of the
backlog reported that there was none — a clean absence, in the one place a reader goes to
ask what is left.


### What the backlog's shape says about where work comes from

**The written-conventions backlog is empty** — invariant 14 closed the last gateable
candidate — so nothing above comes from re-reading docs. That prediction has now held
three times: the v1.21.1 candidates came from incidents, the three additions of 2026-08-11
came from **reading an outside implementation's own failure notes**, and
`evals/smoke-runners.py` (2026-08-27) came from an incident too — a runner dead for three
weeks that no doc could have predicted. Item 11 is the near-exception that shows the shape
rather than breaking it: it *was* found by re-reading docs, at the v1.22.14 cut — and it is
**not gateable**, so it earns a ledger row and a habit, not a check.

### The full item ledger

<!-- count-check: ^\| \d+ \| -->
All 56 items, ordered by number, not priority. **Only 1 is open** — 5, and it is **dormant until 2027-01-08** with a cron that raises it by itself, so the actionable set is **empty** (1 closed permanently 2026-09-12 by operator decision — won't track, not done) (48 closed 2026-09-12: the hook clause shipped, the effect measured, and the trigger defect it uncovered fixed with a routing check that caught a regression on the way) (49 closed 2026-09-12: no decay, and the K=0 anomaly resolved into a measurement artefact — the rubric cannot tell a correct clarifying question from an omission) (55 closed 2026-09-12: rules/10 split at the citation seam, 484 → 230 lines) (47 closed 2026-09-12: loading lean cuts the judge-reported conflict rate 63%, and the lean floor hand-verifies to 0.000) (53 closed 2026-09-12 by an operator decision on a measured null: keep the tails) (55 opened 2026-09-12: `sota-code-security` rules/10 is at 484/500 with two classes queued behind a split) (54 opened and closed 2026-09-11: the plugin install path could not fix the listing budget itself, and now reports it) (53 opened 2026-09-11 as the half of 52 the mechanism did not answer; **52 closed the same day by reading the shipped CLI**, and the answer was no — around 20 of our 42 descriptions never reach the model; 51 opened and closed that day, a dead runner the CI gate could not see and then could; 50 also opened and closed that day when the last executable ADOPTION-LOG deferral resolved into a confirmed gap; 46 closed the same day, all three confirmed conflicts fixed on both sides; 49 opened the same day, a decay question that had been citing a retired item number for two months; 43 closed 2026-09-10, H1 confirmed at n=3; 39 closed 2026-09-09 by measuring it, and **46 and 47 were opened by that measurement** — the three conflicts it confirmed, and the lean-loading follow-up its own ceiling framing demands) (12, 41, 44 and 45 all closed 2026-09-09; 12 by measuring the routing trigger that replaced its file count, and 41/44/45 by taking the three decisions they were parked on) (38 and 40 both closed 2026-09-08 by running them; 44 opened the same day by the run that closed 38) (32 closed 2026-09-07 as measured-and-underpowered and **item 43 is its follow-up**, opened 2026-09-08 because the priorities table had been pointing at work with no ledger row; 42 opened at the v1.35.2 cut and closed the same day), as
listed above (25 and 26 closed 2026-09-01; 31 was opened and withdrawn within one cut; 33 and 34 were opened at the v1.32.3 cut on 2026-09-05 and **both closed the next day**); the rest are closed or are recorded lessons kept for the lesson rather than
the work. (A count of "closed" rows resists grepping: a case-insensitive match on *done*
scores row 12's "**NOT** done" as closed. Count the open ones, they are few.) Use the
priorities table to decide what to do; use this one to find out why something was or was
not done.

| # | Item | Why not done | First move |
|---|---|---|---|
| 1 | **CLOSED PERMANENTLY 2026-09-12 — by operator decision, not by completion** | Not a code task; needs a person, not a gate | **This row is retired and must not be reopened or re-derived.** What it tracked is real and partly done — the [awesome-ai-plugins](https://github.com/hashgraph-online/awesome-ai-plugins) listing PR merged 2026-08-26, and the salience write-up [WHY-SALIENCE-LASTS.md](WHY-SALIENCE-LASTS.md) shipped 2026-09-01 (this row kept asking for it for five days after it landed, which is the point). What remained — external publication, a before/after audit demo, working the listing channels — is **hours of a person's time and nothing an agent can move**. A roadmap row that no session can act on is not a backlog item, it is a recurring reminder of that fact, and it was surfaced at or near the top of the priorities table for **seven weeks** without once being actionable. Closed as **won't track**. Distribution work still happens; it simply is not managed from here |
| 2 | **Real-repo audit eval — CLOSED 2026-08-14.** Recall *and* precision both measured, both +0.00 | Recall 15/16 = 15/16; precision **1.00 = 1.00** over 59 blinded findings, adjudicator controlled at 4/4; severity mix indistinguishable. Nine instruments, zero lifts | Nothing. Do **not** build a tenth audit-recall or audit-precision instrument. If the audit claim is ever revisited, it needs a different *dependent variable* (time-to-find, report usability, or defects found by a non-expert), not another accuracy metric |
| 3 | **Competitor comparison — content-only re-run DONE 2026-08-14/15, claim holds. As-deployed REJECTED 2026-08-16** | Re-run at the pinned SHAs with the same build model: SOTA 98.7 / ECC 84.9 / cursorrules 80.0 / claude-skills 77.0 / unguided 58.2, 17 wins / 4 ties / 0 losses of 21, unguided arm reproducing to 0.2 points as the drift control. **As-deployed is rejected, not deferred:** it measures corpus size and a retrieval path we have already found saturated, not guidance quality — reasoning below the table | Nothing. Do not re-open without a new argument that answers the corpus-size confound |
| 4 | **Router trim — RESOLVED 2026-08-26 by offloading, not trimming. And the "2×" was wrong: it is 3.3×** | The cap was never protecting routing quality — **measured**: recall stayed **flat at 1.000** with the router padded to 902 and 1,302 lines and the routing table pushed 800 lines deeper, while the untreated arm reproduced 0.867 exactly ([ROUTER-LENGTH](../evals/results/2026-08-26/ROUTER-LENGTH.md)). What *is* real is per-load cost: `count_tokens` gives **16,442 tokens** at 484 lines, **3.3×** the ~5k guidance — this table said ~10,211 (2×) from a chars/4 heuristic that under-read it by ~60% | **Nothing on the cap.** BUILD/AUDIT detail now lives in `skills/sota/rules/` and loads on demand (PR #284): 500 → 484 lines, ending compress-on-every-addition. **Superseded 2026-09-02:** the same move applied to the 108-line **library map** (→ `sota/rules/04`) took the router to **399 lines / 13,415 tokens** from **500 / 16,997** — **−21.1%**, measured with `count_tokens` on `claude-sonnet-5`, and **seven times** the ~3% this PR-#284 row reports. A lookup table is denser than prose and is the part nobody reads inline, so offloading pays where it did not before; the router still sits at **2.7×** the ~5k guidance. Be honest about the size of that win — the token saving is 16,934 → 16,442, **~3%**; the win was **headroom**, not context economy. Next addition goes to `rules/`, not the router. Two caveats on the sweep, published with it: the metric is **at ceiling** (it can only detect a drop) and the filler is **inert**, so it tested length/depth and *not* competition between real rules |
| 5 | **OPEN — 6-month accuracy sweep — DORMANT until 2027-01-08, do not surface before then** | Scheduled; the trigger is mechanical | `LAST-VERIFIED` reads **2026-07-08**, so the sweep is due ~**2027-01-08**; bump it only after a full pass. **Nothing needs to track this row.** `.github/workflows/freshness.yml` runs `check-freshness.sh` at 06:00 UTC on the 1st of every month, and that script **exits 1** once the stamp passes its 6-month window — so the first red run is **2027-02-01**, unprompted. Until that run goes red this item is **not actionable work and must not appear in the priorities table, a session summary, or a status line**. Re-reading it early costs a sweep's worth of attention and buys nothing the cron does not already do |
| 6 | **CLOSED 2026-08-21 — both deferred ideas landed** | (a) Event-sourcing replay preconditions → `sota-architecture/rules/03` §6: the `apply` step must be a pure function of (state, event); capture non-deterministic answers *in the event*; gate outbound effects during replay; and the **event log**, not commands, carries the durability budget. (b) Geospatial → `sota-databases/rules/03`, a *Geospatial* section on the three ways the index is lost. Both got audit checklist items **in the same change**, which is the point of item 16 | **Nothing.** Two honesty notes kept in the log: (a) Fowler's *Event Sourcing* supports the external-query mechanism but never says *deterministic*, so the rule is written from the mechanism with the citation scoped to what it covers; (b) geospatial was adopted **on instruction, not because its revisit condition fired** — that condition is still unmet |
| 7 | **`sota-rust` subprocess coverage — CLOSED 2026-08-19.** The gap was real (zero hits, three independent greps) and is now `sota-rust/rules/05` §9, seven rules with four audit probes | Every claim measured on rustc 1.97.1 / tokio 1.53 rather than carried over from Go or Python — which mattered: **three languages behaved three different ways** under the same pipe-holding-grandchild test. Go's `Wait` blocks past cancellation without `WaitDelay`; Python's raises on schedule; **Rust/tokio's `timeout` fires on schedule but leaves the child running**, because cancelling a future is not killing a process | Nothing. Two corrections rippled out: `sota-sandboxing/rules/04` R5.1 claimed "beware `.arg` vs `.args` splitting" and **neither splits** (measured), and R5.3a's per-language pointer list now includes Rust |
| 8 | **Per-language subprocess rows — CLOSED 2026-08-20. All five runtimes now measured.** Java was the last unmeasured row; run on Temurin **25.0.3** in a podman container, since no JDK is installed on this machine | `ProcessBuilder` confirmed (no whitespace splitting, no shell). Three things the row did **not** say: `Runtime.getRuntime().exec(String)` **tokenizes on whitespace** and is `@Deprecated(since="18")` on all three `String` overloads while the `String[]` ones are not (read off `Runtime.class` by reflection, not from docs); `waitFor(t, unit)` fires on schedule and **returns `false`**, so the caller *is* told, unlike Node; and `destroy()` orphans the grandchild while **`Process.descendants()` + `destroyForcibly()` kills it** — Java is the only one of the five with a portable process-tree kill. Also corrected a claim the new row exposed: the table said "no two agree on all three questions", which was **already overstated** — Python and Rust answer all three identically | **Nothing.** The probe's first run was *wrong* (its liveness check matched an orphan left by the previous phase and reported the tree-kill as failing); re-run with per-phase markers and a control that demonstrably reads both true and false. Any sixth runtime gets the same treatment |
| 9 | **Pre-push stage — DONE 2026-08-19.** The repo now practises what it prescribes | The narrow case held up: invariants **11 and 14 are diff-based** and at pre-commit time the change is only *staged*, so they have nothing to read and pass by skipping. Pre-push is the first local moment a commit exists | Nothing. `default_install_hook_types: [pre-commit, pre-push]` makes a plain `pre-commit install` create both hooks; every hook now states its `stages` **explicitly**, because a hook with no `stages:` key runs at *every* configured stage (measured) — which is exactly the doubling this item warned about. `verify-setup.sh` check 9a now reports PASS on this repo |
| 10 | **Two suggestions from the 2026-08-18 brief were declined, on purpose** | Recorded so they are not re-litigated | **(a)** Moving BUILD step 4's gate advice earlier: its last position is where the measured completeness lift is attributed, and the router is now **full at 500/500**, so it would displace a line rather than reflow. Revisit only with a measurement. **(b)** The hook-versus-typed-instruction note: **done** as documentation (README, always-on routing), stated as mechanism rather than as a measured effect |
| 11 | **Invariant 17 sees counts, not meaning — first instance found 2026-08-19 at the v1.22.14 cut** | `AGENTS.md`'s invariant 14 row read "a declared term resolves in **neither** `README.md`/`docs/INDEX.md` **nor** the release's own entry" — an OR across all three — while `scripts/check-invariants.sh:842` requires (README **or** INDEX) and `:848` requires the release's own entry, an AND. `CONTRIBUTING.md` item 14 was already correct, so two documents describing one gate disagreed **in logic while agreeing in count**, which is exactly what invariant 17 cannot see: it asserts every stated count equals N and that `AGENTS.md`/`CONTRIBUTING.md` enumerate 1..N with no gaps, nothing more (read at `check-invariants.sh:1027`+) | **Nothing to build.** Applying the three filters ([CONVENTIONS-LEDGER](CONVENTIONS-LEDGER.md)): incident **yes** (once), silent **yes**, mechanically checkable **no** — comparing the semantics of two prose restatements written at deliberately different granularities is the judgement class the ledger argues against gating. The remedy is the habit that caught it: re-read the prose *beside the script* at each cut. Recorded so it is not re-litigated as a gate proposal |
| 12 | **CLOSED 2026-09-09 — the replacement trigger was measured and reads negative** | The count trigger fired on 2026-09-06 and the answer was still no, which is the tell that a count was a **proxy**. The trigger that replaced it — *split when a routing measurement shows the combined description mis-classifies verification-shaped tasks* — was run: 12 blind cases, 6 vulnerability-shaped and 6 verification-shaped, `sonnet-5`, 3 samples, temp 0.7, [pre-registered](../evals/results/2026-09-09/PRE-REGISTRATION-SKILL-SPLIT-ROUTING.md) before any call. | **Top-1: verification 0.500 vs vulnerability 1.000**, clearing every registered H1 threshold — and all three misses unanimous, all three to `sota-shell-scripting`, all three naming a *script*: the classifier matched the **artifact** over the **question**, the `r1_token_count` shape again. The registration required the **cheap fix first**, so a clause claiming the question shape against the artifact went into the description (keywords were already there and had lost); verification 0.500 → **0.611**, vulnerability unchanged at 1.000. The residual is `c3` and `c5`, which the router's **rule 17** routes to *two* skills — so a pick-one instrument was forcing a choice the router does not make, a limitation the registration recorded before the run. The registered follow-up settled it the same day: `run-routing-recall.py`'s **set** metric reads `evidence_shell_script` **recall 1.00** — `sota-code-security` is never omitted. **No split.** [Write-up](../evals/results/2026-09-09/SKILL-SPLIT-ROUTING.md) |
| 13 | **Cap watch — re-measured 2026-09-13; three files now have ≤ 4 lines of slack** | Top of the tree, `grep -c ''` after the day's last release: `sota-code-security/rules/10` **484**, `sota-docs-workflow/rules/01` **477**, `sota-code-security/rules/11` **474**, `sota-code-security/rules/14` **465**, `sota/rules/03` **461**, `sota-devsecops/rules/01` **450**, `sota-shell-scripting/rules/02` **414**. **`sota-shell-scripting/rules/01` has left this list entirely** — 498 → 366 → 502 → **343**, split twice in one day (constructs → `rules/05`, ad-hoc commands → `rules/06`). | **2026-09-13, after invariants 30 and 31 landed:** `sota-shell-scripting/rules/06` **500** (at the cap, zero slack — the next change to it must split first), `sota-docs-workflow/rules/01` **497**, `sota/rules/03` **496**, `sota-code-security/rules/11` **474**, `rules/14` **465**, `sota-devsecops/rules/09` **460**, `rules/01` **450**, `sota-code-security/rules/15` **444**. `sota-code-security/rules/10` has left the list (484 → **230**, split at its citation seam). **Three files within four lines of the cap is the pressure to watch** — the 2026-09-08 numbers below are kept as the prior reading rather than edited. **Two lessons, both measured.** *Pick the seam from the citations, not the headings*: the seam this row once proposed was 114 lines against 384, while counting external references (6 at §3, 2 at everything that moved) put the cut somewhere that broke **zero** of them. And *a file that hits the cap twice in a day was two files* — treat the second breach as the signal, not the first. Watch next: `rules/10` at 484 and `rules/11` at 474, both in `sota-code-security`, which is also item 12's subject |
| 14 | **DONE 2026-08-20 — the repo now practises `sota-code-security` rules/12 §1b.** `./scripts/check-invariants.sh --self-test` | Structural pass (~1 s): every check must be either probed by `check-negative-controls.sh` or listed in that script's own *NOT COVERED* block. Both sets are **derived from the harness**, not restated, so there is no second list to drift. It then execs the harness. Watched to fail on two mutations — a deleted `probe 13` ("check 13 has no known-bad") and a probe added for the declared-unprobeable check 5 ("both probed and declared unprobeable") — with the clean tree passing at `18 checks: 13 probed, 5 declared unprobeable, 0 unaccounted` | **Nothing.** Two design choices to keep: the probe **count** stays ungated (a static count of call sites under-reads, 13 vs an actual 24), and mutations keep asserting they landed |
| 15 | **BUILD↔AUDIT correspondence — measured 2026-08-21, ~4% and NOT gated** | Four attempts: `§`-anchors (1% of items cite one — measured a convention that does not exist), lexical overlap (defeated by synonymy and cross-file grounding), a shell sampler (mangled its own alternation), and finally **read a sample**. n=20 said 10%; n=60 said ~2%; pooled n=80 gives **~4% confirmed**. Recorded as a **floor with a soft ceiling** — 18 of 60 read in full, the rest screened, and the screen errs both ways | **Do not re-attempt a mechanical version** — the ledger records why. If the number is ever wanted tighter, the method is reading, not scripting: ~40 more sections. The *actionable* output was never the percentage (see item 16) |
| 16 | **Gaps cluster by FILE, and a fan-out is the mechanism** | Ranking files by weak-coverage density beat sampling sections: two `rules/02-design-api.md` files topped it, and reading the first found the cause — the in-band-sentinel row added to **nine** language skills on 2026-08-20 shipped with an audit item in **two**. Seven fixed 2026-08-21 | **When a change fans out across N skills, treat it as N chances to ship the build half alone** and check the audit half per skill before opening the PR. The author is the last person who will notice. No gate: the correspondence is semantic (item 15) |
| 17 | **Every headline claim is dated to a model. One expired; completeness did NOT** | Completeness (+0.39), freshness (+0.53) and routing (+0.10) were all measured on `claude-sonnet-4.6` or `gpt-5.1`. On 2026-08-21 defect-avoidance was re-run on `claude-sonnet-5` and went to **+0.000** — the newer model does not write those defects unaided, and its *unguided* strict score equals `sonnet-4.6`'s **with-library** score. Model progress absorbed the result in four months | **Completeness DONE 2026-08-21 — it holds**: 0.62 → 1.00, **+0.38** on `claude-sonnet-5`, unchanged within the ±0.03 noise floor, zero truncation warnings ([write-up](../evals/results/2026-08-21/COMPLETENESS-SONNET-5.md)). The mechanism is now understood: knowledge gaps close with model progress, **salience gaps do not** — `sonnet-5` unguided still omits tests in **7 of 7** tasks. **Freshness and routing CLOSED 2026-08-25** (item 20): routing holds at **+0.13**, freshness **erodes to +0.30** — and the "freshness is likely durable, models still have cutoffs" prediction stated here was **refuted**, because a cutoff *advances* into a fixed set. Three shapes, not two: expired / durable / **eroding**. Budget the runs: `sonnet-5` produced 40–122k tokens per build in the 2026-08-21 work, so it is materially more expensive than the models these numbers were established on |
| 18 | **`temp 0` is not deterministic — the harness noise floor is ≈±0.03 at n=1** | Established 2026-08-21 by the *untreated* arm: it cannot see the router, and it still moved 0.60 → 0.57 between two otherwise identical runs. Any single-sample delta below ≈0.05 is unresolvable | **Read the untreated arm before interpreting the treated one** — an arm that cannot see the treatment is a free negative control for the measurement itself. Recorded in `evals/README.md`. Retroactive consequence: past n=1 comparisons with deltas under ≈0.03 were never meaningful |
| 19 | **A pushed branch with no PR reads as finished work — and nothing reports it** | 2026-08-21: the sonnet-5 completeness branch was committed, pushed, written up and reported as landed. No PR existed. Every gate in this repo runs *on* a PR, so a branch that never opens one is not merely unmerged — it is **unchecked**, while looking done from the session transcript. It sat a day, found only by re-reading state at the next cut rather than by any signal | **Verify at the remote, not from your own summary** — the same rule `sota-kubernetes/rules/04` §7 states for write-back controllers, arriving in our own workflow. `gh pr list` before believing a branch landed; a push is not a landing. Not gated: the gates live on the PR that is missing, which is precisely why nothing caught it |
| 20 | **Freshness and routing on a current flagship — CLOSED 2026-08-25. Both re-measured; one prediction refuted** | `claude-sonnet-5`, same 3×/temp-0.7 protocol as the originals. **Routing holds: 0.87 → 0.99, +0.13** — unchanged within the set's one-case resolution (20 cases, 0.05/case) and, unlike its two neighbouring instruments, **not saturated**; the unguided arm still misses the same rule-driven routes (testing, sandboxing, code-security, web-frameworks) a generation later. **Freshness erodes: 0.44 → 0.69 unguided, lift +0.53 → +0.30.** The pre-registered prediction that a training cutoff is a gap model progress cannot close is **REFUTED** — 8 of the 32 facts moved inside `sonnet-5`'s window. The with-arm *rose* (0.97 → 0.99), so this is the **set ageing, not the library** | **Nothing on the measurement.** It produced a third claim-shape the knowledge/salience dichotomy missed — *knowledge gap, renewable*: erodes toward a floor rather than expiring. Predictions were committed at `91ca8d9` before the first API call; cost ~$0.77 against a ~$0.77 estimate. Write-up [ITEM-20](../evals/results/2026-08-25/ITEM-20-FRESHNESS-ROUTING.md) |
| 21 | **The freshness set was fixed and ageing — CLOSED 2026-08-25, same day it was opened. Re-authoring restores the lift** | A 10-case set built from facts whose primary source changed Sept 2025 – Aug 2026 reads **0.33 → 1.00, +0.67** on `claude-sonnet-5` — *higher* than the original +0.53, and measured on the same model the same day as the aged set's +0.30. The guidance did not improve between two runs an hour apart; the questions got newer. The with-arm is a **zero-variance 1.00**, independently corroborating the authoring-time verification of all ten facts against primary sources | **Quote a freshness lift with the date its questions were written**, the way every other number is quoted with its model. The old 32-case set is kept unedited as the continuity series; `freshness-2026.jsonl` is the live one. Its **selection rule** — recency + the library states the fact, never model performance — is in the file header, because picking the cases a model fails would guarantee a big number and measure nothing. Two of the ten questions telegraph each other (TypeScript 6.0/7.0) and inflate the *without* arm, i.e. against the reported result; worth splitting next revision. Write-up [ITEM-21](../evals/results/2026-08-25/ITEM-21-REFRESHED-FRESHNESS.md) |
| 22 | **Dependabot — CLOSED 2026-08-27. It fires, and its PRs can now pass CI** | PR #281 (`actions/checkout` 7.0.0 → 7.0.1) landed minutes after the config, with the SHA matching the real tag and the `# vX.Y.Z` comment rewritten — so the automation and the pin convention are both **proven**, which is what leaving the pin un-bumped bought. It then exposed a real gap: Dependabot branches are same-repo, so the *Require denylist secret* step ran, while Dependabot's token is denied repository secrets | **Fixed the right way** — `SOTA_DENYLIST` added to the **Dependabot** secret store (a separate store from repository secrets; it was empty), *not* by exempting `dependabot[bot]`, which would have re-introduced the silent degradation the step exists to catch. Verified by re-running the PR: invariant 3 passes with the secret injected. Two follow-on facts recorded in `CONTRIBUTING.md`: the value is the **pipe-joined ERE**, and a Dependabot PR opened before a release also trips invariant 5 (`tag ahead of VERSION`) until `gh pr update-branch`. **Dependabot maintains the trailing `# vX.Y.Z` comment but not prose comments** — one went stale for a commit, now fixed by not naming a version there |
| 23 | **Case-set selection rules — CLOSED 2026-08-27. 20/20** | Every `evals/cases/*.jsonl` now states **how its cases were chosen** and whether it is a **measurement** set (a lift may be reported, so cases must never be picked by a model's score) or a **regression** set (selection-by-outcome is the point). Verified by re-count, not memory: 20 of 20, none missing | **Nothing.** Two defects surfaced doing it — `silent-failure.jsonl`'s header still described the **retracted 15-case version** while the file held **81**, and `freshness.yml` carried the stale `actions/checkout v7.0.0` comment the `ci.yml` fix had missed. Both fixed. The rule this practises is `sota-llm-engineering` rules/01 §8 |
| 24 | **Freshness re-authoring cadence — CLOSED 2026-08-27, mechanically** | `scripts/check-freshness.sh` reads an explicit `# AUTHORED:` marker (git dates move under rebase) and **warns** when the newest freshness set is older than the window. **Watched both ways**: warns at 19 months, and **fails closed (exit 1)** when no marker exists | **Nothing.** The 6-month window is **borrowed** from `LAST-VERIFIED`, not derived from decay data — one before/after pair is not a decay rate, and guessing one would be inventing a number. It warns rather than fails because an ageing set still measures a real floor |
| 25 | **Real rules vs inert filler — CLOSED 2026-09-01, both halves null** | Routing half (2026-08-27): padding rebuilt from genuine rules prose with every routing signal stripped scored **0.992 vs base 1.000**, identical to inert filler. Completeness half (2026-09-01): 400 lines of genuine unrelated rules prose added to the with-library arm moved the mean **1.00 → 0.99, −0.01**, six of seven cases unchanged, the single move one criterion of eleven on one case | **The null lands on us, which is why it was worth running.** `sota/rules/02` §1 and the router's BUILD step 2 both asserted that a long context of similar-looking guidance *"measurably reduces how many rules the model applies"* — never measured, and not supported when it finally was. Both corrected; the router edit was prose-only, so `ROUTER_BUILD_SHA` moved after a clause-by-clause re-read with `BUILD_WORKFLOW` verified unaffected. The claim had been generalised from WHY-COMPLETENESS-RESIDUAL, where adding a **relevant** rule hurt — that result stands; the leap to "any extra context costs applied rules" does not. Also re-baselined the treatment arm: **+0.39** (0.61 → 1.00) ([COMPLETENESS-PADDING](../evals/results/2026-09-01/COMPLETENESS-PADDING.md)) |
| 26 | **`§AUDIT` had no drift guard, unlike `§BUILD` — CLOSED 2026-09-01 as invariant 20** | `ROUTER_BUILD_SHA` has pinned §BUILD since v1.15.0 and caught drift twice; §AUDIT had nothing, and `sota/rules/01` §5 said so outright — *"nothing catches this automatically"* | **The parked reason was FALSE when re-read**, which is the lesson. The row said "no eval consumes §AUDIT the way `run-completeness.py` consumes §BUILD", so a gate would be decoration. But `run-repo-audit.py:89` returns `f"{router}\n\n{rules}"` — the **whole router**, §AUDIT included — so an audit eval had been measuring against an unpinned §AUDIT for as long as it has existed. The trigger was met and the ledger never noticed, because a trigger nobody re-tests is a decision that quietly stops being true. The pin lives in `check-invariants.sh`, not in a runner: `run-repo-audit` pastes verbatim and cannot drift, so the drift that matters is **router-vs-rules** — §AUDIT states seven passes whose procedure lives in `sota/rules/01` and `rules/03`. Probed in `check-negative-controls.sh` (**15 of 20** now covered); invariant 19 demanded that probe the moment the check was added, and invariant 17 then named all six documents whose counts had to move |
| 29 | **Verification discipline for agent-produced findings — CLOSED 2026-08-29, opened and written the same day** | Intake from two Anthropic primary sources: the `/security-review` prompt extracted from the CLI (verified current by diffing the 2.0.76 JS bundle against the live 2.1.251 native binary — one line differs in 10.5k chars) and [`anthropics/defending-code-reference-harness`](https://github.com/anthropics/defending-code-reference-harness) (Apache-2.0, every quote checked against the raw README). Five parts, each grep-checked against `skills/` before being called a gap, all five now written: **(a)** a numeric confidence gate and **(b)** a refuter given *less than the finder* with **only the artifact** crossing over → `sota/rules/03` **§4a**; **(c)** N-of-N reproduction for a behavioural finding → `rules/03` §2; **(d)** partition before you fan out, because N unpartitioned agents give one chance N times and the duplication reads as corroboration → `sota-llm-engineering/rules/04` §7; **(e)** the multi-wave yield curve, where a flat count means the waves were not independent → `sota/rules/01` §4, alongside the sharpening that a fix is verified when **a fresh search** cannot get around it | **Deliberately not gated**, per [CONVENTIONS-LEDGER.md](CONVENTIONS-LEDGER.md): all five are judgement conventions, and a threshold a repo cannot mechanically check is prose by definition. The open question this leaves is **whether any of it works** — none of the five is measured, and the honest read is that they are borrowed from two tools Anthropic ships rather than validated here. If an audit eval is ever built, (a) and (c) are the two with an obvious measurable form. The gate earned its keep on the way in: it caught a `rules/12 §7` citation that should have been §2.2 |
| 28 | **A runner can be dead for weeks and nothing reports it — gated 2026-08-27, for two distinct failures** | `run-desc-routing.py` raised before its first API call for three weeks. `evals/smoke-runners.py` now runs in CI and was **watched to fail** on a reintroduction of that bug. It also asserts every runner keeps side effects behind `__main__`, and that every `.env` read is **existence-checked** (that one shipped twice and is unreachable locally — a maintainer's tree has a `.env`; the assertion itself was **vacuous on first draft** and only watching it fail caught that): **the smoke check cannot catch a module-level script itself**, because importing one runs it and that reads as "reached the network" — which is exactly how `run-router-length.py` passed while executing its sweep on import. Two runners were in that state | **Know the ceiling.** It proves a runner can *start* and is import-safe; it does **not** prove the numbers are right — the per-runner selftests and `check-negative-controls.sh` do that. Three runners are still doing local work at the alarm and count as "alive", which is honest but weaker than reaching the network |
| 30 | **ECC second-pass intake, and the first instrument that varies the prompt against the rule — CLOSED 2026-08-31** | [affaan-m/ecc](https://github.com/affaan-m/ecc) read whole at `a104765` (MIT; already a pinned competitor at `ed38744`, where it scored 0.87 to our 0.99). ~6 of 286 skill files carried value. Nine adoptions, three rejections, one deferral — all in [ADOPTION-LOG.md](ADOPTION-LOG.md). The rules: a **required** tool call enforced in the harness rather than asserted in the prompt (`sota-llm-engineering/rules/04` §2 — the *mandatory* twin of `sota-code-security/rules/14` §3, recorded as a correction because my first read called it an uncovered gap and it is not); a loop's **done-criterion written with its boundary** plus reconciliation-over-assertion and a judge the builder cannot edit (rules/04 **§3a**); **memory admission precedence** (rules/04 §5); **ask for a fact, not a judgment** (`sota/rules/02` §4); **collect deterministically, then judge** (`sota/rules/01` §3); a **self-contained verdict reason** and a **blocker-capped summary posture** (`sota/rules/03` §3, §5) | **Measured, not asserted** — `evals/run-prompt-independence.py`, built for this intake. Library lift **+0.083 supportive → +0.236 neutral → +0.431 competing** at one sample; the confirmation run (competing, 3×, temp 0.7) reads **0.491 → 1.000, +0.509**, with the with-library arm perfect in **18 of 18** runs (sd 0.000). The three treated cases move **+0.426** pre→post against a measured sampling noise of **+0.074** on the three byte-identical controls — a ~6× ratio ([PROMPT-INDEPENDENCE](../evals/results/2026-08-31/PROMPT-INDEPENDENCE.md)). All four guards were watched to fail with exit 1 before the first scored run |
| 31 | **WITHDRAWN the same day — a null that did not reproduce** | Item 30's instrument produced an apparent gap on its first run: case `pi05`, under *"just the function please — no tests"*, read **0.67 in all three arms**, suggesting principle 5(c) and principle 9 (*"an unnamed shortcut is not a prototype"*) both failed under pressure. It was written up here as an open item on the strength of **one sample at temperature 0**. The confirmation run at `--samples 3 --temp 0.7` scores the with-library arm **1.00, 3/3**, and the item is withdrawn | **Kept as a row rather than deleted**, because the lesson is the process, not the finding: `sota/rules/03` §2 (*a reproduction you ran once is a coincidence you have not ruled out*) caught this project's own eval within hours, and it was the pre-registered confirmation run — not a re-read — that killed it. The same run corrected a second number: run 1's control ablation of **+0.000** was a temperature-0 artifact, and the instrument's real sampling noise is **+0.074** |
| 32 | **CLOSED 2026-09-07 as MEASURED-AND-UNDERPOWERED — the padding run had the self-audit gate ON, so it measured lean-plus-gate, not lean** | Item 25's completeness half added 400 lines of competing guidance to an arm that also ran step 4, the terminal re-read whose entire job is recovering dropped cross-cutting concerns. So −0.01 supports *"lean plus a terminal re-read is robust to competing context"* and says nothing about context length on its own. The two are worth separating: if the gate is what absorbs it, that is a much stronger argument for step 4 than anything currently published | ~~**First move is cheap and already built**~~ — **that was wrong, corrected 2026-09-06**: `--pad-rules` existed, the `BUILD_WORKFLOW` ablation did **not**, so the row and the priorities table both said *"nothing — the flag exists"* about a flag that had to be written. Third stale trigger found by re-testing rather than trusting, in one session. **Now genuinely built**: `--no-gate-arm` adds a fourth arm and reports `GATE-ABSORPTION`, with two guards watched to fail (it refuses without `--pad-rules`, and refuses if the ablation leaves the prompt byte-identical). Prediction pre-registered with numbers and a falsification condition in [evals/results/2026-09-06/PRE-REGISTRATION.md](../evals/results/2026-09-06/PRE-REGISTRATION.md). **Run 2026-09-06/07: `with` 1.00, `with+pad` 0.97, `pad-nogate` 0.93 → GATE-ABSORPTION +0.04.** By the registered rule H1 needed ≥ +0.05, so **H1 is refuted**; H0's null band was ±0.03, so H0 is unsupported too — **the result lands in the dead zone between my own two bands and is underpowered, not null**. The registered ceiling risk did *not* materialise (`pad-nogate` moved to 0.93), and item 25 replicated (−0.01 → −0.03). Settling it needs n≥3 at temp 0.7, which is **a new experiment with its own pre-registration** — [GATE-ABSORPTION](../evals/results/2026-09-06/GATE-ABSORPTION.md) — the honest one is that the gate absorbs it, which means the un-gated padded arm should drop and the gated one should not. **Do not** fold the result into item 25; it is a different question |
| 33 | **CLOSED 2026-09-06 — the CONVENTIONS-LEDGER's gate tables skipped two invariants** | The ledger has two places a new gate gets a row with its three filters: *Gates added since the ledger was derived* and *Gateable but not gated*. **Invariants 20 and 21 are in neither** (found 2026-09-05 while adding 22's row, which went into the first). The prose list of enforced invariants had drifted the same way and was corrected in the same change. **Done**: three rows written — 20, 21 and 23 — each with its incident, its silence argument and what the gate does *not* check, read out of `check-invariants.sh` rather than from the CHANGELOG. | **The ledger is the document that argues about which conventions earn a gate, so a gate missing from it is the same failure it exists to prevent** — and it is the *third* time this file has drifted from the checks (2026-08-19 heading "(14)", 2026-08-19 missing invariant-17 row, now this). Invariant 17 cannot catch it: it checks stated counts and enumerations in `AGENTS.md`/`CONTRIBUTING.md`, not whether the ledger's *tables* are complete |
| 34 | **CLOSED 2026-09-06 as invariant 23 — CHANGELOG version link refs were gated by nothing** | Cutting v1.32.3 found `[1.31.2]`, `[1.32.0]`, `[1.32.1]` and `[1.32.2]` had **no `[X.Y.Z]: …/releases/tag/vX.Y.Z` link ref** at the bottom of `CHANGELOG.md`, so four consecutive releases rendered their version heading as plain text. Backfilled in that cut. | **Same shape as invariant 21 and a natural sibling**: 21 checks a CHANGELOG version has a *git tag*; nothing checks it has a *link ref*, and the two failure modes are independent. Passes filters 1 (has already failed — four times) and 2 (fails silently — a missing ref renders as text, not an error). Filter 3 is trivial: enumerate `^## \[X.Y.Z\]` headings against `^\[X.Y.Z\]:` refs across `CHANGELOG.md` and both archives, since a heading and its ref must live in the same file. **Built as invariant 23**, and it went further than the row proposed: it compares **sets**, not counts (at build time all three files' heading and ref counts matched exactly, so a count check would have been just as green with two versions swapped), checks the **orphan** direction (a ref whose heading moved — one edit, two defects, no count change), and checks each ref ends in `/releases/tag/v<its own version>`. Watched to fail on all four shapes, including inside an archive file. Probe 23 added; **29 probes, 18 of 23** |
| 35 | **CLOSED 2026-09-06 as invariant 24 — `AGENTS.md`'s own <200-line target was ungated and had already been breached twice** | The file states *"Keep it under 200"* because it symlinks to `CLAUDE.md`/`GEMINI.md` and loads into **every** session, where long always-loaded files reduce adherence. Nothing checks it. It reached **201** on 2026-09-05 (invariant 22's table row) and **202** on 2026-09-06 (invariant 23's), both caught only because a session happened to run `awk 'END{print NR}'` | **All three CONVENTIONS-LEDGER filters pass**: it has already failed (twice in two days), it fails silently (no output changes — the file just gets longer, and invariant 1 deliberately exempts it), and it is trivially checkable. **The counter-argument is in the file itself**: it says *"Ungated, and a different constraint from invariant 1"*, so gating it means editing that sentence too, and picking whether 200 is a hard cap or a target — a gate on a *target* is a category error, and the honest fix may be to restate it as a cap first. **Decided: it is a CAP.** The file already stated it as an imperative with a named escape (move detail to `CONTRIBUTING.md` behind a pointer), which is exactly invariant 1's shape — so the sentence calling it *"ungated, and a different constraint from invariant 1"* was the thing that had to change, not the number. The gate also asserts `CLAUDE.md`/`GEMINI.md` are **still symlinks**, which is `rules/10` §1's proxy question aimed at one of our own gates: the 200 only *matters* while those symlinks make the file load every session, and a cap on a file nobody loads passes forever while its reason has quietly gone. Watched to fail on four shapes (200 exactly, 202, a copy for a symlink, a re-pointed symlink), then **caught its own author on the first run** — adding rows 24 and 25 took the file to 201 |
| 36 | **CLOSED 2026-09-06 as invariant 25 — a new eval capability could ship without reaching `evals/README.md`** | Invariant 14 makes a release declare its front-door terms and resolves them against `README.md` or `docs/INDEX.md` — **not** `evals/README.md`, which is the harness's own front door. `--no-gate-arm` shipped in v1.33.0 documented in the root README's index and the runner's `--help`, and reached `evals/README.md` only because a follow-up sweep looked. The same sweep found that file's ROADMAP-25 entry still ending *"nobody has run it with the gate off"* | **Filters 1 and 2 pass**; filter 3 is the open question. "Did this release add a runner flag, and is it documented where runners are documented?" is checkable — diff `add_argument` names in `evals/*.py` against the strings in `evals/README.md`, the same shape as invariant 16's README-vs-`HOOK_CMD` comparison. **Both options in this row turned out wrong, and measuring/reading is what said so.** The strict form ("every flag is documented") opens red on **27** pre-existing (file, flag) pairs, nearly all generic plumbing — a gate that opens red on things it does not care about is one someone disables. And the "cheaper alternative" of adding `evals/README.md` to invariant 14's resolution set would have made 14 **looser**, since it accepts a term in README *or* INDEX: a third accepted location weakens the gate it was meant to reinforce. Shipped instead as a **ratchet** — the undocumented count may not rise — which **fails closed on an empty scan**, because a drifted regex would otherwise make it pass on every possible input (`rules/11` §2.2a, this repo's newest rule applied to its newest gate) |
| 37 | **CLOSED 2026-09-06 — the negative-control harness could accuse a healthy gate** | CI reported probe 4 a **FALSE PASS** while the probe's own diagnostic printed the expected string out of the same variable. The verdict was `printf ... \| grep -qF -- "$want"`; `grep -q` exits the instant it matches, the shape `check-invariants.sh`'s header warns about. **The signal was never established** — CI-only, 29/29 on macOS in the same commit, and a 400 KB synthetic case would not reproduce it | **Fixed without needing the diagnosis**: both verdicts now match in pure bash with no pipe, so they can fail only on content. Part B's is anchored, so it iterates lines via a here-doc — flattening to a glob would have accepted a match on a *different* line, loosening the probe instead of fixing it. Both matchers were then shown to accept a correct expectation **and reject a wrong one**. The uncomfortable part: this is the harness that proves our gates can fail, and it had run green **6 times** carrying this |
| 38 | **CLOSED 2026-09-08 — priced: ~10.7k tokens per task, +109% on the `SKILL.md` load** | Counted with `POST /v1/messages/count_tokens` (`claude-sonnet-5`) over the `extra` sets of the 2026-09-06 routing run, 22 distinct `SKILL.md`: **mean 10,738 extra tokens/task**, median 11,838, max 20,071; pooled 98,673 gold vs 107,375 over-selected. **Both single-skill controls over-select zero** — the cost is entirely in multi-domain tasks | **The registered rule said *"a few thousand tokens → a router note"*; at ~10.7k it is an order of magnitude past that, so it is not merely a note.** But direction matters and the evidence exists: padded context measured **−0.01** (item 25) and **−0.03** (item 32), so this is a **token/latency/money** cost, not a measured quality one. Deliberately no currency figure — that needs live pricing this library will not hardcode. Floor, not bill: `SKILL.md` only, `rules/*` extra. Write-up: [OVER-SELECTION-COST](../evals/results/2026-09-08/OVER-SELECTION-COST.md) |
| 39 | **CLOSED 2026-09-09 — measured, and the honest prior was wrong** | The one failure mode of the four with a real incident behind it (a liveness-probe rule against a no-`await` async rule in a live build). Never measured until now. `evals/run-conflict-rate.py`: gold-set compositions (no routing call), 17 pairs from 8 multi-skill cases, both skills' full corpus, judge calibrated **in the same batch** (planted contradiction → 1, benign → 0, VOID otherwise). | **Judge-reported 6/17 = 0.353; VERIFIED 3/17 = 0.176.** `--verify` killed **3 of 11** reported conflicts as fabricated quotes — a sentence absent from the file the judge named — and the hand read killed two more. **H1 (conflicts are rare) is REFUTED**: it required a verified rate ≤ 0.10. Survivors: a bare-CIDR NetworkPolicy example in `sota-sandboxing` rules/03 against `sota-network-security`'s *"never a bare CIDR"* non-negotiable; **severity rubrics with no stated precedence** (the router says the finding *format* supersedes per-skill variants and says nothing equivalent for severity); and an unconditional `...rest` spread against *"never spread attacker-influenced objects"*. **It is a CEILING** — the judge saw every rules file of both skills where a session loads lean, and it cannot see the router, which is where conflict resolution lives, so it over-reports exactly the classes the router resolves. Nothing was fixed: repairing them would change what was measured. [Write-up](../evals/results/2026-09-09/CONFLICT-RATE.md) |
| 40 | **CLOSED 2026-09-08 — run, and the honest headline is about our instrument** | `obra/superpowers` @ the pinned `b36e0829` (clone verified at that SHA before any call), 7 completeness cases, build `sonnet-4.6` / blind judge `opus-4.8`, **n=1 per arm, temp 0**: SOTA **0.987**, unguided **0.637**, Superpowers **0.599** — **−0.39 vs SOTA and −0.04 vs unguided**. Against this repo's measured **±0.03** noise floor at n=1, that second number is **no measurable difference from no guidance at all** | **Do not quote it as a win.** The manifest caveat is the finding: Superpowers is *process* guidance and these cases score a *built artifact's* domain coverage, so a low score is evidence about **fit to this measure**. What it settles: the two are not substitutes and not measured by the same yardstick. What it does **not** settle: the assessments' actual claim, that a methodology beats a corpus — measuring that needs an instrument we do not have, and building one to score a competitor is not a neutral act. Write-up: [SUPERPOWERS-HEAD-TO-HEAD](../evals/results/2026-09-08/SUPERPOWERS-HEAD-TO-HEAD.md) |
| 41 | **CLOSED 2026-09-09 — invariant 25 gained a runner half, and the fix this row proposed was the wrong one** | The row asked whether per-(file, flag) documentation was worth building. **It is not, and the defect does not need it.** `evals/README.md` is organised by the *question* each instrument measures, not by runner, so per-runner flag sections are structure it does not have; it would reopen the red-on-27 problem one level down; and *which* flag deserves a mention in which section is the same judgement the check's own header already refuses to mechanise. | **The unit that went missing was the RUNNER, not the (file, flag) pair** — so the check is presence of the runner: every `evals/*.py` must be named in `evals/README.md`, boundary-anchored so `run-build-safe.py` is not credited to a mention of `run-build-safe-arms.py`. No ratchet and no pin: it opened red on exactly **two** files, `run-unscoped-audit.py` and `run-build-safe-arms-guided.py` — both real instruments, both never described at the harness's front door, both fixed in the same change. A gate that opens red on two things it *does* care about is the case [CONVENTIONS-LEDGER](CONVENTIONS-LEDGER.md) argues **for**; the 27-flag one was the case against. Probe **25b**. It then caught `run-conflict-rate.py` the same day, on its first real opportunity |
| 42 | **CLOSED 2026-09-07 (v1.36.0) — `sota-devsecops` rules/03 §3.9 offloaded to `rules/10`** | Opened at the v1.35.2 cut and closed the same day, for the reason it was opened: the cap, not the argument, had chosen two placements in that release. rules/03 **487 → 316**, new `rules/10` **179** | **The reference cost, measured again:** invariant 18 reported **16 findings** — 14 pre-existing refs across 11 files (incl. `scripts/check-invariants.sh`'s own header and two eval runners), 2 in the new file's header — and **6 more files were repointed by hand with no gate report at all**: five outside its scope (`README.md`, `docs/INDEX.md`, `docs/MAINTENANCE.md`, two `evals/cases/*.jsonl`) and one *inside* it, `skills/sota/rules/04-library-map.md`, which resolved **fail-open** because the citation omitted the `rules/` prefix the checker keys on. Two defects the gate could not see: a repointed line in `evals/README.md` that left `rules/03` dangling on the previous line, and a pre-existing `rules/03 §3` in `sota-sandboxing` that resolved nowhere (now §3.4). One reference correctly did **not** move — `sota-mobile` rules/03 §3.9 is that skill's own token-lifecycle section, the fail-open case this repo keeps re-learning. Older rows below that cite `§3.9` mean `rules/10` now; the map is in [ADOPTION-LOG.md](ADOPTION-LOG.md) |
| 43 | **CLOSED 2026-09-10 — H1 confirmed at n=3, temp 0.7** | Item 32 closed as *measured and underpowered*: **+0.04** against a registered **+0.05** and a null band of **±0.03**, which one run at n=1 could not separate. | **GATE-ABSORPTION = +0.062**, SE **0.019** across the 7 case-level differences, **95% CI [+0.024, +0.099] — excluding zero**; six of seven cases positive, none negative, the lone zero at a ceiling. The **+0.05 threshold was carried over unchanged** from the 2026-09-06 registration and deliberately not moved toward the +0.04 already seen, which is the only reason the number means anything. The dead zone was not entered, so the stopping rule did not fire. **The registered noise-band assumption was checked, not assumed** — it derived ±0.02 from the sample count and warned it *plausibly is* wrong at temp 0.7; observed SE 0.019 against an assumed 0.02, so it held (while the within-arm per-sample spread is 0.071 mean / 0.300 worst, which is why n=1 could not resolve this). **One prior claim does not survive**: item 32 said *"item 25 replicates"* on a PAD-DELTA of −0.03; at this power it is **+0.01**, so with the gate on, 400 lines of competing prose cost nothing measurable. First result here to put a CI excluding zero on BUILD step 4. [Write-up](../evals/results/2026-09-09/GATE-ABSORPTION-N3.md) |
| 44 | **CLOSED 2026-09-09 — invariant 29, a release-time declaration** | The decision the row asked for: **not a CI gate on the run** (routing costs live calls, and a gate expensive enough to be disabled is worse than none), and **not nothing**. The check fires only when BOTH hold — a release commit (VERSION changed against the merge base, the same detection invariant 14 uses) **and** the extracted `(name, description)` **map** differs from the base's. Comparing the map rather than the diff is deliberate: a folded description block, a rename and a deletion all change routing without touching a line beginning `description:`. | The escape is `**Routing checked:** <artifact>`, and the artifact must exist **and** mention `desc-routing-regressions` — a declaration that must be TRUE, like invariant 11's. `RELEASING.md` §2c carries the run (~12 calls). **Probe 29b found the check broken on its first build**: the CHANGELOG section was piped to `python3 -` while the script arrived on the same stdin via a heredoc, so the declaration was always empty and a correct release would have been failed. Probe 29 passed on that build, because the no-declaration branch was the only reachable one — the argument for probing **both** sides of an escape hatch. Writing these also killed two stale exemptions: 11 and 14 were declared unprobeable as *"diff-based"*, which was false — a worktree lacks a **commit**, not a merge base, and the harness can make one |
| 45 | **CLOSED 2026-09-09 — verify-setup §F, behavioural and INFO-only** | Both decisions the row asked for. **In remit:** section A already reads `$CLAUDE_HOME`, so this script's subject was never only the repo, and a false absence corrupts every other answer an agent gives afterwards. **Behavioural, not presence:** a four-match fixture under `$TMPDIR` (plain, behind a symlinked dir, `.gitignore`'d, hidden) and one row per searcher naming what it skipped. | Every row is **INFO** — `rg` skipping ignored files is a feature, not a defect — and exactly one branch can FAIL: the **positive control**, since a searcher that cannot find the plain file makes every absence it reports worthless (`sota-shell-scripting` rules/06 §2). `SOTA_SEARCHERS` picks the commands probed and is the seam the negative control uses (a stub that always exits 1, watched to FAIL). The read-only claim in the header is **amended, not quietly broken**. **The first fixture was vacuous**: its behind-a-symlink file also sat inside the searched root, so tools that never follow a symlink passed the row — found an hour later by measuring it by hand, which also **corrected `sota-shell-scripting` rules/06 §2**: BSD grep 2.6.0 (macOS) follows a symlinked dir met in traversal with **neither** `-r` nor `-R`, where the table said `-R` follows. That table had been measured through ugrep and generalised to "grep" |
| 46 | **CLOSED 2026-09-11 — all three fixed, on both sides where there were two** | Held open deliberately: repairing them in the same change would have altered what the measurement measured, so the run and the repair were kept separable. **Each trigger was re-tested against the tree before being touched** and all three were still live. | (a) `sota-sandboxing` rules/03's reference egress NetworkPolicy uses `ipBlock: { cidr: 10.0.5.0/24 }` while `sota-network-security` non-negotiable 3 says allows reference identity, **never a bare CIDR** — and vanilla NetworkPolicy has *no* identity selector for a destination outside the cluster, so one of the two is too broad as written (the router's own resolution: an explicit exception in whichever it is). (b) **Severity rubrics have no stated precedence** — the router says the finding *format* supersedes per-skill variants and says nothing equivalent for severity, while at least four skills ship their own table. (c) `sota-frontend-design` rules/03's unconditional *"forward `...rest`"* against `sota-web-frameworks`' *"never spread attacker-influenced objects"* — a one-clause exception. **(b) is the one worth thinking about before typing**: adding precedence is a router edit, and the router's §AUDIT is pinned by invariant 20  **How each was resolved.** (a) **Both sides.** `sota-sandboxing` rules/03 R3.4's reference egress policy now selects its in-cluster backend by identity (`namespaceSelector` + `podSelector`, validated as parsing to a single AND-ed peer) instead of `ipBlock: 10.0.5.0/24`, because a recycled pod IP silently re-points a CIDR; and `sota-network-security` non-negotiable 3 now says **where** its absolute binds, with the substance in rules/03 §3 R3a — identity in-cluster with no exception, `ipBlock` out-of-cluster as a documented exception, since vanilla NetworkPolicy has no identity selector for an external destination and the rule read literally was unsatisfiable there. Audit halves on both sides, including the tell that an `ipBlock` overlapping the pod/service range is the in-cluster case wearing the exception's clothes. (b) **Cheaper than this row predicted, and the row's premise was wrong.** It warned that precedence *"touches the pinned §AUDIT"*. It does not: the natural home is the same sentence that already supersedes per-skill **format**, which sits in the router **header** — outside `ROUTER_AUDIT_SHA` (`## AUDIT`→`## Library map`), outside `ROUTER_BUILD_SHA` (`## BUILD`→`## AUDIT`) and outside `principle5()`'s live extraction. Verified by running all three guards after the edit: invariant 20 green, mirror guard PASS, principle 5 still 2,838 chars. Router 410 → 415 lines; the reasoning went to `sota/rules/03` §1 as hard rule 5, which also fixed that list's own header saying *"two"* over four items. (c) One clause in `sota-frontend-design` rules/03: `...rest` is the caller's leftover props, never a bag of untrusted data, with the audit half pointed at the **call sites** rather than the component, since the injecting spread is written where the props are built. |
| 47 | **CLOSED 2026-09-12 — measured. Lean floor 0.000 verified; leanness cuts judge-reported conflicts 63%** | ROADMAP 39 measured a **ceiling**: the judge saw every `rules/*.md` of both skills, where BUILD step 2 says load lean. 0.176 verified is the most a session could trip over, not what it does trip over. | Two design questions to settle **before** spending: which rules files a lean session would open (judgement — the honest form is probably the case's own `expect` plus the files each `SKILL.md` index names for that task), and whether the judge should see the **router**. It currently cannot, which is why it over-reported the finding-format and scoped-severity classes the router already resolves — but handing it the router measures a different thing (*does the resolution work?*) and deserves saying so out loud. Needs its own pre-registration  **Result** ([write-up](../evals/results/2026-09-12/CONFLICT-LEAN.md), pre-registered before any call): **full 0.471 judge-reported vs lean 0.176, same tree same day — a 63% reduction — and the lean arm hand-verifies to 0.000 of 17 pairs.** The registered prediction (lean floor near zero, threshold 0.10) is confirmed. **Both parked decisions were settled and reasoned, not deferred again**: lean = `SKILL.md` only, because choosing index-matched rules files is the measurer's judgement and the measurer holds the hypothesis; and the judge stays blind to the router, because that is a different question. **Both arms on the same tree was the design's whole point** — and it earned itself: the full arm's rate went *up* against the 2026-09-09 ceiling (0.353 → 0.471) because the corpus grew by 50k chars, partly from rules added to those same skills hours earlier, so repairs, new content and judge noise are confounded in that pair and no attribution is offered. The same-tree comparison is immune to all three. **All six lean-reported conflicts refute**, in the classes the registration predicted would inflate both arms: two finding-format, three severity precedence, one conflating shell's `check-before-create` (idempotency) with code-security's weak existence check (verification). **The one worth keeping:** the RBAC collision is the first measured case where the severity-precedence rule added in v1.40.2 — adopted *from* the ROADMAP 39 conflict measurement — decides an otherwise-live conflict. **Not established:** the lived rate (it sits between the arms, and neither is it), and the full arm's *verified* rate, which would need eight pairs hand-read and is left blank rather than estimated. **Instrument defects found and worth fixing before the next run:** the runner's caveat line is hardcoded to claim the judge saw every rules file and printed that in the lean run too, and the artifact's `_meta` records neither corpus size nor which arm ran — a run that cannot attribute its own number. |
| 48 | **CLOSED 2026-09-12 — clause shipped, effect measured, and the trigger defect fixed** | Observed twice, both times from *outside* the usual discovery modes, and neither is a trigger defect: the description matched, the rule existed, and it simply was not loaded when the work changed shape. Not gateable — it is agent behaviour, not repo content — so it earns an item, not an invariant. | **Two independent observations.** (a) A session of mine typed zsh one-liners to verify claims while auditing; `sota-shell-scripting` rules/01 §3, router rule 17 and rules/15 §2.2 each covered the exact bug and none was loaded. (b) The `sota-testing` field brief of 2026-09-10 reports invoking the router **once at session start** for a documentation task, loading `sota-docs-workflow`, and never re-routing as the session became campaign execution, process diagnosis and test-lane reading — *"I treated routing as done-for-the-session rather than per-task-shape"*. It declined to call this a library defect and the reviewer agreed. **First move:** decide whether this belongs in the router's own imperatives (a numbered re-route trigger — but the router body is at 410/500 and §AUDIT edits move the pin invariant 20 guards) or in the **re-injection hook** ([CONTEXT-MANAGEMENT.md](CONTEXT-MANAGEMENT.md)), which already fires periodically and is the only surface that can act *after* a session has changed shape. Measure before building: the honest instrument is whether a long session that changes task shape mid-run loads the second skill at all, which is a **routing** eval and the harness for that already exists. **A third observation should raise this to the top of the priorities table** (it used to say *"above item 46"*, which closed 2026-09-11)  **TRIGGER FIRED 2026-09-12 — a third and fourth observation, both in one pair of field reports, and the cheap surface is now built.** (c) The InterdictOps report of 2026-09-12 §1 retracts one of its own proposals and diagnoses it as *"a routing failure — I was doing shell work, loaded `sota-shell-scripting`, and never opened `sota-devsecops/rules/09`. The rule was correct, precise, and unreachable from where I was standing."* (d) **The review of that report committed the same error from the other side**: the claimed gap was verified inside the file the report named and nobody asked which skill *owns* the topic, so a duplicate rule was written and had to be removed. Four observations, three discovery modes, one shape: **the skill set gets fixed by the session's opening frame and never revisited when the work moves.** **Built:** a clause in the re-injection hook — *"Routing is per task SHAPE, not per session: if the work has changed shape since you last routed — different layer or language, or from building to verifying — route again."* That surface was chosen because it is **the only one that fires after a session has changed shape**; a numbered imperative inside the router cannot fix "the router was not re-read". Landed in `install.sh`'s `HOOK_CMD` and the README block together, which invariant 16 holds in lockstep, and the refresh path was verified against a live install: an existing hook is detected as **stale by exact text comparison**, not merely by signature, so `update.sh` offers the new wording rather than reporting "already current". **STILL OPEN, deliberately**, because the item's own instruction was *measure before building* and only half of that is honoured: the clause is cheap and shipped, the **measurement is not done** — whether a long session that changes task shape mid-run loads the second skill at all. That is a routing eval, the harness exists, and it needs live spend and its own pre-registration.  **Measurement DESIGNED 2026-09-12, not yet built — and the honest finding is that the harness does NOT already exist**, contrary to what this row said. `run-desc-routing.py` is single-turn; `run-decay.py` is multi-turn but scores a *build* against a rubric, not a routing choice. The measurement needs a new runner, and here is its design so it can be pre-registered without re-deriving it. **Instrument:** reuse `run-desc-routing.py`'s catalogue and objective name-match scoring — no judge — inside `run-decay.py`'s multi-turn scaffold. **Arms, two, and the control is the point:** (a) **fresh** — a single prompt of task shape B, which is the ceiling and is what `run-desc-routing` already measures; (b) **shifted** — K turns of genuine shape-A work first, *then* the same shape-B prompt. Same prompt, same catalogue, same scoring; the only difference is the conversation in front of it. **Metric:** does the model name the shape-B skill? **ROUTING-SHIFT = fresh − shifted.** A positive value is the effect this item was opened for, measured rather than anecdotal. **Cases:** pairs whose shapes are genuinely different skills, drawn from the four observations — documentation → shell verification (obs. a and c), documentation → test-lane diagnosis (obs. b), shell → CI/gate reproduction (obs. c, the `sota-devsecops` rules/09 §5 miss). **Two risks to register first.** (1) **Ceiling**: `run-desc-routing`'s fresh arm already scores 0.90, so the detectable range is narrow and a null may be a floor effect rather than a result — check the fresh arm before reading the delta. (2) **An eval has no Skill tool**, so this measures *which skill the model says applies*, not whether it loaded one. That is a proxy, it is the same proxy `run-desc-routing` already publishes on, and it must be labelled as such rather than quietly read as behaviour. **Cost:** 2 arms × N cases × 3 samples, with the shifted arm carrying K turns of context.  **MEASURED 2026-09-12** ([write-up](../evals/results/2026-09-12/ROUTING-SHIFT.md)), with the runner built to the design above and pre-registered first. **ROUTING-SHIFT = +0.250** — fresh 0.750 vs shifted 0.500 — which is exactly the registered threshold, and with four cases **one case is 0.25**, so that headline means precisely one case moved. It did: s4, where two turns about building a secure endpoint kept the model on `sota-code-security` after the question had moved to whether an attestation script's self-test proves anything. Real, 3/3 in both arms, thin on its own. **The finding that outranks it, and it contradicts this row's own framing.** The row said *"neither is a trigger defect"*. For case s3 that is **false**: *"the pre-commit hook passes locally but the same check fails in CI on the identical commit"* routes to `sota-shell-scripting` **3/3 in the FRESH arm**, with no prior context at all. Nothing was treated as done-for-the-session — the classifier never pointed at the right skill. The right skill is `sota-devsecops`, whose rules/09 §5 is titled *"The scoped gate is not the gate — reproduce the invocation"*; its `description` contains **neither "pre-commit" nor "local" nor "reproduce"**, while the prompt's surface words (hook, check, passes, locally) are shell words. **This is the same miss that produced the 2026-09-12 retraction** — a session doing shell work that never opened rules/09 and filed a duplicate-rule proposal. It was logged here as a routing-treated-as-done failure; it is a **description** problem that reproduces cold. **Pinned** as `r3_local_vs_ci_gate` in `evals/cases/desc-routing-regressions.jsonl` so it cannot come back unnoticed. **STAYS OPEN** for the fix, which is deliberately not taken here: editing `sota-devsecops`'s description is a routing change touching the entire auto-load classifier, so it needs its own change with invariant 29's declared routing check against that regression set.  **FIXED and verified** ([routing check](../evals/results/2026-09-12/ROUTING-FIX-DEVSECOPS.md)). `sota-devsecops`'s description gained *"and a pre-commit hook that passes locally but fails in CI"* plus the keywords *pre-commit, local vs CI* (915 → 995 chars). Results across three instruments: regression set **0.667 → 1.000** (r3 flips from `sota-shell-scripting` 3/3 to `sota-devsecops` 3/3), the 10-case set **0.900 → 0.900** with `q8_bash_review` still shell 3/3, and routing-shift's fresh arm **0.750 → 1.000**. **The routing check earned itself by catching a regression mid-fix**: the first phrasing said *"a pre-commit hook **or gate**"*, which fixed s3 and **broke s4** — an attestation-script question containing *"after every gate run"* moved to `sota-devsecops` 3/3 in both arms, away from `sota-code-security`. Deleting the two words *"or gate"* (description "gate" count 2 → 1) restored it. **One token moved a case 3/3 in both arms**, and **neither `desc-routing` set caught it** — s4 lives only in `routing-shift.jsonl`, so a check limited to the set invariant 29 names would have shipped it, which is the v1.35.0 pattern precisely. Lesson recorded: run every routing instrument you have, not only the declared one. **The next release must carry `**Routing checked:** evals/results/2026-09-12/ROUTING-FIX-DEVSECOPS.md`** — invariant 29 fires on the version bump. |
| 49 | **CLOSED 2026-09-12 — no decay; and the K=0 anomaly was the rubric, not the model** | The one run ([DECAY](../evals/results/2026-07-13/DECAY.md), 2026-07-14) **bounded** the problem and did not find its edge: guidance at turn 1 held at **1.00** through 30 filler turns against a 0.40 control. It could not find a breaking point because the filler is **smaller than the anchor** — 30 turns = 13,001 chars ≈ 3.2K tokens against an ~18.6K-token guidance block, so there is nothing there to dilute it with. | **This item had no row until 2026-09-11**, which is the point worth recording: four places cite *"roadmap item 5, still open"* for it ([CONTEXT-MANAGEMENT](CONTEXT-MANAGEMENT.md), [RESULTS](../evals/results/RESULTS.md), and DECAY.md twice), and item 5 has meant **the 6-month accuracy sweep** since the ledger was renumbered. So it read as tracked while being untracked, and the citation pointed at a calendar item nobody would connect to it. **Not superseded by items 25 / 32 / 43**, checked 2026-09-11 against the runners rather than the write-ups: those pad a **single prompt** (`run-completeness.py --pad-rules`), this drives **K filler turns** (`run-decay.py`) — distance-in-turns and competition-in-one-context are different questions with different instruments. **First move — and it is not the flag.** DECAY.md says *"the harness is ready for it"*; that is half true. `--depths` exists **and is correctly guarded**: `run-decay.py` refuses `--depths 0,12,60` with *"only 30 filler turns exist; the run would report a depth it never reached"* (watched to fail **and** to pass at 30, 2026-09-11), so the silent-cap hazard was already closed on 2026-08-16. What is missing is **filler content** — scaling up means authoring off-topic turns until they outweigh the anchor, or running a deliberately smaller anchor, and only then spending on the depths.  **First move REVISED 2026-09-12 after measuring both sides, and the blocker turns out to be the wrong one.** Numbers, from the runner rather than the write-up: the anchor (`guidance_text` = `principle5()` + the case's skills files) is **83,958 characters**, the filler is 30 pairs / **12,997** — a ratio of **0.15:1**. Diluting that to even 3:1 by authoring would take roughly **580 filler pairs** at the current 433-char mean. That is not a content backlog, it is a dead end, and it is why this item has sat. **The item's own alternative — 'or running a deliberately smaller anchor' — is the cheap one and nobody had priced it.** A lean anchor (principle 5 plus a single `SKILL.md`, ~3–5k chars) flips the ratio to roughly **3:1** using the filler that already exists, for the cost of one flag. **And it measures the more honest question**: BUILD step 2 says load lean, so a lean anchor is what a real session actually carries — the 84k anchor is a worst case nobody has. Same argument as ROADMAP 47's lean decision, reached independently on the other instrument the same day. **Revised first move:** add `--lean-anchor` to `run-decay.py`, verify the ratio flips before spending, pre-register, then run `--depths 0,12,30` against it. Do **not** author filler.  **RUN 2026-09-12 with `--lean-anchor`, and it produced a finding nobody registered.** ([write-up](../evals/results/2026-09-12/DECAY-LEAN-ANCHOR.md).) The registered headline `DECAY = anchor@K0 − anchor@K30` **could not be computed**, because the anchor arm does not produce a build at K=0 at all. What is measurable: **anchor@K12 = anchor@K30 = 0.80** — no decay across eighteen further turns, now that the filler can actually dilute (**4.12:1**, against the 0.15:1 that made the 2026-07-14 run undetectable by construction). And the lean anchor **works**: 0.80 against a 0.40 control, so the pre-registered void condition (floor effect, gap < 0.20) did not trigger and that null is real. **The unregistered finding, reproduced across two independent runs:** at K=0 the anchor arm returns **~1.2k characters and scores 0.00**, where its own K=12/K=30 builds run 17–23k and the *reminder* arm — differing only by one reminder line on the same probe after the same anchor — returns ~25k and scores **0.80–1.00**. **REMINDER RECOVERY at K=0 = +1.00.** In the one condition where the guidance is the immediately preceding turn, the task is least likely to be performed, and depth *helps*. **Mechanism NOT established** — the plausible reading is that the model answers the guidance conversationally instead of performing the task, but `run-decay.py` stores only `artifact_len` and never the artifact, so the 1.2k response cannot be read. That instrument gap is the blocker for closing this item. **Why it matters beyond the item:** the reminder arm is the eval analogue of the shipped re-injection hook, and this is the first measurement where that mechanism does something large — on the surface ROADMAP 48 chose from separate evidence. **Stays OPEN** for: retaining artifacts in the runner, then reading the 1.2k response and settling the mechanism.  **Resolved by fixing the instrument that was hiding it.** `run-decay.py` retained only `artifact_len`, so a cell that scored 0.00 three times with a ~1.2k response could not be diagnosed. It now retains the artifact (bounded at 8k). The K=0 anchor response reads: *"Before I build, one clarifying question that affects security scope: is rate limiting handled at a gateway in front of this service, or does it need to live in this endpoint? I'll build the full treatment either way…"* — followed by a table stating TLS/HSTS, HMAC-SHA256 verification, idempotency on the provider event ID, structured logging without secrets or PII, and tests. **It is a correct clarifying question, not a failure to answer** — operating principle 2 (stop and ask on security-relevant decisions), principle 9 (ask in one line when genuinely ambiguous) and principle 5 (say so rather than silently omitting) all prescribe exactly that for a money-touching, network-reachable endpoint on untrusted input. **The rubric scored the pause as ten missing requirements.** The other arms confirm it: control had no guidance so it just built (0.40); the reminder arm's text says *review your code **before finishing***, which presupposes finishing, so it built and documented the gateway assumption inline (0.90). Both are correct library behaviour; the rubric can only see one. **Findings: (1) no decay** — anchor@K12 = anchor@K30 = 0.80 with the filler finally able to dilute at 4.12:1; **(2) a completeness-style rubric cannot distinguish "correctly paused to ask" from "omitted the requirement"**, which is a hole in every instrument of that shape and is now recorded; **(3) the claim published here hours earlier — that guidance adjacent to a task suppresses it — is RETRACTED.** It was plausible, it was labelled unverified, and it survived exactly as long as it took to read the evidence the runner had been throwing away. |
| 50 | **CLOSED 2026-09-11 — written as `sota-security-compliance` rules/04 §3a** | Deferred, then executed, then written, all on one day: the ADOPTION-LOG deferral's trigger was **executed** on 2026-09-11 (read `sota-security-compliance` rules/04 in full, 131 lines) instead of re-read, and the gap is real. | **What exists**: rules/04 carries the CVD *obligation* — a published intake (`security.txt`/portal) and a documented handling process under CRA Annex I Part II — and the **outbound** Article 14 clocks (24h / 72h / 14 days / 1 month). rules/03 (SSDF) covers *having* a disclosure process. **What is missing**: the discipline in between — deciding whether an inbound claim is real, reproducible, in-scope and exploitable, and who owns that decision. **Why it matters rather than merely being absent**: Article 14's clock runs from **awareness**, and an unresolved inbound report is precisely the undecided state; rules/04 already says *"a clock that depends on someone happening to notice is already blown"* and then stops one step short of the process that prevents it. **First move:** decide placement before writing — a new `## 6` in rules/04 keeps it beside the clock it feeds (file is at 131 lines, no cap pressure), while a cross-cutting home would have to argue why an intake discipline is not CRA-shaped. **Licence constraint:** the idea came from a CC-BY-SA-4.0 source, so idea classes only — though the gap above was derived from our own rules/04 and needs none of their text.  **Landed:** rules/04 **§3a** (placed after §3, the clocks it feeds, so nothing renumbered and no `§` reference moved), four audit-checklist bullets, the `SKILL.md` rules-index row and non-negotiable 7 — the front door, because a capability that lands only in a rules file reaches nobody. **Anchored on primary sources read this session, not recall:** ISO/IEC **30111:2019** (ed. 2, Oct 2019 — vulnerability *handling*, the internal process) paired with **29147:2018** (disclosure, the external interface), with a freshness note that both are under revision as AWI items. The 2026-specific triage step — **check that the code the report cites exists** — and the published-bar list (human-written summary, self-contained reproducer, affected and earliest versions, ideally a patch, a reachable reporter) come from Daniel Stenberg's *"Do excellent vulnerability reports"* (2026-06-29) and curl's July 2026 intake pause, both read at source. **A figure was deliberately dropped**: search summaries reported curl's confirmed-vulnerability rate falling from >15% to <5%, and the primary blog carries no such number, so it is not in the rule. **Licence:** the idea arrived via a CC-BY-SA-4.0 source and none of its text was needed — the gap was derived from our own rules/04 and the content from independently-read primaries. |
| 51 | **CLOSED 2026-09-11 — the gate now injects a dummy credential and sees past it** | Found 2026-09-11 by running the gate **with** an API key, which CI never has. Not a defect in the gate's logic — it is doing what it says — but its *reachable depth* in CI is bounded by whatever each runner checks first. | **The incident.** `run-prompt-independence.py` — the instrument behind the **+0.509** headline, this library's largest measured lift — could not load its own case file. Its `load_cases` skipped blank lines and `_comment` objects but **not** `#` lines, and it was the only loader in `evals/` that did not; invariant 28 (PR #333, 2026-09-09) then required every case set to declare a `SELECTION RULE`, the header was added as `#` comments, and `json.loads()` raised on line 1 from that commit onward. **A gate added for one purpose broke an instrument, and the gate that exists to catch dead runners was blind at that depth**: `main()` calls `key()` before `load_cases()`, so with no `OPENROUTER_API_KEY` the runner exits at the key check, and `smoke-runners.py` scores a `SystemExit` as *alive* — correctly, since a usage exit is legitimate. Every CI run since #333 was green on a runner that could not start. **Scope, measured rather than assumed:** re-run locally with a key, 21 runners, **exactly one** dead — so the blindness currently hides one defect, not a class of them. **The published +0.509 is NOT invalidated**: the run was 2026-08-31, nine days before the break; what was lost was the ability to re-run it. The loader is fixed (2026-09-11, watched to fail, then to load exactly the 6 cases the headline is over, and the empty-set guard re-checked so the fix did not loosen it). **What is open is the gate**, and it is a design decision, not a bug fix: injecting a dummy key in `smoke-runners.py` would push every runner past its credential check and exercise real local work — deeper coverage, but it changes what a CI job does and could legitimately turn `main` red. Decide before typing.  **Resolution.** `smoke-runners.py` sets `OPENROUTER_API_KEY` to an obvious dummy before importing any runner, deliberately overriding a real one so the gate measures the same depth on CI and on a maintainer's laptop. Safe by construction rather than by luck: `urlopen` is already stubbed, **no runner uses `requests`/`httpx`/`http.client`** (checked, not assumed), every `key()` reads `os.environ` first (checked across all 21), and a fake credential spends nothing if one ever reaches the wire by a path the stub misses — so this is *less* risky than the status quo of maintainers running the gate with a live key. **Watched to fail under CI conditions**, which is the only test that mattered: `.env` moved aside, `OPENROUTER_API_KEY` unset, the loader defect reintroduced — the gate reported `DEAD JSONDecodeError` and exited 1, where the same tree previously printed `ok (exited: OPENROUTER_API_KEY not found)`. Then restored and re-run clean: 21 runners, 0 dead. The feared cost — that deeper reach would turn `main` red — did not materialise, because the one defect it uncovered had already been fixed; that was measured before the change, not hoped for. |
| 52 | **CLOSED 2026-09-11 — it does NOT, and the mechanism is not the one the intake described** | Opened by the `MadAppGang/magus` intake (2026-09-11). Two questions that share one instrument, neither ever asked here: **(a)** the aggregate, and **(b)** whether the trailing `Trigger keywords:` lists pay for themselves. | **Measured this session, and these are ours, not theirs:** 42 descriptions total **37,330 characters** (mean 888, max 1,021 — `sota-detection-engineering`); **40 of 42** carry a `Trigger keywords:`/`Triggers —` list, sitting on average at the **65% mark**, so the lists occupy roughly the **last 35%** of each description — about 13k characters of tail. **Observed, not inferred:** in a 1M-context session the descriptions arrive **complete** — `sota-detection-engineering` and `sota-network-security` tails compared byte-for-byte against disk, both intact. **The claim we could NOT verify** is magus's formula `context_tokens × 4 × listingBudgetFraction (default 0.01)` with over-budget handled by *shortening descriptions rather than dropping skills* — they verified it against Claude Code **2.1.223**; this machine runs **2.1.268** and the CLI is bundled inside another app where the binary could not be located, so it is **unverified here and must not be quoted as fact**. If it does hold, the arithmetic is uncomfortable: 1M context → 40,000-char budget and we fit with ~7% headroom; **200k context → 8,000, and we are 4.7× over** — the tails that carry our trigger vocabulary would be the first thing cut, silently, on the context size most users run. **First move, in order:** (1) settle the mechanism — read it out of the shipped CLI rather than re-deriving it, the same way the `/security-review` prompt was extracted; (2) if it truncates, the aggregate becomes a real number to manage and a candidate gate (per [CONVENTIONS-LEDGER](CONVENTIONS-LEDGER.md): silent — yes; mechanically checkable — the aggregate is, the *budget* is not, since it depends on the consumer's context); (3) A/B the keyword tails with `run-desc-routing.py`, which already A/Bs the same catalogue with and without a description feature, and **pre-register it** — a null would mean 13k characters of every user's listing budget is buying nothing.  **Settled by reading the shipped binary** (`~/.local/share/claude/versions/2.1.268`, 210MB — `~/.local/bin/claude` is a 58-byte stub), not by re-deriving it. **The formula is confirmed**: `budget = Math.max(1, Math.floor((contextTokens ?? 200000) * 4 * skillListingBudgetFraction))`, fraction default **0.01**, **no `Math.min`** — so 200k → 8,000 chars, 1M → 40,000. Ours needs **38,240**. **But the consequence the intake described is wrong**, and this is the part worth keeping: it is *not* a tail-trim across all descriptions. Over budget the entries are **ranked** and the losers render as a bare `- name` with **no description at all** — all-or-nothing per skill. The ranking is `usageCount * max(0.5^(days/7), 0.1)`, so a **never-used skill scores 0 and is dropped first**: a discovery ratchet, invisible because unused and unused because invisible. A *separate* per-skill cap (`skillListingMaxDescChars`, default **1536**) does tail-slice, but no description of ours exceeds it, so it never applies to us — two mechanisms the tool's own warning text calls "truncation" alike. **Confirmed live, and the evidence had been in front of us all session**: roughly **20 of 42** sota skills were listed name-only in the session that found this. **Why the library still works**: the router is used every session so it ranks top and keeps its description, and a name-only skill stays **invocable by name** — which is exactly what the router's routing table does, making always-on routing the mitigation rather than a nicety. What is really lost is *direct* auto-selection when the router has not fired. **Shipped:** README gains the setting (`skillListingBudgetFraction: 0.05` fits all 42 at 200k) with its per-turn cost stated, and `sota-skill-security` rules/03 §1 was **corrected** — it had shipped hours earlier in v1.40.2 saying a cap is enforced by *skip or shorten*, and the third shape is the one that matters. |
| 53 | **CLOSED 2026-09-12 — measured null, and the operator decided to KEEP the tails** | Item 52's second half, reframed by what 52 found. The original question assumed tails get trimmed; they do not. But **total size is now the lever that decides how many skills keep a description at all**, which makes a trailing keyword list a cost paid by every *other* skill in the set, not just by itself. | **Measured inputs:** 42 descriptions, **37,330** chars of text (**38,240** as the listing counts it), **40 of 42** carrying a `Trigger keywords:` tail at roughly the last 35% — about **13k characters**. Cutting them would take the corpus to ~25k, which fits a 200k default budget far better and would let most entries keep a description without any setting change. **The experiment**: `run-desc-routing.py` already A/Bs the same catalogue with and without a description feature — about 12 live calls, so it is a spend decision, and it must be **pre-registered** with the null stated first. **Two confounds to write into the registration**: the runner reads descriptions directly and so measures matching *given* the text, which is **not** the question of whether the text survives the budget; and a null would mean the tails buy nothing *for matching* while still possibly earning their place as documentation. Decide which claim is being tested before spending.  **RUN 2026-09-11 — 180 paid calls, still not answered, and that is the honest state.** Pre-registered, then **amended before the final run with the reason written down first** ([KEYWORD-TAILS](../evals/results/2026-09-11/KEYWORD-TAILS.md)). Runs 1 and 2 agreed exactly (`0.800/0.900`, **Δ −0.100**) and **crossed the registered "tails actively hurt" threshold — and must not be reported that way**: the 95% CI is **[−0.296, +0.096]**, *one* case of ten moved, and that case was wrong twice over. `q7_pod_hardening` expected `sota-kubernetes` for a task that is literally pod-level `securityContext` — which **router rule 9** and `sota-kubernetes`'s **own description** (*"NOT pod-level securityContext/seccomp (sota-sandboxing)"*) both assign to `sota-sandboxing`. The with-keywords arm answered sandboxing **3/3, correct by our own rules, and was scored wrong**; corrected, the same runs read **+0.100 the other way**. And the ablation was **impure**: 2 of 39 descriptions put their cross-reference *after* the keyword list, so the strip removed two features — one of them `sota-kubernetes`, the very skill in the case that moved. **Both defects landed on the single case carrying the whole effect.** Run 3, with the ablation isolated and `q7` relabelled, read **0 of 9 completed cases moved** (q7 now `1.00/1.00`) before **HTTP 402** at case 10 — recorded then as exhausted credit and **corrected 2026-09-12: a provider-side fault, the balance was fine** (key `limit: null`, `/api/v1/key` returns 200). **Not quoted as a result**: the registration fixed the denominator at 10, and q10 read `1.00/1.00` in runs 1–2, so imputing it would be choosing the value that confirms the prediction. **First move now: top up, run the last case, done** — the instrument is fixed and the registration stands. **The deterministic half needs no calls and already stands**: the tails are **12,227 of 37,330 chars (33%)**, and ROADMAP 52 showed the budget drops *whole* descriptions, which is why the question matters at all — and is not what this eval measures.  **ANSWERED 2026-09-11 after the top-up.** The registered denominator was completed by re-running only the case `HTTP 402` had cut short (`q10`, 6 calls, identical settings) and splicing it in — completing a fixed denominator, not choosing between values, and q10 was deliberately *not* imputed earlier even though runs 1–2 made its value predictable. Final: **with 0.900 / without 0.900, Δ +0.000, distractor-pick 0.000 in both, 0 of 10 cases moved, SD 0.000** — inside the registered ±0.03 band, and the pre-registered prediction of a null was right. Detection limit stated: 0/10 bounds the per-case flip rate at ~**0.26** by the rule of three, so this bounds the effect rather than proving it nil. **What remains is a decision, not a measurement**, and the registration said so before the number existed: the tails cost **12,227 of 37,330 chars (33%)**, and under ROADMAP 52 that cost falls on *other* skills, whose whole descriptions get dropped by usage rank. Cutting them takes the corpus to ~25k. The case *for* keeping them is no longer about matching — documentation value, drafting aid, a future model that weights them differently. **If cut, it is a routing change**: 40 `description` fields is the entire auto-load classifier, so invariant 29 applies and the release must declare a routing check.  **Decision, 2026-09-12: keep them.** Recorded here so it is not re-litigated from the null alone — the null is real and it is *not* the reason. Three arguments, in the order that decided it. **(1) Cutting does not fix the thing it was proposed to fix.** At the default fraction on a 200k context the corpus keeps descriptions for **8 of 42** skills with the tails and **12 of 42** without — still broken either way, while `skillListingBudgetFraction` takes it to **42 of 42**. The lever is the setting, which now ships in `install.sh` and is reported by `verify-setup.sh` 1b and the plugin hook. **(2) The null is looser than it looks.** Δ +0.000 with 0 of 10 cases moving bounds the per-case flip rate at only ~**0.26** by the rule of three, on one model and one day — and cutting edits **40 `description` fields**, the entire auto-load classifier, against a 2-case regression set. v1.35.0 showed a *single* description change inverting a regression case and running live for a day. **(3) The tails are not restatement.** Measured: **59% of their 1,322 terms** appear nowhere else in the description. They buy nothing detectable at n=10; that is not the same as being worth nothing. **What would reopen this:** the corpus outgrowing the setting (38,240 of a 56,000 budget at 0.07 — about 17k of headroom), or a tighter null from a larger set. Not the null on its own, which is already in hand. |
| 54 | **CLOSED 2026-09-11 — the plugin now reports the listing budget it cannot set** | Opened because the plugin install path was judged unacceptable as it stood: a plugin user got the default fraction, ~8 of 42 descriptions, and no indication anything was wrong. The brief was explicit — find a reliable solution or drop the plugin as an install option. | **A plugin cannot fix it declaratively, and that was verified rather than assumed.** Against the shipped 2.1.268 binary: settings precedence is `["userSettings","projectSettings","localSettings","flagSettings","policySettings"]` — **no plugin scope** — and a plugin contributes skills, hooks, agents, commands and MCP only. **The engine already detects it and tells nobody**: forcing the condition with `SLASH_COMMAND_TOOL_CHAR_BUDGET` produced `[WARN] Skill listing over budget: 65 skills, 47324 chars > 8000 budget` — written to `~/.claude/debug/` and nowhere else, the *reported-but-never-read* class, and the reason a whole session ran on a crippled listing unnoticed. That run also gave the **true corpus**: 65 skills / 47,324 chars, i.e. our 42 plus **23 bundled skills no script can enumerate**. **Shipped:** a `SessionStart` hook (`scripts/plugin-budget-check.sh`) that measures what it can see, adds the bundled-skill allowance, and reports the numbers plus the exact setting when they do not fit. It **does not write global settings** — that reserves a share of every context window, so it is the user's call, the same *offer, never perform* rule `install.sh` follows. Speaks once per (size, fraction) pair: silent once fixed, audible again if the corpus grows. Five behaviours tested in a disposable config dir — silent when adequate, speaks when not, no nag on repeat, silent after a fix, re-fires when skills are added. **The +25% bundled-skill allowance is no longer a guess**: 38,507 visible estimated 48,134 against the engine's true 47,324, **+1.7% and conservative**. **Verdict: keep the plugin.** Removing it would have helped nobody — the install path works once the fraction is set, and the defect was that the failure was silent, not that it was unfixable. |
| 55 | **CLOSED 2026-09-12 — split at the seam the citations chose; 484 → 230 lines** | rules/10 (silent control failure) sits at **484 of 500 lines**. Two classes have now been placed *elsewhere* specifically to avoid letting the line cap shape the writing, which this library has watched happen twice before. | **The queue, both from field reports:** (a) the **over-firing control** — fires too broadly, degrades the outcome it protects, and appears to work throughout (deferred 2026-09-11, still marked `**DEFERRED —` in the ADOPTION-LOG); (b) the **guard that correctly declines and says nothing** (2026-09-12), which went to `rules/15` §3a — a defensible home, since it is guard-shaped, but not the one the reporter proposed. **The seam is the question, not the split.** Do not split by line count: [pick-a-seam-by-citations] — the reactive split that worked chose its boundary where the file's inbound `§` citations clustered, not where its headings suggested, and broke **zero** references as a result. So the first move is to count inbound citations per section of rules/10 and find where they thin out. Invariant 18 makes the split safe but **not automatic**: 6 of 16 §-refs resolved fail-open last time and 22 bare pointers carried no section at all, so grep explicitly as well as running the gate. **Not urgent** — nothing is broken, and both classes are placed and findable. It becomes urgent the first time something genuinely rules/10-shaped has nowhere to go.  **First move DONE 2026-09-12 — the seam analysis, which is all this item asked for; the split itself is not done and is still not urgent.** Measured inbound `§` citations per section (same-line matches only, `sota-devsecops` rules/10 excluded — it is a different file with the same number): **§1 = 11** citations / 53 lines · **§2 = ~44** / 263 lines · **§3 + §3a = 7** / 23 lines · **§4 = 0** / 38 lines · checklist 71. Total ~62 across the file. **§2 is 54% of the file and carries roughly 70% of the citations**, which settles the shape of the problem: the two candidate seams trade off against each other. **(A)** Move §2 out — takes 263 lines, leaves 222, and requires rewriting **~44** references. **(B)** Move the framing (§1 + §3 + §4, 114 lines) out — rewrites only **~18**, but §1 is the skill's signature idea and the single most-cited section, referenced from the router's own BUILD step 4, so it is the half you least want to move. **Recommendation to whoever does it: (A), despite the churn**, because §2 is a *catalogue* and catalogues are what grow — the two queued classes are both §2-shaped, so seam (B) leaves the pressure exactly where it was. Do it with invariant 18 as the net, and grep bare pointers explicitly as well: last time 6 of 16 §-refs resolved fail-open and 22 carried no section at all. **A methodological note worth more than the numbers:** this count took **three** attempts — a 40-character gap in the pattern matched a neighbouring file's reference, then `\s*` matched across newlines, then `sota-devsecops` rules/10 was conflated with this one. Each was caught by the result being *implausible* (citations to a §5 and §6 that do not exist in a four-section file), never by it being red. That is `rules/15` §2.1's sixth bullet, adopted hours earlier, landing on the session that adopted it.  **Done, and it followed its own analysis rather than the line count.** §2 — the catalogue, 54% of the file and ~70% of its inbound citations — moved to **`rules/16-where-no-ops-hide.md`**. rules/10 keeps the *method* (the falsification question, making degradation loud, the evidence rules) at **230** lines; rules/16 is **292**. Seam (A) was taken despite costing ~44 citation rewrites against seam (B)'s ~18, for the reason recorded before the work: catalogues are what grow, and both classes queued behind this split are §2-shaped, so (B) would have left the pressure exactly where it was. **Section numbers deliberately unchanged across the move** — a file starting at §2 reads oddly, and that is the price of making every citation a pure path substitution (`rules/10 §2.7` → `rules/16 §2.7`) instead of a renumbering checked one reference at a time. 44 rewritten across 11 files by a single same-line regex. **Invariant 18 earned its keep three times in ten minutes**, exactly as [pick-a-seam-by-citations] predicted it would: it **crashed** on the new file until it was `git add`ed (the documented trap), then caught **20 bare `§2.x` pointers** in `.py`, `.sh` and `SKILL.md` that had resolved only because they sat *inside* rules/10 and which no path-substitution could have found, then caught a same-file `§2.10` that does not resolve because its heading is the range `2.10–2.14`. Invariant 6 caught the README file count (312 → 313) in the same pass. **Final state: 29/29 green over 313 skill files / 271 rules files.** |
| 56 | **CLOSED 2026-09-13 — shipped as invariant 30, and the AGENTS.md blocker removed with it** | The class has already failed, silently, for 17 days | `README.md` said *"Eleven classes of defect"* against a list of **26** — correct when written 2026-08-27, fifteen behind when recounted at the v1.41.2 cut, and **nothing could have caught it**: invariant 6 checks counts of the `skills/` tree, invariant 17 only counts that describe the *scripts*. A count whose denominator is a **list in the same document** is mechanically checkable — count `^- \*\*` between the heading and the next one, compare to the number-word — and it passes this repo's three filters (has it failed · silently · mechanically checkable). Cost is not the check, it is the surround: invariant 19 demands a known-bad probe, and **`AGENTS.md` has no line headroom for a 30th invariant's table row** (199/200), so this needs the file restructured first — which is why it is a row and not a commit. **Done the same day**: the 29-row table moved to `docs/INVARIANTS.md` (AGENTS.md 199 → 169), the gate shipped opt-in via a `<!-- count-check: -->` marker after a sweep showed a strict rule would open red on ~200 historical mentions, and probes 30/30b/30c cover the number edited down, the list grown, and every marker deleted. Its first parser caught the real defect with the **wrong diagnostic**, found because probe 30 asserts on the comparison's own wording |
| 27 | **Estimated token counts — CLOSED 2026-08-27. Swept, and the docs were worse than expected** | All 301 skill files measured with `count_tokens`. `docs/CONTEXT-MANAGEMENT.md` claimed *"12 of 297 files exceed ~5,000 tokens"* — the real figure is **132 of 301, an 11× under-count** — and *"exactly one file breaches the recommendation"* is **5 of 41** `SKILL.md` bodies. Both were chars/4-derived, the same heuristic that under-read the router by 60% | **Nothing outstanding.** Corrected in place with the measurements and a note saying why. Standing rule, now in `sota-llm-engineering` rules/02: **if a size claim was not produced by a tokenizer, assume it is wrong by half.** Density across the tree runs ~24–46 tokens/line, so two files of equal length differ ~2× in cost — which is the argument the line cap cannot make |
**Why the as-deployed competitor comparison is rejected (2026-08-16), not deferred.**
Checked against the pinned clones rather than from memory: **ECC ships 889 `SKILL.md`
files with a `.claude-plugin/marketplace.json`, claude-skills ships 777 with
`.claude-plugin/` and `.codex-plugin/`** — so two of the three competitors deploy through
*exactly our own mechanism*, and only awesome-cursorrules differs (257 `.mdc` +
199 `.cursorrules`, glob-loaded). "As deployed" is therefore not three mechanisms; it is
our mechanism over a corpus 20× ours (41 vs 889).

That makes the measurement land on two things we do not want to publish as a claim about
a named third party:

- **Corpus size, not guidance quality.** A larger library is likelier to *have* a
  matching skill and likelier to surface a distractor. Either way the number partly
  measures how big someone else's repo is.
- **A retrieval path we have already measured as saturated.** `run-desc-routing.py` A/Bs
  the description-selection layer and reads **+0.00** ([RESULTS](../evals/results/RESULTS.md) §5).
  Testing competitors through a layer that does not discriminate for *us* cannot produce
  an honest comparative result.

Two further blockers with no neutral resolution: simulating a loader none of them ships
means our simulation choices decide the outcome, while driving real sessions per plugin is
non-deterministic and hard to blind; and a retrieval **miss** (the loader surfaces nothing
relevant) would score as a content zero, which is a real deployment outcome but reads as
rigged when published under our name.

The content-only benchmark stays the claim, and it is deliberately conservative — it turns
*off* SOTA's self-audit forcing function, so a win there is the guidance, not the method.
Its known weakness is that the maintainer hand-picks 4–8 files per competitor; that is
disclosed in [COMPETITOR-BENCHMARK](../evals/results/2026-07-13/COMPETITOR-BENCHMARK.md)
and is a better-understood limitation than the confounds above.

**Release cadence, for reference.** That test (`RELEASING.md` §"Minor or patch?" —
minor = the library gains a surface someone can *use*; patch = the change lives inside
existing surfaces) has produced a run of patches: 1.22.4 through **1.22.9**, none of them
adding a skill, script, or gate. Invariant 14 requires each one to carry a
`**Front door checked:**` line whose terms resolve, and at the 1.22.9 cut it did its job —
the release's own capability (double-entry ledgers, reconciliation) read **zero** in
`README.md` until the cut added the sentence.

**This cycle (PRs #240-242, 2026-08-19) — a brief, a question, and two of my own
errors.** A second field brief plus one operator question about `update.sh`. Carry
forward:

1. **The gate hole came from a *question about a script*, not from reading a rule.**
   "Are pre-commits updated by update.sh?" surfaced that `pre-commit` writes
   `.git/hooks/<type>` only at install time, so a release adding a `pre-push` stage
   reaches every user's config and nobody's hooks — and `verify-setup.sh` check 9
   could not see it, because it counts hook *files* and the pre-commit one is present.
   Now check 9a, with a probe (harness 21 → **22**, still 22/22). The library's
   own gate-scope rule (`devsecops/rules/05` §5.6) predicted this shape a day earlier.
2. **The first cut of check 9a aborted its own script and exited 0.** Under
   `set -euo pipefail` a grep matching nothing takes the whole run with it, so the
   report truncated after check 9 and returned success. Caught by *running* it. If you
   add a check to `verify-setup.sh`, run it against a repo where the new branch matches
   nothing before you trust a green.
3. **Two derived numbers of mine were wrong on first write** — a comparison-table cell
   filled in by symmetry rather than by a command, and a ratio range that contradicted
   the series printed beneath it. Both were caught by re-reading the rendered diff, not
   by any gate, and neither is machine-checkable. Budget a reader's pass over the diff.

**This cycle (PR #236, 2026-08-18) — a session transcript, five for five.** A session
that *applied* the library to Go subprocess sandboxing handed back five proposals; all
five landed, **three of them with a correction**, which is the field-brief pattern
holding at a larger sample (see [ADOPTION-LOG](ADOPTION-LOG.md) 2026-08-18). Three
things worth carrying forward:

1. **The library's own rules had a direction.** `rules/12`'s mutation probe installs the
   *permissive* no-op, `sota-testing` rules/09 §1 says the assertion is refusal "not that
   the happy path works", and `sota-sandboxing` rules/01's probe list was **entirely**
   denial arms. Three independent sites all pointed one way, so a control that blocks
   *everything* passed all of them. When a class is missing, check whether the existing
   rules are asymmetric rather than absent — that shape is invisible to a coverage grep,
   because the rule *is* there.
2. **Both of the transcript's self-reported misses were already ours**, the zsh one
   **twice** (routing rule 17 and `rules/12` §2). A third statement was deliberately not
   written: that is the effect measured in
   [WHY-COMPLETENESS-RESIDUAL](WHY-COMPLETENESS-RESIDUAL.md), where adding the missing
   rule made adherence *worse*. The fix taken was **placement** — a cross-reference at
   the paragraph where the exec call gets written, not another statement of the rule.
3. **Reviewing the rendered diff caught two defects the invariants could not.** A
   comparison table in `rules/12` contained a cell filled in by symmetry rather than by a
   run (a 400 MiB deny arm at a 512 MiB `RLIMIT_DATA` cap — which would have *succeeded*),
   and an "orders of magnitude" claim that the table beneath it contradicted. Both were
   mine, both survived authoring, and neither is machine-checkable. Read the diff as a
   reader, not as the author.

**Closed 2026-08-16 — the instrument audit (PRs #223, #224, #225).** Prediction
[pre-registered and committed before any finding](../evals/results/2026-08-16/PRE-REGISTRATION-INSTRUMENT-AUDIT.md);
it held — **highest severity in `scripts/`, zero findings in `skills/`**. Closed: a
**Critical** data-loss bug in `install.sh` (an altered END marker deleted every user line
below the managed block), invariants 4 and 8 printing `ok` over an empty scope, CI's shell
lint unable to see SC2086, `principle5()` silently emptying the flagship's treatment arm,
`judge-live-build` averaging over survivors, a judge parser that scored 0.00 on a
wrong-shaped reply, unpinned competitor clones, and a negative-control harness that
misreported its own coverage. Probe coverage **6/16 → 11/16** (21/21 mutations caught).

**Still open from that audit, deliberately:** probes for invariants 5, 9, 11, 12, 14 —
each needs state a disposable worktree lacks (a tag, a merge base, an mtime), so they need
a fixture, not another probe. And `run-unscoped-audit`'s scoring was tightened *after* its
+0.00 was published: the number would need a re-run to be strictly comparable (both arms
were at ceiling, so any change lowers both).

**Closed 2026-08-13, both with evidence rather than a tick:**

- **Every eval runner declares its denominator — 12 of 12.** The five that did not
  (`run-adjudication`, `run-competitors`, `run-decay`, `run-desc-routing`,
  `run-silent-open`) now call `note_work` at the point the count is known.
  `run-decay` gets `arm-depth runs`, not `cases`: it drives **one** case across every
  arm × depth, so "cases" would have declared a denominator of 1 for a run that does
  15 units of work — a wrong denominator is worse than none. Verified by executing the
  import from a script in `evals/`, not by reading it, and `test_scoring.py` still
  passes 38 checks.
- **§3.9 tool-table rot: re-checked, none found.** All six named third-party projects
  resolve, none archived, all pushed within four months (`knip` 2026-08-11, `deptry`
  2026-08-12, `cargo-machete` 2026-08-10, `cargo-udeps` 2026-04-29, `composer-unused`
  2026-04-27, `ReferenceTrimmer` 2026-08-12). The rename the file warns about is
  confirmed live — `fpgmaas/deptry` still answers and reports `full_name:
  osprey-oss/deptry` — and the rules file already carries the new name. Checked by
  reading `full_name` back, per the ledger's own lesson that the API follows renames
  silently.

**Closed since the 2026-08-05 cut** (2026-08-11/13, PRs #204, #205, #207):

- **Three rules adopted from an outside implementation's own incident notes** — chained
  partitions and two-directional canonicalization in `sota-code-security/rules/04` §8, a
  fourth guard form in `rules/12` §3, and "a replay harness is not an eval" in
  `sota-llm-engineering/rules/01` §5. Six further findings were checked and **rejected as
  already ours**, which is the signal that made the three worth taking.
- **A leak the leak-check could not see** — a project name sat in two tracked docs for a
  month behind a green invariant 3, because the private list had no pattern for it. Green
  meant "no match", not "clean": `rules/12` §3 in our own machinery. Redacted, both lanes
  extended, and the CI secret **proven live** by a synthetic canary rather than by a real
  name (which would have published to a public log the very thing the control suppresses).
  The two-lane rule and the canary procedure are now in `CONTRIBUTING.md`.

**Closed in the v1.22.x cycle (2026-08-05)** — kept here rather than in the table above,
which is for what is still *actionable*. Numbering is deliberately dropped: these five were
items 8 and 9 across three separate cuts, and re-using the numbers made the table unreadable.

- **Gate the router's library map against `rules/*` files** — shipped as **invariant 15**
  (v1.22.0). Both directions; watched to fail on the real defect (drop `11` from the map)
  and on its inverse before being trusted.
- **A negative control for our own CI** — shipped as `scripts/check-negative-controls.sh`
  (v1.22.0), its own CI job. Injects a known-bad per invariant and requires *the intended
  check* to complain; any other failure is a FALSE PASS.
- **`verify-setup.sh` had 14 checks and no negative control** — closed by part B (v1.22.1):
  a fully-configured fake machine (`CLAUDE_CONFIG_DIR` + throwaway repo + stub `gh`), 10
  probes. Watched to fail: making check 6a always-pass makes the probe report NOT CAUGHT.
- **Gate README's documented hook against `install.sh`'s `HOOK_CMD`** — shipped as
  **invariant 16** (v1.22.2). Parses the fenced JSON rather than regexing the string.
  Watched to fail four ways, including both fail-closed cases.
- **Two CI jobs ran but could not block** — fixed (v1.22.3): all four jobs are now required
  checks. Watched to *block*: a PR with only `Negative controls` failing went
  **UNSTABLE → BLOCKED** across the change, and a real merge attempt was refused.

**Explicit do-nots** (each has a recorded reason — do not re-litigate): another
audit-recall instrument · a synthetic large-repo fixture · rebuilding the BUILD-safe
instrument · relocating the remaining ~18 judgment conventions · running the
`reimplement` set · splitting long `rules/*.md` **for navigability** · adding a TOC to
rules files · a SessionStart version check that phones home · `gh-sota`.

**One do-not needed narrowing (2026-08-05).** "Splitting long `rules/*.md`" was
recorded against the *TOC/navigability* question — agents read files whole, so
splitting buys no retrieval benefit. It never covered the **500-line invariant**, which
is a hard cap and a different reason entirely; v1.21.1 split the inert-control family
into `rules/10`/`11`/`12` when the first two reached 493 and 495. Splitting for the cap
is fine; splitting to help a reader navigate is still not.

## The v1.22.0 cycle — closed *(written 2026-08-05, kept for the mechanism)*

**The v1.22.0 cycle — activation, and gates that prove they can fail.** Two threads
closed and one opened:

1. **Activation is defense 0, and it was broken.** A real ~25-turn session invoked
   **zero** `sota-*` skills; the router body was never read, so its content was
   irrelevant. Only the frontmatter `description` auto-loads, which makes it the whole
   trigger classifier. The old verbs assumed you own the codebase; non-owned-code
   triggers (PR review, diff, upstream contribution) are now in, paid for by cutting the
   31-domain enumeration. Full mechanism and the three causes:
   [CONTEXT-MANAGEMENT § the precondition](CONTEXT-MANAGEMENT.md).
2. **Structure beat repetition, which is the transferable finding.** The re-injected
   hook had two numbered rules and one subordinate clause. The numbered rules were
   obeyed every turn; the clause was dropped every turn. Same text, same repetition.
   Defense 5 works on *grammatical form*, not on presence.
3. **Both v1.21.1 gate candidates shipped** — invariant 15 (router library map vs rules
   files) and `check-negative-controls.sh`. The harness found a defect in *itself* on
   its first run, which is the argument for its FALSE-PASS assertion.
4. **Still unmeasured, and must stay labelled so.** Nothing in v1.22.0 has an efficacy
   number. `desc-routing` reads +0.00 (saturated) and cannot distinguish two
   descriptions; the AUDIT arm remains +0.00 across seven instruments.

**The previous cycle (v1.21.1, 2026-08-04/05).** An external inert-control audit
spec (seven classes) and two commissioned research reports were taken in; the
inert-control family became three files. What a next session should carry forward:

1. **The recurring gap shape is "the rule without the probe."** Three of four gaps in
   the first intake, and three of four in the second, were cases where the library
   *stated the BUILD rule* and never wrote the **AUDIT probe** — "unit tests touch no
   sockets" appeared in three places with no way to find out that they do. When
   evaluating a proposal, grep the rule first (it is usually there, often more than
   once), then ask separately whether anything says how to *detect the violation*.
2. **Research reports land ~4 of 13, and their citations are the liability.** One
   report misquoted NIST SSDF PO.3.3 by folding a footnote into the clause, and
   over-generalised a formal-verification statistic from hardware to software. Extract
   the primary document and grep it yourself; read abstracts, never search summaries
   (one rendered EvoMap's "84% of approved **assets**" as "84% of **agents**").
   Where a source is paywalled (IEC 61508 clauses) or unreachable (EUR-Lex returned
   only recitals for the CRA annexes), name the *concept* and say in the file that the
   clause number is unverified. Full detail: [ADOPTION-LOG](ADOPTION-LOG.md) 2026-08-05.
3. **Two gate candidates arrived from incidents** — now #8 and #9 above. Both were
   found by *doing the work*, which is what the ledger predicted would happen once the
   written-conventions backlog emptied.
4. **Still unmeasured, and must stay labelled so.** Nothing in v1.21.1 has an efficacy
   number. The AUDIT arm remains at +0.00 across seven instruments; none of this
   changes that, and none of it may be cited as if it did.

**The previous cycle's research (2026-08-02/03).** Four questions were answered
with evidence rather than reasoning, and three of the four answers were *"don't do the
thing"*:

1. **Do long rules files need a table of contents?** No — planted-canary test across 4
   arms including a positive control and a 1,719-line stress file; every arm retrieved
   it, agents read files whole. 242-file sweep cancelled.
   ([CONTEXT-MANAGEMENT](CONTEXT-MANAGEMENT.md))
2. **What size limits actually govern this library?** Verified against three official
   sources; one decision table now settles it. Hard limits are frontmatter only; the
   500-line cap is a *loose proxy* for a ~5k-token recommendation (density varies 3.3×).
   ([CONTEXT-MANAGEMENT](CONTEXT-MANAGEMENT.md) → *Size limits*)
3. **Can a synthetic large-repo fixture test audit skill?** No, demonstrated twice —
   a planted defect is by construction a deviation from filler, found mechanically.
   ([BIG-REPO-AUDIT](../evals/results/2026-08-03/BIG-REPO-AUDIT.md))
4. **Can §2b's front-door check be gated?** Yes — not by gating *discovery* (judgement)
   but by gating the *declaration*, invariant 11's pattern. Shipped as invariant 14.

**Latest cycle (2026-08-02/03, PRs #174–#188).** Two invariants and a diagram, from a
**fifth** discovery mode: *writing marketing copy about the repo forced a look at a
surface nobody reads from inside it.* Drafting a LinkedIn post about what shipped
since v1.0.0 led to the how-it-works diagram, and the diagram turned out to be
**stale against its own source** — #173 had fixed the line-cap wording in
`assets/how-it-works.html` and never re-rendered `how-it-works.png`, so `main` served
the old claim all day while the diff, the commit message and the CHANGELOG all read
as done. Landed: the render + a diagram that finally shows the *loop* the README
argues for (#174), **invariant 12** — a rendered asset is never older than its source
(#175), and **invariant 13** — every scoreboard row declares its sample size (#176),
which closes the ledger's last actionable candidate.

The generalisable finding is in [CONVENTIONS-LEDGER.md](CONVENTIONS-LEDGER.md)
finding 2b: **invariant 12's convention appeared in none of the five documents the
ledger extracts from.** It was *unwritten*, not merely ungated, and a method that
matches the repo's convention format is structurally blind to that class. So "the
gateable set is small" bounds the **documented** set only — re-deriving the ledger
will not find the next invariant 12, and only an incident will.

**Prior cycle (2026-08-01, v1.19.9 — "counted as a layer").** A **fourth** discovery
mode, after external repos (v1.19.1–2), running the library ourselves (v1.19.3–6),
and a user-authored audit prompt (v1.19.7): **a separate agent session applying the
library to its own problem handed back three proposed additions, each citing our
`file:line`.** Two were adopted — `sota-code-security` rules/08 §1 (a same-class
checker is not an independent layer; common-cause failure, and escalate-only cascades
fail *deductively* because a tier seeing only the primary's *uncertain* inputs cannot
see a confidently-wrong one) and rules/04 §8 (a TEE does not fix a **completeness**
gap; "never recorded" is liveness, outside the CC guarantee). The third — a vendor API
reporting `confidentialCompute: true` over a box with CC off — was **rejected: already
covered** by `rules/16` §2.2 (line 102, *"check the shipped artifact, not the
checkout"*) and §2.11. All three are in [ADOPTION-LOG.md](ADOPTION-LOG.md).
**Not measured — do not cite a lift.**

Two process notes from the cut. The §2b front-door grep returned **0 hits** for every
term this release added, exactly as at v1.19.7 — the second consecutive cycle where
capabilities landed in rules files with no front-door sentence, which is evidence the
habit does not stick without the gate that §2b still lacks. Fixed by extending the
README's audit-class list from seven classes to eight. And the two adoption rows were
first stamped `· [Unreleased]`, which the pre-tag checklist's `grep -n '· unreleased'`
**would not have matched** (case and brackets); the grep is now case-insensitive and
bracket-tolerant. A checklist item that silently matches nothing is the same class the
release itself is about.

**Prior cycle (2026-07-30, v1.19.7 — "inert dependency").** One release, from a
**third** discovery mode: not an external repo (v1.19.1–2) and not us running the
library (v1.19.3–6), but a **user-authored audit prompt aimed at the library's
coverage**, with CVEs and versions explicitly ruled out of scope. Under that
exclusion, 5 of its 6 requirements had no home — `rules/03-dependencies.md`
answered "is what we ship vulnerable" from end to end and never "is this
dependency reached at all" (all eight `reachab*` mentions in the file were
CVE-triage reachability). Landed: `sota-devsecops` rules/03 **§3.9
declared-but-not-reached** (entrypoint tracing incl. the impossible-path trap,
per-ecosystem tools each with its documented blind spot, **deletion-as-proof**,
leverage ratio, `gh api` upstream health, A–D taxonomy), cross-refs into the four
language skills with partial or zero coverage, and 8 rows + an entry in
[ADOPTION-LOG.md](ADOPTION-LOG.md). **Not measured — do not cite a lift.**

Two rules came out of *validating* that section rather than writing it: `gh api`
follows repo renames silently (so a 200 under a manifest's URL is not evidence the
project is still there), and where an ecosystem has no established tool (Ruby;
.NET is thin) the honest instruction is to skip the tool and go straight to the
deletion proof. Four first-draft claims were wrong and were corrected against
primary sources; one (`pushed_at` "moves on any branch push") could not be
confirmed and was **dropped** rather than shipped.

**Also this cycle: the README's audit half was invisible.** Grep on `main` before
the cut returned **0 hits** for `adversarial`, `refut`, `decision ledger`, `inert`,
`no-op`, and `ADOPTION-LOG` — five capabilities shipped across v1.17.0–v1.19.7 that
no reader could find from the front door, and "How it works" still described a
five-step audit chain that predated three of its own passes. Fixed with a new
README section carrying its own +0.00 caveat. The generalisable finding is below.

**Prior cycle (2026-07-28, after v1.19.6).** Six patch releases landed
2026-07-24…28 (**v1.19.1 → v1.19.6**), and the notable shift is *how* they were
found: v1.19.1–2 came from reading external repos, v1.19.3–6 from **running the
library and watching it fail**. Landed: three external intakes recorded in
[ADOPTION-LOG.md](ADOPTION-LOG.md) (training-knowledge-vault, swarm-forge,
claude-project-scaffold) with rejections logged alongside adoptions; the
**day-zero** work (router section + `rules/01` §10 + host-capability report +
agent-hooks-must-not-rewrite); [VERIFY-SETUP.md](VERIFY-SETUP.md), a read-only
setup-check prompt; **invariants 8 and 9** (internal-link resolution;
single-`[Unreleased]`); `sota-code-security` rules/10 **§2.13 a control that
never executes**; `sota-docs-workflow` rules/01 §7 **verify an agent file's
claims, not just its commands**; and the **liveness/async-def contradiction**
between two of our own rules, plus the router rule for resolving such conflicts.
All six are content/CI changes — **none measured**, none claiming a lift.

**Field validation this cycle (n=1 per arm, not a measurement).** The day-zero
trigger fired correctly on a purpose-built fresh repo (one throwaway checkout:
1 commit, no gates/licence/agent file) — once, in a line, offering rather than
running the scripts, and the build proceeded. It stayed correctly silent on a
mature 4304-commit repo. **It only fires when the `sota` router actually loads**:
a vague three-word prompt routed to clarifying questions instead and skipped it.
Silence is therefore not evidence the rule is broken — check the router loaded
first.

**New open items from the 2026-07-31 cycle:**

- ~~**One gateable convention remains ungated: every scoreboard row must declare its
  sample size.**~~ **CLOSED 2026-08-02 — shipped as invariant 13.** Surfaced by
  [CONVENTIONS-LEDGER.md](CONVENTIONS-LEDGER.md), which extracted **41 distinct
  conventions** from the five agent-facing docs and found **11 enforced as invariants
  plus 4 more enforced inside the eval runners** — so reading `check-invariants.sh`
  alone undercounts enforcement by about a third. Applying three filters left exactly
  **one** actionable candidate against a predicted 2–4, and it was a **regression
  guard** rather than a repair: all 10 rows already populated the Samples column. The
  implementation finds the table by its `Samples` **header** rather than a column
  index, so renaming or dropping the column fails closed instead of passing over zero
  rows. **The actionable set from written conventions is now empty.**
- ~~**`RELEASING.md` §2b's front-door grep stays blocked**~~ **CLOSED 2026-08-02 —
  shipped as invariant 14.** It was blocked on *"needs a machine-readable capability
  list per release"*, which was true and still is: **discovery cannot be gated**,
  because what counts as a capability is judgement. What *can* be gated is the
  **declaration** — the same move invariant 11 makes for `LAST-VERIFIED`. A release
  states its front-door terms and the gate proves each resolves, in
  `README.md`/`docs/INDEX.md` **and** in the release's own entry. Fires only when
  `VERSION` changes, so ordinary PRs are untouched. **The actionable set from
  written conventions is now empty** — the next gate will come from an incident,
  not from re-reading the docs.
- **CLOSED 2026-08-02: long rules files do NOT need a table of contents.** The
  skill-authoring guidance recommends one for reference files over 100 lines
  *"even when previewing with partial reads"*, and 242 of ours qualify with none.
  Tested with a planted canary across four arms (control / TOC / positive control /
  4× stress at 1,719 lines): **every arm retrieved it, every agent read the file
  whole, and the positive control showed no depth effect for a TOC to correct**.
  The sweep is not justified. *n*=1 per arm — a pilot, not on the scoreboard; it
  covers direct `Read` calls, while the guidance's stated trigger is *nested*
  references, which this library does not use. Detail:
  [CONTEXT-MANAGEMENT.md](CONTEXT-MANAGEMENT.md).
- **NEW 2026-08-02: the router is 2× the spec's token budget, and invariant 1 cannot
  see it.** The Agent Skills spec states the budget in **tokens** — *"Instructions
  (< 5000 tokens recommended)"* — and enforces nothing; invariant 1 checks the
  *line* half because lines are cheap to count. Measured across 297 skill files,
  line density varies **3.3×** (38–127 bytes/line), so a 500-line file lands
  anywhere between ~4,750 and ~15,870 tokens. **12 files already exceed ~5,000
  tokens and 11 of them pass invariant 1 comfortably.** Exactly one breaches the
  recommendation where it applies (the `SKILL.md` body): `skills/sota/SKILL.md` at
  **~10,211 tokens**, at 500/500 lines with no slack. It matters twice over —
  context cost, and Claude Code's compaction keeps only *"the first 5,000 tokens"*
  of a re-attached skill, so half the router would not survive a summarization.
  - A byte-or-token check passes all three ledger filters but **would fail on `main`
    today**, and the only fix is trimming the router — a design decision, not a
    mechanical one. The pre-existing trim candidates are recorded below (the
    per-domain pass ordering in AUDIT step 3, the duplicated severity glossary in
    step 6).
  - **Unverified in practice**: `bytes/4` is a heuristic and the real tokenizer will
    differ. Measure with a real tokenizer before acting on any specific number.
  - Detail and the measurement table:
    [CONTEXT-MANAGEMENT.md](CONTEXT-MANAGEMENT.md).
- **The reimplement case set is documentation, never run**
  (`evals/cases/reimplement.jsonl`). If anyone ever runs it, the predictions written
  *before* any run exist in the case-file header and must be used rather than fresh
  ones. A null there is the **eighth** and the recorded conclusion is to stop, not
  to author a ninth.
- **The remaining ~18 judgment conventions were deliberately not relocated.** Three
  with an identifiable point of use were moved 2026-07-31 (the stamp file, the
  invariant script's "adding a check?" block, the live-agent runners). The rest —
  *verify every claim* chief among them — apply everywhere, which is why they cannot
  be moved and must stay principles. Do not "finish" this by relocating the other 18.

**New open items from the 2026-07-30 cycle:**

- ~~**Does the rewritten build-safe spec discriminate?**~~ **Tested 2026-07-31: no.**
  Two bare agents on the thin spec scored **1.000 / 1.000** — five bare builds across
  two spec versions, all at ceiling. These seven classes are **not elicitable from a
  spec** at this model tier. The useful residue is a distinction, not a number:
  the +0.39 comes from **cross-cutting omissions** under a one-sentence prompt
  (rate limiting, logging, TLS, tests), whereas these are **local correctness
  decisions inside a feature the model is actively writing**, and it makes them
  well. Defect-avoidance and practice-completeness are different targets; only the
  second has ever shown a gap. **Do not rebuild this instrument.** Original entry: `SPEC.md` was rewritten the same day to *state features and facts,
  never the property to preserve* (verified: zero "must …" quality clauses, zero
  defect names, all six product tensions intact). Whether that restores discriminating
  power is untested: if the bare arm still scores 1.000, these classes may not be
  elicitable from a spec at all, and that is the finding. **Do not cite a build-safe
  number until the pilot lands and is scored.**

  **CROSS-MODEL 2026-08-21 — the headline does not replicate, and that qualifies it.**
  On `openai/gpt-5.1` the *unguided* arm scores **1.000 × 3**: it does not write these
  defects, so there is no headroom and Δ avoided is **+0.000** (sonnet-4.6: +0.191). The
  stricter *with-positive-evidence* measure moves on both (+0.333 / +0.095) because
  neither bare arm saturates there. Same law the breadth test found for completeness —
  **the lead tracks the unguided baseline**, here not the domain but the model. README,
  WHY-IT-WORKS and the scoreboard were all re-qualified the same day rather than left
  implying generality.

  **NEXT, and it is a new instrument not a re-run: a second TASK.** Three of the seven
  `fail` patterns are domain-specific (`ORDER BY {sort}`, the quota-handler registration,
  the role-revocation cache), so a second domain needs new patterns **plus its own
  known-bad and known-good references validated to separate** before any number from it
  counts. Deliberately not rushed: an unvalidated instrument produces numbers, not
  measurements.

  **RUN 2026-08-21 — the bare arm did NOT saturate, so the instrument discriminates.**
  Unguided 0.714 / 0.714 / 1.000 (mean **0.809**); with-library 1.000 × 3. Δ avoided
  **+0.19**, Δ avoided-with-safe-evidence **+0.33**. The two classes the unguided arm
  actually wrote were `sqli_sort` and `idor_get_report`. Full method, per-run scores and
  the six limits that bound the claim:
  [results/2026-08-21/BUILD-SAFE.md](../evals/results/2026-08-21/BUILD-SAFE.md). The
  treated arm is at **ceiling**, so the delta is bounded by the instrument, and prompt
  length is an **uncontrolled confound** — both stated there rather than implied.

  **Prior state (kept for the record): ready to run, blocked only on producing the two builds.**
  Verified rather than assumed — `run-build-safe.py` is a **scorer, not a generator** (it
  grades a `--build` directory and makes no model calls), and its `--selftest` passes with
  the two references separating cleanly: **0.000 on the known-bad (`reportkit`), 1.000 on
  the known-good (`reference-safe`)**. The case file's 49 lines are 42 comments and **7
  real cases**, and `load_cases` exits rather than score an empty set. `SPEC.md`
  re-checked: **zero** "must …" quality clauses, so the rewrite held. What is missing is
  one bare-arm and one library-arm build from that spec — model spend, and therefore an
  owner's decision rather than a scripting task.
- **Calibration — MEASURED 2026-08-21, deliberately kept out of the headline scoreboard.**
  Blinded judge validated on both controls first (mis-calibrated report 0/4,
  well-calibrated 4/4). Unguided 3/3/2 (mean **2.67/4**); with-library 4/4/4 (**4.00/4**).
  The mover is *conditioning severity on evidence*: **1/3 → 3/3**. Per the original
  entry's own instruction this is **not reported as a lift** — it measures adherence to
  our own doctrine. Write-up:
  [results/2026-08-21/BUILD-SAFE.md](../evals/results/2026-08-21/BUILD-SAFE.md).
- **Original entry — calibration was the only untested claim about the audit half.** Across four
  settings today, every library arm downgraded its own findings on evidence, bounded
  claims by what it had actually run, and labelled what it had not verified; no bare
  arm did. Nothing in the harness scores that. An instrument would measure adherence
  to our own reporting doctrine — a far weaker claim than "finds more bugs" — so if
  it is ever built, it must not be reported as a lift.

- ~~**The BUILD-safe eval needs a thinner spec before it measures anything.**~~
  **SUPERSEDED 2026-07-31** — the thinner spec was written *and* tested, and it did
  not discriminate either (see the closed item above). Kept for the diagnosis it
  records; the remedy it proposes is done and did not work.
  Built 2026-07-30 to test whether the library stops these defect classes being
  *written* rather than found. The bare arm scored **1.000 (n=3, verified
  library-free)** — ceiling, so no lift is measurable
  ([BUILD-SAFE](../evals/results/2026-07-30/BUILD-SAFE.md)). Cause is mine: the
  spec states the non-functional property to defend ("expect the change to take
  effect", "must never take the endpoint down"), which is the audit-vocabulary
  leak in a new costume — it supplies the consideration set. Fix: state the
  feature, not the requirement, and let the safety judgment come from the model.
  The fixture, scorer, and two references are reusable as-is; only SPEC.md needs
  rewriting. **Not on the scoreboard — it is an instrument failure, not a null.**

- ~~**Our own gates now report a denominator — the rest of the automation does
  not.**~~ **Done 2026-07-30.** `check-freshness.sh` now exits 1 on an empty scope
  (it printed the denominator but never failed on it); `evals/test_scoring.py`
  now prints `(25 checks)` — the floor has since risen to **38** — and fails below
  it, watched to fail by simulating
  an early return (`only 17 ran, expected at least 25`). One suspicion was
  **REFUTED** and recorded: CI's `shellcheck scripts/*.sh` fails loudly on an
  unmatched glob in bash (exit 2), so there was nothing to fix. ~~Still unexamined:
  what gitleaks reports as its scope over the full history.~~ **Examined
  2026-08-02 — it reports a denominator and nobody read it.** gitleaks prints
  `179 commits scanned`; measured in a `--depth 1` clone of this repo it scans
  **1 of 179**, prints `no leaks found`, and **exits 0** — a green secret scan over
  0.5% of history, with `fetch-depth: 0` the only thing preventing it and nothing
  asserting that. CI now asserts the scope. The assertion keys on
  `git rev-parse --is-shallow-repository`, **not** on a commit count, for a reason
  worth keeping: `git rev-list --count HEAD` truncates to 1 in the same clone, so
  it degrades alongside the scan it would be checking — and the three available
  numbers disagree anyway (rev-list HEAD 175, rev-list --all 181, gitleaks 179),
  so any equality test would be flaky. It also fails if gitleaks stops printing the
  line at all, since an unparsable output means the scope is no longer verified.
- ~~**Duration is not recorded for any of our automation.**~~ **DONE 2026-08-03.**
  The remaining half — no recorded baseline — is closed: `_elapsed.py` appends every
  run to a git-ignored `evals/results/durations.tsv` and the next run of the same
  runner prints the delta, flagging a swing of ≥ 5×. §2.1's tell is a *comparison*,
  so printing alone never sufficed. Denominators matter as much as the seconds
  ("12s over 7 cases", not "12s"): **7 of 12 runners declare one** *(as of 2026-08-03; there are **19** runners as of 2026-09-01, so re-count before quoting this)*, the rest record
  `-` and are labelled weak evidence rather than silently compared. The ledger is
  machine-local by design — a duration is only comparable on the same machine and
  network. **The CI half needed nothing**: the GitHub API already exposes
  `started_at`/`completed_at` per step (verified). Original entry: **Partly done
  2026-07-30.** `check-invariants.sh` prints wall time with its denominators
  (`10 checks over 297 skill files / 256 rules files, 10s`). Deliberately printed
  and **not gated** — a duration threshold in CI is flaky under runner variance,
  and a flaky gate gets disabled. **The runner half is done 2026-08-02**: all 13
  runners now print `[<runner> elapsed 12.3s]` via `evals/_elapsed.py`, registered
  with `atexit` so the line survives the `sys.exit(...)` several of them use on an
  empty corpus — the fast-exit case most worth timing. To **stderr**, so a runner
  whose stdout is piped or parsed is not handed an extra line. Printed, never
  gated: these call a remote API whose latency is not ours. **Still open**: no
  recorded baseline to compare a future run against, so "it got 30× faster" is
  still visible only to a human reading two logs.
- ~~**The dead-path eval has never been run against a live agent.**~~ **Run
  2026-07-30 — and the hypothesis was wrong.** Six local sub-agents, 3 per arm:
  **both arms 1.000/1.000, +0.00**. The pre-registered prediction ("a bare agent
  reasons and scores ~0.25 verdict / 0.00 proof") is **refuted** — the bare agents
  worked in scratch copies, mutated the controls, deleted the modules, ran
  `trace.Trace`, and one used `dis` to spot the discarded return, none of it
  requested. So "these instruments score recognition, not procedure" no longer
  explains the audit family's saturation
  ([DEAD-PATH](../evals/results/2026-07-30/DEAD-PATH.md)). The arms differ only in
  reporting discipline (ACTIVE/LATENT labels 0/3 vs 3/3, bounded claims 0/3 vs
  3/3, decision-boundary fix-risk 0/3 vs 3/3) — post-hoc, partly tautological
  since the library arm was told to use that vocabulary, and **not a lift**.
- ~~**Where the audit frontier actually is, after that null.**~~ **Both readings
  tested 2026-07-30 and both are dead** ([UNSCOPED-AUDIT](../evals/results/2026-07-30/UNSCOPED-AUDIT.md)):
  stripping the answer vocabulary changed nothing (A), and unusual defect classes
  under an unscoped brief changed nothing (B) — verified-clean bare agents scored
  1.000 on both. **Do not build another audit-recall instrument.** The one
  untested claim is *calibration*: every library arm downgraded its own findings
  on evidence and bounded claims by what it had run; no bare arm did. Measurable,
  but it measures adherence to our own doctrine — a far weaker claim than "finds
  more bugs", and not to be reported as a lift. **Effort moves to BUILD**, which
  is where the measured lift is (+0.39 completeness, +0.53 freshness).
  Original framing kept below for the record.

  Two readings survived the dead-path null and neither is tested. (a) *The brief did the work*: naming four suspects and
  demanding a `PROOF` field is a strong nudge; a genuinely unscoped "audit this
  repo" over a large tree might separate the arms — this run is weak evidence for
  prioritising the **agentic large-repo audit** (item 2 below) over building more
  small fixtures. (b) *The scored axes are the wrong ones*: an instrument grading
  labels, bounded claims and fix-risk would measure something, but it would be
  measuring adherence to our own vocabulary, a far weaker claim than "finds more
  bugs" — it must never be reported as a lift. Do not build a sixth small fixture
  without a reason to expect a different answer.

- ~~**No gate notices a capability that never reached a front-door surface.**~~
  **CLOSED 2026-08-02 — invariant 14.** Original entry below; the gate verifies the
  *declaration*, since discovery is judgement and cannot be gated.
  Invariant 6 fails the build on a wrong *number* in the README; nothing fails on a
  missing *feature*. That is why five audit capabilities went undocumented for three
  releases — the same silent-surface shape `sota-code-security` rules/10 describes
  for controls. Interim fix landed in [RELEASING.md](../RELEASING.md): the pre-tag
  checklist now says to grep the README and `docs/INDEX.md` for a distinctive term
  from each capability the release added. A real gate would need a machine-readable
  list of capabilities per release — worth considering, not obviously worth the
  ceremony.
- **§3.9 may be the one audit instrument that could move off +0.00.** Every audit
  eval saturates because a frontier model handed the code *and* the question is
  already at ceiling — but §3.9 grades a **procedure** (copy the tree, delete the
  dependency, run the real build, report exit codes) rather than a recognition. An
  eval that scores whether the model *actually ran the deletion* instead of asserting
  "appears unused" would test something the saturated instruments cannot reach. Needs
  a tool-using harness, so it shares the blocker with the agentic large-repo audit
  (item 2 below) — cheaper, though: a small fixture repo with two genuinely inert
  dependencies and one reached only from a test.
- **The §3.9 tool table will rot.** It names eight third-party projects, each with
  its documented blind spot, all verified live 2026-07-30. Two had already been
  **renamed** under the URLs a manifest would carry. It is now a named target in
  [MAINTENANCE.md](MAINTENANCE.md); the section itself tells readers to re-verify
  before trusting a row, which is the only maintainable posture.
- **Ruby and .NET have no dependency-reachability tool worth naming.** Recorded as a
  deliberate gap, not an oversight (candidates: 5 stars, one contributor each, one
  with no push since 2025-01-03). Revisit if a maintained option appears.

**Open items from the 2026-07-28 cycle (still open):**

- ~~**No update-notification path for clone installs.**~~ **CLOSED 2026-08-02 —
  `scripts/update-reminder.sh`**, reaching both install paths and making no network
  request. Original entry below. Symlinked skills update the
  moment you `git pull`, but nothing ever tells you to pull. The plugin's
  `SessionStart` notice (`hooks/hooks.json` → `scripts/plugin-notice.sh`) is
  marker-guarded to fire **once ever**, so it is onboarding, not a version
  channel. **Partly done (2026-07-30).** The claim previously recorded here — that
  `install.sh --update` "already knows both versions" — was **false**: the script
  had **zero** references to `VERSION` (`grep -c VERSION scripts/install.sh` → 0).
  It now reads `VERSION` before and after the pull and prints the delta
  (`1.19.7 → 1.20.0 — see CHANGELOG.md`), and `--version` reports the release,
  checkout, upstream state as of the last fetch, and whether the install is
  symlinked or a pinned `--copy` snapshot. ~~What remains open is the *push*
  half.~~ **DONE 2026-08-02 — and the phone-home question was dissolved rather
  than answered.** `scripts/update-reminder.sh` runs on `SessionStart` and, at
  most once every 14 days, tells the user their install is getting old and how to
  check. **It makes no network request** — it cannot know whether a new version
  exists, only how long since it last spoke. That is the point: the benefit was
  *reminding you updates exist*, which needs no telemetry, and a real check from
  every session start would turn a documentation library into something that
  reports when and how often you work. The check stays manual and is one command
  (`install.sh --update`). TTL from the state file's mtime (`find -mtime`, because
  GNU `date -d` and BSD `date -v` disagree), silent on first run, opt-out with
  `SOTA_UPDATE_REMINDER_DAYS=0`, and **fails open on every path** — unwritable
  data dir, missing `VERSION`, garbage in the env. Reaches **both** install paths:
  the plugin via `hooks/hooks.json`, clone installs via `install.sh`'s routing
  setup (which is what the original item was actually about).
- ~~**Nothing reports which version is in use.**~~ **Done 2026-07-30** —
  `scripts/install.sh --version` reports it (release from `VERSION`, `git
  describe`, upstream-ahead count as of the last fetch, symlink-vs-snapshot
  install mode), and the README's Updating section tells reporters to quote it.
  Tested on six paths: normal checkout, non-git snapshot, missing `VERSION`,
  unlinked target, `--update` with and without a version change, and behind-
  upstream. Still true that **no skill file carries a version**, deliberately:
  a version string inside a skill is one more surface to bump every release, and
  `VERSION` is already the invariant-5-guarded source of truth.
- ~~**`scripts/verify-setup.sh`** — the deterministic half of VERIFY-SETUP.md.~~
  **DONE 2026-08-02.** 14 checks, strictly read-only (verified by hashing the file
  tree and `git status` before/after), exits 1 on any FAIL, `--runs N` widens the
  CI-history sample. The prompt keeps the half a script cannot do: whether an agent
  file's *content* is meaningful (4) and whether its claims are still true (5b),
  plus the routing dry-run (11) — each now labelled `N/A — judgement check` in the
  script's own output so the split is visible where you run it.
  - **Writing it found a bug in itself.** Check 8 used `git grep`, which reads only
    **tracked** files, so an untracked `.pre-commit-config.yaml` configuring
    gitleaks was reported as *no secret scanning* — a false FAIL on precisely the
    case the doc names first ("on a repo you just scaffolded"). Found by running
    the fail path, not by reading the code. Now plain `grep`.
  - **And it validated its own UNVERIFIED vocabulary.** On this repo, check 10b
    (*has CI ever rejected anything?*) reads UNVERIFIED at the default 60-run
    sample — 60/60 success — and turns up **1 failure at 200**. "Not in the last
    60" really is not "never", and that is why `--runs` exists.
- ~~**`gh-sota` extension — considered and deferred, with reason.**~~ **CANCELLED
  2026-08-02, not deferred.** Its one real benefit was update notification, and
  that is now delivered directly by the SessionStart reminder below — without a
  second repo, a shim, or a CLI nobody would invoke. Closing it rather than
  leaving it "deferred" forever: a deferred item with a dead rationale is
  indistinguishable from a live one on a list. Original reasoning, kept because it
  is still why the shape never worked: gh requires the
  repo to be named `gh-*` with a root executable of the same name (verified in
  `gh extension --help`, 2.96.0), so it cannot live in this repo; it would need a
  thin shim repo delegating to `scripts/`. Its headline benefit does not
  materialise either: gh's update notice fires **on invocation**, and nobody
  invokes a CLI for a library used inside an agent session. Revisit only if
  one-command install becomes the bottleneck.
- **Router headroom: 500/500 lines — exhausted.** The rules/11 pointer in AUDIT
  step 4 consumed the last three lines, and invariant 1 caught the overflow at 504
  mid-edit; the text was compressed twice to fit. **The next router addition must
  trim first — there is no slack at all.** Candidates when that day comes: the
  per-domain pass ordering in AUDIT step 3 (11 lines, largely re-derivable from the
  routing table) and the severity glossary in step 6 (5 lines, duplicated in
  `rules/01` §4). `ROUTER_BUILD_SHA` is still `71a9d78ea5e9e341`, **re-computed and
  matched after every router edit on 2026-07-30**, so all of them landed outside the
  eval-pinned BUILD block and historical completeness runs stay comparable.
- ~~**Unverified claim in the README** — that git-hosted plugin marketplaces
  re-check at session start.~~ **Checked 2026-07-30 and it was wrong in the way
  that matters.** The Claude Code docs state that *"third-party and local
  development marketplaces have auto-update disabled by default"* — this is a
  third-party marketplace, so a plugin user gets **no** automatic refresh unless
  they explicitly enable it; and even enabled, the check runs after session start
  "with a random delay of up to ten minutes" while the running session keeps its
  launch versions. The README implied users were being kept current when by
  default they are not. Fixed with the quote, the opt-in path, and a pointer to
  `--version`. **This makes the notification item above more important, not less**:
  neither install path pushes updates by default.

**Prior open items, still open (2026-07-22 framing, re-checked today):**

The foundation is de-risked and the
release cadence caught up: **v1.17.0 → v1.19.0** shipped across 2026-07-20…22.
Landed this stretch — silent-control `rules/10` (measured **+0.00**, the +0.07 and
the taxonomy-anchoring signal both retracted as noise), adversarial verification and
decision-ledger review in AUDIT mode, the gap-reporting loop, the drifted
`BUILD_WORKFLOW` mirror found and pinned (`ROUTER_BUILD_SHA`), the eval **scoring
functions given mutation-tests in CI**, negative controls grown 8→20 (over-flagging
resolved as noise), the README re-led on the proven lift + an architecture
infographic, and — the headline — **cross-model replication: the +0.39 completeness
lift is not sonnet-specific** (`openai/gpt-5.1` shows **+0.44**).

**Genuinely open, ordered by value:**
1. **Distribution / adoption** — the real bottleneck. Re-checked live 2026-07-30 via
   `gh api`: **8 stars, 0 watchers, 2 forks** — unmoved in two days — and **exactly
   one true issue ever** (#4, closed; filtering `has("pull_request")` out of the
   issues endpoint, which otherwise counts all 150+ PRs as issues). The gap-reporting
   loop has produced **0 external reports in 8 days**. The asymmetry is now sharper,
   not softer: every gap closed in v1.19.3–v1.19.7 was found by *us* running the
   library or by the maintainer aiming a prompt at it — **none by an external
   reporter**. Publish the salience write-up + the infographic (LinkedIn is the
   measured top referrer). A **people problem, not a measurement one** — the
   highest-leverage lever left.
2. **Agentic large-repo audit** — **ATTEMPTED 2026-08-03; a SYNTHETIC fixture cannot
   do it** ([BIG-REPO-AUDIT](../evals/results/2026-08-03/BIG-REPO-AUDIT.md)). Two
   fixture generations, 360+ files and ~95k tokens each, six planted defects. The bare
   arm scored **6/6, 6/6, 6/6** on v1 and **6/6, 5/6** on v2 — at ceiling, no headroom,
   so the library arm was never run and no number is published. The reason
   generalises: **in a synthetic corpus a planted defect is by construction a deviation
   from generated filler, and agents find deviations mechanically** — v1 by file
   naming, v2 by AST-normalising every method body and diffing. Scaling the repo makes
   the anomaly *cheaper* to spot, not harder. The pre-registered prediction (bare
   0.30–0.50) was **wrong by ~2×**. What would be needed instead: a **real** repository
   with **real** defects at a known commit, where the flaw is ordinary code someone
   believed was correct. Original framing — the *only* design that could move AUDIT off
   +0.00
   (all four single-prompt audit instruments saturate). Needs a new tool-using harness
   + a large ground-truth-defect fixture + two-axis (recall × efficiency) scoring;
   cost band **$15–60**, deferred by the user until later.
3. **Cheap incremental confidence** (~$3 within current credit): a 2nd cross-family
   BUILD model (gemini-2.5-pro) → "holds across three families"; cross-model freshness
   + routing (both still single-build-model).
4. **As-deployed competitor comparison** (~$8) and competitor domains beyond the five.
5. **Multi-turn amplification at scale** — needs much larger intervening context than
   the moderate-scale decay run.
6. **First 6-month accuracy sweep ~Jan 2027** (`LAST-VERIFIED` 2026-07-08).

Credit was ~**$8.79 as of 2026-07-22** and has **not been re-checked since** — no
paid eval ran in the 2026-07-24…28 cycle (all six releases were content/CI work).
Verify via the OpenRouter credits API before planning anything paid; never assume
this figure. The dated per-cycle record below is the history; this block is the
live picture.

---

**v1.16.0 released** (2026-07-16, PR #115, tag `v1.16.0`) — rolled up the big
post-v1.15.0 batch (PRs #88–#114). Executed across it: multi-sample tightening
(item 1), live-agent BUILD validation (item 2), cross-file audit (item 3, +0.00 →
agentic large-repo is the frontier, 3′), the **competitor benchmark** (item 6)
**and a 5-domain breadth run** (the lead tracks the unguided baseline, not the
domain — SOTA-skills leads on incomplete-by-default tasks: backend [Python+Go] +
hard frontend; ties on simple UI + templated IaC), a first **decay/multi-turn** run
(item 5, no decay at moderate scale), a **discoverability overhaul** (docs/INDEX.md,
docs/CONTEXT-MANAGEMENT.md, RESULTS.md scoreboard, README TOC), the **500-line cap
scoped to skill files only**, a **4-way accuracy sweep**, and **theme-aware
benchmark + breadth charts**.

**Post-release, same session (PRs #111–#117):** concluded the breadth comparison
(#111); mined a separate agent-orchestration project of the maintainer's and adopted
**three pure-Markdown conventions, each independently measured** — negative routing
cross-refs, plan-concreteness in BUILD step 3, and an evidence-based-completion
operating principle (#112) — with regression checks proving no loss (completeness
held **0.991/+0.385** #112; routing held **1.00** #113); built the **description-
routing eval** measuring the skill auto-loader path (#114, honest **+0.00** —
saturated like audit; cross-refs kept as zero-cost defensive clarity); cut **v1.16.0**
(#115); consolidated the breadth chart + full story into RESULTS.md (#116); and added
**`sota-docs-workflow` rules/01 §8 "The documentation baseline"** — the must-have doc
set incl. community-health files, GitHub search precedence verified (#117). Runtime-
bound ideas from that project (memory-bank persistence, RAG, worktree locks, agent
framework)
were deliberately **not** ported.

**Post-v1.16.0 (2026-07-20):** added **`sota-code-security` rules/10 "Silent
control failure"** — controls that look enabled and do nothing. A gap analysis
over the whole tree found 9 of its 12 concepts uncovered anywhere (the falsi-
fication question, optional-dependency degradation, weak existence checks,
zero-rule loads, attacker-triggerable early returns, doc/code default drift,
hardcoded report numbers, shipped-artifact gaps, asymmetric negative-claim
evidence); fail-open (rules/03) and test vacuity (`sota-testing` rules/02/06/09)
were already strong and are cross-referenced, not duplicated. Wired into the
**default** paths rather than left opt-in: router BUILD step 4 (falsification
question over every control in the diff), a new AUDIT **step 4 silent-control
pass**, routing rule 20, and the asymmetric evidence burden in operating
principle 3 + `sota/rules/01` §5. **Then measured** (same day,
[`evals/results/2026-07-20/SILENT-FAILURE.md`](../evals/results/2026-07-20/SILENT-FAILURE.md)):
a case set run two ways — vocabulary-given and open-ended/blind-judged — plus an
**ablation arm** that drops rules/10 from the with-library context. A first
15-case version showed **+0.07**; the set was then **grown to 49** (41 positives,
8 loud-failure negative controls, 6 mechanisms rules/10 does *not* enumerate) and
**the lift did not replicate**: **+0.03** vocabulary / **−0.01** open-ended, both
inside a per-arm spread of ±0.04, with rules/10's ablated contribution **+0.00**.
The +0.07 was small-sample noise (the 15-case with-arm sat at 0.99–1.00 — no
headroom); it is **retracted** in `RESULTS.md` and the writeup. Silent-control
detection therefore joins audit / cross-file audit / desc-routing as a **+0.00**
dimension. rules/10 is kept on gap-analysis grounds with **no efficacy claim**.
Open follow-ups: (a) **DONE 2026-07-20 — the `novel` subgroup was grown 6 → 26 and the taxonomy-anchoring hypothesis is RETIRED**: the gap collapsed from 1.00 vs 0.83 (n=6) to **0.96 vs 0.92 (n=26) — one case, inside run spread**, so the library's enumerative content pattern is *not* shown to reduce generalization to unlisted mechanisms. Overall lift reproduced at **+0.00** on the 69-case set. One thing to watch if the negative set grows: the ablated arm scored 1.00 on the 8 loud-control negatives vs 0.75 for both other arms, hinting mildly at over-flagging rather than anchoring (2 of 8 — not a finding). (b) the **agentic** design remains the only one that can measure what the file is for; (c) cross-model replication — **DONE 2026-07-22** (gpt-5.1, see the cross-model
entry below). Note kept from that work: the four cases that defeat every arm (build-tag
no-op, glob extension mismatch, env-filter mismatch, unawaited async assertion) were
deliberately **not** written into the rule, since that is fitting guidance to the test set.

**Cycle detail (2026-07-20…22) — done items, kept as the record:**
- **DONE 2026-07-22 — cross-model replication of the BUILD lift.** Every completeness
  number had used one build model. Re-run with `openai/gpt-5.1` (different family)
  driving BUILD, same judge/rubrics/tasks: **0.44 → 0.88, +0.44** (every case positive).
  The +0.39 is **not sonnet-specific**; the lift is larger where the baseline is lower,
  reproducing the "lift tracks incompleteness" mechanism across models. Cost $1.87.
  [CROSS-MODEL.md](../evals/results/2026-07-22/CROSS-MODEL.md). Follow-ups: a second
  cross-family model (gemini) and cross-model freshness/routing remain single-build-model.
- **DONE 2026-07-20 — the flagship number is verified against the workflow that
  ships.** `BUILD_WORKFLOW` had drifted from router BUILD steps 3–4 for four days.
  Both arms run: drifted **0.59 → 1.00 (+0.40)**, synced **0.58 → 0.98 (+0.40)**. The
  `+0.39` was never wrong — only measured against stale text; `RESULTS.md` now carries
  the synced numbers. Drift cannot recur silently (`ROUTER_BUILD_SHA` pins the router
  section; the runner aborts on mismatch, guard watched to fire).
  [MIRROR-VERIFICATION.md](../evals/results/2026-07-20/MIRROR-VERIFICATION.md).
  **Follow-up CLOSED 2026-07-21:** arm B was repeated and the 0.02 dip was **noise** —
  c1 recovered 0.86 → 0.94, and its own swing across three runs (0.86–0.97, 0.11) is
  larger than the gap it was meant to explain. No measurable cost to the falsification
  clause. Two-run synced mean: **0.59 → 0.98 (+0.39)**, now the published figure —
  note that `+0.40` had been published from a *single* run. **Standing lesson: stop
  publishing from n=1.** Second time this week a single run produced a figure a larger
  sample walked back (the other: the retracted +0.07 on silent-control detection).
- **Distribution** (item 7): publish the salience write-up
  (`docs/writeups/completeness-blind-spot.md`) — LinkedIn is the proven channel
  (corroborated 2026-07-20: it is the **top referrer** in GitHub traffic);
  marketplace visibility; badge→verifiable-audit. **Traffic measured 2026-07-20:**
  ~24 organic clones/day (the three days with zero CI runs show clones exactly equal
  to unique cloners) against **7 stars, 0 watchers, 1 issue ever**. Since the install
  path *is* `git clone`, clones are the adoption metric and stars badly understate it
  — but the project also learns nothing from those users, which is what the
  **gap-reporting loop** (#124, shipped) is meant to change. Whether it produces
  reports is unmeasured; if it yields nothing in a few weeks, cut it.
- **As-deployed competitor comparison** + **more competitor domains** (data/mobile/
  CLI); the baseline-driven finding is established but these extend it.
- **Agentic large-repo audit** (3′) and **constraint-budget probe** (4).
- **Multi-turn amplification, at scale** (5): the decay run found *no* decay at
  moderate scale — needs much larger intervening context to find the breaking point.
- **Grow the eval case sets** (item 1 sub-task, content authoring). Done this cycle:
  silent-failure 15 → **69** (35 enumerated + 26 novel + 8 negative controls) and a
  new 30-case audit-precision set. **Negative controls grown 8 → 20 on
  2026-07-21 and the over-flagging signal RESOLVED as noise** — all three arms now
  score 1.00 on them (the 0.75-vs-1.00 hint was 2 of 8 cases). Every subgroup signal
  this set has produced has evaporated when the subgroup grew: anchoring at 6→26,
  over-flagging at 8→20. Still thin: the 7-case completeness set and competitor
  domains beyond the five measured.
- **First 6-month accuracy sweep ~Jan 2027** (item 8; bump `LAST-VERIFIED`).

Historical per-item notes below (kept as the record of what was done):

1. **Tighten the eval numbers (confidence, not point estimates).** **Multi-sample
   DONE 2026-07-13** — [`evals/results/2026-07-13/MULTI-SAMPLE.md`](../evals/results/2026-07-13/MULTI-SAMPLE.md).
   All three value dimensions re-run at `--samples 3 --temp 0.7`: completeness
   **0.60 → 1.00 (+0.39)** with the with-arm at ±0.01 across-case sd (reproduces
   the single-sample headline, 6/7 cases perfectly steady); routing **0.90 → 1.00
   (+0.10)**, with-arm ±0.00; freshness **0.44 → 0.97 (+0.53)**, with-arm ±0.00
   (reused). The with-library arm is near-zero variance everywhere; the sampling
   wobble is all in the unguided arm. Single-sample caveat retired. **Remaining
   sub-task:** *grow* the completeness (7) and freshness (32) sets — that's
   content authoring (new cases), not a re-run, and is still open.
2. **Validate the v1.15.0 BUILD-workflow changes in a *real* agent run.**
   **DONE 2026-07-13, fully closed** — [`evals/results/2026-07-13/LIVE-BUILD.md`](../evals/results/2026-07-13/LIVE-BUILD.md).
   Seven live sub-agents built the 7 completeness tasks through the real router
   flow (load-lean → checklist → terminal self-audit). Verified from their
   `process.md` audit logs (primary source): all 7 followed the workflow;
   cross-cutting concerns present in every applicable build; the self-audit gate
   **caught and fixed real gaps** live (c6: prod `/docs` exposure + unbounded DB
   critical section; c3: orphaned-task cancellation bug). The blind-judge scalar
   (run once credit was restored) is **0.99 mean, 6/7 perfect — matching the
   0.99 simulation (0.987 vs 0.988) and far above the 0.60 base**, proving the paste-based eval is a faithful
   proxy for the live router flow (`evals/results/2026-07-13/live-build.json`).
3. **Cross-file / repo-level audit eval.** **DONE 2026-07-13** —
   [`evals/results/2026-07-13/REPO-AUDIT.md`](../evals/results/2026-07-13/REPO-AUDIT.md),
   `evals/run-repo-audit.py`, 15-file fixture with 8 defects invisible in any
   single file. Result: **+0.00 on sonnet-4.6 and opus-4.8** (strict,
   file-attributed). The finding *refines* the hypothesis: cross-file is not the
   barrier — **context the model can't hold at once** is. A ~17 KB repo pastes
   whole, so recognition (already saturated) catches everything. The real
   frontier is now item 3′ below.
3′. **Agentic large-repo audit eval** *(new, replaces the snippet/small-repo
   version).* The only untested audit-lift path left: a repo too large to hold in
   context, audited through a **tool-driven agent loop** (selective file reads
   under a budget), with-library vs without — where the router's "which files to
   open, what to connect" guidance is the thing under test, not recognition.
   Materially bigger harness (a real agent loop, not one API call).
4. **Constraint-budget probe** *(new, from the v1.15.0 whack-a-mole: c1 dropped
   size-limit when principle 5 was added).** Measure how many simultaneous
   non-negotiables a model reliably satisfies — informs how short principle 5 and
   per-task checklists must stay. Directly tests the salience/attention finding
   in [`WHY-COMPLETENESS-RESIDUAL.md`](WHY-COMPLETENESS-RESIDUAL.md).
5. **Multi-turn / agentic amplification test** *(new)*. **First run DONE 2026-07-15**
   (`evals/run-decay.py`, `results/2026-07-13/DECAY.md`): guidance at turn 1 → K
   filler turns → build probe. **No decay at moderate scale** (guidance held over 30
   turns) — the filler is too small to dilute a ~18.6K-token anchor, so it bounds
   the problem but doesn't find the breaking point. **Open:** scale up (much larger
   intervening context, or a subagent chain).
6. **Competitor-library benchmark** — **DONE 2026-07-14/15** (see "Unexplored ideas"
   below for the full result): SOTA-skills beats the fair peers on completeness on
   backend tasks, content-only. **5-domain breadth (2026-07-15/16) reframes it: the
   lead tracks the unguided BASELINE, not the domain** — SOTA-skills leads +~10 pts
   where a base model ships incomplete code (Python+Go backend, hard SSR/auth
   frontend; baseline ≤0.67) and ties where it's already complete (simple frontend
   77%, IaC 87%). See `results/2026-07-13/BREADTH.md`. The honesty gate is cleared for a *scoped-to-backend* "vs library X"
   claim; every doc surface was rescoped accordingly.
7. **Distribution over coverage** (item 6): marketplace visibility, a published
   before/after demo, badge→verifiable-audit. **Started 2026-07-13/14:** (a) the
   README now leads with the measured lifts as a scannable list (completeness
   +0.39, freshness +0.53, routing +0.10) and puts the clone/script install right
   after the plugin method (PRs #92–#93); (b) a publication draft of the
   completeness/salience finding is ready at
   [`docs/writeups/completeness-blind-spot.md`](writeups/completeness-blind-spot.md)
   (verified before/after — webhook 0.50→1.00, upload 0.55→1.00). **Still open:**
   the maintainer publishes the write-up (LinkedIn is the proven referral channel
   per traffic data); marketplace visibility and badge→verifiable-audit are
   untouched. The compelling demo is **completeness** before/after, not audit —
   audit lift is +0.00 (item 3), so an audit demo would undersell.
8. **Scheduled — first 6-month accuracy sweep ~Jan 2027** (item 5): re-verify
   fast-moving claims per `docs/MAINTENANCE.md` and bump `LAST-VERIFIED`.

## Now — prove and protect accuracy *(done this cycle)*

The audit's verdict was "content is trustworthy; the gap is that nothing
*proves or protects* accuracy." Closed 2026-07-10 (PRs #63–#66):

1. **Content-accuracy runbook + shorter window** — `docs/MAINTENANCE.md`
   documents the reproducible per-skill re-verification sweep (was only in
   maintainer memory); `check-freshness.sh` window cut 12→6 months. *(#66)*
2. **Audit defect cleanup** — content corrections (OWASP/RFC/ingress/Iceberg/
   version-pins) + router-map refresh *(#63)*; **invariant 7** (router
   completeness) + check-2 fence / check-5 semver / CI fail-open hardening
   *(#64)*; installer decline-abort + profile-clobber *(#65)*.
3. **Eval-harness prototype** — `evals/` (golden-set cases + `score.py`,
   verified end-to-end) makes the efficacy claim measurable. *(#66)*

## Next — grow what the prototypes started

4. **Eval baseline + clean isolated control** — *done 2026-07-10/11*
   ([`BASELINE.md`](../evals/results/2026-07-10/BASELINE.md); `evals/run-clean.py`):
   **routing lift ~+0.10 replicates in a true library-vs-nothing raw-API
   control** (+0.09/+0.14/+0.09 across sonnet-4.6/sonnet-5/opus-4.8) — the
   contamination concern is resolved, the lift is real. **Audit +0.00**;
   **Freshness +0.50–0.65** (base model confidently wrong on 2026 facts, but a
   web-search agent would likely recover most of it — predicted, untested). **Completeness +0.39** (0.60→0.99 over
   7 tasks, full library, `cases/completeness.jsonl` + `run-completeness.py`,
   blind opus judge) — the **thesis, validated**: from a bare "build X" prompt the
   base model skips tests/rate-limits/logging/transport ~40% of the time; the
   library embeds them, and search can't close this gap. **Load-bearing as an
   ablation:** base 0.60 → +rules ~0.89 → +BUILD self-audit 0.93 → +principle 5
   0.99 (`results/2026-07-13/`). Surfaced fixes, all landed: the self-audit is a
   hard BUILD gate; cross-cutting concerns are the router's short **operating
   principle 5**; and the BUILD workflow now says load-lean + plan-with-checklist
   + terminal re-read. **Root-cause investigation (2026-07-13):** the residual is
   NOT a coverage gap (the forgotten rule was in scope + in a checklist); it's a
   **salience / context-rot attention effect** — *adding* the missing rule made it
   worse, a short reminder fixed it ([`docs/WHY-COMPLETENESS-RESIDUAL.md`](WHY-COMPLETENESS-RESIDUAL.md),
   experiments + literature). Curated for readers in
   [`docs/WHY-IT-WORKS.md`](WHY-IT-WORKS.md) (honest "vs. an unguided model"
   framing — see the unexplored idea below). **Eval-suite hardening — done
   2026-07-12:** completeness 4→**7** tasks; freshness 20→**32** cases
   (all primary-source-verified; +0.50, and +0.53 at 3 samples with 0.97±0.00 vs
   0.44±0.03); harder-audit 7→**14** — still +0.00 (a capable model catches even
   subtle/multi-vuln snippets *in isolation*, so a real audit lift needs
   cross-file context, not more snippets); and `--samples/--temp` added to both
   harnesses (retires the single-sample caveat on the cheap dimensions).
   **Shipped as v1.15.0** (2026-07-13, PRs #78–#85). Follow-through: the
   multi-sample averaging is **done** (2026-07-13, PR #91 — see Open tasks item 1,
   with-arm near-zero variance); *growing* the completeness + freshness sets is
   still open (Open tasks item 1, content authoring).
5. **First 6-month accuracy sweep** comes due ~Jan 2027 (freshness window) —
   run it per the `docs/MAINTENANCE.md` runbook and bump `LAST-VERIFIED`.

## Later — distribution over coverage

6. **Pause net-new skills; invest in distribution.** Coverage is an exhausted
   lever at current adoption (audit: 4 stars / 1 issue after 41 skills). Put
   the effort into visibility (marketplace, a published before/after audit
   demo) and the badge→verifiable-audit idea (link the "Built with" badge to a
   committed audit report + commit SHA). *(audit STRAT-MED-1)*

## Unexplored ideas

- **Comparative benchmark vs. named competing libraries.** ~~Unexplored~~
  **DONE 2026-07-14** ([`evals/results/2026-07-13/COMPETITOR-BENCHMARK.md`](../evals/results/2026-07-13/COMPETITOR-BENCHMARK.md),
  `evals/run-competitors.py`, `evals/cases/competitors.json`). SOTA vs. the fair
  peers, content-only, blind-judged, 7 build tasks: **SOTA 0.99 >
  [affaan-m/ECC](https://github.com/affaan-m/ECC) ~230k★ 0.87 >
  [PatrickJS/awesome-cursorrules](https://github.com/PatrickJS/awesome-cursorrules) ~40k★ 0.83 >
  [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) ~23k★ 0.81**
  (unguided 0.58). SOTA wins/ties every one of 21 cases, loses none; competitors
  are legitimate (all +0.23–0.28 over unguided) but drop the cross-cutting
  non-negotiables SOTA embeds. The honesty gate is **cleared** — `WHY-IT-WORKS.md`
  now carries a scoped "vs library X" claim. **Breadth DONE 2026-07-15/16 — lead tracks the
  BASELINE not the domain (5 domains, BREADTH.md):** SOTA-skills leads where the base
  model is incomplete (backend any-lang, hard frontend) and ties where it's complete
  (simple frontend, IaC). [old note kept:] on 3 simple React tasks SOTA-skills ties ECC and
  claude-skills (all 97%, even losing one task); frontend completeness is easy
  (unguided 77% vs 58% backend) so any guidance reaches the top. So the claim is
  scoped to **backend**, not general (`competitor-breadth-frontend.json`).
  **Follow-ups still open:** multi-sample the arms; more domains (data/mobile/CLI);
  ~~optionally an *as-deployed* comparison~~ — **rejected 2026-08-16**, see the reasoning
  under the open-items table.
  Original plan/targets kept below for reference.
- **(reference) Original competitor-benchmark plan.** Every eval to
  date is library-vs-*nothing* (an unguided model), so the public claim was
  honestly limited to that; to earn a "vs X" claim, run a competitor's content
  as a **third arm** (same fixed rubric, blind judge, token budget) and report the
  delta — **publishing it even if SOTA ties or loses.**
  **Targets validated 2026-07-14 via the GitHub API** (stars + created-date +
  license + repo structure). **Pick on purpose-overlap, not raw stars** — many
  high-star repos are a *different kind* of thing, and the biggest ones are all
  2026-new with explosive (plausibly inflated) star growth, so treat the numbers
  skeptically. Tiers:
  - **Same-kind engineering guidance a model reads to build/audit code** (the fair
    completeness peers): **[affaan-m/ECC](https://github.com/affaan-m/ECC)** (~230k★, MIT, cross-AI — Claude/Codex/
    Cursor/Gemini/Kimi/Kiro; "agent harness… skills, security, research-first dev"
    → highest-profile, PRIMARY); **[alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills)** (~22.6k★, MIT,
    multi-domain engineering + `audit/` + plugin, structured like SOTA → closest
    same-kind peer); **[PatrickJS/awesome-cursorrules](https://github.com/PatrickJS/awesome-cursorrules)** (~40.3k★, CC0, per-stack
    `.cursorrules` → the rules-library reference); tertiary
    [SebastienDegodez/copilot-instructions](https://github.com/SebastienDegodez/copilot-instructions) (~190★ but genuinely same-kind: DDD/
    clean-arch/testing rules) and [sanjeed5/awesome-cursor-rules-mdc](https://github.com/sanjeed5/awesome-cursor-rules-mdc) (~3.5k★).
  - **Popular but a *different axis*** (compare only on a workflow/quality axis, not
    build-completeness): **[garrytan/gstack](https://github.com/garrytan/gstack)** (~122k★, cross-AI — a 23-tool
    role/workflow setup, not a rules library); **`multica-ai/andrej-karpathy-
    skills`** (~192k★ but **no license** → can't legally reuse content; mostly one
    behavior CLAUDE.md).
  - **Excluded, different category:** `x1xhlol/system-prompts-and-models-of-ai-
    tools` (~142k★ leaked tool prompts); [JuliusBrussee/caveman](https://github.com/JuliusBrussee/caveman) (~89k★ token
    gimmick); [agentsmd/agents.md](https://github.com/agentsmd/agents.md) (the spec/website); `travisvn/awesome-claude-
    skills` (link list); [ComposioHQ/awesome-claude-skills](https://github.com/ComposioHQ/awesome-claude-skills) (~67k★ productivity).
  Fairness controls: each competitor's *best-matching* content per task (not a
  strawman), same fixed rubric + blind opus judge + token budget, record commit
  SHAs, respect licenses (skip no-license repos for pasted content), state
  format/scope caveats, **publish even if SOTA ties/loses.** Expected edge =
  freshness (SOTA primary-source-verified; competitor rules go stale) + the
  cross-cutting completeness the self-audit/principle-5 design recovers; expected
  non-edge = raw "does the code work". **Cost:** ~$16 per competitor per full
  completeness run (3-arm ≈ 1.5× the 2-arm) — one pilot fits the current ~$36
  balance; the full `affaan-m/ECC` / `alirezarezvani/claude-skills` /
  `PatrickJS/awesome-cursorrules` sweep needs a top-up. Still
  gated on the maintainer wanting a "vs X" claim at all (2026-07-12 chose the
  honest vs-unguided framing).
- **Cross-file / repo-level audit eval.** ~~Unexplored~~ **Explored 2026-07-13,
  no lift** ([`evals/results/2026-07-13/REPO-AUDIT.md`](../evals/results/2026-07-13/REPO-AUDIT.md)).
  Built the planted-vuln repo (8 defects invisible in any single file) the audit
  dimension was said to need. Result: **+0.00** on two models — when the whole
  repo fits in one context, cross-file collapses to "read it all" and recognition
  (already saturated) catches everything. The hypothesis was wrong about *why*
  audit is +0.00: the barrier is **context that exceeds what the model holds**,
  not file-spanning per se. The genuine remaining frontier is the agentic
  large-repo eval (open task 3′) — a repo too big to paste, audited under a
  context budget through tool-driven reads.

---

## Completed — 2026-07-01 audit cycle *(history)*

### Now — correctness of what's shipped

1. **Fix the audit's HIGH and MEDIUM findings.** The two HIGHs
   (sota-security-compliance frontmatter invalid under strict YAML;
   `init-gates.sh` language-detection SIGPIPE fail-open) plus the script
   silent no-ops, the denylist-check gaps, and the sota-jvm scoped-values
   correction. *(Landed in the audit-remediation PR, #37.)*
2. **Library lint gate** (extends `check-invariants.sh`): YAML-parse all
   SKILL.md frontmatters, VERSION == plugin.json == latest tag lockstep,
   README count-basis check, shellcheck over `scripts/`. Blocks the whole
   defect class the audit found. *(Landed: YAML-validity check and shellcheck
   CI job in #37; version-lockstep (check 5) and count-surface (check 6)
   invariants on 2026-07-04.)*

### Next — keep the core promise true

3. **Freshness ledger.** Per-rules-file `last-verified: YYYY-MM` metadata plus
   a scheduled CI job reporting files past their re-verify window. The README
   promises "fast-moving claims are web-verified against primary sources";
   today only ~21 of 220 rules files carry any verification date, so the
   promise is unauditable — and every "2026 baseline" assertion goes silently
   stale in 2027. *(Mechanism landed 2026-07-04 as per-file line-1 markers;
   SUPERSEDED 2026-07-09, PR #52: a full-library verification sweep
   (per-skill web research, adversarially verified, 65 fixes applied)
   replaced the per-file ledger with a single root `LAST-VERIFIED` stamp —
   the per-file backfill would have duplicated git metadata at 210-file
   scale. `check-freshness.sh` now reds when the stamp exceeds the
   12-month window; re-sweeping resets it. DONE.)*
4. **Release procedure in-repo** (`RELEASING.md` or a CONTRIBUTING section):
   VERSION + plugin.json + CHANGELOG + tag + GitHub release, plus the
   version-bearing strings in README/CLAUDE.md. Eight releases shipped in the
   first 14 days from a procedure that lives outside the repo; the v1.0.0
   pointer rot in CLAUDE.md was the predictable result. *(Landed 2026-07-02:
   [RELEASING.md](../RELEASING.md), incl. the count-bearing surfaces — the
   v1.8.0 release found the social-preview image still saying "30 skills",
   the same rot class again.)*
5. **Structured feedback intake.** `.github/ISSUE_TEMPLATE` with a
   bad-guidance report (file:line + primary source, mirroring SECURITY.md's
   format) and a skill-request template; enable Discussions. A no-telemetry
   project's only adoption signal is structured issues — currently absent.
   *(Landed 2026-07-04: both issue forms — the bad-guidance form requires a
   primary source and redirects security-sensitive reports to the private
   advisory flow — plus a contact-link config; Discussions enabled.)*

### Later — coverage decisions (decide, don't drift)

6. **Close or declare the language/domain gaps.** PHP and Ruby have no skill
   (incidental mentions only); Swift exists only at sota-mobile's
   platform/stack level, not as a language-idiom skill; Active
   Directory/Kerberos/ADCS have zero coverage despite identity and detection
   skills whose real-world audits are AD-heavy. Ship `sota-php`, `sota-ruby`,
   a Swift-language rules file, and AD content — or add a README "coverage &
   non-goals" section stating what is deliberately excluded. The mission
   statement overclaims until one of the two happens. *(Closed 2026-07-04:
   all four builds shipped — `sota-php`, `sota-ruby`, `sota-mobile` rules/07
   (Swift language), and AD/Kerberos/ADCS as `sota-identity-access` rules/07
   + `sota-detection-engineering` rules/07 — each claim web-verified against
   primary sources; the README "Coverage & non-goals" section now lists only
   true non-goals (Scala/Elixir, standalone C, platform-engineering depth).)*

## Coverage additions (post-audit, demand-driven)

- **`sota-web-frameworks`** *(shipped 2026-07-06)* — React 19/Next.js + Vue 3/Nuxt 4
  and the SSR/hydration/server-components concerns those stacks share. Previously
  only incidental coverage existed (a React section in `sota-javascript-typescript`
  rules/06; XSS-sink names in rules/05). Closes the frontend-framework gap that sat
  between the language skill (`sota-javascript-typescript`) and the design skill
  (`sota-frontend-design`) without overlapping either. 40 skills total.
- **`sota-confidential-computing`** *(shipped 2026-07-09)* — TEEs
  (SEV-SNP/TDX/ARM CCA, SGX enclaves, Nitro Enclaves, confidential GPUs),
  remote attestation (RATS RFC 9334, attest-then-release), confidential
  Kubernetes (CoCo/Kata/Trustee), and cryptographic PETs (FHE/MPC/ZKP/PSI).
  Covers the workload-from-host trust direction — the inverse of
  `sota-sandboxing`; router rule 19 encodes the boundary. Demand-driven
  (user gap-check found zero prior coverage). 41 skills total.
- **Within-skill gap closures** *(2026-07-09/10, demand-driven)* — two coverage
  gaps found by user-prompted assessments, closed as sections in
  `sota-network-security` (no new skill): **rules/05 R8.1** self-hosted /
  bare-metal L3/4 DDoS hardening (SYN cookies/synproxy, conntrack, rp_filter,
  no-open-reflector — the library assumed a scrubbing edge); **rules/06
  R12–R14** email authentication & anti-spoofing (SPF/DKIM/DMARC, MTA-STS/DANE,
  bulk-sender rules — previously only incidental SPF/DKIM mentions). Assessment
  also judged firmware/UEFI/measured-boot-as-a-discipline a real-but-niche gap,
  deliberately **not** built (partly subsumed by confidential-computing +
  kubernetes; revisit only on demand).

## Maintenance mode (de-prioritized by audit evidence)

- **Optional-extras scripts** (`statusline.sh`, `init-gates.sh`,
  `gen-agents-md.sh`): highest defect density found by the audit, and plugin
  users don't get them by default. Bug-fix only; no new extras until the
  plugin path can deliver them natively.

## Explicitly rejected (with reasons, so they aren't re-litigated)

- **History rewrite to purge the pre-2026-07 denylist names** — rejected
  2026-07-01: the names are low-sensitivity, the repo already has public
  clones/forks/archives, and a rewrite breaks every clone and all release
  tags. Going forward the list is externalized (git-ignored locally, CI
  secret) so the tree no longer discloses it.
- **Telemetry/analytics in the scripts** — privacy stance; feedback comes
  from issues (see item 5).
- **Importing an external system-design "fundamentals" guide** — assessed
  2026-07-14 (a compiled X-thread series on scaling/architecture: load
  balancing, CDN, caching layers, API gateway, CAP, sharding, replication,
  consistency, queues, fault tolerance, etc.). **No action:** it is a *secondary
  source* (can't be cited under the primary-source policy), and a topic-by-topic
  check found full coverage already — caching + stale-while-revalidate
  (`sota-performance/05`, `sota-architecture/05`), CDN/origin-lock
  (`sota-cloud-infrastructure/03 §9`), L4/L7 LB + health checks
  (`cloud-infrastructure/03 §8`, `architecture/04`), gateway-vs-mesh N-S/E-W
  (`sota-network-security`), rate limiting (router principle 5), and the
  distributed-systems topics across `sota-architecture/03,05` + `sota-databases`.
  Only marginal non-coverage: enumerating LB *algorithms* (deliberately subsumed
  by the "use managed LBs + meaningful health checks" stance) and back-of-envelope
  capacity estimation (an interview skill, not a BUILD/AUDIT rule — a non-goal).
