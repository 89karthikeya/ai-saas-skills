#!/usr/bin/env python3
"""Description-based skill-routing eval — does the negative cross-reference in a
skill description ("Not for X — use sota-Y") reduce mis-routing when a model picks
a skill purely from the description catalogue (the path a skill *auto-loader* uses,
as opposed to the router table that `run-clean.py --cases router.jsonl` measures)?

Two arms over the SAME adversarially-confusable tasks, same catalogue except:
  with-xref     — descriptions exactly as committed (carry the "Not for … — use …")
  without-xref  — the same descriptions with only that one sentence stripped

Each case names the correct skill (`expect`) and the tempting wrong sibling
(`distractor`) that shares surface keywords. Metric: **distractor-pick rate** (what
the cross-ref is designed to cut) and primary-correct rate. Scoring is objective —
exact skill-name match on the model's answer, no LLM judge.

Auth: OPENROUTER_API_KEY (env or ./.env). Never printed or committed.
Run: python3 evals/run-desc-routing.py --samples 3 --temp 0.7 \
        --out evals/results/2026-07-13/desc-routing.json
"""
import argparse, glob, json, os, re, statistics, sys
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CASES = os.path.join(ROOT, "evals/cases/desc-routing.jsonl")
# Strips exactly the added cross-ref sentence(s): each starts "Not for " and, by
# construction, contains no internal period, so this removes one sentence cleanly.
XREF_RE = re.compile(r"\s*Not for [^.]*\.")
# ROADMAP 53 (2026-09-11). The second ablation: the trailing `Trigger keywords: …`
# list, which 40 of 42 descriptions carry and which is 12,693 of 37,330 characters
# (34%). It became worth measuring when ROADMAP 52 established that the listing
# budget drops WHOLE descriptions once the corpus is over it — so a tail is a cost
# paid by every OTHER skill in the set, not only by the one carrying it.
# Anchored to end-of-string: the list is always last, and a non-greedy match would
# stop at the first period inside the keyword list itself.
KEYWORDS_RE = re.compile(r"\s*(?:Trigger keywords?|Triggers)\s*[:\u2014\u2013-]\s*.*$",
                         re.IGNORECASE | re.DOTALL)
# The tail is not purely keywords. Two of 39 descriptions (sota-kubernetes,
# sota-devsecops) put their NEGATIVE CROSS-REFERENCE after the keyword list, so a
# strip-to-end-of-string removes two features at once and the run measures their
# sum. Found 2026-09-11 the expensive way: the single case that moved in the first
# keyword run was `q7_pod_hardening`, and what actually moved it was losing
# sota-kubernetes' "NOT pod-level securityContext/seccomp (sota-sandboxing)".
# So: strip the keywords, then put any exclusion clause back.
XREF_KEEP_RE = re.compile(r"(?:Not for [^.]*\.|NOT pod-level[^.]*\.)", re.IGNORECASE)


def strip_keywords(desc):
    """Remove the trailing keyword list while PRESERVING any exclusion clause in it."""
    m = KEYWORDS_RE.search(desc)
    if not m:
        return desc
    kept = " ".join(x.strip() for x in XREF_KEEP_RE.findall(m.group(0)))
    return (desc[:m.start()].strip() + (" " + kept if kept else "")).strip()
ABLATIONS = {"xref": XREF_RE, "keywords": KEYWORDS_RE}
STRIPPERS = {"keywords": strip_keywords}


def load_env_key():
    k = os.environ.get("OPENROUTER_API_KEY")
    if k:
        return k
    envp = os.path.join(ROOT, ".env")
    if os.path.exists(envp):
        for line in open(envp, encoding="utf-8"):
            line = line.strip()
            if line.startswith("OPENROUTER_API_KEY="):
                return line.split("=", 1)[1].strip().strip("'\"")
    sys.exit("OPENROUTER_API_KEY not found in env or ./.env")


def parse_desc(path):
    """(name, description) from a SKILL.md frontmatter — handles both an inline
    scalar (`description: text…`) and a folded/literal block (`description: >-`)."""
    fm = open(path, encoding="utf-8").read().split("\n---", 1)[0]
    name = re.search(r"(?m)^name:\s*(.+)$", fm).group(1).strip()
    rest = re.search(r"(?m)^description:(.*)$", fm).group(1).strip()
    if rest and rest not in (">-", ">", "|", "|-", "|+", ">+"):
        return name, rest.strip("'\"")  # inline (single-line) description
    grab, out = False, []             # block scalar: gather indented lines
    for ln in fm.splitlines():
        if ln.startswith("description:"):
            grab = True
            continue
        if grab:
            if re.match(r"^\S", ln):  # next top-level key
                break
            out.append(ln.strip())
    return name, " ".join(x for x in out if x)


def catalogue(strip, rx=XREF_RE, stripper=None):
    items = []
    for d in sorted(glob.glob(os.path.join(ROOT, "skills/sota-*"))):
        if not os.path.isdir(d):
            continue
        name, desc = parse_desc(os.path.join(d, "SKILL.md"))
        if strip:
            desc = stripper(desc) if stripper else rx.sub("", desc).strip()
        items.append((name, desc))
    if not items:                       # empty catalogue => both arms identical => fake +0.00
        sys.exit(f"skill catalogue is EMPTY (globbed skills/sota-* under {ROOT}). "
                 f"Both arms would be identical. Refusing to run.")
    return items


def build_prompt(items, task):
    cat = "\n".join(f"- {n}: {d}" for n, d in items)
    return ("You are selecting the single most relevant skill for a task from a "
            "library. Here is the catalogue (skill name: description).\n\n"
            f"{cat}\n\nTASK: {task}\n\n"
            "Respond with ONLY the exact name of the single most relevant skill "
            "(for example: sota-python). No explanation — just the name.")


def call(model, key, prompt, temp, tries=4):
    body = json.dumps({"model": model, "messages": [{"role": "user", "content": prompt}],
                       "temperature": temp}).encode()
    for attempt in range(tries):
        try:
            req = urllib.request.Request("https://openrouter.ai/api/v1/chat/completions", data=body,
                                         headers={"Authorization": f"Bearer {key}",
                                                  "Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=180) as r:
                d = json.load(r)
            ch = d["choices"][0]
            content = ch["message"]["content"]
            # HTTP 200 with null/empty content is NOT success — a reasoning model can
            # burn the whole max_tokens budget on reasoning and return nothing. Raise so
            # the retry above engages, then fail loudly. See run-completeness.py call().
            if not content:
                raise RuntimeError(f"empty completion from {model}: "
                                   f"finish_reason={ch.get('finish_reason')}")
            return content
        except Exception as e:  # transient network/5xx — retry with linear backoff
            if attempt == tries - 1:
                raise
            import time
            time.sleep(3 * (attempt + 1))


def pick_from(txt, names):
    """First sota-* token in the reply that is a real skill name."""
    for tok in re.findall(r"sota-[a-z0-9-]+", txt):
        if tok in names:
            return tok
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default=CASES,
                    help="case file. The default is the MEASUREMENT set, whose A/B number "
                         "is published. Regression cases live in a separate file and must "
                         "never be averaged into it (sota-llm-engineering rules/01 §8).")
    ap.add_argument("--model", default="anthropic/claude-sonnet-4.6")
    ap.add_argument("--samples", type=int, default=1)
    ap.add_argument("--temp", type=float, default=0.0)
    ap.add_argument("--out", default=None)
    ap.add_argument("--ablate", choices=sorted(ABLATIONS), default="xref",
                    help="which description feature to strip in the second arm. "
                         "'xref' is the published default and what every historical "
                         "run measured; 'keywords' is ROADMAP 53's trailing "
                         "`Trigger keywords:` list.")
    a = ap.parse_args()
    key = load_env_key()
    cases = [json.loads(l) for l in open(a.cases, encoding="utf-8")
             if l.strip() and not l.startswith("#")]
    from _elapsed import note_work   # duration baseline needs a denominator
    note_work(len(cases), "cases")
    names = [os.path.basename(d) for d in glob.glob(os.path.join(ROOT, "skills/sota-*"))
             if os.path.isdir(d)]
    rx = ABLATIONS[a.ablate]
    arms = {f"with-{a.ablate}": catalogue(False),
            f"without-{a.ablate}": catalogue(True, rx, STRIPPERS.get(a.ablate))}
    # Assert the ablation TOOK (rules/15 §2.2). If no description matched XREF_RE the
    # two arms are byte-identical and this tool prints a fake +0.000 — a manufactured
    # null in a project that publishes real ones. Both sibling ablations already abort.
    # catalogue() returns a list of (name, description) tuples — NOT a string. This
    # compared `.splitlines()` on a list from 2026-08-05 (PR #223) until 2026-08-27,
    # which raised AttributeError before the first API call, so the runner could not
    # execute at all. It went unnoticed because the last recorded run predates the
    # guard: a guard added to stop a fake null instead stopped the instrument, and
    # nothing re-ran it (`sota-code-security` rules/12 — watch the guard run).
    a_full, a_strip = arms[f"with-{a.ablate}"], arms[f"without-{a.ablate}"]
    changed = sum(1 for (_, d1), (_, d2) in zip(a_full, a_strip) if d1 != d2)
    removed = sum(len(d1) for _, d1 in a_full) - sum(len(d2) for _, d2 in a_strip)
    if changed == 0:
        sys.exit(f"ablation '{a.ablate}' removed nothing: both arms are identical, so any "
                 f"result is a fake null. Check the regex against the current descriptions.")
    # Report the SIZE too, not just the count: a regex that clips one word off 40
    # descriptions also passes `changed > 0` while ablating essentially nothing.
    print(f"  ablation '{a.ablate}': {changed} description(s) differ, {removed} characters removed")
    print(f"model={a.model}  cases={len(cases)}  samples={a.samples}  temp={a.temp}  "
          f"arms={list(arms)}  (clean API, objective name-match scoring)\n")
    result = {"model": a.model, "samples": a.samples, "temp": a.temp, "cases": {}}
    agg = {arm: {"correct": [], "distractor": []} for arm in arms}
    for c in cases:
        result["cases"][c["id"]] = {"task": c["task"], "expect": c["expect"],
                                    "distractor": c["distractor"], "arms": {}}
        for arm, items in arms.items():
            picks = [pick_from(call(a.model, key, build_prompt(items, c["task"]), a.temp), names)
                     for _ in range(a.samples)]
            corr = statistics.mean(1.0 if p == c["expect"] else 0.0 for p in picks)
            dist = statistics.mean(1.0 if p == c["distractor"] else 0.0 for p in picks)
            agg[arm]["correct"].append(corr)
            agg[arm]["distractor"].append(dist)
            result["cases"][c["id"]]["arms"][arm] = {"picks": picks, "correct": corr, "distractor": dist}
            print(f"  {c['id']:<20} {arm:<14} correct={corr:.2f} distractor={dist:.2f} picks={picks}")
    result["summary"] = {arm: {"correct": statistics.mean(agg[arm]["correct"]),
                               "distractor": statistics.mean(agg[arm]["distractor"])} for arm in arms}
    print("\nSUMMARY")
    for arm in arms:
        s = result["summary"][arm]
        print(f"  {arm:<14} correct={s['correct']:.3f}  distractor-pick={s['distractor']:.3f}")
    # Derive the arm keys from the ablation instead of hardcoding "with-xref". They were
    # literals until 2026-09-11, so `--ablate keywords` completed all 60 paid calls, printed
    # the summary, and then died with KeyError BEFORE json.dump — the run's artifact was
    # lost to a print statement. A reporting line is part of the instrument.
    wx, wo = result["summary"][f"with-{a.ablate}"], result["summary"][f"without-{a.ablate}"]
    print(f"\n  Δ correct           (with − without) = {wx['correct'] - wo['correct']:+.3f}")
    print(f"  Δ distractor-pick   (with − without) = {wx['distractor'] - wo['distractor']:+.3f}"
          f"   (negative = the {a.ablate} text helps)")
    if a.out:
        result["ablation"] = a.ablate
        json.dump(result, open(a.out, "w"), indent=1)
        print("saved", a.out)


if __name__ == "__main__":
    from _elapsed import note_complete, report_on_exit
    report_on_exit("run-desc-routing")
    main()
    note_complete()   # main() returned: a measurement, not an abort
