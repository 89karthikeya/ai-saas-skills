# Eval results — consolidated scoreboard

The single place to see every measured number, newest first. Each row links its
full writeup (method, per-case data, limitations). All runs are clean raw-API
(OpenRouter, no sota config), a **different** model grades each artifact **blind**
to which arm produced it, and every harness is in [`evals/`](../). Reproduce any
row from the command shown in its writeup.

## 1. Efficacy vs. an unguided model

Same model, same task, library loaded vs. nothing.

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="../../assets/lift-dark.svg">
    <img alt="Measured lift with the library vs without. Completeness 0.59 to 0.98 (+0.39) on claude-sonnet-4.6 and 0.62 to 1.00 (+0.38) on claude-sonnet-5 — durable. Freshness 0.44 to 0.97 (+0.53) on a set authored July 2026, 0.69 to 0.99 (+0.30) on that same set once aged, and 0.33 to 1.00 (+0.67) on a set re-authored August 2026 — the question set ages, not the library. Routing 0.90 to 1.00 (+0.10) then 0.87 to 0.99 (+0.13) — holds. Defects avoided 0.81 to 1.00 (+0.19) then 1.00 to 1.00 (+0.00) — expired." src="../../assets/lift-light.svg" width="100%">
  </picture>
</p>

| Dimension | Without | With SOTA | Lift | Samples | Source |
|---|---|---|---|---|---|
| **Completeness** (7 build tasks) | 0.59 | **0.98** | **+0.39** | 2 runs × 3, temp 0.7 | [MIRROR-VERIFICATION](2026-07-20/MIRROR-VERIFICATION.md) |
| **Completeness — `claude-sonnet-5`** (current flagship, 2026-06): **holds** | 0.62 | **1.00** | **+0.38** | 1×, temp 0.0 | [SONNET-5](2026-08-21/COMPLETENESS-SONNET-5.md) |
| **Freshness** (32 current-2026 facts) — `claude-sonnet-4.6` | 0.44 | **0.97** | **+0.53** | 3×, temp 0.7 | [MULTI-SAMPLE](2026-07-13/MULTI-SAMPLE.md) |
| **Freshness — `claude-sonnet-5`**, same set once **aged**: the set ages, not the library | 0.69 | **0.99** | **+0.30** | 3×, temp 0.7 | [ITEM-20](2026-08-25/ITEM-20-FRESHNESS-ROUTING.md) |
| **Freshness — `claude-sonnet-5`, set RE-AUTHORED 2026-08-25** (10 recent facts): **the lift returns** | 0.33 | **1.00** | **+0.67** | 3×, temp 0.7 | [ITEM-21](2026-08-25/ITEM-21-REFRESHED-FRESHNESS.md) |
| Routing (20 tasks) — `claude-sonnet-4.6` | 0.90 | **1.00** | **+0.10** | 3×, temp 0.7 | [MULTI-SAMPLE](2026-07-13/MULTI-SAMPLE.md) |
| Routing — **`claude-sonnet-5`** (current flagship): **holds**, unchanged within one case | 0.87 | **0.99** | **+0.13** | 3×, temp 0.7 | [ITEM-20](2026-08-25/ITEM-20-FRESHNESS-ROUTING.md) |
| Routing **robustness to router length** — 501 → 1,302 lines, table pushed 800 deeper | 0.87 | **1.00 at every length** | n/a — *not a lift* | 3×, temp 0.7 | [ROUTER-LENGTH](2026-08-26/ROUTER-LENGTH.md) |
| **ROUTING-SHIFT** — does a session that has settled into one task keep routing the *next*, differently-shaped question correctly? Not a library lift: both arms are with-library | shifted **0.500** | fresh **0.750** | **+0.250** — one case of four | 4 cases × 2 arms × 3, temp 0.7 | [ROUTING-SHIFT](2026-09-12/ROUTING-SHIFT.md) |
| ROUTING-SHIFT **after** the `sota-devsecops` description fix — both arms rise one case; the gap is unchanged | shifted **0.750** | fresh **1.000** | **+0.250** | 4 cases × 2 arms × 3, temp 0.7 | [ROUTING-FIX-DEVSECOPS](2026-09-12/ROUTING-FIX-DEVSECOPS.md) |
| **BUILD-safe** (7 defect classes the model must not *write*) — **sonnet-4.6** | 0.81 | **1.00** | **+0.19** | 3×, temp 0.7 | [BUILD-SAFE](2026-08-21/BUILD-SAFE.md) |
| BUILD-safe — **gpt-5.1**: bare arm saturates, so **no headroom** | 1.00 | 1.00 | +0.00 | 3×, temp 0.7 | [BUILD-SAFE §1b](2026-08-21/BUILD-SAFE.md) |
| BUILD-safe — **claude-sonnet-5** (current flagship): bare arm saturates | 1.00 | 1.00 | +0.00 | unguided 3×, guided 2× (one truncated build excluded), temp 0.7 | [BUILD-SAFE §1c](2026-08-21/BUILD-SAFE.md) |
| BUILD-safe, *with positive evidence of the safe path* — sonnet-4.6 | 0.29 | **0.62** | **+0.33** | 3×, temp 0.7 | [BUILD-SAFE](2026-08-21/BUILD-SAFE.md) |
| BUILD-safe, *with positive evidence* — gpt-5.1 (this measure does **not** saturate) | 0.43 | **0.52** | **+0.10** | 3×, temp 0.7 | [BUILD-SAFE §1b](2026-08-21/BUILD-SAFE.md) |
| **Does the terminal self-audit absorb competing context?** (ROADMAP 32) — the padded arm run with `BUILD_WORKFLOW` removed | pad-nogate **0.93** | with+pad **0.97** | **GATE-ABSORPTION +0.04** — *pre-registered H1 needed ≥ +0.05, so **H1 refuted**; H0's null band was ±0.03, so **underpowered, not null*** | 1×, temp 0 (7 tasks × 4 arms) | [GATE-ABSORPTION](2026-09-06/GATE-ABSORPTION.md) |
| **Routing recall over a gold SET** — does the description catalogue assemble *all* the skills a multi-domain task needs? Refutes the "knowledge is unreachable" hypothesis | recall **0.975** | precision **0.569** | over-selected **8/10** cases, under-selected **1/10** | 1×, temp 0 (10 cases) | [ROUTING-RECALL](2026-09-06/ROUTING-RECALL.md) |
| **Competing guidance vs rule application** — 400 lines of genuine unrelated rules prose added to the with-arm | with 1.00 | **with+pad 0.99** | **−0.01** — *a null, and it refutes a claim we were making* | 1×, temp 0.0 (7 tasks × 3 arms) | [COMPLETENESS-PADDING](2026-09-01/COMPLETENESS-PADDING.md) |
| **Prompt independence** — same 6 tasks under a **competing** prompt ("internal MVP, skip the extras", "no tests") | 0.491 | **1.000** | **+0.509** | 3×, temp 0.7 (18 runs/arm; with-arm sd 0.000) | [PROMPT-INDEPENDENCE](2026-08-31/PROMPT-INDEPENDENCE.md) |
| Prompt independence — the same tasks at *neutral* pressure, for contrast: the library helps **least** where every other number here is measured | 0.764 | **1.000** | +0.236 | 1×, temp 0.0 | [PROMPT-INDEPENDENCE](2026-08-31/PROMPT-INDEPENDENCE.md) |
| **Comment triage** — real vs wrong review comments, on the external **AACR-Bench** (Apache-2.0). Chance = 0.500 by construction. **Neither arm saturates**, unlike the audit instruments this replaces | 0.517 | 0.542 | **+0.025 — a registered NULL**, and underneath it a **threshold shift**: REAL recall −0.183, NOT_REAL recall +0.234 | 40 cases × 2 arms × 3, temp 0.7 (0 parse failures) | [COMMENT-TRIAGE](2026-09-12/COMMENT-TRIAGE.md) |
| Silent-control detection (81 inert-control cases) | 0.91 | 0.93 | +0.00 | 3×, temp 0.7 | [SILENT-FAILURE](2026-07-20/SILENT-FAILURE.md) |
| Audit **precision** (30 claims, 15 false) | 1.00 | 1.00 | +0.00 | 3×, temp 0.7 | [AUDIT-PROCESS](2026-07-20/AUDIT-PROCESS.md) |
| Audit (14 hard snippets) | 1.00 | 1.00 | +0.00 | 1× | [BASELINE](2026-07-10/BASELINE.md) |
| Cross-file audit (8-defect repo) | 1.00 | 1.00 | +0.00 | 2 models | [REPO-AUDIT](2026-07-13/REPO-AUDIT.md) |
| Dead-path **procedure** (4 items, live sub-agents) | 1.00 | 1.00 | +0.00 | 3 per arm | [DEAD-PATH](2026-07-30/DEAD-PATH.md) |
| Unscoped audit A — no vocabulary (8 defects) | 1.00 | 1.00 | +0.00 | 3 per arm | [UNSCOPED-AUDIT](2026-07-30/UNSCOPED-AUDIT.md) |
| Unscoped audit B — unusual defect classes (7) | 1.00 | 1.00 | +0.00 | 3 per arm | [UNSCOPED-AUDIT](2026-07-30/UNSCOPED-AUDIT.md) |
| **Real-repo audit — recall** — Harbor v2.5.1, 16 real BOLA sites, live agents | 15/16 | 15/16 | +0.00 | 1 clean per arm (2 of 4 discarded for contamination) | [REAL-REPO-AUDIT](2026-08-13/REAL-REPO-AUDIT.md) |
| **Real-repo audit — precision** — 59 findings, blinded 3-way adjudication vs the code | 1.00 | 1.00 | +0.00 | 29 + 30 findings, 1 report per arm; adjudicator passed a 4/4 known-answer control | [REAL-REPO-AUDIT](2026-08-13/REAL-REPO-AUDIT.md) |
| **Conflict rate between loaded skills** — `claude-sonnet-5`, a **CEILING** (full corpus of both skills; a session loads lean). Not a lift: there is no "without" arm — a conflict needs two skills | n/a | **0.176 verified** (judge-reported 0.353) | n/a | 17 pairs × 3, temp 0.0; judge separated a planted contradiction (1) from a benign pair (0) in the same batch; 3 of 11 reported conflicts had **fabricated quotes** | [CONFLICT-RATE](2026-09-09/CONFLICT-RATE.md) |
| **GATE-ABSORPTION** — what BUILD step 4's terminal self-audit recovers **under competing context** (400 lines of unrelated rules prose). Not a library lift: both arms carry the library | 0.929 `pad-nogate` | **0.991** `with+pad` | **+0.062** | 7 tasks × 4 arms × 3, temp 0.7; SE 0.019, **95% CI [+0.024, +0.099]**; 6 of 7 cases positive, none negative | [GATE-ABSORPTION-N3](2026-09-09/GATE-ABSORPTION-N3.md) |

**Completeness re-verified against the workflow that actually ships (2026-07-20).**
`run-completeness.py`'s `BUILD_WORKFLOW` is a hand-compressed **mirror** of router
BUILD steps 3–4, and it had drifted — the falsification clause added in #119 was
missing for four days, so this row was being measured against text that no longer
shipped. Both arms were run, and the synced arm **twice**: drifted **0.59 → 1.00 (+0.40)**;
synced **0.58 → 0.98 (+0.40)** and **0.60 → 0.98 (+0.38)**, two-run mean
**0.59 → 0.98 (+0.39)** — which is where the row now sits. The original `+0.39` was
never wrong. A 0.02 with-arm dip in the first synced run looked like it might be a
salience cost of the falsification clause; **the repeat run refuted that** — c1
recovered 0.86 → 0.94 and is simply the noisiest case (0.86–0.97 across three runs,
a 0.11 swing on its own). No measurable cost. Note the honest sequence: `+0.40` was
published from **one** synced run and the two-run mean is `+0.39` — small samples
again. Drift can no
longer recur silently: `ROUTER_BUILD_SHA` pins the router section and the runner
aborts on mismatch. Method, per-case table, limits:
[MIRROR-VERIFICATION.md](2026-07-20/MIRROR-VERIFICATION.md).

**Cross-model replication (2026-07-22): the +0.39 is not sonnet-specific.** Every
completeness number had used one build model (`sonnet-4.6`). Re-running the eval with a
**different-family frontier model**, `openai/gpt-5.1`, driving BUILD — same judge, same
rubrics, same 7 tasks — gives **0.44 → 0.88, lift +0.44** (every case positive, +0.29
to +0.55). The lift generalizes and is *larger where the baseline is lower* (gpt-5.1's
unguided arm is 0.44 vs sonnet's 0.59), the same "lift tracks incompleteness" mechanism
the breadth study found across domains, now reproduced across models. The with-arm
ceiling is lower (0.88 vs 0.98) — the library takes gpt-5.1 to *very good*, not
*near-perfect*. The blind judge shares a family with sonnet but not gpt-5.1, so if
anything +0.44 is a conservative floor. Two families ≠ model-agnostic, but the
single-model assumption is discharged for the flagship dimension.
[CROSS-MODEL.md](2026-07-22/CROSS-MODEL.md).

**Third family (2026-08-13/14): `google/gemini-3.1-pro-preview`, 0.38 → 0.96, lift
+0.58 at n=3, temp 0.7** (the n=1 run read +0.55; both are recorded).** Three labs, three positive lifts (+0.39 / +0.44 / +0.55), and the same
relationship each time — the lift tracks the **baseline**, not the lab: gemini's
unguided arm is the lowest measured (0.41) and takes the largest lift, sonnet's is
the highest (0.59) and takes the smallest. Re-run at **3 samples per arm** on 2026-08-14: every one of the 7 cases positive
(+0.52 to +0.67), with-arm mean 0.96 and max within-case spread 0.10 against the
unguided arm's 0.18 — the same higher-and-steadier pattern as the other
dimensions. Cost $4.48 (n=3) + $1.63 (n=1).
[CROSS-FAMILY-GEMINI.md](2026-08-13/CROSS-FAMILY-GEMINI.md).

The with-library arm is **near-zero variance** on every value dimension
(completeness ±0.01 across-case sd, routing/freshness ±0.00); the sampling wobble
is all in the unguided arm. Audit is +0.00 and reported, not hidden — a capable
model already recognizes vulnerabilities, even cross-file when the repo fits in
context. The audit frontier was an **agentic large-repo** audit — **and as of
2026-08-03 a *synthetic* one is ruled out**: a planted defect is by construction a
deviation from generated filler, and agents find deviations mechanically (bare arm
6/6 across two fixture generations,
[BIG-REPO-AUDIT](2026-08-03/BIG-REPO-AUDIT.md)). Only a **real** repo with **real**
defects could still test it. Original framing: an agentic large-repo audit
(too big to hold at once); logged in the [roadmap](../../docs/ROADMAP.md).

**Closed (2026-08-14) — nine instruments, four designs. The "Final (2026-07-30)"
paragraph below is superseded on its scope, not its conclusion.** It called the question
at seven instruments while naming the one design that could still overturn it: a *real*
repository at a *real* vulnerable commit. That design was then built and run — Harbor
v2.5.1, 16 real BOLA sites, live agents — and it returned the same answer on both
dependent variables: recall **15/16 = 15/16**, precision **1.00 = 1.00** over 59 blinded
findings with the adjudicator controlled at 4/4 (rows above). The audit arm is therefore
**+0.00 across nine instruments and four designs**, and the strongest available form of
the test is among them. ~~**Do not build a tenth accuracy instrument** — recall and
precision are both exhausted.~~

> **Superseded 2026-09-12 on its reasoning, and half of it was wrong.** A tenth instrument
> *was* built — [COMMENT-TRIAGE](2026-09-12/COMMENT-TRIAGE.md), on the external, Apache-2.0
> **AACR-Bench** — and building it was right. The **lift** conclusion survives intact: it
> read a registered **null** too, which is now ten instruments agreeing. What does **not**
> survive is the word *exhausted*. That rested on precision reading **1.00 in both arms**,
> which was taken as "precision is perfect, there is no headroom". On an instrument that
> discriminates, both arms sit **near chance** (0.517 / 0.542 against a constructed 0.500).
> **1.00/1.00 did not mean perfect — it meant the instrument could not tell.** The correct
> standing instruction is therefore the opposite of the struck sentence: *do not close an
> axis on a saturating measure*; a both-arms-perfect reading is a warning about the
> instrument, not a result about the system. Only a different *dependent variable* (time-to-find,
report usability, reach for a non-expert) is untested. **Calibration was measured on
2026-08-21** — unguided 2.67/4, with-library 4.00/4, the mover being *conditioning
severity on evidence* (1/3 → 3/3), judge validated on both controls first
([BUILD-SAFE](2026-08-21/BUILD-SAFE.md)). It stays **off this scoreboard and is never
reported as a lift**: it measures adherence to our own reporting doctrine, which is a far
weaker claim than "finds more bugs".

**Final (2026-07-30) — seven instruments, three designs, one answer: stop building
audit-recall instruments.** After the procedure design also returned +0.00, the
remaining explanation was that every instrument *hands the model its search space*
(`run-repo-audit.py` supplies a 21-slug vocabulary containing all 8 planted
answers) while the +0.39 BUILD instrument does not. Two experiments tested that,
pre-registered with numbers before either ran. **Both +0.00, both predictions
wrong** — the second by ~3x its own lower bound. Verified-library-free agents,
given only *"audit this repository"*, found a swallowed webhook signature, a
handler registered for an event nothing emits, a cache key narrower than the
behaviour it gates, an `assert`-as-authorization, and a scanner reading 64 KB of
a 25 MB allowance. The audit half is justified by gap analysis and by real
defects it found in this repo — **not by a measured lift**, and that is now the
settled position ([UNSCOPED-AUDIT](2026-07-30/UNSCOPED-AUDIT.md)).

**Update (2026-07-30) — the leading explanation for the audit nulls is refuted.**
The four nulls below were explained by "these instruments score *recognition*, and
a frontier model is already at ceiling there". `rules/11`/§3.9 grade a
**procedure** instead — mutate the control, delete the dependency, run the build —
so a fifth instrument was built specifically to test that distinction, with a
fixture whose traps make a careful static read get **half the items wrong**. Six
live sub-agents, 3 per arm: **both arms scored 1.000/1.000, +0.00**. The bare
agents ran the mutations, deletions and traces unprompted, and hit both inverted
traps and the REFUTED case. So the saturation is not about recognition-vs-procedure
([DEAD-PATH](2026-07-30/DEAD-PATH.md); the arms differ only in *reporting*
discipline — labels, bounded claims, fix-risk — which nothing here measures and
which must not be cited as a lift).

**The audit-family result, stated plainly (2026-07-21).** All four rows above that
score audit ability sit at **+0.00**: audit-hard recall, cross-file repo audit,
silent-control detection (n=81), and audit precision. Across *recall and precision*,
a frontier model handed the code and the question does not need the library — and
**every subgroup signal that looked like an exception dissolved when its subgroup
grew** (taxonomy-anchoring 6→26, over-flagging of loud controls 8→20). This is not
"the audit content is worthless": it is "no single-prompt eval can distinguish
audit-*process* guidance, because when the code and the question both fit one prompt
the model is already at ceiling." The library's audit half is currently justified by
gap analysis and one real-world self-audit that found two genuine defects in the
harness ([EVALS-SELF-AUDIT](2026-07-21/EVALS-SELF-AUDIT.md)) — **not by a measured
lift**, and that is stated rather than implied. The only design that could move it is
the agentic large-repo audit — *since qualified: a synthetic fixture cannot do it
(2026-08-03), only a real repo with real defects could*. The measured lift lives
entirely in **BUILD**
(completeness +0.39, freshness +0.53; both re-measured on the current flagship
2026-08-25 — completeness +0.38, freshness **+0.30 and eroding**, [ITEM-20](2026-08-25/ITEM-20-FRESHNESS-ROUTING.md)).

**Retraction (2026-07-20).** This row first shipped as **0.92 → 0.99 (+0.07)**
from a 15-case set. Growing the set to **49** — adding harder cases that broke the
ceiling, 8 negative controls, and 6 mechanisms the rule file does *not* enumerate
— **did not reproduce it**: +0.03 (vocabulary design), −0.01 (open-ended design),
both inside a per-arm spread of ±0.04. **The +0.07 was small-sample noise.** The
row now reads +0.00. An ablation isolating `sota-code-security` rules/10 returns
**+0.00** (vocabulary design: with and ablated identical at 0.918, same four
missed cases). Two things worth knowing: the **taxonomy-anchoring hypothesis is now
tested and retired** — the novel subgroup was grown 6 → 26 and the gap collapsed
from 1.00 vs 0.83 to **0.96 vs 0.92 (one case, inside run spread)**, so the
library's enumerative content pattern is not shown to hurt generalization; and the design's own limit is that both arms must be *told* to hunt inert
controls, which is the lens the rule teaches, so what it uniquely adds stays
unmeasured. Full detail, subgroup tables, and limitations in
[SILENT-FAILURE.md](2026-07-20/SILENT-FAILURE.md).

**Regression check (2026-07-16).** Three guidance changes adopted from an external
review (negative routing cross-refs; a plan-concreteness clause in BUILD step 3; a
new "claim done only with evidence" operating principle) were regression-tested by
re-running this 3× completeness eval — because our own
[context-rot finding](../../docs/WHY-COMPLETENESS-RESIDUAL.md) warns that *adding*
guidance text can lower salience. Result: with-arm **0.991** (was 0.996), lift
**+0.385** (was +0.395) — statistically unchanged (Δ −0.005, inside the run's
sampling noise; the two dipped cases have an **empty aggregate missing-set**, i.e.
no cross-cutting concern was systematically dropped, and c7 — the prior wobbler —
went to 1.00). Routing was re-run too (principle 6 is added to the router, which
the routing eval pastes whole): with-arm **held at 1.00** (n=3, no misses), lift
+0.09. The changes are kept. Raw:
`2026-07-13/completeness-3sample-postadopt.json` + `routing-3sample-postadopt.json`.

## 2. Live-agent validation

Does the paste-based completeness eval reflect a real router-driven agent?

| Test | Result | Source |
|---|---|---|
| 7 live sub-agents, real router BUILD workflow, blind judge | **0.987** (6/7 perfect) ≈ the 0.988 paste-simulation | [LIVE-BUILD](2026-07-13/LIVE-BUILD.md) |

The simulation is a faithful proxy, and the self-audit gate caught real bugs live
(a prod `/docs` exposure, an unbounded DB critical section, a task-cancellation leak).

## 3. Competitor benchmark — SOTA vs. the most popular libraries

Content-only (SOTA's self-audit **off**), same rubric, blind judge, on the 7
Python/FastAPI backend completeness tasks. Targets validated live via the GitHub
API. This is the Python backend row of a broader picture — the five-domain breadth
run below ([BREADTH.md](2026-07-13/BREADTH.md)) shows the lead tracks the **unguided
baseline** (task incompleteness), not the domain.

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="../../assets/benchmark-dark.svg">
    <img alt="Best-practice completeness on backend build tasks by library: SOTA-skills 99%, affaan-m/ECC 87%, PatrickJS/awesome-cursorrules 83%, alirezarezvani/claude-skills 81%, unguided model 58%." src="../../assets/benchmark-light.svg" width="100%">
  </picture>
</p>

One consolidated view — every competitor's standing in a single table. Scores are
**% of a fixed best-practice rubric the generated code actually implements**
(blind-judged); higher is better.

| Library | Stars | Completeness (7 backend tasks) | Confidence (3 tightest, 3×) | Gap vs SOTA-skills | This library vs SOTA-skills — won / tied / lost¹ |
|---|---|---|---|---|---|
| [**SOTA-skills**](https://github.com/martinholovsky/SOTA-skills) | — | **99%** | **98%** | — | — |
| [affaan-m/ECC](https://github.com/affaan-m/ECC) | ~230k | 87% | 87% | −12 pts | 0 / 2 / 5 |
| [PatrickJS/awesome-cursorrules](https://github.com/PatrickJS/awesome-cursorrules) | ~40k | 83% | 82% | −16 pts | 0 / 0 / 7 |
| [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | ~23k | 81% | 82% | −17 pts | 0 / 1 / 6 |
| unguided model | — | 58% | 65% | −40 pts | — |

### 3a. Superpowers — a different shape, measured separately on purpose (2026-09-08)

**Deliberately not a row in the table above**: it is a separate run
(build `claude-sonnet-4.6`, judge `claude-opus-4.8`, **1 sample/arm/case, temp 0.0**,
7 cases) whose own unguided arm read **0.637**, not the 58% above — merging them would
imply a comparability this does not have.

| arm | completeness | vs SOTA | vs unguided |
|---|---:|---:|---:|
| SOTA-skills | **0.987** | — | +0.35 |
| unguided | 0.637 | −0.35 | — |
| [obra/superpowers](https://github.com/obra/superpowers) @ `b36e0829` (~282k ★) | 0.599 | −0.39 | **−0.04** |

**Read the caveat before quoting the number.** Superpowers is *process* guidance (TDD loop,
systematic debugging, verification-before-completion); these cases score whether a **built
artifact** embeds domain best practices. **A low score here is evidence about fit to this
measure, not about that project.** The honest headline is the unflattering one: on this
measure Superpowers is **indistinguishable from no guidance at all** (−0.04 against a
measured ±0.03 noise floor at n=1) — which reports our instrument's blind spot as much as
anything else. It settles that the two are not substitutes and are not measured by the same
yardstick; it does **not** adjudicate the assessments' actual claim, that a methodology is a
more complete offering than a corpus. Full write-up and limits:
[SUPERPOWERS-HEAD-TO-HEAD](2026-09-08/SUPERPOWERS-HEAD-TO-HEAD.md).

**Re-run 2026-08-14/15 — the ranking and the gap are stable.** Same build model (verified unchanged since the original commit), same pinned competitor SHAs: SOTA **98.7%**, ECC 84.9%, awesome-cursorrules 80.0%, claude-skills 77.0%, unguided **58.2%** — and SOTA again **won 17, tied 4, lost 0** of 21 head-to-head cases. The unguided arm reproducing to 0.2 points is the control that says the harness did not drift. Competitor moves of 2–4 points are **not** claimed as regressions (n=1 per arm). [COMPETITOR-RERUN](2026-08-14/COMPETITOR-RERUN.md).

¹ **This library's record against SOTA-skills**, across the 7 build tasks (how many
that library scored *higher than* / *equal to* / *lower than* SOTA-skills,
single-sample). Read it on the library's own row: `0 / 2 / 5` on the
[affaan-m/ECC](https://github.com/affaan-m/ECC) row = ECC **won 0, tied 2, lost 5**.
**No competitor won a single task against SOTA-skills** (on backend).

**Breadth — the lead tracks the unguided baseline, not the domain** (5 domains).
SOTA-skills leads where a base model ships *incomplete* code and ties where it's
already near-complete. Ordered by unguided baseline, the green lead appears only
where the unguided bar is low:

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="../../assets/breadth-dark.svg">
    <img alt="Completeness % by domain (unguided / best competitor / SOTA-skills), ordered by unguided baseline: hard frontend 53/83/93, Python backend 58/87/99, Go backend 67/87/97, simple frontend 77/97/97, IaC 87/100/100. SOTA-skills leads where the baseline is low and ties where it is high." src="../../assets/breadth-light.svg" width="100%">
  </picture>
</p>

| Domain | Unguided | SOTA-skills | best competitor | SOTA lead |
|---|---|---|---|---|
| Frontend — hard SSR/auth | 53% | **93%** | 83% | **+10** |
| Python backend | 58% | **99%** | 87% | **+12** |
| Go backend | 67% | **97%** | 87% | **+10** |
| Frontend — simple forms | 77% | 97% | 97% | +0 |
| IaC (K8s/Docker/TF) | 87% | 100% | 100% | +0 |

Clean threshold near **0.7 baseline**: below it (production backend in any language,
complex/security-sensitive frontend) SOTA-skills leads by ~10 pts; above it (simple
UI, templated infra) everyone converges. So the win isn't "backend" — it's **wherever
the base model's default is incomplete.** The mechanism: the library forces in the
concerns a base model silently omits, and that headroom is large only when the missing
pieces need non-trivial added logic (rate-limit middleware, a server-side auth check),
small when they're a well-known template field the model already emits (a K8s
`securityContext`, a React controlled input). Per-domain notes + raw data:
[BREADTH.md](2026-07-13/BREADTH.md).

SOTA-skills **wins or ties all 21 head-to-head cases and loses none.** The
confidence check confirms it isn't noise: gaps match the full run, and
**SOTA-skills' worst sample ≥ each competitor's best sample** on every tight case.
Competitors are legitimate (all beat an unguided model by +17 to +28 pts) but drop
the cross-cutting non-negotiables (rate limiting, transport, tests) — even the
~230k-star [affaan-m/ECC](https://github.com/affaan-m/ECC)
omits rate limiting on 3 of 7 tasks. Full method + honest limits (backend + frontend, content-only, bundle-size
asymmetry): [COMPETITOR-BENCHMARK](2026-07-13/COMPETITOR-BENCHMARK.md).

## 4. Skill-application decay over a long session

Does a rule loaded early stop being applied as the session grows?
([`run-decay.py`](../run-decay.py); the mechanisms that fight it live in
[docs/CONTEXT-MANAGEMENT.md](../../docs/CONTEXT-MANAGEMENT.md).)

| arm | K=0 | K=15 | K=30 turns of filler | Source |
|---|---|---|---|---|
| guidance at turn 1 | 1.00 | 1.00 | **1.00** (no decay) | [DECAY](2026-07-13/DECAY.md) |
| no guidance (control) | 0.40 | 0.40 | 0.40 | |

First run: **no decay at moderate scale** — an ~18.6K-token (~72 KB) guidance block held after 30
unrelated turns. This *bounds* the problem but doesn't find the breaking point (the
filler is too small to dilute the anchor); scaling the test up needs a top-up.
*(roadmap **item 49**, still open — cited as *item 5* until 2026-09-11, a number that has
meant the 6-month accuracy sweep since the ledger was renumbered.)*

## 5. Description-based routing — do the negative cross-refs help? (A/B, +0.00)

Skill descriptions carry negative cross-references ("Not for X — use sota-Y") to
disambiguate confusable siblings. This is the path a skill **auto-loader** uses
(pick from the description catalogue), distinct from the router table §1 measures.
[`run-desc-routing.py`](../run-desc-routing.py) A/Bs the *same* catalogue with vs
without those clauses on 10 adversarially-confusable tasks (each names the correct
skill and the tempting sibling), 3× temp 0.7, objective name-match scoring.

| arm | correct | distractor-pick | Source |
|---|---|---|---|
| with cross-refs | 0.80 | **0.00** | [desc-routing-3sample.json](2026-07-13/desc-routing-3sample.json) |
| without cross-refs | 0.80 | **0.00** | |

### 5b. Conflict rate at LEAN loading — the floor (ROADMAP 47)

ROADMAP 39 measured a **ceiling** by handing the judge every `rules/*.md` of both skills.
This measures the **floor**: `SKILL.md` only, which is what BUILD step 2 opens before any
rules file. Both arms run on the **same tree on the same day** — the point of the design.

| arm | corpus | judge-reported | hand-verified | Samples |
|---|---|---|---|---|
| full | 1,546,535 chars | 0.471 (8/17) | not computed | 17 pairs × 3, temp 0.0, `claude-sonnet-5` |
| **lean** | **147,116 (9.5%)** | **0.176 (3/17)** | **0.000** | 17 pairs × 3, temp 0.0, `claude-sonnet-5` |

**Loading lean cuts the judge-reported conflict rate 63%, and the lean floor hand-verifies
to zero** — all six reported conflicts refute, five of them in the two classes the judge
cannot resolve because it is blind to the router (finding format, severity precedence).

**The lived rate is between the arms and neither arm is it.** A real lean session opens
*some* rules files; this one opened none.

**Do not read the full arm as a before/after against ROADMAP 39's 0.353.** The corpus grew
50k characters in between, partly from rules added to those same skills hours earlier, so
repairs, new content and judge noise are confounded there. The same-tree comparison above is
immune to all three.

### 5a. The trailing `Trigger keywords:` lists — A/B, **+0.000** (ROADMAP 53)

Same instrument, second ablation: strip the `Trigger keywords:` tail that 40 of 42
descriptions carry (**12,227 of 37,330 characters, 33% of the corpus**) and see whether
routing moves. Pre-registered with the null band, the decision thresholds and a predicted
null, all committed before any call
([PRE-REGISTRATION](2026-09-11/PRE-REGISTRATION-KEYWORD-TAILS.md) ·
[write-up](2026-09-11/KEYWORD-TAILS.md)).

| arm | correct | distractor-pick | Samples |
|---|---|---|---|
| with keyword tails | 0.900 | 0.000 | 10 cases × 3, temp 0.7, `claude-sonnet-4.6` |
| without keyword tails | 0.900 | 0.000 | 10 cases × 3, temp 0.7, `claude-sonnet-4.6` |

**Δ = +0.000, and 0 of 10 cases moved** — not one of 60 calls picked a different skill.
Detection limit stated rather than hidden: 0/10 puts the rule-of-three 95% upper bound on the
per-case flip rate at ~**0.26**, so this bounds the effect, it does not prove it nil.

**What it cost to get a trustworthy null: 186 paid calls and two instrument defects.** The
first two runs read **−0.100** and crossed the registered "the tails actively hurt" threshold.
Both were artefacts: the single case driving it (`q7_pod_hardening`) was **mislabelled**
against the router's own rule 9, *and* the ablation was **impure** for that very skill
(`sota-kubernetes` keeps its cross-reference after the keyword list, so the strip removed two
features). Corrected, the effect vanished entirely. The number had been measuring the
instrument.

**This says nothing about the listing budget.** The runner hands the model the whole catalogue,
so it measures matching *given the text is present* — whereas §52's mechanism drops whole
descriptions before the model ever sees them. The two halves are independent and both stand.

**The regression set is a separate instrument and must not be averaged in here**
(`evals/cases/desc-routing-regressions.jsonl`; selection-by-outcome is its point). Run
2026-09-08, `claude-sonnet-5`, **3 samples per case per arm, temp 0.0, 2 cases**: after a
one-keyword fix both cases read **1.00 in both arms**, distractor-pick 0.000. The run's value
was not the score — it caught `r1_token_count` **regressed** to the wrong skill 3/3, live for
a day since v1.35.0 added a description that claims r1's *noun* while the correct skill claims
its *question*
([ROUTING-REGRESSION-SET](2026-09-08/ROUTING-REGRESSION-SET.md), ROADMAP 44).

**Over-selection has now been priced** (ROADMAP 38, 2026-09-08): counted with
`count_tokens` over the 2026-09-06 routing run, over-selected skills cost a **mean 10,738
tokens per task, +109%** on the `SKILL.md` load — a cost in tokens and latency, not in
measured quality (padded context read −0.01 and −0.03). Samples: arithmetic over one measured
10-case run, no new sampling
([OVER-SELECTION-COST](2026-09-08/OVER-SELECTION-COST.md)).

**Honest +0.00.** The model **never** routed to the warned-against sibling in
*either* arm (distractor-pick 0.00 across all 10 cases × 3 samples, perfectly
steady) — so the cross-ref had nothing to fix here. The two non-`expect` picks are
*defensible co-answers*, not distractor mis-routes (a goroutine-race task → the Go
language skill; pod-securityContext hardening → `sota-sandboxing`, which covers pod
security), and they are identical in both arms. Like audit (+0.00), a capable model
already does the easy version: the description-selection path is **saturated** for a
frontier model on these pairs. The cross-refs are kept anyway — zero runtime cost,
harmless, and plausibly useful for weaker/smaller models or genuinely ambiguous
phrasings outside this set (a prediction, not measured). No routing lift is claimed.

## 6. Router refactor regression — does offloading the library map cost routing? (±0.000)

The router's 108-line **library map** moved to `sota/rules/04-library-map.md`, taking
`skills/sota/SKILL.md` from 499 to 398 lines and **16,997 → 13,415 tokens** (−21.1%
per load; `count_tokens`, `claude-sonnet-5`). This checks the accuracy side.
[`run-clean.py --cases router.jsonl`](../run-clean.py) run twice against trees
differing **only** in the router — `main` in a `git worktree`, so both existed at once.
Pre-registered before either arm ran.

| arm | recall BEFORE | recall AFTER | Δ | Samples |
|---|---|---|---|---|
| **with-library** (treatment) | **1.000** | **1.000** | **+0.000** | 3 × 20 cases, temp 0.7, per config |
| without-library (control — never reads the router) | 0.900 | 0.900 | +0.000 | 3 × 20 cases, temp 0.7, per config |

**The pre-registered falsification condition — a recall drop — did not trigger**: zero
misses across 120 case-samples. Three caveats, all in
[ROUTER-MAP-OFFLOAD.md](2026-09-03/ROUTER-MAP-OFFLOAD.md): recall is **at ceiling** so
this can only detect a drop; the control's Δ=0.000 is **not** a measured noise floor
(its identical per-sample triple looked like provider caching until checked — its
predictions do differ, in 1 of 20 cases); and the treatment arm's predictions churn in
**11 of 20** cases, so the favourable `Δprecision=+0.037` is **not reportable** at n=3,
consistent with the golden set's own header (*extra loads are not penalized; a MISS is
the real signal*). Evidence of **no detected degradation**, not of no change.

**Instrument correction worth keeping.** The PR first proposed
[`run-desc-routing.py`](../run-desc-routing.py) (§5). That runner reads only frontmatter
`description`s and **never the router body** — the arm could not have seen the
treatment, so its `+0.00` would have been structural. Caught by reading the runner
before spending; the fake null would have looked identical to this real one.

## Not yet measured (open)

- **Competitor breadth — DONE (5 domains).** The lead tracks the unguided baseline,
  not the domain (table above; [BREADTH.md](2026-07-13/BREADTH.md)). Data pipelines /
  mobile / CLI remain untested, but the baseline-driven pattern is established.
- ~~**As-deployed competitor comparison**~~ — **REJECTED 2026-08-16, not open**, and
  moved off this list on 2026-09-11 because a rejected-with-reason idea sitting under a
  heading that says *open* is how it gets re-litigated. Checked against the pinned clones:
  two of the three competitors deploy through *exactly our own mechanism* (ECC ships 889
  `SKILL.md` files with a `.claude-plugin/marketplace.json`, claude-skills 777), so
  "as deployed" is not three mechanisms — it is our mechanism over a corpus 20× ours, which
  measures **corpus size** and a **retrieval path already measured as saturated** (§5 reads
  +0.00). Full reasoning: [ROADMAP item 3](../../docs/ROADMAP.md).
- **Full-7 multi-sample** of the competitor arms (only the 3 tightest done).

## The three-layer story

SOTA **lifts an unguided model** where it matters (completeness +0.39, freshness
+0.53 — on the current flagship +0.38 and +0.30 respectively, the freshness figure
eroding as its fixed case set ages into the model's cutoff, [ITEM-20](2026-08-25/ITEM-20-FRESHNESS-ROUTING.md)); that lift **reproduces in a live agent** (0.99); and it **beats the most
popular competing libraries** head-to-head **on tasks a base model gets incomplete**
(production backend in any language, complex/security-sensitive frontend: ~+10 pts) —
while honestly bounding it: on tasks the base model already handles well (simple UI,
templated infra) everyone converges. The lead tracks task incompleteness, not the
domain. Boundaries stated, not buried.
