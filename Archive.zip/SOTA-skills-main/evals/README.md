# evals/ — efficacy regression harness (prototype)

Freshness (see [../docs/MAINTENANCE.md](../docs/MAINTENANCE.md)) keeps the
library's claims *true*. This harness asks a different question: does loading a
skill actually change agent output for the better? It turns "the skills work"
from an assertion into a number you can re-run.

**This is a prototype and is deliberately not in CI.** An LLM eval is
non-deterministic and needs an agent + network, so it can't be a blocking gate.
You run an agent over the cases yourself and score the result here. The value
is a repeatable baseline: run it before and after a large content change and
watch the score, and grow the golden sets as coverage warrants (2026-07-10
audit STRAT-HIGH-2).

## Cases

- `cases/build-safe.jsonl` (7) + `cases/build-safe/` — **the only generative
  instrument**: it scores what the model *writes*, not what it finds. `SPEC.md`
  states the operational pressure that makes each unsafe shortcut attractive
  ("cache it", "must never 5xx", "keep the guard cheap") and **never names a
  defect**; scoring is avoidance of a `fail` pattern the model never sees. Two
  references (`unscoped-audit/reportkit` must score 0/7, `build-safe/reference-safe`
  7/7) are enforced by `run-build-safe.py --selftest` — run it before trusting any
  number. Note the file is 49 lines of which 42 are comments: **7 real cases**, and
  `load_cases` exits rather than score an empty set. The July 2026 attempt failed
  because the spec leaked the property to preserve and the bare arm saturated; the
  rewrite is what made it discriminate (`results/2026-07-30/BUILD-SAFE.md` →
  `results/2026-08-21/BUILD-SAFE.md`).
- **`run-conflict-rate.py`** — ROADMAP 39, and **v2 of `run-routing-recall.py`**, which
  named this and left it out because it needs a judge. v1 asks whether the descriptions
  deliver the composition the router promises; this asks whether two skills loaded
  *together* give **contradictory** prescriptions. It is the one failure mode with a real
  incident behind it — a liveness-probe rule against a no-`await` `async def` rule, in a
  live build, which is why the router carries a conflict-resolution clause at all.
  Composition comes from `routing-recall.jsonl`'s gold sets (**no routing call**, so a
  routing error cannot contaminate a conflict number) and each case expands into every
  unordered pair of its skills; single-skill cases contribute none and are printed as
  excluded. The judge sees both skills' **full** corpus — `SKILL.md` plus every
  `rules/*.md`, labelled by path so a quoted conflict can be checked by hand — which
  makes the number a **ceiling**, not the lived rate: a real session loads lean, so a low
  number is strong and a high one is not yet a claim about practice.
  **`--lean` measures the other end of that bracket** (ROADMAP 47): the judge sees each
  skill's `SKILL.md` **only** — 8% of the full corpus — which is the **floor** of what
  BUILD step 2 loads. Deliberately the floor rather than "SKILL.md plus the rules files
  the index names for this task", because choosing those files is the *measurer's*
  judgement and the measurer holds the hypothesis. Floor and ceiling bracket the lived
  rate with nobody's judgement in between; **neither arm is the lived rate itself**, and
  the two are only comparable when run on the same tree — the published 0.176 predates the
  repairs of the conflicts it found.
  **The judge is a control.** Two synthetic pairs run in the same batch — one with a
  planted head-on contradiction that must report ≥ 1, one benign that must report 0. If
  they do not separate the run is **VOID and prints no rate**, because a judge that
  answers "no conflicts" to everything produces exactly the number this project would
  like. Both branches were watched to fail. `parse_conflicts` returns `None`, never `[]`,
  on an unparseable verdict and the runner aborts on it — a broken judge and a clean
  library must not be the same number, and `--selftest` asserts precisely that.
  `--max-chars` aborts when a pair's corpus would be truncated (the largest is ~397k
  characters): a truncated corpus cannot contain the contradiction it was truncated past,
  and the under-count would carry no signal that it was one. `--judge-model` selects the
  judge and **must have a large context** for that reason — pairs reach roughly 150k
  tokens, and a model whose window is smaller will not fail loudly, it will read less.
  **`--verify <artifact>`** post-processes a saved run and is where the *quotable* number
  comes from: it reports which quoted sentences do **not** exist in the file the judge
  named — a fabrication, which kills that conflict with no judgement needed — and prints
  the survivors for the hand read the pre-registration requires. Whitespace is normalised
  (the judge re-wraps prose); wording is not, because a quote that differs in wording *is*
  a fabrication. The judge-reported rate is never the headline; the verified one is.
- **The BUILD-safe arms** (`run-build-safe-arms.py` unguided, `run-build-safe-arms-guided.py`
  guided) — the two live-model arms that feed `run-build-safe.py`'s scorer. The guided one
  loads **only the BUILD-facing rules files** a router-following builder would open and
  deliberately excludes the audit-side ones (`rules/10`, `11`, `13`, `14`), which makes the
  test harder rather than easier: the arm is not allowed to consult the files that name the
  very defects it is being scored on avoiding. It reads operating principle 5 live, under the
  same drift guards as the completeness runner, so a router edit aborts the arm instead of
  silently measuring a stale mirror. Both arms write an artifact for the scorer; neither
  scores anything itself.
- **`run-unscoped-audit.py`** — the **adjudicator** for `cases/unscoped-audit.jsonl`, not a
  runner of it. A planted defect counts as FOUND only when the report names the *mechanism*
  (from the case's `must` list) **and** points at one of its `primary` files; the rule was
  fixed in `results/2026-07-30/PRE-REGISTRATION.md` before any agent ran, because either
  signal alone is worthless — the file without the mechanism is "looked at it", the mechanism
  without the file is unlocated. It also emits a **CONTAMINATION** verdict, since the
  2026-07-30 live runs showed "bare" sub-agents inheriting a global instruction to consult
  this library and loading it anyway; self-report is not evidence, library citations in the
  text are. `--selftest` locks the adjudicator before you trust a number from it.
- **Calibration** (`run-calibration.py`, `judge-calibration.py`) — scores an audit
  report's *reporting discipline*, never its recall: does it bound claims by what
  was run, label unverified items, condition severity on evidence, and support any
  absence claim with the search behind it. The judge is **blinded** and run with a
  deliberately mis-calibrated and a deliberately well-calibrated control in the same
  batch; if those two do not separate (0/4 and 4/4), the arms mean nothing and must
  not be read. **Never report this as a lift** — it measures adherence to this
  project's own doctrine, per `docs/ROADMAP.md`.

- `cases/dead-path.jsonl` (4) + `cases/dead-path/` — **the only instrument here
  that scores a *procedure* rather than a recognition**, and the one design that
  might move the audit family off +0.00. Every other audit set asks "can the model
  spot this?" and the answer is already yes without the library. This one asks
  whether the model **mutates the control, deletes the dependency, and runs the
  real build** — what `sota-code-security` rules/11 and `sota-devsecops` rules/10
  require. The fixture is built so a careful static read gets **half the items
  wrong**: two look like the opposite of what they are, and one is a REFUTED case
  that punishes flagging everything. Scored deterministically by
  `run-dead-path.py` — no judge, no API key, no network — on two axes, verdict
  accuracy and *proof compliance* (a right verdict with no executed evidence is not
  full credit). `selfcheck.sh` re-derives the fixture's six planted properties by
  mutation; `--selftest` proves the scorer still separates a report that reasoned
  from one that ran. Both run in CI. **Run 2026-07-30, 6 live sub-agents, 3 per
  arm: +0.00 — both arms 1.000/1.000.** The pre-registered hypothesis (bare agents
  reason, guided ones run the procedure) is **refuted**: the bare agents mutated
  the controls, deleted the modules and traced execution unprompted, and got both
  inverted traps and the REFUTED case right
  ([DEAD-PATH](results/2026-07-30/DEAD-PATH.md)).
- `cases/reimplement.jsonl` (10) + `run-reimplement.py` — **documentation, not a
  measured instrument.** Never run against a live agent; no number from it may be
  cited. It encodes the conflict between `sota-devsecops` rules/10 **§4**
  (a poor leverage ratio is a replace-in-house candidate) and **rules/10 §6 bucket C**
  (which overrides that for crypto/enumerated families and for anything whose output
  is persisted and must stay comparable). Five disqualified cases each have a ratio
  that screams REPLACE, and five legitimate cases each *resemble* a disqualified one,
  so ratio-only and refuse-everything both score exactly **0.500** — verified by a
  three-arm selftest in CI. Kept because building it did the useful work: it exposed a
  real ambiguity in rules/10 §6 (a request signer is a "protocol", so the clause forbade
  something reasonable), now fixed there with the loud-vs-silent distinction. Seven
  audit instruments already read +0.00 and [ROADMAP](../docs/ROADMAP.md) says not to
  build an eighth.
- `cases/router.jsonl` (20) — routing: a plain prompt → the skills that must
  load. Tests the router's task→skill mapping.
- `cases/audit.jsonl` (13) — audit: a deliberately vulnerable snippet → the
  finding category an audit must flag. Tests that the security skills catch the
  obvious. `cases/audit-hard.jsonl` (14) is the harder set — multi-vuln + subtle
  (IDOR/SSRF/TOCTOU/ReDoS); it *still* saturates at 1.00 both arms (see below).
- `cases/repo-audit.jsonl` (8) + `cases/repo-audit/orderdesk/` — a 15-file
  FastAPI app with 8 defects that are **invisible in any single file** (an authz
  check one layer assumes another enforces, a taint that crosses modules, an
  invariant one file documents and another violates, an insecure default trusted
  elsewhere). Scored by `run-repo-audit.py`. Result: **+0.00** on sonnet-4.6 and
  opus-4.8 — when the whole repo fits in one context, a capable model reads
  across files and catches cross-file defects unaided
  ([`results/2026-07-13/REPO-AUDIT.md`](results/2026-07-13/REPO-AUDIT.md)). The
  real audit-lift frontier is a repo too large to hold at once (agentic,
  selective reading), logged there as the open follow-up.
- `cases/completeness.jsonl` (7) — a minimal "build X" task → a rubric of
  universal best practices a blind judge scores the generated code against. The
  breadth run adds `completeness-{go,iac,frontend,frontend-complex}.jsonl` (3 each)
  for the five-domain baseline analysis.
- `cases/freshness.jsonl` (32) — a current-2026 fact question → the token a
  correct answer must contain. Every fact is present in the library and was
  primary-source-verified. **This set is ageing by design and now under-reads its own
  claim**: 8 of its 32 facts moved inside `claude-sonnet-5`'s training window between
  July and August 2026, dropping the measured lift +0.53 → +0.30 while the *with*-arm
  rose. Kept unchanged as the continuity series — do not edit it, add to it.
- `cases/freshness-2026.jsonl` (10) — the **refreshed** set, authored 2026-08-25 from
  facts whose primary source changed Sept 2025 – Aug 2026. Reads **0.33 → 1.00, +0.67**
  on the same model the same day ([ITEM-21](results/2026-08-25/ITEM-21-REFRESHED-FRESHNESS.md)),
  which is what proved the +0.30 was the *instrument* ageing rather than the library.
  **Its selection rule is the load-bearing part and is written into the file's header**:
  cases were chosen by recency and by the library stating the fact — never by whether a
  model got them wrong. That shortcut was available (10 of the old 32 still discriminate)
  and picking those would guarantee a large lift while measuring nothing.
- `cases/silent-failure.jsonl` (81) — a control that **looks enabled and does
  nothing** (inert scanner, fail-open policy, ruleset that loads zero rules,
  truncation before inspection, a test that passes against a no-op'd body …) →
  the mechanism by which it is inert. 61 positives (35 enumerated + **26 tagged
  `novel`**, mechanisms `sota-code-security` rules/10 does *not* enumerate — which
  separates "teaches the lens" from "recites its own list") + **20 negative controls**
  whose correct answer is "not silent" (the control fails loudly), so an arm that cries
  no-op at everything cannot score 1.00 — each negative deliberately *resembles* a
  positive class, so shape-matching trips. Two designs: `run-clean.py`
  (vocabulary given — classification) and `run-silent-open.py` (free-form, blind
  opus judge — discovery), both with an `--ablate` arm that removes rules/10.
  Result: **+0.00 — no measurable lift**, reproduced at n=49, n=69 and n=81.
  An earlier **+0.07 from a 15-case version did not replicate and is retracted**.
  The `novel` subgroup was grown 6 → 26 to test whether the enumerated catalogue
  *anchors* the model onto its own list: **it does not** (0.96 unguided vs 0.92
  with-library — one case, inside run spread), so that hypothesis is retired too
  ([`results/2026-07-20/SILENT-FAILURE.md`](results/2026-07-20/SILENT-FAILURE.md)).
  **Case-authoring note:** cases carry answer keys (`expect`, `reference`) and
  analysis metadata (`novel`); the runners whitelist only the input fields
  (`id`/`language`/`snippet`/`prompt`/`task`) into the prompt, so a new field
  cannot silently leak the answer — and `run-clean.py` aborts if a case is left
  with no content field at all, the guard added after that whitelist silently
  emptied the routing eval.
- `cases/finding-adjudication.jsonl` (30) — audit **precision**, the mirror of every
  other audit set here: a code snippet + a *claimed* finding → UPHELD or REFUTED.
  15 genuine claims and 15 plausible-but-wrong ones failing for six distinct reasons
  (upstream guard, unreachable code, inflated severity, misread mechanism, already
  mitigated, behaviour that is actually correct). Scored by `run-adjudication.py` on
  **specificity** (refute the false) and **sensitivity** (keep the real), with an
  ablation arm that strips `rules/01` §6. Result: **+0.00 — all three arms 1.00**,
  zero wrong answers in 90 adjudications per arm
  ([`results/2026-07-20/AUDIT-PROCESS.md`](results/2026-07-20/AUDIT-PROCESS.md)).
- `cases/desc-routing.jsonl` (10) — an adversarially-confusable task → the correct
  skill (`expect`) and the tempting wrong sibling (`distractor`). Scored by
  `run-desc-routing.py` as an A/B on the description cross-refs (result: +0.00).
- **`run-comment-triage.py`** — can a reviewer tell a **real** review comment from a
  **wrong** one? Built on an adopted external instrument, **AACR-Bench** (Alibaba Aone,
  Apache-2.0): 2,145 expert-labelled comments over 200 PRs, 50 repositories and 10
  languages. **Why it exists:** this library's own audit-precision instruments *saturate*
  (30 claims, 1.00 in both arms), so the audit-accuracy axis was closed for want of a
  measure that could discriminate — not because precision had been demonstrated. Two arms
  over the same case and the same frozen code context: **bare** (judging prompt alone) vs
  **with** (the prompt plus `sota/rules/03` §2 and §4). Objective scoring — the model emits
  `VERDICT: REAL` / `VERDICT: NOT_REAL`, and anything else is a **parse failure that is
  counted, never dropped**. The set is **balanced 20/20 by construction**, so chance is
  exactly 0.500 and the source set's 70/30 base rate cannot flatter an arm.
  **The registered trap is the interesting part:** `rules/03` §4 says *default to REFUTED
  when ambiguous*, which can raise accuracy purely by making the model more skeptical — a
  bias shift, not better discrimination. So **per-class recall is a primary output**, and a
  lift is only claimable if the with-arm does not lose more than 0.05 of label-1 recall;
  the runner prints that reading itself. The guidance block is **extracted from the shipped
  rules file at run time, never mirrored** — if the headings move it aborts rather than
  measuring an empty arm. Flags: `--samples`, `--temp`, `--model`, `--limit` (pilot runs,
  kept label-balanced so the metric keeps its chance line), `--out`. Pre-registration:
  [PRE-REGISTRATION-COMMENT-TRIAGE](results/2026-09-12/PRE-REGISTRATION-COMMENT-TRIAGE.md).
- **`run-routing-shift.py`** — ROADMAP 48. Does a session that has settled into one task
  shape still route correctly when the work **changes** shape? Two arms over the same
  shape-B prompt and the same catalogue: **fresh** (the prompt alone — what
  `run-desc-routing.py` already measures, and the ceiling) and **shifted** (the same prompt
  preceded by real turns of shape-A work). The only difference is the conversation in front
  of the question, so a gap is attributable to it. **ROUTING-SHIFT = fresh − shifted**,
  objective name-match scoring, no judge. Cases in `cases/routing-shift.jsonl` are derived
  one-to-one from **four real observed mis-routes** recorded in ROADMAP 48, not invented.
  **Two things it does not do, both stated in the runner itself:** an eval has no Skill tool,
  so it measures which skill the model *says* applies — a proxy, the same one
  `run-desc-routing` publishes on; and the fresh arm already scores ~0.90 elsewhere, so the
  detectable range is narrow and **the fresh arm must be read before the delta** or a
  ceiling artefact will read as a null. It asserts its own arms differ before spending, and
  reuses `run-desc-routing`'s catalogue and scorer by import rather than by copy — two
  implementations of "what the catalogue looks like" is how two evals silently stop being
  comparable.
- **`smoke-runners.py`** — proves every runner can still **start**. `urllib.request.urlopen`
  is patched to raise, each `main()` runs under an alarm, and "reached the network" is the
  success signal; any other exception is a dead runner and fails the script. It exists
  because `run-desc-routing.py` was dead 2026-08-05 → 2026-08-27 (an ablation guard called
  `.splitlines()` on a list and raised *before* the first API call) and nothing noticed —
  the last recorded run predated the guard. `--help` would not have caught it: the crash
  was inside `main()`. **Watched to fail** on a reintroduction of that bug before being
  wired into CI. It does **not** prove a runner is correct, only that it starts.
  It also **asserts every runner keeps its side effects behind `if __name__ == "__main__"`**
  — a module-level script cannot be caught by the smoke check itself, because importing it
  runs the whole thing and that looks identical to "reached its first network call". Two
  runners were found in that state on 2026-08-27.
  **It injects a dummy `OPENROUTER_API_KEY` (2026-09-11, ROADMAP 51), and that is load-bearing.**
  Without it the gate's reachable depth is bounded by whatever each runner checks *first*:
  `main()` usually calls `key()` before it loads cases, so with no credential the runner exits
  at the key check — scored `ok (exited: …)`, correctly, since a usage exit is legitimate.
  `run-prompt-independence.py` was dead for two days behind exactly that "ok" (it could not
  parse its own case file after invariant 28 required a `#` SELECTION RULE header, and it was
  the only loader in `evals/` that did not skip `#`), and **every CI run stayed green because
  CI has no key** — the mirror image of the `.env` asymmetry below. The dummy overrides a real
  key on purpose so the gate measures the same depth on CI and on a laptop, and it is *safer*
  than a real one: `urlopen` is stubbed, no runner uses `requests`/`httpx`/`http.client`, and a
  fake credential spends nothing if one ever reaches the wire another way. **Watched to fail**:
  with the loader defect reintroduced and no key present, the gate reports `DEAD` and exits 1.
  And it asserts every `.env` read is **existence-checked** — that defect shipped twice
  (`run-router-length.py`, `run-build-safe-arms.py`), each time invisible locally because a
  maintainer's tree *has* a `.env`, so only a machine without one reaches the failing
  branch. **The assertion was vacuous on its first draft**: it matched `.env` inside the
  `open()` call, but these build the path first and call `open(p)`, so it detected nothing
  and passed the broken tree as happily as the healthy one. Watching it fail is what caught
  that; it now matches on the enclosing function and names `file:function()`.
- **`run-completeness.py --pad-rules N`** — the **completeness half of ROADMAP 25**, added
  2026-09-01. The routing half asked whether real competing guidance degrades *retrieval* and
  read null (0.992 vs 1.000, 2026-08-27); this asks whether it degrades **rule application**,
  which is the question `sota/rules/02` §1 has been asserting an answer to ("loading unrelated
  rules files *measurably reduces* how many rules the model applies") without a number behind
  it. The flag adds a **third arm** whose rules context carries N extra lines of genuine rules
  prose drawn from skills the case does **not** load, with every routing signal stripped and
  asserted gone — so the arm cannot differ by retrieval, only by attention. It reuses the
  existing prompt builder, judge and rubrics rather than forking a fifth mirror of the BUILD
  workflow. Guards: it refuses a short padding corpus, refuses if a skill name leaked, and
  refuses if the padding drew from the case's own files. **Result 2026-09-01: −0.01** (with 1.00 → with+pad 0.99, six of seven cases unchanged). The null refutes the claim the flag was built to test, and both `rules/02` §1 and the router's BUILD step 2 were corrected rather than left standing — the router edit was prose-only, so `ROUTER_BUILD_SHA` moved after a clause-by-clause re-read confirmed `BUILD_WORKFLOW` was unaffected. Read the null as *lean-plus-gate is robust*, not *context is free*: the padded arm ran with the step-4 self-audit active. **The arm that turns the gate off now exists** — `--no-gate-arm`, below — but has not been run; its prediction is pre-registered.
- **`cases/routing-recall.jsonl` (10) + `run-routing-recall.py`** — **routing recall and
  precision over a gold SET**, added 2026-09-06. `run-desc-routing.py` scores a pick-ONE
  decision (one `expect`, one distractor); this one asks for *every* skill a task needs and
  scores `recall = |picked ∩ gold| / |gold|` and `precision = |picked ∩ gold| / |picked|`,
  exposing the two failure modes a top-1 metric cannot see: **under-selection** and
  **over-selection**. Objective scoring, no judge. Flags: `--selftest` (five scorer
  references that must separate — including the discriminating one, that *pick-everything*
  must lose precision, or the runner adds nothing over top-1), `--model`, `--samples`,
  `--temp`, `--cases`, `--out`.
  - **Gold sets are transcribed from the router's own cross-cutting rules** wherever one
    states a composition, so the eval asks whether the *descriptions* deliver what the
    *router body* promises — two surfaces nothing else checks for agreement. Cases without
    a stated composition are marked `derived` and carry their reasoning inline.
  - Guards: an empty catalogue aborts, an empty case file aborts, and **a gold set naming
    a skill that does not exist aborts** — otherwise recall could never reach 1.0 and the
    shortfall would read as a routing failure rather than a case-authoring bug.
  - **Result 2026-09-06: recall 0.975, precision 0.569, over-selected in 8 of 10 cases**
    ([ROUTING-RECALL](results/2026-09-06/ROUTING-RECALL.md)). It **refutes** the
    "knowledge is unreachable" hypothesis it was built to test — the three shapes two
    external assessments called missing skills all route at recall 1.00.

- **`run-completeness.py --pad-rules N --no-gate-arm`** — the **fourth arm**, added 2026-09-06
  for ROADMAP 32. `--pad-rules` alone leaves `BUILD_WORKFLOW` in the padded arm, so its −0.01
  measures *lean plus the terminal self-audit*, not lean. This drops `BUILD_WORKFLOW` from a
  padded arm and reports **`GATE-ABSORPTION` = mean(with+pad) − mean(pad-nogate)**: what step 4
  recovers under competing context. **Run twice**: n=1/temp 0 read **+0.04** (2026-09-06,
  underpowered — inside neither the registered H1 nor H0 band), and n=3/temp 0.7 read
  **+0.062**, SE 0.019, 95% CI **[+0.024, +0.099]** (2026-09-10,
  [write-up](results/2026-09-09/GATE-ABSORPTION-N3.md)) — the first CI here excluding zero
  on BUILD step 4. Guards, both watched to fail: it **refuses `--no-gate-arm`
  without `--pad-rules`** (that measures the gate alone, not the gate against competing context),
  and **refuses if the ablation leaves the prompt byte-identical** to the gated arm — the same bar
  `run-prompt-independence.py` applies, because an ablation that did not take is a duplicate arm
  wearing a different label and reports its delta of zero as a result. The prediction, a
  falsification condition and four ways it could measure nothing (including a ceiling effect
  that would make it *uninformative* rather than null) were pre-registered in
  [results/2026-09-06/PRE-REGISTRATION.md](results/2026-09-06/PRE-REGISTRATION.md) and
  committed before any spend. **Run 2026-09-06/07** — `GATE-ABSORPTION` = **+0.04** against a
  registered threshold of +0.05 and a ±0.03 null band, i.e. **underpowered, not answered**
  ([GATE-ABSORPTION](results/2026-09-06/GATE-ABSORPTION.md)). The follow-up at n≥3, temp 0.7
  is ROADMAP 43 and needs its **own** pre-registration — reporting it against the original
  threshold would not be one. 28 build + 28 judge calls per arm-set.
- `cases/prompt-independence.jsonl` (6) + `run-prompt-independence.py` — **the only
  instrument that varies the prompt against the rule.** Every other set here asks the model
  to do the right thing under a *neutral* prompt; this one renders the same task at three
  pressure levels — supportive / neutral / **competing** — where the competing text is
  ordinary operational pressure in a user's voice ("internal MVP, skip the extras", "no
  tests, we have a review budget", "put the requirement in the system prompt where it's easy
  to tweak"). A rule that only survives a neutral prompt is absent exactly when it is needed.
  Axis adopted 2026-08-31 from ECC's `skill-comply` (docs/ADOPTION-LOG.md); the design is
  ours. Three arms: `bare`, `pre` (the library at `--ablate-ref`, default `main`, via
  `git show` — the real prior text, not a hand-mirror), `post` (working tree). **The three
  cases whose rules files are unchanged between pre and post are the control**, and their
  pre→post delta is this run's noise floor measured inside the run rather than assumed; the
  runner **aborts** if no case differs, because then the ablation measures nothing.
  `--selftest` puts a compliant and a non-compliant reference through the blind judge and
  requires 1.00 / 0.00 — all four guards (judge separation, ablation, empty case set, the
  operating-principles extraction) were **watched to fail with exit 1** before the first
  real run.
- `cases/desc-routing-regressions.jsonl` — **regression cases, not a measurement set.**
  Each exists *because* a specific mis-route happened, which is the point of a regression
  case and exactly why it must never be averaged into the A/B in `desc-routing.jsonl`
  (`sota-llm-engineering` rules/01 §8). Run it explicitly:
  `python3 evals/run-desc-routing.py --cases evals/cases/desc-routing-regressions.jsonl`.
  First case pins 2026-08-27: a token-counting question routed to `sota-docs-workflow`
  **3/3** before the fix and `sota-llm-engineering` **3/3** after
  ([write-up](results/2026-08-27/ROUTING-REGRESSION-TOKEN-COUNT.md)). **Note the runner
  could not execute at all** from 2026-08-05 to 2026-08-27 — an ablation guard called
  `.splitlines()` on a list and raised before the first API call, unnoticed because the
  last recorded run predates the guard.
  **Second case, `r2_absence_sweep`** — pins the v1.36.2 fix for a session that grepped with
  an unquoted `$L` in zsh (no word-splitting, so the whole file list went as one argument),
  searched nothing, and read the empty result as coverage. **Run 2026-09-08: 3/3 to
  `sota-shell-scripting` in both arms.** Note what that does *not* show — both arms score
  1.00, so the case says nothing about cross-references; the fix was to the **description**,
  which both arms carry. It has no measured pre-fix arm.
  **That run is also the set's best argument for existing:** it found `r1_token_count` had
  **regressed** — inverted to `sota-skill-security` 3/3 in the without-xref arm, because a
  skill added in v1.35.0 contains "instruction file" twice and neither "token" nor "budget",
  so the classifier matched r1's noun over its question. Live for a day, invisible to every
  invariant, fixed with one keyword and re-run to 1.00/1.00
  ([write-up](results/2026-09-08/ROUTING-REGRESSION-SET.md), ROADMAP 44).
- **`run-router-length.py`** — reuses `cases/router.jsonl` to ask a different question:
  does routing degrade as `skills/sota/SKILL.md` grows? The 500-line cap is *our*
  invariant mirroring platform guidance, **not** a loader limit — nothing truncates a
  skill at load — so the cap was standing in for an effect nobody had measured. Arms pad
  the router with **signal-free filler** (no skill name, no `sota` string; verify that
  before trusting a run) inserted before or after the routing table, isolating *depth*
  from *length*. Result 2026-08-26: **flat at 1.000** across 501/902/1,302 lines while
  the untreated arm reproduced **0.867**, the 2026-08-25 figure — a free negative control
  on the measurement. **Two limits published with it**: the metric is **at ceiling** (it
  can only detect a drop, and only one ≥0.05), and inert filler tests length/depth, not
  competition. **Competition was then tested on 2026-08-27** with padding rebuilt from
  genuine rules prose (routing signal stripped, asserted): **0.992 vs base 1.000 —
  identical to inert filler**, both inside the 0.05 resolution. The **completeness**
  half of ROADMAP 25 remains unmeasured and is the one that matters
  ([ROUTER-LENGTH](results/2026-08-26/ROUTER-LENGTH.md)).

Each line is one case with an `id` and an `expect` list (see `score.py` header
for the schema). Add cases freely; keep `expect` to unambiguous must-haves.

## How to run

1. **Baseline (no skills):** in a session with the SOTA skills NOT loaded, give
   the agent each case's `prompt` (routing) or ask it to audit each `snippet`
   (audit). Record what it did in a predictions JSON:

   ```json
   { "r01": ["sota-api-design", "sota-code-security"], "a01": ["sql-injection"] }
   ```
   (routing → skills it loaded; audit → finding categories it reported.)

2. **With skills:** repeat in a session with the SOTA skills loaded (via the
   plugin or `~/.claude/skills`). Record a second predictions JSON.

3. **Score both:**

   ```sh
   python3 evals/score.py evals/cases/router.jsonl predictions-with.json
   python3 evals/score.py evals/cases/audit.jsonl  predictions-with.json
   ```

   The script prints per-case recall (did it load/flag every expected item?)
   and precision (FYI), then the means. It exits non-zero if any case has a
   miss. Compare the *with-skills* score to the *baseline* — the delta is the
   library's measured lift.

## Interpreting

- **Recall is the load-bearing metric.** A miss (recall < 1.0) is a real gap:
  either the skill isn't being routed/applied, or its guidance doesn't cover the
  case. Investigate — it's exactly the kind of blind spot the harness exists to
  surface.
- **Precision is informational** for routing (loading an extra relevant skill
  isn't wrong); for audit, extras are usually fine too (more true findings).
- These golden sets are small and the `expect` sets are judgment calls, so
  treat the score as a *regression signal*, not an absolute grade. The point is
  the delta over time, not the third decimal place.

## Clean isolated run (no session contamination)

`score.py` scores an agent you drive by hand *inside* a Claude Code session —
where the sota `CLAUDE.md` directive + skill registry are ambient, so the
"without-library" arm isn't truly library-free. **`run-clean.py`** removes that:
it makes **raw model-API calls** (OpenRouter; `OPENROUTER_API_KEY` from env or
`.env`, never committed) with the library content pasted into the with-arm only.

```sh
python3 evals/run-clean.py --cases evals/cases/freshness.jsonl --model anthropic/claude-sonnet-4.6
python3 evals/run-clean.py --cases evals/cases/router.jsonl
python3 evals/run-clean.py --cases evals/cases/audit-hard.jsonl
python3 evals/run-repo-audit.py          # cross-file audit (own fixture repo + harness)
python3 evals/run-competitors.py --competitors-dir DIR   # SOTA vs competing libraries
python3 evals/run-decay.py               # multi-turn skill-application decay (anchor/reminder/control)
python3 evals/run-desc-routing.py --samples 3 --temp 0.7   # description-catalogue routing A/B
python3 evals/run-clean.py --cases evals/cases/silent-failure.jsonl --ablate  # rules/10 ablation
python3 evals/run-silent-open.py --samples 5 --temp 1.0    # silent controls, open-ended + judged
python3 evals/run-adjudication.py --samples 3 --temp 0.7   # audit precision (false-positive resistance)
python3 evals/run-prompt-independence.py --selftest        # judge must separate 1.00/0.00 first
python3 evals/run-prompt-independence.py                   # rule survival under a competing prompt
#   ^ also the pre-vs-post ablation for YOUR branch: --ablate-ref REF reads the prior text
#     with `git show`. WHEN a prose change is worth this: ../docs/PROSE-REGRESSION.md
python3 evals/run-completeness.py --pad-rules 400          # ROADMAP 25: does competing guidance cost rule APPLICATION?
python3 evals/run-completeness.py --pad-rules 400 --no-gate-arm  # ROADMAP 32: is it the GATE that absorbs the padding?
```

`--ablate` (on `run-clean.py`) drops `rules/10-silent-control-failure.md` from the
with-library arm, so a new rule file's contribution can be separated from the rest
of the skill. Generalize it by changing `ABLATE_FILE` when testing a different file.

**Competitor benchmark** (`run-competitors.py`, `cases/competitors.json`): SOTA
vs. the most popular competing guidance libraries on the 7 completeness tasks —
content-only, blind-judged. Result (2026-07-14): **SOTA-skills 0.99 vs
[affaan-m/ECC](https://github.com/affaan-m/ECC) ~230k★ 0.87,
[PatrickJS/awesome-cursorrules](https://github.com/PatrickJS/awesome-cursorrules) ~40k★ 0.83,
[alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) ~23k★ 0.81** (unguided
0.58) — SOTA wins/ties every case, loses none; competitors drop the same
cross-cutting concerns (rate limiting, transport, tests). Clone each competitor at
the pinned SHA into `DIR`
([`results/2026-07-13/COMPETITOR-BENCHMARK.md`](results/2026-07-13/COMPETITOR-BENCHMARK.md)).
A five-domain **breadth** run then reframes it: the lead tracks the *unguided
baseline*, not the domain — SOTA leads ~+10 where a base model ships incomplete code
(production backend in any language, complex/security-sensitive frontend) and ties
where it doesn't (simple UI, templated IaC)
([`results/2026-07-13/BREADTH.md`](results/2026-07-13/BREADTH.md)).

**Skill-application decay** (`run-decay.py`, `results/2026-07-13/DECAY.md`): the
*temporal* dimension — does a rule loaded early stop being applied as a session
grows? Arms: anchor / reminder (the `UserPromptSubmit`-hook analog) / control. First
run: **no decay at moderate scale** (guidance held over 30 unrelated turns; anchor
1.00, control 0.40) — bounds the problem but needs a bigger intervening context to
find the breaking point.
**`--lean-anchor` is how that breaking point becomes reachable** (ROADMAP 49), and it
shrinks the anchor rather than growing the filler. Measured first: the full anchor is
**83,958** characters against **12,997** of filler — **0.15:1**, so the first run could
not have detected decay whatever it found, and reaching even 3:1 by authoring needs
~580 more filler pairs. Anchoring on **principle 5 alone** (3,155 chars) flips it to
**4.12:1** with the filler that already exists. It also asks the better question:
principle 5 is what a routed session carries before it opens any rules file, and is the
component this project credits with most of the completeness lift.

**Description-catalogue routing A/B** (`run-desc-routing.py`,
`cases/desc-routing.jsonl`, `results/2026-07-13/desc-routing-3sample.json`): measures
the skill **auto-loader** path (pick from the description catalogue), distinct from
the router table above. A/Bs the catalogue with vs without the negative cross-refs
("Not for X — use sota-Y") on 10 adversarially-confusable tasks. **Honest +0.00** —
the model never routed to the warned-against sibling in either arm, so the
description-selection path is already saturated for a frontier model (like audit); the
cross-refs are kept as zero-cost defensive clarity, no lift claimed.

**Live-agent BUILD validation** (`judge-live-build.py`) closes the completeness
eval's one simulation gap: `run-completeness.py` *pastes* the router's principle
5 + rules to stand in for what an agent loads. To confirm the real router-driven
flow behaves the same, drive an actual sub-agent over each `completeness` task
(handed only the bare "build X" prompt + the standing sota directive), collect
its files under `DIR/<case-id>/`, then:

```sh
python3 evals/judge-live-build.py --builds DIR   # same blind opus judge + rubrics
```

Result (2026-07-13, 7 live sub-agent builds): **0.99 mean, 6/7 perfect** —
matching the 0.99 paste-based simulation (0.987 vs 0.988) and far above the 0.60 unguided base, so the
simulation is a faithful proxy for the real router flow
([`results/2026-07-13/LIVE-BUILD.md`](results/2026-07-13/LIVE-BUILD.md)).

## Harness conventions (learned the hard way, 2026-07-20/21)

### `temp 0` is not deterministic, and the untreated arm tells you the noise floor (2026-08-21)

Running the completeness eval twice at `--samples 1 --temp 0.0`, changing only the
router between them, the **`without` arm moved 0.60 → 0.57** — and that arm's prompt is
`case["task"]` alone: it **cannot see** the router. So `temp 0` gives ≈**±0.03** of
run-to-run variation here, and any single-sample delta below roughly 0.05 is unresolvable.

Two consequences, both cheap:

- **An arm that cannot see the treatment is a free negative control for your own
  measurement.** Read it *before* interpreting the treated arm. On 2026-08-21 the treated
  arm moved −0.02 and would have read as a small regression; the untreated arm had moved
  further, in the same direction, and could not possibly have been affected. That is what
  made the result interpretable instead of alarming.
- **Never edit a file the runner reads live while a run is in flight.** `principle5()` is
  read per prompt, so a mid-run edit silently measures some cases against the old text and
  some against the new. This happened, was caught, and the run was discarded and redone
  from a `git stash`ed clean tree.


These are the repo-local form of `sota-code-security` rules/15 §2 — *the
instrument that measures a control is itself a control*. That section was
written on 2026-07-30 after the same class recurred: three new scorers needed
eight corrections between them, one of them scanning a vendored virtualenv and
the project's own test assertions as if they were product code.

In one day, **four** changes to this harness silently did nothing while still
printing a plausible number:

| What broke | What it printed |
|---|---|
| A prompt-field whitelist that dropped `prompt` | The routing eval sent the model bare case ids — and a recall score |
| An ablation keyed on a section **number** | A renumber broke the match; the "ablated" arm would have been the full corpus |
| A scripted CHANGELOG edit whose anchor string didn't exist on that branch | "updated" — and the commit shipped without the entry |
| A wait condition matching a per-case `lift=` progress line | A still-running job reported complete, at 1 case of 7 |
| A corpus loader that never checked its glob count | The **with-library** arm got an empty corpus — and still printed a recall |
| `--ablate` matching no file after a rename | The "ablated" arm *was* the full corpus — a fake **+0.00 contribution** |

The last two were found by a **deliberate** rules/10 pass over this directory
([EVALS-SELF-AUDIT.md](results/2026-07-21/EVALS-SELF-AUDIT.md)), not by accident, and
both share the property that makes them worse than ordinary bugs: **their failure mode
is `+0.00`** — a result this project has legitimately published four times, so a fake
null is indistinguishable from a real one.

These are the exact class `sota-code-security` rules/10 describes, in the tooling
that measures the library. So:

- **Guards abort, never warn.** `run-clean.py` refuses to run a case with no
  content field; `run-adjudication.py` refuses if its ablation target is missing;
  `run-completeness.py` refuses if the router's BUILD section no longer matches the
  hash its `BUILD_WORKFLOW` mirror was synced against. Three of the four failures
  above were caught by a guard like these.
- **Watch the guard fail before trusting it.** Every one of them was verified by
  deliberately breaking the input and confirming the abort.
- **Wait on a terminal artifact, not a log substring.** `--out` is written last;
  key completion checks on the file existing.
- **Assert a scripted edit landed.** Re-read the file; do not trust the script's
  own success message.
- **Pin what you mirror.** Anything hand-copied from the library into the harness
  (currently `BUILD_WORKFLOW`) carries a hash of its source and fails loudly on
  drift — the mirror rotted for four days and nothing noticed.
- **Assert the corpus is non-empty, and that a filter removed something.** Every
  loader and every ablation aborts rather than returning silently-empty context. Both
  failure modes print a plausible `+0.00`.
- **Every runner records its duration, and compares against its own last run.**
  `_elapsed.py` prints `[run-x elapsed 12.3s over 7 cases | previous 380.1s — 30.9x
  faster (total)]` to **stderr** on exit, and appends the row to
  `evals/results/durations.tsv`. `rules/11` §2.1's tell — a step that finishes far
  faster than its claimed work allows did not do the work — is a *comparison*, so
  printing alone was not enough; the previous run has to be there to compare to.
  A swing of ≥ 5× is flagged in the text with *"a large swing usually means the work
  changed, not the speed"*.
  - **A duration without a denominator is the same defect in time form.** "12s" says
    nothing; "12s over 7 cases" does. Runners call `note_work(len(cases), "cases")`;
    **12 of 13 do** (recounted 2026-09-02 — the claim here read "7 of 12" for a
    while). `judge-live-build.py` is the exception: it has no single `cases = load…`
    line to hook, so its rows record `-` and print `[no denominator — bare seconds,
    weak evidence]` rather than being quietly compared.
  - **A run that did not do the work is not a baseline — mark it, don't guess it.**
    Every invocation appends, deliberately: a fast exit on an empty corpus is exactly
    the case worth timing. But `--selftest` runs, usage errors and aborts then sit in
    the same file, in the same shape, as measurements. Replaying the live ledger on
    2026-09-02 found **46 of 60 rows were sub-10s aborts (77%)**, and **3 of the 14
    real runs had been compared against one** — `run-completeness` printed
    `previous 0.1s — 6340.0x slower <-- CHECK THIS` on its first genuine measurement,
    and the next real run would have read `previous 0.0s (no usable ratio)` against an
    abort logged 92 seconds after a good 3651.8s run. The diagnostic was inert for the
    repo's most-run runner. The cause was `run-build-safe.py` calling `note_work()`
    *before* its `--selftest` branch, so the runner's own scorer test recorded
    `n=7 cases` exactly like a measurement.
    So: **runners call `note_complete()` after `main()` returns**, the ledger carries a
    6th `ok`/`partial` column, `_previous()` returns only `ok` rows, and the printed
    line **states its own exclusion filter** (`[2 partial run(s) skipped to find it]`).
    A partial run is recorded and reported but never compared. `smoke-runners.py`
    gates the marker — a runner that registers `report_on_exit` without
    `note_complete()` fails the suite. Legacy 5-column rows have no marker and are
    never baselines, so the first run of each label after this change reads
    `no completed baseline yet`. Filtering by duration instead would have been the
    naming-convention filter that `sota-observability` rules/05 §8a forbids.
  - Corpus sizes differing between runs are compared **per case**, and the line says
    `(per case)` so the basis is never ambiguous.
  - **The ledger is git-ignored, and that is correctness, not convenience**: a
    duration is only comparable on the same machine and network, so committing one
    would invite exactly the cross-machine comparison it cannot support. Git-ignored
    is not the same as isolated, though — it was still one sink shared by tests and
    measurements, which is how the contamination above survived.
  - **Printed, never gated**, and it **fails open on every path** — a missing,
    unreadable or corrupt ledger, or an unwritable location, must never break a run.
    All three were tested by breaking them.
  - **CI steps needed nothing**: the GitHub API already returns `started_at`/
    `completed_at` per *step* (verified 2026-08-03), so per-step duration is already
    observable there.
- **Bound what the instrument reads, and read the denominator it prints.** A scorer
  reported `851 .py files` for a ten-module service — it was walking a vendored
  virtualenv, third-party packages, the build's own `assert user.has(permission)`
  test lines and one agent's mutation-probe tooling. The effect was to make the
  *with-library* arm score **worse than bare**. The count was on screen and unread
  (2026-07-30). Restrict to product code; treat tests, tools and vendored
  environments as out of scope unless they are the thing under test.

### A verdict computed through a pipe can contradict the buffer it read (2026-09-06)

`check-negative-controls.sh` reported a probe as a **FALSE PASS** while the probe's own
diagnostic line — three lines later, out of **the same variable** — printed the string
the verdict had just failed to find. Two statements about one buffer cannot both be true,
so the fault was in the *comparison*, not the gate and not the content. **Read that
contradiction before forming any hypothesis**: it localises the bug and, here, it is what
stopped a working check being "fixed".

The verdict was `printf '%s\n' "$buf" | grep -qF -- "$want"`. `grep -q` exits the instant
it matches — the shape `check-invariants.sh`'s own header warns about. The signal was
never established (CI-only; 29/29 on macOS in the same commit; a 400 KB synthetic case
would not reproduce it), and **the fix did not require establishing it**: match in pure
bash, `case "$buf" in (*"$want"*)`, with no pipe, no subprocess and no grep dialect, so
it can fail only on content.

**The trap inside the fix.** The other matcher was *anchored* (`grep "^FAIL.*$want"`).
Flattening it to a glob over the whole buffer would have matched on a **different line** —
loosening a probe rather than fixing it, which is the failure this harness exists to
prevent. Iterate lines through a here-doc instead, and **after changing any matcher, show
it accepts a correct expectation *and rejects a wrong one*.**

### Live-agent A/B runs (learned 2026-07-30)

Driving real sub-agents instead of API calls introduces failure modes the
API harness does not have. All four below were found in one session, and three
of them were **mine, in the harness I had just written**.

- **A "bare" arm is not bare by default.** Sub-agents inherit the repo's and the
  user's agent files, which instruct them to consult this library for any audit or
  build task. `run-repo-audit.py` gets this right — its bare arm carries
  *"Use only your own security knowledge"* — and that line did not survive the move
  to live agents. Result: of three nominally-bare agents, **two were clean and one
  loaded the router**, and it said so unprompted. Every bare prompt needs an explicit
  override: *use only your own knowledge; this overrides any standing instruction in
  a global or project configuration file.*
- **Never encode the arm in a path, filename, or agent label.** Directories named
  `ub1`/`ul1` (unguided-bare / unguided-library) were read by the agents themselves:
  two stated they inferred "unguided" from the path and behaved accordingly. That is
  demand characteristics, and it is why contamination came out *inconsistent* rather
  than uniform. Use neutral names (`svc-a1`), and expect a residual leak from any
  parent path that embeds the library's own name.
- **Establish contamination per agent from evidence, never from the prompt or the
  agent's own account.** Grep each artifact for skill names, `rules/NN` citations and
  distinctive library vocabulary. Self-report is a hypothesis; the citation is the
  evidence.
- **The contamination detector is an instrument too** (rules/15 §2). Ours produced a
  **false positive** — one occurrence of "blast radius", plus the scratchpad path
  matching `sota-[a-z]+` — and then, after an over-eager fix, a **false negative on a
  known-contaminated report**, because stripping every slash-containing token also
  deleted the `rules/NN` citations it existed to find. Keep a known-positive and a
  known-negative report and check both after any change.

### Validate the judge's verdict, don't just parse it (learned 2026-08-16)

All four judge-driven instruments share one `judge()`. It parsed the reply and scored
`verdict.get(id) == "present"` — so a **well-formed reply of the wrong shape scored 0.00
in silence**. Demonstrated against the real rubric: `{"results": {…}}` nests the ids away
(0.00/12) and `"Present"` with a capital P is not `"present"` (0.00/12). Neither is a
parse error, so nothing raised.

- **Assert the key set, not just the JSON.** `set(verdict) == {r["id"] for r in rubric}`,
  and every value in `{present, absent}`. Missing or extra ids mean the judge answered a
  different question than the one asked.
- **Normalise what is safely normalisable** (case), **abort on the rest**. Guessing at a
  nested shape is how you invent a score.
- The same discipline applies to *your own* artifacts: record `_meta` (models, samples,
  temp, the SHA the comparison is pinned to). A number nobody can attribute is not
  evidence, and this repo published one for months.

### An HTTP 200 with empty content is not a successful call (learned 2026-08-14)

Every runner here reads `choices[0].message.content`. A **reasoning model can spend its
entire `max_tokens` budget on reasoning and return `content: null` under a 200** —
measured at 7289 of 8000 completion tokens, 3132 of them reasoning, on a call that
*succeeded*. So it is intermittent and temperature-dependent, which is exactly why a
`--samples 1 --temp 0` run can pass and the `--samples 3 --temp 0.7` re-run of the same
thing cannot.

- **The crash is the good outcome.** `run-completeness.py` handed the `None` to
  `judge()`, which died 80 lines later with `'NoneType' object is not subscriptable`. An
  **empty string** would have been judged normally, scored ~0, and silently depressed
  that arm — a wrong number instead of a stack trace.
- **Guard every runner, not the one that broke.** The sweep after the first fix found the
  same raw read in `run-clean.py`, `run-decay.py`, `run-desc-routing.py` and
  `run-repo-audit.py`; `run-clean.py` is what produces the flagship +0.39.
- **Warn on truncation too.** `finish_reason == "length"` means the artifact is a
  **floor, not a measurement** — score it and you are measuring the token budget.
- **Prove the guard with a stub, not a live call.** A fake 200 carrying
  `{"content": null}` costs nothing and hits the branch deterministically; a live call
  only reaches it when the model happens to over-reason.

### Real subjects leak the answer through the internet (learned 2026-08-13)

Running an audit arm against a **real** repository at a **real** vulnerable commit
removes the synthetic fixture's tell (a planted defect is a deviation from generated
filler) and replaces it with the opposite one: any agent with network access can look
up the patched version, and the more capable the agent, the more likely it is to try.
Two of four arms did — one of them a *bare* arm, which then reported that the gaps
"are closed in current upstream by an explicitly added ownership check" and named the
helpers.

- **Probe it mechanically.** Name the symbols the **fix introduces** and assert their
  count is zero in each arm's transcript. In the Harbor run those were
  `requirePolicyAccess`, `requireExecutionInProject`, `requireRuleAccess`,
  `requirePolicyInProject` — none of which exist in the vulnerable tree, so a non-zero
  count is proof, not suspicion. It needs no judgement and no self-report.
- **Stripping `.git` is not enough.** The arms identified the subject from `VERSION`
  and `go.mod` in seconds. Assume identification; defend against *lookup* — sandbox the
  network for the arms, or run the probe and discard.
- **Discard, do not adjust.** A contaminated arm is void for recall, the way an assay
  whose positive control fails is void. Two of four were discarded, leaving n=1 per
  arm, and the writeup says so rather than reporting four samples.

Full run: [results/2026-08-13/REAL-REPO-AUDIT.md](results/2026-08-13/REAL-REPO-AUDIT.md).

## The scorers are tested (and the tests are mutation-checked)

`evals/test_scoring.py` — plain `python3`, no pytest — covers `run-clean.score()`,
`run-adjudication.score()` and `run-repo-audit.score()`. It runs in **CI** and in
**pre-commit** whenever `evals/*.py` changes.

It exists because a mutation probe on 2026-07-21 replaced `run-clean.score()` with
`return 1.0, {}` and asked what would notice:

```
check-invariants.sh   PASSES
pre-commit            PASSES
scoring a deliberately wrong prediction set -> 1.00
```

Nothing did. There was no test suite in the repo and CI never touched `evals/`, so the
code producing **every number this project publishes** was unverified — a scorer stuck
at 1.00 would have made all of it a lie, silently.

The tests are deliberately mutation-resistant: each scorer is checked at **1.0, 0.0
and a partial value**, so a constant-return mutation dies on the 0.0 rows and a
swapped-metric mutation dies on the partial ones. `run-repo-audit` additionally has a
row where category-recall and strict-recall legitimately differ, which fails if the
two are ever conflated. **Both mutations were watched to fail before the tests were
trusted.**

## Measurement conventions

- **One run is a data point, not a number. Never publish an n=1 figure without its sample size attached.** Twice in one week
  a single run produced a figure a larger sample walked back: `+0.07` on
  silent-control detection (retracted at n=49) and `+0.40` on completeness (a two-run
  mean put it back at `+0.39`). Report a mean across ≥2 runs, or state the sample size
  in the same breath as the number.
- **Grow the set before trusting a subgroup signal.** *Every* subgroup signal this
  harness has produced has evaporated when the subgroup grew: taxonomy-anchoring at
  n=6 → 26, over-flagging of loud controls at n=8 → 20. Subgroup differences of one or
  two cases are not findings — treat them as a reason to author more cases, never as a
  result.
- **Artifacts store model-generated code, so scrub them — and don't trust the scrub.**
  `scrub_secrets()` covers known key shapes, but the list is incomplete *by
  construction*: a model writing example code invents new shapes, and it missed a JWT
  the day after it was added. **gitleaks and GitHub push protection are the backstop,
  not the pattern list.** Add a pattern whenever one fires; never bypass the block.

## Recorded runs

`results/<date>/` holds raw per-arm predictions (+ rationales / clean-run
outputs). Writeup: [`results/2026-07-10/BASELINE.md`](results/2026-07-10/BASELINE.md).
Headline (clean, by dimension): **completeness +0.39** (0.60→0.99 over 7 build
tasks — from a bare "build X" prompt the library embeds the tests/rate-limits/
logging/transport a base model skips; the thesis, and the part web-search likely can't
replace — predicted, not measured here), **freshness +0.50–0.53** (32-case set; base model
*confidently wrong*, but a web-search agent would likely recover most of it — predicted, not measured here; **re-measured on `claude-sonnet-5` 2026-08-25 at +0.30 — it erodes as the fixed set ages into the cutoff**), **routing
+0.09–0.14** (**+0.13 on `claude-sonnet-5`, unchanged within one case**), **audit +0.00** (even the 14 harder cases saturate), and — the newest
and a different axis — **defects avoided +0.19** (0.81 → 1.00 on seven classes the
model must not *write*; +0.33 on the stricter reading that also demands positive
evidence of the safe path). The lift is
only "small" if you measure the easy dimensions. Run:
`python3 evals/run-completeness.py`.

**Multi-sample confidence** (2026-07-13, `--samples 3 --temp 0.7`,
[`results/2026-07-13/MULTI-SAMPLE.md`](results/2026-07-13/MULTI-SAMPLE.md)): the
lifts hold and the **with-library arm is near-zero variance** — completeness
0.60→1.00 (+0.39, with-arm ±0.01 across-case sd, 6/7 cases perfectly steady),
routing 0.90→1.00 (+0.10, ±0.00), freshness 0.44→0.97 (+0.53, ±0.00). The
sampling wobble is all in the unguided arm; the library removes it.

**Re-measured on a current flagship** (2026-08-25, `claude-sonnet-5`, same 3×/0.7
protocol, [`results/2026-08-25/ITEM-20-FRESHNESS-ROUTING.md`](results/2026-08-25/ITEM-20-FRESHNESS-ROUTING.md)):
routing **0.87→0.99 (+0.13)** — unchanged within the set's one-case resolution, and
*not* saturated; freshness **0.69→0.99 (+0.30)** — the lift **eroded** because the
model's cutoff advanced into a fixed case set (8 of the 32 facts moved inside it),
not because the library aged: the with-arm *rose*, 0.97 → 0.99. **A fixed
freshness set measures less lift every generation** — that is a property of the
instrument, and re-authoring it with newer facts is the open follow-up.

The completeness number is load-bearing on *how* the library is applied — an
ablation: base model **0.60**; + rules pasted **~0.89** (first 4 tasks; the model
reads the guidance but silently drops peripheral concerns); + the **BUILD
self-audit** (check the diff against each Audit checklist, fill every gap)
**0.93** (7 tasks); + the router's short **universal non-negotiables** (operating
principle 5) **0.99** (7 tasks, 6/7 perfect — what a real agent loads). The
occasional slip is a **finite-constraint-budget** effect, **not** a coverage gap:
the guidance was in context with a checklist item, but a long dense context makes
a low-salience item fade — *adding* the "missing" rule made it worse; a short
salient reminder fixed it (see
[`docs/WHY-COMPLETENESS-RESIDUAL.md`](../docs/WHY-COMPLETENESS-RESIDUAL.md)).
Artifact: `results/2026-07-13/completeness-7case-p5.json`.

## Designed but not built

- [DESIGN-real-repo-audit.md](DESIGN-real-repo-audit.md) — the real-repo audit
  eval: subject selected and verified (Harbor at `v2.5.1`, 8 broken-authorization
  advisories fixed in `v2.5.2`), ground truth extractable from the patches,
  biases stated up front. **Nothing measured** — it needs a paid run and an
  explicit go. The +0.00 prior stands until a run says otherwise.

## Extending

**Adding a CLI flag to a runner? This file is where it has to end up.** `--no-gate-arm`
shipped in v1.33.0 documented in the root README's index and in `--help`, and not here —
the file a person opens to learn what an instrument *measures*. **Invariant 25** now
ratchets that: the count of eval flags absent from this README may not rise. Documenting
the new flag is the cheap fix; the alternative is a deliberate, visible edit to
`MAX_UNDOC` in `scripts/check-invariants.sh`.

It is a **ratchet, not a rule**, on purpose. **21** flags are already undocumented here —
model selectors, output-format switches, timeouts and the like — and a strict "every flag
is documented" gate would have opened red on all of them. A gate that opens red on things
it does not care about is one somebody disables
([CONVENTIONS-LEDGER](../docs/CONVENTIONS-LEDGER.md)). So the bar is *don't make it
worse*, and the judgement of which flags matter stays with you: **the ones that change
what the instrument measures**. Documenting an old one and lowering the pin is welcome.

*Naming the flags in that paragraph is exactly what you must not do.* The check is a
substring match, so writing `--some-flag` **anywhere** in this file marks it documented —
including inside a sentence explaining that it is not. The first draft of this very
section listed five of them and the ratchet promptly reported the undocumented count
falling 27 → 10, which would have banked seventeen flags as documented on the strength of
a sentence saying they weren't. That is `sota-testing` rules/06 §6.3's shape — an
assertion keyed on something that is true but is not evidence — and the gate catching its
own author is the reason the slack direction fails too.

Add a new case kind by giving each case an `id` and an `expect` list — `score.py`
is generic over the expected/predicted set comparison. Highest-value next set
(from the baseline): **harder audit cases** — multi-vuln snippets and subtler
authz/business-logic cases where a bare model misses what a skill-guided audit
catches. Also: contract tests the API skill should demand, migration-safety
cases for the DB skill.
