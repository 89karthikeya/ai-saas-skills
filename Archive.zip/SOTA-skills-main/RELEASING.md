# Releasing

How to cut a SOTA-skills release. Everything lands through a PR — `main` is
protected for everyone, including admins (see [AGENTS.md](AGENTS.md)).

## Minor or patch?

One line used to say *"adding a skill is a minor bump; fixes to existing content
are a patch."* The first half is exceptionless. The second half misled at the
v1.20.0 cut, because it reads as *no new skill → patch*, and that is not what this
repo has ever done. Measured across all 31 releases (`git ls-tree` per tag):

| | |
|---|---|
| Skill-adding releases | **6**, and **all 6 were minor** — the rule holds in that direction |
| Minor bumps | **21** — so **15 of 21 added no skill at all** |
| Patch bumps | **10**, none of which added a skill |

So a new skill is **sufficient** for a minor and never **necessary**. What actually
separates the 15 no-skill minors from the 10 patches, spot-checked against six of
them (v1.9.0, v1.13.0, v1.14.0, v1.17.0, v1.18.0, v1.20.0):

- **Minor — the library gains a new surface someone can *use*.** A skill, a script
  or command (`v1.20.0`: `verify-setup.sh`, `update-reminder.sh`), a hook, a
  cross-tool integration (`v1.9.0`: `AGENTS.md` support), or a new eval instrument
  or harness (`v1.13.0`, `v1.14.0`, `v1.17.0`, `v1.18.0`).
- **Patch — the change lives inside surfaces that already exist.** Rule text,
  doc fixes, corrections, an intake, and — on the evidence — **a new CI invariant on
  its own**: invariants 8, 9 and 11 each shipped in a patch (`v1.19.1`, `v1.19.5`,
  `v1.19.9`). Invariants 12 and 13 rode a minor because that release also added two
  scripts and a hook, not because they were invariants.

When it is genuinely unclear, ask whether a *reader of the release notes gains
something new to run*. If not, it is a patch.

## 1. Version-bearing files (every release)

| File | What changes |
|---|---|
| `VERSION` | the new semver, single line |
| `.claude-plugin/plugin.json` | `"version"`; also the skill/domain counts in `"description"` if they changed |
| `docs/ADOPTION-LOG.md` | any `adopted` row whose **Landed in** cell still says `unreleased` gets the shipping version — `grep -n '· unreleased' docs/ADOPTION-LOG.md`, replace each with `vX.Y.Z`. Adoptions land in ordinary PRs between releases, so the version isn't knowable when the entry is written; nothing in CI catches a stale marker (it's prose), which is exactly why it's on this list |
| `CHANGELOG.md` | new `## [X.Y.Z] - YYYY-MM-DD` section at the top **and** a `[X.Y.Z]: …/releases/tag/vX.Y.Z` link ref at the bottom (top entry = current version — no `[Unreleased]` left behind). **Consolidate first if more than one PR opened its own `[Unreleased]`** — invariant 9 now fails the build on that (added v1.19.5, after two feature PRs each opened one and `main` carried both until a cut caught it by hand). CHANGELOG is **no longer line-capped** (the 500-line invariant is skill-files-only since 2026-07-15), so archiving old releases is now **optional hygiene** for navigability, not forced: when the root gets long, you *may* move the oldest sections **and their link refs** into the newest `docs/CHANGELOG-archive*.md` (headings and `[X.Y.Z]:` refs must stay in the same file) |

## 2. Count-bearing surfaces (when the skill count changes)

Recount from the tree — never adjust numbers by memory (invariant 6 fails CI
on drift among these surfaces, and invariant 5 on version drift):

```sh
ls -d skills/*/ | wc -l                          # N skills (incl. router)
find skills -name '*.md' | wc -l                 # M files
find skills -name '*.md' -exec cat {} + | wc -l  # ~L lines
```

Then update every surface that carries a count:

- **README**: badge `skills-N`, hero sentence "N skills (M files, ~Lk lines)",
  and a table row per new skill. The social-preview `alt` text says **"N+"**
  (a floor, e.g. "40+") — leave it alone unless the tree count falls below
  the floor or you deliberately raise it.
- **Router** (`skills/sota/SKILL.md`): body "A library of N domain skills"
  (N = total − 1), a routing-table row + library-map entry per new skill, and
  the domain list in the frontmatter description — which must stay
  **≤ 1024 characters** (invariant 4; it hit the cap at v1.8.0 and needed a
  trim).
- **`.claude-plugin/marketplace.json`**: counts in the plugin `description`.
- **`assets/social-preview.html`**: the pill reads **"N+ skills"** (a floor —
  "40+" since 2026-07-09) so the image does NOT need re-rendering or
  re-uploading on every skill addition; invariant 6 only fails if the tree
  count drops below the floor. When you *do* raise the floor: re-render the
  PNG by serving the directory over localhost (`python3 -m http.server`) and
  screenshotting at exactly **1280×640** with a headless browser (`file://`
  is typically blocked), commit both files, and re-upload the PNG at GitHub
  **Settings → Social preview** (the repo file does not refresh it).
  **Invariant 12 now enforces the commit-both half**: any `assets/*.html` whose
  paired PNG is older fails CI, so a re-render can no longer be forgotten the way
  `how-it-works` was in #173. Full procedure and per-asset sizes:
  [CONTRIBUTING.md → Rendered assets](CONTRIBUTING.md#rendered-assets).

## 2b. Front-door surfaces (every release) — now gated by invariant 14

Invariant 6 fails the build on a wrong **number** in the README. Until 2026-08-02
**nothing** failed on a capability that never got a sentence anywhere a reader looks. That gap is not
hypothetical: at the v1.19.7 cut, grepping `main` returned **0 hits** in `README.md`
for `adversarial`, `refut`, `decision ledger`, `inert`, `no-op`, and `ADOPTION-LOG` —
five capabilities shipped across v1.17.0–v1.19.7 with no front-door mention, and
"How it works" still described an audit chain that predated three of its own passes.

So before tagging, for each capability this release (and the last few) added:

```sh
grep -ic '<distinctive term>' README.md docs/INDEX.md
```

Zero hits is a **documentation finding**, not a polish item — fix it in the release
PR. `README.md` is the front door and is where a rule-level capability earns its
sentence; `docs/INDEX.md` indexes *documents*, so a new rule inside an existing file
usually belongs in the README's class list rather than as an INDEX row. It read zero at **three consecutive cuts**
(v1.19.7, v1.19.9, v1.20.0) — which was the argument for a gate, not evidence the
habit was taking.

**Invariant 14 now enforces the verification.** Add to the new version's CHANGELOG
section:

```text
**Front door checked:** verify-setup · update-reminder · commits scanned
```

Every term must appear in `README.md` or `docs/INDEX.md` **and** in that release's own
CHANGELOG entry, so a filler word cannot buy a pass.

**The match is literal (`grep -F`) and the front-door line is excluded from the entry
search**, so a term cannot satisfy itself. **Four** ways this bites at cut time, all seen on
real cuts:

1. declaring `negative control` when the entry writes `negative-control` — hyphenation counts;
2. declaring a word that only appears in the declaration line;
3. **a comma inside a term splits it.** The parser is `tr '·,;' '\n'`, so
   `floor, not a ceiling` is declared as *two* terms. Both halves happened to resolve at
   v1.35.2, so it **passed** while the declaration did not say what it meant — the tell is a
   `N terms declared` count higher than the number of `·` separators you typed. Pick
   comma-free terms;
4. **`grep -F` is line-scoped, so a term broken across a line wrap does not match.** Twice at
   v1.35.2: `floor, not a ceiling` and `a grep is not proof` were both present in `README.md`
   and both wrapped mid-phrase. The prose reads fine and the gate is right. Rewrap the
   README, or pick a shorter term.

Check a candidate before you commit to it:

```sh
sec=$(awk -v v="## [$VER]" 'index($0,v)==1{f=1;print;next} f&&/^## \[/{exit} f{print}' CHANGELOG.md)
printf '%s\n' "$sec" | grep -v 'ront door checked' | grep -qiF -- "$term" && \
  grep -qiF -- "$term" README.md docs/INDEX.md && echo "usable"
```

Note also that invariant 14 and invariant 11 are **diff-based**: they resolve against a
merge base, so they can report differently before and after the release branch is pushed.
Re-run the gate once the branch exists upstream, and never let a pre-push result be the
thing that authorises the push (`sota-shell-scripting` rules/04 §1b). The check fires **only** when
`VERSION` changes, so ordinary PRs are unaffected. It gates the *verification*, not
the *discovery* — deciding what counts as a capability is still yours, and the grep
above is still how you find them. Two habits that go with it: say where a capability is *not* backed by a measured
number rather than letting the reader assume, and re-read the long-lived prose while
you are there (that cut found "keep every file ≤ 500 lines" in both README and
CONTRIBUTING, a cap that has been skill-files-only since PR #100).

## 2c. Routing surface (only when a `description` changes) — gated by invariant 29

A skill's `description` is the **entire** auto-load classifier: it is the only text a
loader reads before deciding whether to open the skill at all. So adding a skill, or
editing one description, silently competes for every neighbouring skill's traffic.

That is not hypothetical either. `sota-skill-security` shipped in **v1.35.0** carrying
*"instruction file"* twice and neither *"token"* nor *"budget"*. The regression case
`r1_token_count` — *"how many tokens is this 484-line Markdown instruction file?"* —
inverted from `sota-llm-engineering` **3/3** to `sota-skill-security` **3/3**: the
classifier matched the question's **noun** over its **question**. It was live for a day,
and invariants 4, 7 and 15 (description exists, is under the cap, is indexed and mapped)
were green the whole time. It was found only because someone ran the regression set for
the second time ever.

So when a release adds a skill or edits any `description`:

```sh
python3 evals/run-desc-routing.py --samples 3 \
    --cases evals/cases/desc-routing-regressions.jsonl
```

It is about **12 live calls** — 2 cases × 3 samples × 2 arms — which is why this is a
release-time step and *not* a CI gate. A gate expensive enough to be disabled is worse
than none ([docs/CONVENTIONS-LEDGER.md](docs/CONVENTIONS-LEDGER.md)), so what CI checks
is the **declaration**, exactly as invariant 14 checks the front-door one:

    **Routing checked:** evals/results/<date>/<write-up>.md

The named artifact must exist **and** mention `desc-routing-regressions`, so a line
resolving to an unrelated file fails rather than passing as a checkbox. A case that moves
is a finding: fix the description on the side that owns the *question*, then add the case
to `evals/cases/desc-routing-regressions.jsonl` if it is not already there. Invariant 29
compares the extracted `(name, description)` **map** against the merge base, not the
diff — a folded description block, a rename and a deletion all change routing without
touching a line that starts `description:`.

## 3. Land the PR

```sh
./scripts/check-invariants.sh        # same checks as CI
git checkout -b <branch> && git commit && git push
# open the PR; every required check green → squash-merge
```

**Branch naming:** avoid dots. The assistant's permission rule `Bash(git checkout *.*)`
— meant to block file-discarding checkouts — also matches a *branch* name containing
dots, so `release/v1.19.7` is denied while `chore/release-v1-19-7` works. This bites
at almost every cut (it did again at v1.19.7); a human shell is unaffected.

## 4. Tag and publish (after the squash-merge)

**Never put the tag or the release in the same command as the merge.** On 2026-08-27 one
chained command ran `gh pr merge` → checkout → invariants → `git tag` → `gh release create`.
The **merge failed** (CI red), the checkout succeeded, and everything downstream ran anyway:
`v1.29.2` was tagged at the *previous* release's commit and published with **empty notes**.
Invariant 5 caught the *result* ("tag ahead of VERSION"), not the act. Cleanup needed
`gh release delete` plus `git push origin --delete vX.Y.Z`, and re-tagging needed
`git tag -f -a` because **`git tag -d` is denied to the assistant**.

So verify from the REMOTE state, in its own step, before tagging:

```sh
git checkout main && git pull --ff-only

# GATE: does main actually carry the release? (all three must agree)
v=$(cat VERSION)
pj=$(python3 -c "import json;print(json.load(open('.claude-plugin/plugin.json'))['version'])")
top=$(grep -m1 '^## \[' CHANGELOG.md | sed 's/## \[\([^]]*\)\].*/\1/')
[ "$v" = "$pj" ] && [ "$v" = "$top" ] || { echo "main does not carry $v — do not tag"; exit 1; }

./scripts/check-invariants.sh && git tag -a "v$v" -m "v$v" && git push origin "v$v"

# release notes = the [X.Y.Z] section of CHANGELOG.md — check it is NOT EMPTY first:
# an awk range over the wrong branch silently yields zero lines and publishes a blank release.
awk '/^## \['"$v"'\]/{f=1} f&&/^## \[/&&!/'"$v"'/{exit} f' CHANGELOG.md > /tmp/notes.md
[ "$(grep -c '' /tmp/notes.md)" -gt 5 ] && gh release create "v$v" --title "v$v" --notes-file /tmp/notes.md
```

Plugin installs pick the release up because the `plugin.json` version bumped
(`/plugin update sota-skills@sota-skills`); symlinked clone installs update on
`git pull`, and `./scripts/install.sh --update` also links any brand-new
skills.

## Pre-tag checklist

- [ ] `./scripts/check-invariants.sh` passes
- [ ] `VERSION` == `plugin.json` version == the tag you're about to push
- [ ] CHANGELOG top entry is the new version, dated, with its link ref
- [ ] `grep -ni '· \[\?unreleased' docs/ADOPTION-LOG.md` returns nothing — every
      adopted row carries the version it shipped in. Match the `· ` separator
      rather than the bare word (the file's own conventions section says
      "unreleased"), and keep it **case-insensitive and bracket-tolerant**: at the
      v1.19.9 cut two rows had been written `· [Unreleased]`, which the previous
      case-sensitive pattern did not match. A checklist step that silently matches
      nothing is the class `sota-code-security` rules/11 §2.2 is about
- [ ] If the skill count changed: README badge/hero, router body +
      description, plugin/marketplace.json show the recounted numbers
      (the social-preview pill + README alt are "N+" floors — touch them
      only when deliberately raising the floor, which also means
      re-rendering the PNG)
- [ ] New skills appear in the README table, the router's routing table
      (`skills/sota/SKILL.md`) and the library map (`skills/sota/rules/04-library-map.md`
      — offloaded out of the router 2026-09-02; invariant 7 reads both files)
- [ ] **Front-door grep done (§2b)** — every capability this release added has a
      mention in README/`docs/INDEX.md`, and anything unbacked by a measured number
      says so. Then record it: **invariant 14 fails the build** unless the new
      CHANGELOG section carries `**Front door checked:** term · term` and every term
      resolves
- [ ] **Routing regression run (§2c)** — only if this release adds a skill or edits any
      `description`. **Invariant 29 fails the build** unless the new CHANGELOG section
      carries `**Routing checked:** <artifact>` and that artifact exists and mentions
      `desc-routing-regressions`
- [ ] GitHub Settings social-preview re-upload — only if the PNG changed
